set -x
echo "Setting ENV variables..."

export DATABRICKS_HOST=$(databricks_host)
export DATABRICKS_TOKEN=$(adb-token-dbfs)

artifact_path=$(System.DefaultWorkingDirectory)/$(artifact_path)/$(targetJarName)
tgt_path=$(tgt_path)/$(targetJarName)

dbfs cp --overwrite $artifact_path $tgt_path

echo "Upload done.."