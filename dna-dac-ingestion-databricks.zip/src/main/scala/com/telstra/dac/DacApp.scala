package com.telstra.dac

//import com.microsoft.pnp.logging.Log4jConfiguration
//import com.microsoft.pnp.util.TryWith
import com.telstra.dac.service.AzureKeyVaultService
import com.telstra.dac.utils.{AKVSecrets, ArgumentsParser, EnvironmentConfiguration}
import org.apache.spark.internal.Logging

trait DacApp extends Logging with App {


    //initiate LogAnalytics
    /*TryWith(getClass.getResourceAsStream("/properties/log4j.properties")) {
      stream => {
        Log4jConfiguration.configure(stream)
      }
    }*/
    logInfo("initialised logging to logAnalytics")

   // read command line arguments.
    lazy val arguments: EnvironmentConfiguration = {
        require(args.length == 1, "No arguments  specified")
        val argumentString= args(0)
      println(args(0))

        ArgumentsParser.parse(argumentString)
    }
  logInfo("Fetching secrets from AKV ")

  lazy val akvSecrets: AKVSecrets = AzureKeyVaultService.getAppKeyVltSecretCaseObj(arguments.dataBricksKVScope,arguments.environmentName)

}
