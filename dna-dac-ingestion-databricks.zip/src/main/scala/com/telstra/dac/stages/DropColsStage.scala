package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.stages.FilterDatesetStage.logInfo
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable

object DropColsStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {
    /*This stage is responsible for dropping any dropping */
    /**
     * This stage will drop or include onlya list of columns and save a resulting dataframe.
     * Input attributes:
     *  1. Name of dataframe which needs to be processed.   : DROP_COLUMNS_INPUT_DATASET
     *  2. List of columns to drop/include (pipe delimited)
     *  prepend with drop/include eg: include|id|name       : DROP_COLUMNS_COLUMN_NAMES
     *  3. Result dataframe name, if this attribute is
     *  skipped default name would be same as input 1 above
     *  , hence it will replace original dataframe.         : DROP_COLUMNS_RESULT_DATASET_NAME
     **/


    val dataSet = stageAttributesKeyMap(Constants.ATTR_DROP_COLUMNS_INPUT_DF)
    var dfToDropColumns = dataSet match {
      case "previousStage" => previousStageDF
      case _ => sharedDataFrames(dataSet)
    }

    val resultDatasetName = stageAttributesKeyMap(Constants.ATTR_DROP_COLUMNS_RESULT_DF)

    //Better to drop all at once
    val columnsToDrop = stageAttributesKeyMap(Constants.ATTR_DROP_COLUMNS_COLUMN_NAMES).split("\\|")
    val dropOrInclude = columnsToDrop(0)
    val columnNames = columnsToDrop.drop(1)

    var resultDataset = sparkSession.emptyDataFrame
    if (dropOrInclude == "drop"){
      resultDataset = dfToDropColumns.drop(columnNames:_*)
    }else if (dropOrInclude == "include") {
      resultDataset = dfToDropColumns.select(columnNames.map(col): _*)
    }else{
      logInfo("DROP_COLUMNS_COLUMN_NAMES must be prepended with include or drop, separated with |")
    }

    var dfMap = mutable.HashMap[String, DataFrame]()

    logInfo(f"${dropOrInclude} processed for ${columnNames.mkString(", ")} from ${dataSet}, saved as: $resultDatasetName")

    dfMap += (resultDatasetName -> resultDataset)
    (resultDataset, sharedDataFrames ++ dfMap)

  }

}
