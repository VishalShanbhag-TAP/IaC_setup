package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable

object LoadDatasets extends AbstractStage{

  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap:Map[String,String],previousStageDF:DataFrame,sharedDataFrames:mutable.HashMap[String, DataFrame]):(DataFrame,  mutable.HashMap[String, DataFrame]) ={
  logInfo(s"loading load ready set")
  var dfMap = mutable.HashMap[String,DataFrame]()

    val fileFormat = stageAttributesKeyMap(Constants.ATTR_INPUT_FORMAT)

  for ((k, v) <- stageAttributesKeyMap) {
   if (k.startsWith("INPUT_DATASET_")) {
     logInfo(v)

     val df1 = sparkSession.read.format(fileFormat).load("/mnt/" + v)
     // df1.createOrReplaceTempView(k)
     dfMap += k -> df1;
     logInfo(s"Created dataframe for input set ${k} which has path ${v}")
    }
   }
   /*stageAttributesKeyMap.map({
     x=> if(x._1.startsWith("INPUT_DATASET_") && x._2==()
   })*/
  logInfo(s"Dataframe interimDF completed for stage ")
  (sparkSession.emptyDataFrame,dfMap)

 }
}
