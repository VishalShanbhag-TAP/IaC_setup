package com.telstra.dac.stages

import java.security.cert.CRL

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.stages.IntegrationEngine.logInfo
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.apache.spark.sql

import scala.collection.mutable
import com.telstra.dac.DacApp
import org.apache.spark.deploy.history.LogInfo

object ExecuteSQL extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {

    /** essentially: We'll have 2 workflows one for CRL, and one for DQ.
        They will provide an attribute to the stage: ATTR_EXECUTE_SQL_PATH
        DQ will have arguments passed from the ADF pipeline: 1,2,3,4 etc. These are the DQ_IDs to execute (each is an sql file)
          "DQ_IDs":"@{pipeline().parameters.DQ_IDs}"
          DQ_IDs = 1,2,3,4
          DQ_IDs = 3
        CRL will have the CRL to execute: SFDC, CAIMAN, ETC.
          "CRL_Name":"@{pipeline().parameters.CRL_Name}
          CRL_Name = CAIMAN_CRL
          CRL_Name = SFDC_CRL

    arguments.workflowName
     **/

   /* if(arguments.workflowName == "CRL_EXECUTION"){
      if(arguments.CRL_Name.getOrElse(null) != null ) {
        logInfo("executing CRL : " + arguments.CRL_Name)
        val dirPath = stageAttributesKeyMap(Constants.ATTR_EXECUTE_SQL_PATH)
        val fileContent = dbutils.fs.head("/mnt/" + dirPath + "/" + arguments.CRL_Name.getOrElse(null) + ".sql")
        val queryArray = fileContent.split(";")

        for (query <- queryArray) {
          logInfo("executing CRL Query: " + query)
          sparkSession.sql(query)
        }
      }else {
        logInfo("CRL_Name not Available")
      }
    }else if(arguments.workflowName == "DQ_ID_EXEC"){
      if (arguments.DQ_IDs.getOrElse(null) != null) {
        val dirPath = stageAttributesKeyMap(Constants.ATTR_EXECUTE_SQL_PATH)
        val dq_id_lst = arguments.DQ_IDs.getOrElse(null).toString.split(",")

        for(id <- dq_id_lst){
          logInfo("started executing issue_id_"+id)
          val fileContent = dbutils.fs.head("/mnt/" + dirPath + "/issue_id_" + id + ".sql")
          val queryArray = fileContent.split(";")
          for(query <- queryArray){
            sparkSession.sql(query)
          }
          logInfo("completed executing issue_id_"+id)
        }
      } else {
        logInfo("DQ_IDs were not passed from datafactory")
      }
    }*/


    if(arguments.CRL_Name.getOrElse(null) != null ) {
      logInfo("executing CRL : " + arguments.CRL_Name)
      val dirPath = stageAttributesKeyMap(Constants.ATTR_EXECUTE_SQL_PATH)
      val fileContent = dbutils.fs.head("/mnt/" + dirPath + "/" + arguments.CRL_Name.getOrElse(null)+ ".sql")
      val queryArray = fileContent.split(";")

      for(query <- queryArray){
        logInfo("executing CRL Query: " + query)
        sparkSession.sql(query)
      }

    } else if (arguments.DQ_IDs.getOrElse(null) != null) {
      val dirPath = stageAttributesKeyMap(Constants.ATTR_EXECUTE_SQL_PATH)
      val dq_id_lst = arguments.DQ_IDs.getOrElse(null).toString.split(",")

      for(id <- dq_id_lst){
        logInfo("started executing issue_id_"+id)
        val fileContent = dbutils.fs.head("/mnt/" + dirPath + "/issue_id_" + id + ".sql")
        val queryArray = fileContent.split(";")
        for(query <- queryArray){
          sparkSession.sql(query)
        }
        logInfo("completed executing issue_id_"+id)
      }
    } else {
      logInfo("neither CRL_Name nor DQ_IDs were not passed from datafactory")
    }

    (previousStageDF, sharedDataFrames)
  }
}
