package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import scala.collection.mutable

object PersistResultSetADLS extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {
    /* This stage is designed to write dataframes to adls for permanent storage
        *  for a specified dataset - attr = caiman
        *     It is required that the dataframe is already in sharedDataframesMap under the same name
        *  for the previous dataset - attr = previousStage
        *     The dataset needs to be saved as interimDF
        */
    //val permanence = stageAttributesKeyMap(Constants.ATTR_PERSIST_PERMANENCE)

    // "caiman"
    // "previousStage"
    val dataSet: String = stageAttributesKeyMap(Constants.ATTR_PERSIST_INPUT_DF)
    val dfToPersist = dataSet match {
      case "previousStage" => previousStageDF
      case _ => sharedDataFrames(dataSet)
    }

    // "/persist/
    val persistDirectory = "/mnt/" + stageAttributesKeyMap(Constants.ATTR_PERSIST_DIRECTORY)

    // "parquet"
    val persistFormat = stageAttributesKeyMap(Constants.ATTR_PERSIST_FORMAT)

    // "Overwrite"
    val persistModeString = stageAttributesKeyMap(Constants.ATTR_PERSIST_MODE)
    val persistMode = persistModeString match {
      case "Overwrite" => SaveMode.Overwrite
      case "Append" => SaveMode.Append
      case "ErrorIfExists" => SaveMode.ErrorIfExists
    }

    val partitionColumn = stageAttributesKeyMap(Constants.ATTR_PERSIST_PARTITION_ON_COL)

    logInfo(f"Persisting result: ${dataSet}")
    //write dataframe
    partitionColumn match {
      case "none" => dfToPersist.write.format(persistFormat).mode(persistMode).save(persistDirectory)
      case _ => dfToPersist.write.format(persistFormat).mode(persistMode).partitionBy(partitionColumn).save(persistDirectory)
    }

    logInfo(s"Dataframe ${dataSet} saved to ${persistDirectory} for stage")
    (dfToPersist,sharedDataFrames)
    
  }
}
