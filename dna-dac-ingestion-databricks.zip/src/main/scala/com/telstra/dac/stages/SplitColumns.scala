package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.stages.FilterDatesetStage.logInfo
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.functions.{col, lit, udf}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable

object SplitColumns extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {


    /**
     * This stage will split a column into multiple columns in a dataframe.
     * Input attributes:
     *  1. Name of dataframe which need to be processed.    : INPUT_DATAFRAME
     *  2. Input column name which need to be processed.    : FIELD_NAME
     *  3. Delimiter - implementing with single delimiter.  : DELIMITER
     *  4. Maximum splitled columns                         : MAXIMUM_SPLIT_COUNT
     *  5. prefix of generated column this will be appended by "_{n}" example : if prefix is allsiebalcontactid then column names would be allsiebalcontactid_1, allsiebalcontactid_2, allsiebalcontactid_3 etc.
     * : PREFIX_NAME
     *  6. Result dataframe name, if this attribute is skipped default name would be same as input 1 above, hence it will replace original dataframe.
     * : RESULT_DF
     *
     **/

    val INPUT_DATAFRAME = stageAttributesKeyMap(Constants.ATTR_SPLIT_COLUMNS_INPUT_DATAFRAME)
    val FIELD_NAME = stageAttributesKeyMap(Constants.ATTR_SPLIT_COLUMNS_FIELD_NAME)
    val DELIMITER: String = stageAttributesKeyMap(Constants.ATTR_SPLIT_COLUMNS_DELIMITER)
    val MAXIMUM_SPLIT_COUNT = Integer.parseInt(stageAttributesKeyMap(Constants.ATTR_SPLIT_COLUMNS_MAXIMUM_SPLIT_COUNT))
    val PREFIX_NAME = stageAttributesKeyMap(Constants.ATTR_SPLIT_COLUMNS_PREFIX_NAME)

    var RESULT_DF: String = null
    if (stageAttributesKeyMap.contains(Constants.SPLIT_COLUMNS_RESULT_DF)) {
      RESULT_DF = stageAttributesKeyMap(Constants.SPLIT_COLUMNS_RESULT_DF)
    }


    var dataFrameToSplit = sharedDataFrames(INPUT_DATAFRAME)
    /*Define UDF*/

    val getColumn = udf((inputStr: String, columnNum: Int) => {
      var retStr: String = null
      try {
        retStr = inputStr.split(DELIMITER)(columnNum)
      } catch {
        case ex: Exception => {
          retStr = null
        }
      }
      retStr
    })


    sparkSession.udf.register("getcolumn", getColumn)
    for (i <- 0 to MAXIMUM_SPLIT_COUNT - 1) {
      dataFrameToSplit = dataFrameToSplit.withColumn(PREFIX_NAME + i, getColumn(col(FIELD_NAME),lit(i)))
    }

    var dfMap = mutable.HashMap[String, DataFrame]()

    if (RESULT_DF == null) {
      dfMap += (INPUT_DATAFRAME -> dataFrameToSplit);
    } else {
      dfMap += (RESULT_DF -> dataFrameToSplit);
    }

    logInfo(f"split ${INPUT_DATAFRAME} column ${FIELD_NAME}")

    (dataFrameToSplit, sharedDataFrames ++ dfMap)

  }

}
