package com.telstra.dac.stages


import org.apache.spark.sql.functions.lit
import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.stages.FilterDatesetStage.logInfo
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{DataFrame, SparkSession}



import scala.collection.mutable

object DeDupeStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {

    val colLst = stageAttributesKeyMap(Constants.ATTR_DEDUPE_COLUMN_LIST)
    val isPartitiond = stageAttributesKeyMap(Constants.ATTR_DEDUPE_TABLE_PARTITIONED)
    val partiCol = stageAttributesKeyMap(Constants.ATTR_DEDUPE_PARTITION_COLUMN)
    val ordrByCol = stageAttributesKeyMap(Constants.ATTR_DEDUPE_ORDERBY_COLUMN)
    val resultDfName = stageAttributesKeyMap(Constants.ATTR_DEDUPE_RESULT_DF)

    logInfo("Loaded attributes COLUMN_LIST=%s , IS_PARTITIONED=%s , PARTITION_COLUMN=%s , ORDERBY_COLUMN =%s".format(colLst, isPartitiond, partiCol, ordrByCol))

    val dataSet = stageAttributesKeyMap(Constants.ATTR_DEDUPE_INPUT_DF)
    var df1 = dataSet match {
      case "previousStage" => previousStageDF
      case _ => sharedDataFrames(dataSet)
    }

    df1 = removeDuplicate(sparkSession, df1, "workflowname+runid", colLst, ordrByCol)
    //that string was ingestionDriver.workflowName+"runId"

    logInfo("Completed deduplication process")

    var dfMap = mutable.HashMap[String, DataFrame]()
    dfMap += (resultDfName -> df1)
    (df1, sharedDataFrames ++ dfMap)

  }

  def removeDuplicate(sparkSession: SparkSession, df_orig : DataFrame, tableName: String, COLUMN_LIST: String, ORDERBY_COLUMN: String): DataFrame = {
    logInfo("Starting deduplication dataframe filtering")

    df_orig.createOrReplaceTempView(tableName)

    // get active records with ranking
    val sqlDF_A = sparkSession.sql("SELECT *,row_number() OVER (PARTITION BY " + COLUMN_LIST + " ORDER BY "  +ORDERBY_COLUMN + ") as RNK FROM " + tableName + " where active = 'Y'")
    val sqlDF_IA = sparkSession.sql("SELECT *  FROM " + tableName + " where active = 'N'")

    logInfo("Created filtered and sorted dataframes for deduplication")

    // filter out active and inactive records
    val df_active = sqlDF_A.filter(sqlDF_A("RNK") === "1").drop("RNK","active").withColumn("active",lit("Y"))

    //val df_rejected = sqlDF_A.except(df_active).drop("RNK","active").withColumn("active",lit("N"))
    //val df_rejected = sqlDF_A.except(df_active).drop("RNK","active").withColumn("active",lit("N"))
    val df_rejected = sqlDF_A.filter(sqlDF_A("RNK") =!= "1").drop("RNK","active").withColumn("active",lit("N"))


    logInfo("Created final active & inactive dataframes for deduplication")

    //Added to reduce memory spend on long processes
    sparkSession.catalog.dropTempView(tableName)

    // match the column name in data frame before joining
    if(df_active.schema.fields.map(_.name).corresponds(df_rejected.schema.fields.map(_.name)){_ == _} && df_active.schema.fields.map(_.name).corresponds(sqlDF_IA.schema.fields.map(_.name)){_ == _}){
      df_active.union(df_rejected).union(sqlDF_IA)
    }else{
      throw new Exception("Data Frame Column Mismatch in Dedupe Stage")
    }
  }
}