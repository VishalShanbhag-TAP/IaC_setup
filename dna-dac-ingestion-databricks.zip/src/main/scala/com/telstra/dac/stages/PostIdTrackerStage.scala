package com.telstra.dac.stages

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.apps.IngestionDriver.{connString, logInfo, workFlowSchema}
import com.telstra.dac.service.AzureSQLDBService
import com.telstra.dac.utils._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable

object PostIdTrackerStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {

    var dq_id_lst = scala.collection.mutable.Map[String, String]()

    val pitConfig=PostIdentificationTrackerParser.parse(AzureSQLDBService.generateJson(Constants.QUERY_FETCH_PIT_CONFIG.replaceFirst("\\?",s"'${arguments.jobName}'"),connString))

    // calculate the eligible dq issue id's
    pitConfig.foreach { x =>
      if(calculateEligDqId(x.next_run_date.toString)){
        dq_id_lst += (x.dq_id.toString -> calculateNextRunDate( x.frequency.toString))
      }
    }
    logInfo("Eligible DQ ID's  : %s".format(dq_id_lst.keySet.mkString(",")))

   if(!dq_id_lst.isEmpty){

     // load the narrow instance current data
     val df1 = sparkSession.sqlContext.read.parquet(stageAttributesKeyMap(Constants.ATTR_INSTANCE_NARROW_CURRENT))
     df1.createOrReplaceTempView("fact_issue_curr")

     // prepare the final query
     val dq_ids = dq_id_lst.keySet.mkString("'", "','", "'")
     val query = "Select * from fact_issue_curr where issue_id in (" +dq_ids+ ")"
     logInfo("Final query for DQ ID filter  : %s".format(query))

     // execute the final query
     val df2 = sparkSession.sql(query)

     // update the result set in  narrow instance history+current
     df2.write.format("parquet").mode("Append").partitionBy("issue_id","created_dt").save(stageAttributesKeyMap(Constants.ATTR_PIT_INSTANCE_NARROW))
     logInfo("Narrow Instance Data Persisted")

     // persist data to for SqlDW
     df2.write.format("parquet").mode("Overwrite").save(stageAttributesKeyMap(Constants.ATTR_SQLDW_INSTANCE_NARROW))
     logInfo("Data Persisted for SQlDW instance")

     // update the last run date for dq issue id's executed today
     logInfo("Updating last run date and next run date in metadata table for executed dq id's")
     dq_id_lst.foreach { x =>
       var updateQuery = "update pit_tracker_cfg set last_run_date=CONVERT(varchar, getdate(), 23), next_run_date = '"+x._2+"' where dq_id = '" +x._1+ "'"
       AzureSQLDBService.withStatement(x=>x.execute(updateQuery),connString)
     }
   }else{
     logInfo("No Eligible DQ ID's available")
     System.exit(0)
   }

    (previousStageDF, sharedDataFrames)

  }

  /*
    This method is used to compare next run date with today's date
   */
  def calculateEligDqId(next_run_dt: String): Boolean = {

    val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
    val currentDate = format.parse(java.time.LocalDate.now.toString)
    val last_run_date = format.parse(next_run_dt)

    if((last_run_date.compareTo(currentDate)) <= 0)
      return true
    else
      return false
  }

  /*
    This method is used to calculate next run date for eligible dq id based on their frequency
   */

  def calculateNextRunDate(frequency: String): String = {

    if("daily".equalsIgnoreCase(frequency))
      //return format.parse(java.time.LocalDate.now().plusDays(1).toString).toString
      return java.time.LocalDate.now().plusDays(1).toString
    else if("weekly".equalsIgnoreCase(frequency))
      return java.time.LocalDate.now().plusWeeks(1).toString
    else if("fortnightly".equalsIgnoreCase(frequency))
      return java.time.LocalDate.now().plusWeeks(2).toString
    else if("monthly".equalsIgnoreCase(frequency))
      return java.time.LocalDate.now().plusMonths(1).toString

    return java.time.LocalDate.now().toString
  }
}
//java.time.LocalDate.now.toString
