package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable

object IntegrationEngine extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {

    def prefix(myCols: Array[String], prefix: String) = {
      myCols.toList.map(x => col(x).as(prefix+x)
      )
    }

    def addUnionColumns(myCols: Array[String], allCols: Array[String]) = {
      allCols.toList.map(x => x match {
        case x if myCols.contains(x) => col(x).as(x)
        case _ => lit(null).as(x)
      })
    }

    val dataSets = stageAttributesKeyMap(Constants.ATTR_INTEGRATION_INPUT_DFS).split("\\|")
    val allKeys = stageAttributesKeyMap(Constants.ATTR_INTEGRATION_KEYS).split(" or ").map(x => x.split("\\|"))
    val keys = allKeys(0)
    val resultTableName = stageAttributesKeyMap(Constants.ATTR_INTEGRATION_RESULT_DF)
    val joinType = stageAttributesKeyMap(Constants.ATTR_INTEGRATION_JOIN_TYPE)
    val prefixValues = stageAttributesKeyMap(Constants.ATTR_INTEGRATION_PREFIX_VALUES) match {
      case "none" => Array("", "")
      case "Null" => Array("", "")
      case _ => stageAttributesKeyMap(Constants.ATTR_INTEGRATION_PREFIX_VALUES).split("\\|", -1)
    }

    val df1 = sharedDataFrames(dataSets(0))
    val df2 = sharedDataFrames(dataSets(1))

    val cols1 = df1.columns
    val cols2 = df2.columns
    val total = cols1 ++ cols2

    //We implemented a clause to improve performance in full outer joins. Especially Caiman / SFDc. But it only works if there's just one key. Rather than processing all of the null values through the join, we separate them and append them after.
    // We have an old version of this which ran by automatically generating an SQL query to perform the join, but it was found to have issues. Feel free to pick that up again.

    val resultDf = if (allKeys.length == 1 && joinType == "fullouter") {
      val df1NotNull = df1.filter(f"${keys(0)} is not null").select(prefix(cols1, prefixValues(0)):_*)
      val df2NotNull = df2.filter(f"${keys(1)} is not null").select(prefix(cols2, prefixValues(1)):_*)

      val df1Null = df1.filter(f"${keys(0)} is null").select(prefix(cols1, prefixValues(0)):_*)
      val df2Null = df2.filter(f"${keys(1)} is null").select(prefix(cols2, prefixValues(1)):_*)

      val prefixedCols1 = df1NotNull.columns
      val prefixedCols2 = df2NotNull.columns
      val prefixedTotal = prefixedCols1 ++ prefixedCols2

      val notNullsJoined = df1NotNull.join(df2NotNull, df1NotNull(prefixValues(0)+(keys(0))) === df2NotNull(prefixValues(1)+keys(1)), joinType)
      notNullsJoined.union(df1Null.select(addUnionColumns(prefixedCols1, prefixedTotal):_*)).union(df2Null.select(addUnionColumns(prefixedCols2, prefixedTotal):_*))

    } else {
      val df1Left = df1.select(prefix(cols1, prefixValues(0)): _*)
      val df2Right = df2.select(prefix(cols2, prefixValues(1)): _*)

      val prefixedCols1 = df1Left.columns
      val prefixedCols2 = df2Right.columns
      val prefixedTotal = prefixedCols1 ++ prefixedCols2

      val resultDf = if (allKeys.length == 1) {
        df1Left.join(df2Right, df1Left(prefixValues(0) + (keys(0))) === df2Right(prefixValues(1) + keys(1)), joinType)
      } else if (allKeys.length == 2) {
        logInfo(f"joining ${dataSets(0)} with ${dataSets(1)} with 2 keys")
        val keys2 = allKeys(1)

        df1Left.join(df2Right, df1Left(prefixValues(0) + (keys(0))) === df2Right(prefixValues(1) + keys(1)) ||
          df1Left(prefixValues(0) + (keys2(0))) === df2Right(prefixValues(1) + keys2(1)),
          joinType
        )
      } else if (allKeys.length == 3){
        logInfo(f"joining ${dataSets(0)} with ${dataSets(1)} with 3 keys")
        val keys2 = allKeys(1)
        val keys3 = allKeys(2)

        df1Left.join(df2Right, df1Left(prefixValues(0) + (keys(0))) === df2Right(prefixValues(1) + keys(1))
          || df1Left(prefixValues(0) + (keys2(0))) === df2Right(prefixValues(1) + keys2(1))
          || df1Left(prefixValues(0) + (keys3(0))) === df2Right(prefixValues(1) + keys3(1))
          , joinType
        )
      } else {
        logInfo("framework can only handle up to 3 join keys at once, will just return left dataframe")
        df1Left
      }

      resultDf
      }

    var dfMap = mutable.HashMap[String, DataFrame]()

    dfMap += (resultTableName -> resultDf)

    logInfo(f"joined ${dataSets(0)} and ${dataSets(1)} as: $resultTableName and saved to shared data frames")
    (resultDf, sharedDataFrames ++ dfMap)

  }

}
