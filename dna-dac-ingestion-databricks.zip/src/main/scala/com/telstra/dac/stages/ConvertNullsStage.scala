
package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.stages.IntegrationEngine.logInfo
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable

object ConvertNullsStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {
    /** This stage is designed to replace improperly imported null values with true nulls
     *  It requires the dataset to be loaded under the same names as given in ATTR_CONVERTNULLS_INPUT_DF
     *  An issue arises when joining tables with large numbers of Nulls which aren't read properly
     *  which leads to OOM issues when all of these null values are attempted to be joined
     *
     * ATTR_CONVERTNULLS_INPUT_DF
     * ATTR_CONVERTNULLS_COLUMNNAMES
     * ATTR_CONVERTNULLS_RESULT_DF
     **/
    val resultDfName = stageAttributesKeyMap(Constants.ATTR_CONVERTNULLS_INPUT_DF)

    val dataSet = stageAttributesKeyMap(Constants.ATTR_CONVERTNULLS_INPUT_DF)
    var dfInput = dataSet match {
      case "previousStage" => previousStageDF
      case _ => sharedDataFrames(dataSet)
    }

    var columnsToAlter = stageAttributesKeyMap(Constants.ATTR_CONVERTNULLS_COLUMN_NAMES).split("\\|")

    if(columnsToAlter(0) == "all"){
      columnsToAlter = dfInput.columns
    }

    val valuesToBeMadeNull = stageAttributesKeyMap(Constants.ATTR_CONVERTNULLS_INPUT_VALUES)

    var dfResult = dfInput
    for (column <- columnsToAlter){
      dfResult = dfResult.withColumn(column, when(col(column) === valuesToBeMadeNull, lit(null)).otherwise(col(column)))
    }

    var dfMap = mutable.HashMap[String, DataFrame]()

    //interimDF = joinedDf
    dfMap += (resultDfName -> dfResult)
    logInfo(f"filters completed on ${dataSet} saved as: $resultDfName into shared data frames")
    (dfResult, sharedDataFrames ++ dfMap)

  }

}
