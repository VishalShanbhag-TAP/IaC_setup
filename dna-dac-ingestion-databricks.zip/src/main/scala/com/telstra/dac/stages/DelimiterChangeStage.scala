package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.stages.DropColsStage.logInfo
import com.telstra.dac.stages.IntegrationEngine.logInfo
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable

object DelimiterChangeStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {

    val dataSet = stageAttributesKeyMap(Constants.ATTR_DELIMITER_CHANGE_INPUT_DF)
    var dfToChange = dataSet match {
      case "previousStage" => previousStageDF
      case _ => sharedDataFrames(dataSet)
    }

    val columnName = stageAttributesKeyMap(Constants.ATTR_DELIMITER_CHANGE_COLUMN_NAME)
    val sourceDelimiter = stageAttributesKeyMap(Constants.ATTR_DELIMITER_CHANGE_INPUT_DELIMETER)
    val targetDelimiter = stageAttributesKeyMap(Constants.ATTR_DELIMITER_CHANGE_TARGET_DELIMETER)
    val resultDatasetName = stageAttributesKeyMap(Constants.ATTR_DELIMITER_CHANGE_RESULT_DF)

    logInfo(s"Updating column delimiter for ${columnName} with value ${targetDelimiter}")
    dfToChange = dfToChange.withColumn(columnName, regexp_replace(dfToChange(columnName), sourceDelimiter, targetDelimiter))
    logInfo(s"Updating column delimiter for ${columnName} completed")



    var dfMap = mutable.HashMap[String, DataFrame]()

    //interimDF = joinedDf
    logInfo(s"Updating column delimiter for ${columnName} completed")

    dfMap += (resultDatasetName -> dfToChange)
    (dfToChange, sharedDataFrames ++ dfMap)

  }
}
