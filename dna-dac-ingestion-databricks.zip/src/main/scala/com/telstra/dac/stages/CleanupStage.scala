package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.io.File

import com.telstra.dac.stages.DelimiterChangeStage.logInfo

//import com.telstra.generic.manager.driver.IngestionDriver
//import com.telstra.generic.manager.audit.controller.AuditController
import org.apache.spark.sql.DataFrame
import org.slf4j.LoggerFactory


import com.databricks.dbutils_v1.DBUtilsHolder.dbutils


import scala.collection.mutable

object CleanupStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {
    //interimDF = previousStage.getResultDF()
    //var auditBean: AuditController= new AuditController(100100,"CleanupStage","1001","Running")
    //auditBean.insertAudit(previousStage)
    var cleanupLoc = "/mnt/" + stageAttributesKeyMap(Constants.ATTR_PERSIST_DIRECTORY)
    // val cleanupLoc = attributeValueMap(Constants.ATTR_CLEANUP_BASE_DIR).attributeValue + runId

    cleanupLoc = "/mnt/data_an/"
    fileCleanup(cleanupLoc)

    /*
    val listofFiles = new File(cleanupLoc)
    var matchedFiles = listofFiles.listFiles.filter(_.isFile).toList
    //matchedFiles = matchedFiles.filter(_.getName.matches(attributeValueMap(Constants.ATTR_FILE_PATTERN).attributeValue))
    for (file <- matchedFiles) {
      logger.info("File found " + file.getAbsolutePath)
      file.setWritable(true)
      file.delete()
      logger.info("File Deleted " + file.getAbsolutePath)
    }
  }*/

    def fileCleanup(path: String): Unit = {
      //val filelist: List[String] = dbutils.fs.ls(path).map(_.path).toList
      val filelist:List[String] = dbutils.fs.ls(path).map(_.path).toList
      for (matchedFiles <- filelist) {
        logInfo("File found " + matchedFiles)
        dbutils.fs.rm(matchedFiles, true)
        logInfo("File Deleted " + matchedFiles)
      }
      //var auditBean: AuditController= new AuditController(100100,"CleanupStage","1001","Completed")
      //auditBean.insertAudit(previousStage)very small amount
    }
    (sparkSession.emptyDataFrame, sharedDataFrames)
  }
}
