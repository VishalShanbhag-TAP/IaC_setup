package com.telstra.dac.stages

import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.stages.IntegrationEngine.logInfo
import com.telstra.dac.utils.{Constants, EnvironmentConfiguration}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable

object FilterDatesetStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {
    /** This stage is designed to filter a dataset
    *  It requires the dataset to be loaded under the same names as given in ATTR_FILTER_INPUT_DATASET
    *  This logic was decided on as it allows for filtering on multiple custom conditions sequentially
    *
    * ATTR_FILTER_INPUT_DF
    * ATTR_FILTER_CONDITION_1
    * ATTR_FILTER_CONDITION_2 ETC.
    * ATTR_FILTER_RESULT_DF
     **/
    val resultDfName = stageAttributesKeyMap(Constants.ATTR_FILTER_RESULT_DF)

    val dataSet = stageAttributesKeyMap(Constants.ATTR_FILTER_INPUT_DF)
    var dfToFilter = dataSet match {
      case "previousStage" => previousStageDF
      case _ => sharedDataFrames(dataSet)
    }

    for ((k, v) <- stageAttributesKeyMap) {
      if (k.startsWith("FILTER_CONDITION_")) {
        dfToFilter = dfToFilter.filter(v)
        logInfo(s"filtered $dataSet on condition ${v} ")
      }
    }

    var dfMap = mutable.HashMap[String, DataFrame]()

    //interimDF = joinedDf
    dfMap += (resultDfName -> dfToFilter)
    logInfo(f"filters completed on ${dataSet} saved as: $resultDfName into shared data frames")
    (dfToFilter, sharedDataFrames ++ dfMap)

  }

}
