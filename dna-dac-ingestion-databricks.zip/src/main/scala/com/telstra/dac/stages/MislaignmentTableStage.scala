package com.telstra.dac.stages

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.dac.apps.AbstractStage
import com.telstra.dac.apps.IngestionDriver.{connString, logInfo, workFlowSchema}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.telstra.dac.utils._
import com.telstra.dac.service.AzureSQLDBService
import scala.collection.mutable

object MislaignmentTableStage extends AbstractStage {
  def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap: Map[String, String], previousStageDF: DataFrame, sharedDataFrames: mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) = {


    val inputPath = stageAttributesKeyMap(Constants.ATTR_DQ_DATA_TEMP_PATH)
    val setWideOutputPath = stageAttributesKeyMap(Constants.ATTR_DATA_SET_WIDE_OUTPUT)
    val insNarrowOutputPath = stageAttributesKeyMap(Constants.ATTR_INSTANCE_NARROW_OUTPUT)

    logInfo("Loaded attributes DQ_DATA_TEMP_PATH=%s , DATA_SET_WIDE_OUTPUT=%s , INSTANCE_NARROW_OUTPUT=%s".format(inputPath, setWideOutputPath, insNarrowOutputPath))

    val dqIdConfig = ExecuteIssueDetectorParser.parse(AzureSQLDBService.generateJson(Constants.QUERY_FETCH_PARENT_CONFIG,connString))

    dqIdConfig.foreach { x =>
      try{
        logInfo("Started Moving data for Misalignment Table for Parent :: "+x.parent_name.toString)

        val df1 = sparkSession.sqlContext.read.parquet(inputPath + x.parent_name.toString)
        df1.write.format("parquet").mode("overwrite").save(setWideOutputPath + x.parent_name.toString)

        logInfo("Completed Moving data for Misalignment Table for Parent :: "+x.parent_name.toString)

        dbutils.fs.rm(inputPath + x.parent_name.toString, true)

        logInfo("Removed Temp data for Parent :: "+x.parent_name.toString)

      }catch {
        case unknown: Exception => {
          logInfo("Moving data for Misalignment Table failed for parent name :: "+x.parent_name.toString+" with message : "+unknown.getMessage)
          None
        }
      }

    }

    (previousStageDF, sharedDataFrames)

  }
}