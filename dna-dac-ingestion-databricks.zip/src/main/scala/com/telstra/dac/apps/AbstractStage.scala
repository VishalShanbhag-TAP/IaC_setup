package com.telstra.dac.apps
import com.telstra.dac.service.AzureSQLDBService
import com.telstra.dac.utils.{EnvironmentConfiguration, WorkflowConfiguration, WorkflowStages}
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.SparkContext
import org.apache.spark.internal.Logging
import org.apache.spark.sql.{DataFrame, SQLContext, SparkSession}

import scala.collection.mutable
import scala.util.{Failure, Success}

trait AbstractStage extends Logging   {




  def apply(sparkSession: SparkSession,
            environmentName: EnvironmentConfiguration,
            workflowConfiguration: WorkflowConfiguration,
            workflowStages: WorkflowStages,
            stageAttributesKeyMap:Map[String,String],idSeq:String,conString:String,previousStageDF:DataFrame,sharedDataFrames:mutable.HashMap[String, DataFrame]): (DataFrame, mutable.HashMap[String, DataFrame]) ={
    logInfo("Processing started for" + workflowStages.stage_id)
  //  println(s"INSERT INTO audit_tbl(audit_id, workflow_id, stage_id, job_name, run_id, start_time, end_time, status) VALUES(${idSeq},${workflowStages.workflow_id},${workflowStages.stage_id},'${environmentName.jobName}','${environmentName.runId}',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'RUNNING')")
   // val sql= s"INSERT INTO audit_tbl(audit_id, workflow_id, stage_id, job_name, run_id, start_time, end_time, status) VALUES(${idSeq},${workflowStages.workflow_id},${workflowStages.stage_id},'${environmentName.jobName}','${environmentName.runId}',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'RUNNING')"
   // println(sql)

   // AzureSQLDBService.withStatement(x=>x.execute(sql),conString)

    val stageResult = process(sparkSession, environmentName, stageAttributesKeyMap,previousStageDF,sharedDataFrames)


  //  performFinalAction(stageAttributesKeyMap)

  //  AzureSQLDBService.withStatement(x=>x.execute(s"UPDATE audit_tbl SET end_time=CURRENT_TIMESTAMP, status='success' where audit_id=${idSeq} and stage_id=${workflowStages.stage_id}"),conString)
    stageResult
  }

  /*final def performFinalAction(): Unit = {
    //Check for re partition
    logger.info(s"Applying Final Stage actions for stage ${stageName}")
    if (performOptimisation()) {
      if (attributeValueMap(Constants.ATTR_PARTITION_DF).attributeValue.equalsIgnoreCase(Constants.YES)) {
        logger.info(s"Final Stage actions repartition for stage ${stageName}")
        val suggestedRecordsPerPar = Integer.parseInt(attributeValueMap(Constants.ATTR_SUGGESTED_RECORDS_PER_PARTITION).attributeValue)
        /*  recordCount = interimDF.count() */
        val noOfPar = getNumPartitions(suggestedRecordsPerPar)
        logger.info(s"Final Stage actions repartition for stage ${stageName} with partition ${noOfPar}")
        //TODO
        //resultDF = interimDF.repartition(noOfPar)
      } else { // no need to partition
        logger.info(s"Final Stage actions repartition for stage not required ${stageName}")
        resultDF = interimDF
      }
      //Check for caching and action
      if (attributeValueMap(Constants.ATTR_CACHE_DF).attributeValue.equalsIgnoreCase(Constants.YES)) {
        logger.info(s"Final Stage actions caching for stage ${stageName}")
        resultDF.cache()
      }
      if (attributeValueMap(Constants.ATTR_TRIGGER_COUNT_ACTION).attributeValue.equalsIgnoreCase(Constants.YES)) {
        logger.info(s"Final Stage actions count for stage ${stageName}")
        recordCount = resultDF.count()
        resultDF.show(20)
      }
      logger.info(s"Final Stage actions completed for stage ${stageName}")
    } else {
      logger.info("Found flag DF_OPTIMISATION_DISABLED, optimisation not required.")
      performFinalActionNoOpt()
    }
    // successStage
  }
*/

  protected def process(sparkSession: SparkSession, arguments:EnvironmentConfiguration, stageAttributesKeyMap:Map[String,String],previousStageDF:DataFrame,sharedDataFrames:mutable.HashMap[String, DataFrame]):(DataFrame, mutable.HashMap[String, DataFrame])




}
