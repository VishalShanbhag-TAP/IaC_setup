package com.telstra.dac.apps

import com.telstra.dac.apps.IngestionDriver.interimTuple
import com.telstra.dac.service.AzureSQLDBService
import com.telstra.dac.stages.{CleanupStage, DelimiterChangeStage, DropColsStage, ExecuteSQL, FilterDatesetStage, IntegrationEngine, LoadDatasets, PersistResultSetADLS, SplitColumns, ConvertNullsStage, DeDupeStage, ExecuteIssueDetectorStage, PostIdTrackerStage, DAC1DataProcessingStage, MislaignmentTableStage}
import com.telstra.dac.utils.{Constants, CustomException, SparkUtils, WorkflowJsonParser, WorkflowStageJsonParser, WorkflowStagesAttributesParser}
import org.apache.spark.sql.DataFrame

import scala.collection.mutable

object IngestionDriver extends SparkUtils  {

  val environmentName= arguments.environmentName
  val runId=arguments.runId
  lazy val connString: String = {
    s"jdbc:sqlserver://${akvSecrets.dac2SQLdbServer}:1433;database=${akvSecrets.dac2SQLdbDatabase};user=${akvSecrets.dac2JDBCUsername};password=${akvSecrets.dac2JDBCPassword};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30"

  }
  var previousStageDF:DataFrame= _
  var sharedDataFramesMap: mutable.HashMap[String, DataFrame]=_
  var interimTuple:(DataFrame,mutable.HashMap[String, DataFrame])=_

  val configs=mountConfigs

// checking if containers are mounted.

  mountContainer(akvSecrets.dac2ADLSContainer,akvSecrets.dac2ADLSAccount,"dac2",configs)
  mountContainer(akvSecrets.datacoreADLSContainer,akvSecrets.dac2ADLSAccount,"datacore",configs)


  println("initialing connection")

  val sparkSessionObj = getSparkSession()
  //val fsObj=getFileSystem() (May need to work on FS later if needed and pass on to different stages)

  logInfo("Starting ingestion with runid"+runId)


  val workFlowSchema=WorkflowJsonParser.parse(AzureSQLDBService.generateJson(Constants.QUERY_FETCH_WORKFLOW.replaceFirst("\\?",s"'${arguments.workflowName}'"),connString))
  if(workFlowSchema.length>1)
    {
      //log error may not be needed
      logError("Multiple templates found which is an illegal situation"+runId)
      throw CustomException("Multiple templates found which is an illegal situation")
    }
  logInfo("Loading Stages for workflow ")

  val stageSchema=WorkflowStageJsonParser.parse(AzureSQLDBService.generateJson(Constants.QUERY_FETCH_STAGES.replaceFirst("\\?",workFlowSchema(0).workflow_id.toString),connString))
  //Print all messages
  stageSchema.map(x=>logInfo("loaded  stage" + x.stage_name))

  val stageWithAttributesMap =stageSchema.map({
    x=>
      val att=WorkflowStagesAttributesParser.parse(AzureSQLDBService.generateJson((Constants.QUERY_FETCH_ATTRIBUTES.replaceFirst("\\?",x.stage_id.toString)),connString))
      (x,att.map(x=>(x.attribute_name,x.attribute_value)).toMap)
  } )

  val idSeq=AzureSQLDBService.generateSeq("SELECT NEXT VALUE FOR audit_seq",connString)


  stageWithAttributesMap.map{
    x=> {
      val sql= s"INSERT INTO audit_tbl(audit_id, workflow_id, stage_id, job_name, run_id, start_time, end_time, status) VALUES(${idSeq},${x._1.workflow_id},${x._1.stage_id},'${arguments.jobName}','${arguments.runId}',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'RUNNING')"
      println(sql)

      AzureSQLDBService.withStatement(x=>x.execute(sql),connString)

      x._1.stage_name match {

        case Constants.STAGE_LOAD_DATASETS => {
          logInfo("Created " + Constants.STAGE_LOAD_DATASETS)
          interimTuple=LoadDatasets( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_INTEGRATION_ENGINE => {
          logInfo("Created " + Constants.STAGE_INTEGRATION_ENGINE)
          interimTuple=IntegrationEngine( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_PERSIST_ADLS => {
          logInfo("Created " + Constants.STAGE_PERSIST_ADLS)
          interimTuple=PersistResultSetADLS( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)

        }
        case Constants.STAGE_DROP_COLUMNS => {
          logInfo("Created " + Constants.STAGE_DROP_COLUMNS)
          interimTuple = DropColsStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_DELIMITER_CHANGE => {
          logInfo("Created " + Constants.STAGE_DELIMITER_CHANGE)
          interimTuple = DelimiterChangeStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_CLEANUP => {
          logInfo("Created " + Constants.STAGE_CLEANUP)
          interimTuple = CleanupStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_FILTER => {
          logInfo("Created " + Constants.STAGE_FILTER)
          interimTuple = FilterDatesetStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_SPLIT_COLUMNS => {
          logInfo("Created " + Constants.STAGE_SPLIT_COLUMNS)
          interimTuple = SplitColumns( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_CONVERT_NULLS => {
          logInfo("Created " + Constants.STAGE_CONVERT_NULLS)
          interimTuple = ConvertNullsStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_DEDUPE => {
          logInfo("Created " + Constants.STAGE_DEDUPE)
          interimTuple = DeDupeStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_EXECUTE_SQL => {
          logInfo("Created " + Constants.STAGE_EXECUTE_SQL)
          interimTuple = ExecuteSQL( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_EXECUTE_ISSUE_DETECTOR => {
          logInfo("Created " + Constants.STAGE_EXECUTE_ISSUE_DETECTOR)
          interimTuple = ExecuteIssueDetectorStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_POST_IDENTIFICATION_TRACKER => {
          logInfo("Created " + Constants.STAGE_POST_IDENTIFICATION_TRACKER)
          interimTuple = PostIdTrackerStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_DAC1_DATA_PROCESSING => {
          logInfo("Created " + Constants.STAGE_DAC1_DATA_PROCESSING)
          interimTuple = DAC1DataProcessingStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
        case Constants.STAGE_MISALIGNMENT_TABLE => {
          logInfo("Created " + Constants.STAGE_MISALIGNMENT_TABLE)
          interimTuple = MislaignmentTableStage( sparkSessionObj,arguments,workFlowSchema(0),x._1,x._2,idSeq,connString,previousStageDF,sharedDataFramesMap)
        }
       case _ => {
          logError("Stage not found " + x._1.stage_name)
          //throw CustomException("Stage not found"+x._1.stage_name)
        }
      }
      logInfo("Assigning" + x._1.stage_name)
      previousStageDF=interimTuple._1
      sharedDataFramesMap = interimTuple._2
      var updatesql = s"UPDATE audit_tbl SET end_time=CURRENT_TIMESTAMP, status='success' where audit_id=${idSeq} and stage_id=${x._1.stage_id}"
      AzureSQLDBService.withStatement(x=>x.execute(updatesql),connString)

    }

  }

}
