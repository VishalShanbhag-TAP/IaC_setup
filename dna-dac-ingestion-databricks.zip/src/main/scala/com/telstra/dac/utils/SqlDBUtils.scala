package com.telstra.dac.utils

import java.sql.{Connection, DriverManager, ResultSet, Statement}

import com.telstra.dac.DacApp
import org.apache.spark.internal.Logging

import scala.util.Try

trait SqlDBUtils extends Logging  with DacApp {


  lazy val connString: String = {
     s"jdbc:sqlserver://${akvSecrets.dac2SQLdbServer}:1433;database=${akvSecrets.dac2SQLdbDatabase};user=${akvSecrets.dac2JDBCUsername};password=${akvSecrets.dac2JDBCPassword};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30"

  }

  def withConnection [T] ( f: Connection => T): Try[T] = {
    val conn: Connection = DriverManager.getConnection(connString)
    logInfo("Opening DB connection")
    val result: Try[T] = Try(f(conn))
    conn.close()
    result
  }

  def withStatement [T] (f: Statement => T): Try[T] = {
    def statementFun(conn: Connection): T = {
      val stmt: Statement = conn.createStatement()
      try {
        f(stmt)
      }
      finally {
        stmt.close()
      }
    }
    withConnection( statementFun)
  }

  def withResultSet [T] ( sql: String, f: ResultSet => T): Try[T] = {
    def resultSetFun(stmt: Statement): T = {
      val resultSet: ResultSet = stmt.executeQuery(sql)

      // We do not need to wrap this in a Try Monad because we know we will be executing inside 'withConnection'
      // which does it for us.  Using another Try(...) here would just create a confusing second layer of structures
      // for the caller to sort through
      try {
        f(resultSet)
      }
      finally {
        resultSet.close()
      }
    }

    withStatement(resultSetFun)
  }













  /*def withConnection[R](f: Connection => R): Try[R] = blocking {
    import resource._
    managed[Connection](dataSource.getConnection)
      .map { (conn: Connection) => f(conn) }
      .either match {
      case Left(cause) => Failure(cause.head)
      case Right(connection) => Success(connection)
    }
  }
  def withStatement[R](f: Statement => R): Try[R] =
    withConnection[R] { (conn: Connection) => f(conn.createStatement) }
*/


  }
