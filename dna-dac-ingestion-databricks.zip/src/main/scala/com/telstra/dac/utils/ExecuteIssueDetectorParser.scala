package com.telstra.dac.utils

import spray.json._


object ExecuteIssueDetectorParser {
  object ExecuteIssueDetectorProtocol extends DefaultJsonProtocol { //using spray.json._ module.
    implicit val executeIssueDetector: JsonFormat[ExecuteIssueDetector] = jsonFormat4(ExecuteIssueDetector)

  }

  import ExecuteIssueDetectorProtocol._
  @throws(classOf[JsonParser.ParsingException])
  @throws(classOf[DeserializationException])
  @throws(classOf[IllegalArgumentException])
  def parse(json: String): List[ExecuteIssueDetector] = {
    json.parseJson.convertTo[List[ExecuteIssueDetector]]
  }

}
