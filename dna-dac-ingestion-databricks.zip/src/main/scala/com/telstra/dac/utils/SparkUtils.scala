package com.telstra.dac.utils

import java.net.URI

import com.telstra.dac.DacApp
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}
import com.databricks.dbutils_v1.DBUtilsHolder.dbutils


/**
 * Trait that provides the management of a SparkSession
 */

trait SparkUtils extends Logging with DacApp {

  @transient private var _sparkSession: SparkSession = _
  @transient private var _fs: FileSystem = _

  /**
   * Returns a single accessible SparkSession
      * @return Spark session
   */
  def getSparkSession(): SparkSession = {


    val conf = new SparkConf()
    conf.setMaster("local").setAppName(arguments.jobName)
    conf.set("fs.azure.account.auth.type."+akvSecrets.dac2ADLSAccount+".dfs.core.windows.net", "OAuth")
    conf.set("fs.azure.account.oauth.provider.type."+akvSecrets.dac2ADLSAccount+".dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    conf.set("fs.azure.account.oauth2.client.id."+akvSecrets.dac2ADLSAccount+".dfs.core.windows.net",akvSecrets.dac2DataBricksAppId)
    conf.set("fs.azure.account.oauth2.client.secret."+akvSecrets.dac2ADLSAccount+".dfs.core.windows.net", akvSecrets.dac2DataBricksAppSecret)
    conf.set("fs.azure.account.oauth2.client.endpoint."+akvSecrets.dac2ADLSAccount+".dfs.core.windows.net", s"https://login.microsoftonline.com/${akvSecrets.dac2DirectoryId}/oauth2/token") //its a tatent id
    conf.set("spark.sql.parquet.binaryAsString", "true")
    conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    
    _sparkSession = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()

    logInfo(s"Created new Spark session")

    sparkSession
  }

  /** Returns a fs handle
   *
   * @return fs abfss file system handle
   */
  def getFileSystem(): FileSystem = {

    val conf = new Configuration(SparkContext.getOrCreate().hadoopConfiguration)
    val basePath = s"abfss://${akvSecrets.dac2ADLSContainer}@${akvSecrets.dac2ADLSAccount}.dfs.core.windows.net/"
    conf.set("fs.defaultFS", basePath)
    conf.set("fs.azure.account.auth.type", "OAuth")
    conf.set("fs.azure.account.oauth.provider.type", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    conf.set("fs.azure.account.oauth2.client.id",akvSecrets.dac2DataBricksAppId )
    conf.set("fs.azure.account.oauth2.client.secret", akvSecrets.dac2DataBricksAppSecret)
    conf.set("fs.azure.account.oauth2.client.endpoint", "https://login.microsoftonline.com/" + akvSecrets.dac2DirectoryId + "/oauth2/token")
    conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "true")

    _fs = FileSystem.get(new URI(basePath), conf)
    fs
  }

  def mountConfigs():Map[String,String] = {
    val configs = Map(
      "fs.azure.account.auth.type" -> "OAuth",
      "fs.azure.account.oauth.provider.type" -> "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
      "fs.azure.account.oauth2.client.id" -> akvSecrets.dac2DataBricksAppId ,
      "fs.azure.account.oauth2.client.secret" ->  akvSecrets.dac2DataBricksAppSecret,
      "fs.azure.account.oauth2.client.endpoint" -> s"""https://login.microsoftonline.com/${akvSecrets.dac2DirectoryId }/oauth2/token"""
    )
    configs
  }

  def mountContainer(adlsContainer: String, adlsAccount: String, mountName: String, configs: Map[String, String]) = {
    if (!dbutils.fs.mounts.map(mnt => mnt.source).contains(s"abfss://${adlsContainer}@${adlsAccount}.dfs.core.windows.net/")) {
      dbutils.fs.mount(
        source = s"abfss://${adlsContainer}@${adlsAccount}.dfs.core.windows.net/",
        mountPoint = s"/mnt/${mountName}",
        extraConfigs = configs)}
    else logInfo(s"The container  ${adlsContainer} is already mounted")
  }





  def sparkSession: SparkSession = _sparkSession
  def fs: FileSystem = _fs
}
