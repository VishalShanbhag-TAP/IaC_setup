package com.telstra.dac.utils

import spray.json._

object WorkflowJsonParser { //argument json parser. what does it parse?

  object WorkflowJsonProtocol extends DefaultJsonProtocol { //using spray.json._ module.
    //implicit val argumentFileFormat = jsonFormat(WorkflowConfiguration, "workflow_id", "workflow_name", "workflow_description", "created_date")
  implicit val workflowFormat: JsonFormat[WorkflowConfiguration] = jsonFormat4(WorkflowConfiguration)

  }

  import WorkflowJsonProtocol._
  @throws(classOf[JsonParser.ParsingException])
  @throws(classOf[DeserializationException])
  @throws(classOf[IllegalArgumentException])
  def parse(json: String): List[WorkflowConfiguration] = {
    json.parseJson.convertTo[List[WorkflowConfiguration]]
  }


}
