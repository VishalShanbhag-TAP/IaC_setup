package com.telstra.dac.utils

case class EnvironmentConfiguration(environmentName: String,runId: String, workflowName: String, jobName: String, dataBricksKVScope:String,CRL_Name:Option[String],DQ_IDs:Option[String], FilePath:Option[String], FileType:Option[String], FileName:Option[String], WriteMode:Option[String])

case class AKVSecrets(dac2DataBricksAppId: String,dac2DataBricksAppSecret:String,dac2DirectoryId:String,dac2ADLSAccount:String,dac2ADLSContainer:String,datacoreADLSContainer:String, dac2JDBCUsername:String, dac2JDBCPassword:String,dac2SQLdbServer:String,dac2SQLdbDatabase:String)
case class WorkflowConfiguration(workflow_id: Int,workflow_name: String, workflow_description: String,created_date:Option[String])
case class WorkflowStages(stage_id:Int, workflow_id :Int, sequence_num :Int, stage_name: String, description :String, created:Option[String])
case class WorkflowStagesAttributes(attribute_id:Int,attribute_value:String,attribute_name:String,stage_id:Int,created:Option[String])
case class PostIdentificationTracker(job_id:Int, dq_id:String, frequency:String, last_run_date:String, next_run_date:String, business_use_case:String)
case class ExecuteIssueDetector(parent_id:Int, parent_name:String, child_ids:String, business_usecase:String)
final case class CustomException(private val message: String = "",
                                 private val cause: Throwable = None.orNull)
  extends Exception(message, cause)

