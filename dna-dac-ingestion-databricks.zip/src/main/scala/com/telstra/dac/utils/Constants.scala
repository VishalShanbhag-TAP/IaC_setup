package com.telstra.dac.utils

object Constants {
  /*
  *Constants file will define all hard coded vals and vars which will be used throughout the project.
  */

  var CONFIG_FILE: String = ""

  //Constants are defined as under:

  /*Config file constants*/

  val SPARK_SERIALIZER = "spark.serializer"
  val SPARK_SQL_TUNGSTEN_ENABLED = "spark.sql.tungsten.enabled"
  val SPARK_EVENTLOG_ENABLED = "spark.eventLog.enabled"
  val SPARK_APP_ID = "spark.app.id"
  val SPARK_IO_COMPRESSION_CODEC = "spark.io.compression.codec"
  val SPARK_RDD_COMPRESS = "spark.rdd.compress"
  val HIVE_EXEC_DYNAMIC_PARTITION = "hive.exec.dynamic.partition"
  val HIVE_EXEC_DYNAMIC_PARTITION_MODE = "hive.exec.dynamic.partition.mode"
  val HIVE_URL = "hiveurl"
  val HIVE_USER = "hiveuser"
  val HIVE_PASSWORD = "hivepassword"

  /*Basic constants*/
  val YES = "Y"
  val NO = "N"
  val SUCCESS = "SUCCESS"
  val FAILED = "FAILED"
  val IN_PROGRESS = "IN-PROGRESS"
  val PARQUET = "PARQUET"

  /* To be used with audit function in AbstractStage*/
  val AUDIT_START_ENTRY: Int = 0;
  val AUDIT_END_ENTRY: Int = 1;

  /*Stage Name constants   */
//  val STAGE_LOAD_DATASETS = "LOAD_DATASETS"
//  val STAGE_INTEGRATION_ENGINE = "INTEGRATION_ENGINE"
//  val STAGE_PERSIST_ADLS = "PERSIST_ADLS"
//  val STAGE_SPLIT_COLUMNS = "SPLIT_COLUMNS"
//  val STAGE_LOAD_INTERIM_TABLE = "LOAD_INTERIM_TABLE"
//  val STAGE_TRIM_TRANSFORMATION = "TRIM_TRANSFORMATION"
//  val STAGE_CHANGE_DATE_TRANSFORMATION = "CHANGE_DATE_TRANSFORMATION"
//  val STAGE_DYNAMIC_UDF = "DYNAMIC_UDF"
//  val STAGE_APPEND_AUDIT_COLS = "APPEND_AUDIT_COLS"
//  val STAGE_INGESTION = "INGESTION"
//  val STAGE_CLEANUP = "CLEANUP"
//  val STAGE_ADD_NEW_COL_FROM_ENV = "ADD_NEW_COL_FROM_ENV"
//  val STAGE_DROP_COLS_FROM_DF = "DROP_COLS_FROM_DF"
//  val STAGE_FILTER_DF = "FILTER_DF"
//  val STAGE_DATA_COUNT_RECON = "DATA_COUNT_RECON"
//  val STAGE_JOIN_DATASETS = "JOIN_DATASETS"
//  val STAGE_CHANGE_DELIMITER = "CHANGE_DELIMITER"

  /*Stage Name constants   */
  val STAGE_LOAD_DATASETS = "LOAD_DATASETS"
  val STAGE_INTEGRATION_ENGINE = "INTEGRATION_ENGINE"
  val STAGE_PERSIST_ADLS = "PERSIST_ADLS"
  val STAGE_SPLIT_COLUMNS = "SPLIT_COLUMNS"
  val STAGE_CLEANUP = "CLEANUP"
  val STAGE_DROP_COLUMNS = "DROP_COLUMNS"
  val STAGE_FILTER = "FILTER"
  val STAGE_JOIN_DATASETS = "JOIN_DATASETS"
  val STAGE_DELIMITER_CHANGE = "DELIMITER_CHANGE"
  val STAGE_CONVERT_NULLS = "CONVERT_NULLS"
  val STAGE_DEDUPE = "DEDUPE"
  val STAGE_EXECUTE_SQL = "EXECUTE_SQL"
  val STAGE_EXECUTE_ISSUE_DETECTOR = "PERSIST_DATA"
  val STAGE_POST_IDENTIFICATION_TRACKER = "PIT_TRACKER_EXECUTE"
  val STAGE_DAC1_DATA_PROCESSING = "DAC1_DATA_PROCESSING"
  val STAGE_MISALIGNMENT_TABLE = "MISALIGNMENT_TBL"

  /* KeyVault*/

  val AKV_KEY_LIST =Array("dac2-databricks-app-id", "dac2-databricks-app-secret", "dac2-directory-id", "dac2-adls-account", "dac2-adls-container", "datacore-adls-container", "dac2-jdbc-username", "dac2-jdbc-password", "dac2-sqldb-server", "dac2-sqldb-database")

  /*Attribute names*/

  /*Input Atrributes*/
  val ATTR_INPUT_DATASET_CAIMAN = "INPUT_DATASET_CAIMAN"
  val ATTR_INPUT_DATASET_SFDCCONTACT = "INPUT_DATASET_SFDCCONTACT"
  val ATTR_INPUT_DATASET_1 = "INPUT_DATASET_1"
  val ATTR_INPUT_DATASET_2 = "INPUT_DATASET_2"
  val ATTR_INPUT_DATASET_3 = "INPUT_DATASET_3"
  val ATTR_INPUT_DATASET_4 = "INPUT_DATASET_4"
  val ATTR_INPUT_DATASET_5 = "INPUT_DATASET_5"
  val ATTR_INPUT_DATASET_6 = "INPUT_DATASET_6"
  val ATTR_INPUT_FORMAT = "INPUT_FORMAT"
  val ATTR_INPUT_DATASETS = "INPUT_DATASETS"
//  val ATTR_RESULT_COLUMNS = "RESULT_COLUMNS"
//  val ATTR_INTEGRATION_SET_TYPE = "INTEGRATION_SET_TYPE"
//  val ATTR_INTEGRATION_SET_NAME = "INTEGRATION_SET_NAME"

  /*Filter Atrributes*/
  val ATTR_FILTER_INPUT_DF = "FILTER_INPUT_DF"
  val ATTR_FILTER_CONDITION_1 = "FILTER_CONDITION_1"
  val ATTR_FILTER_CONDITION_2 = "FILTER_CONDITION_2"
  val ATTR_FILTER_CONDITION_3 = "FILTER_CONDITION_3"
  val ATTR_FILTER_CONDITION_4 = "FILTER_CONDITION_4"
  val ATTR_FILTER_RESULT_DF = "FILTER_RESULT_DF"

  /*Drop Column Atrributes*/
  val ATTR_DROP_COLUMNS_INPUT_DF = "DROP_COLUMNS_INPUT_DF"
  val ATTR_DROP_COLUMNS_COLUMN_NAMES = "DROP_COLUMNS_COLUMN_NAMES"
  val ATTR_DROP_COLUMNS_RESULT_DF = "DROP_COLUMNS_RESULT_DF"

  /*Integration Atrributes*/
  val ATTR_INTEGRATION_INPUT_DFS = "INTEGRATION_INPUT_DFS"
  val ATTR_INTEGRATION_KEYS = "INTEGRATION_KEYS"
  val ATTR_INTEGRATION_JOIN_TYPE = "INTEGRATION_JOIN_TYPE"
  val ATTR_INTEGRATION_PREFIX_VALUES = "INTEGRATION_PREFIX_VALUES"
  val ATTR_INTEGRATION_RESULT_DF = "INTEGRATION_RESULT_DF"

  /*Persist Attributes*/
  val ATTR_PERSIST_INPUT_DF = "PERSIST_INPUT_DF" // "caiman" "previousStage"
  val ATTR_PERSIST_FORMAT = "PERSIST_FORMAT" //"parquet"
  val ATTR_PERSIST_DIRECTORY = "PERSIST_DIRECTORY" // /tables/sfdc_caiman_int_perm
  val ATTR_PERSIST_PERMANENCE = "PERSIST_PERMANENCE" // "temp", "perm"
  val ATTR_PERSIST_MODE = "PERSIST_MODE" //Overwrite
  val ATTR_PERSIST_PARTITION_ON_COL = "PERSIST_PARTITION_ON_COL" //AllSiebelContacts, Null

  /*Split Columns Attributes*/
  val ATTR_SPLIT_COLUMNS_INPUT_DATAFRAME = "SPLIT_COLUMNS_INPUT_DATAFRAME"
  val ATTR_SPLIT_COLUMNS_FIELD_NAME = "SPLIT_COLUMNS_FIELD_NAME"
  val ATTR_SPLIT_COLUMNS_DELIMITER = "SPLIT_COLUMNS_DELIMITER"
  val ATTR_SPLIT_COLUMNS_MAXIMUM_SPLIT_COUNT = "SPLIT_COLUMNS_MAXIMUM_SPLIT_COUNT"
  val ATTR_SPLIT_COLUMNS_PREFIX_NAME = "SPLIT_COLUMNS_PREFIX_NAME"
  val SPLIT_COLUMNS_RESULT_DF = "SPLIT_COLUMNS_RESULT_DF"

  /*Delimiter Change Attributes*/
  val ATTR_DELIMITER_CHANGE_INPUT_DF = "DELIMITER_CHANGE_INPUT_DF"
  val ATTR_DELIMITER_CHANGE_INPUT_DELIMETER = "DELIMITER_CHANGE_INPUT_DELIMETER"
  val ATTR_DELIMITER_CHANGE_TARGET_DELIMETER = "DELIMITER_CHANGE_TARGET_DELIMETER"
  val ATTR_DELIMITER_CHANGE_COLUMN_NAME = "DELIMITER_CHANGE_COLUMN_NAME"
  val ATTR_DELIMITER_CHANGE_RESULT_DF = "DELIMITER_CHANGE_RESULT_DF"

  /*CONVER TNULLS Attributes*/
  val ATTR_CONVERTNULLS_INPUT_DF = "CONVERTNULLS_INPUT_DF"
  val ATTR_CONVERTNULLS_COLUMN_NAMES = "CONVERTNULLS_COLUMN_NAMES"
  val ATTR_CONVERTNULLS_INPUT_VALUES = "CONVERTNULLS_INPUT_VALUES"
  val ATTR_CONVERTNULLS_RESULT_DF = "CONVERTNULLS_RESULT_DF"

  /*DeDupeStage Attributes*/
  val ATTR_DEDUPE_INPUT_DF = "DEDUPE_INPUT_DF"
  val ATTR_DEDUPE_COLUMN_LIST = "DEDUPE_COLUMN_LIST"
  val ATTR_DEDUPE_TABLE_PARTITIONED = "DEDUPE_TABLE_PARTITIONED"
  val ATTR_DEDUPE_PARTITION_COLUMN = "DEDUPE_PARTITION_COLUMN"
  val ATTR_DEDUPE_ORDERBY_COLUMN = "DEDUPE_ORDERBY_COLUMN "
  val ATTR_DEDUPE_RESULT_DF = "DEDUPE_RESULT_DF"

  /*Execute_SQL Attributes*/
  val ATTR_EXECUTE_SQL_PATH = "EXECUTE_SQL_PATH"

  /*Execute_DQ Issue Detector Attributes*/
  val ATTR_DQ_DATA_TEMP_PATH = "DQ_DATA_TEMP_PATH"
  val ATTR_DATA_SET_WIDE_OUTPUT = "DATA_SET_WIDE_OUTPUT"
  val ATTR_INSTANCE_NARROW_OUTPUT = "INSTANCE_NARROW_OUTPUT"
  val ATTR_DF_OPTIMISATION_DISABLED = "DF_OPTIMISATION_DISABLED" /*Presence of this attribute in a stage will disable optimisation steps*/

  /*Post Identification Tracker Attributes*/
  val ATTR_INSTANCE_NARROW_CURRENT = "INSTANCE_NARROW_CURRENT"
  val ATTR_PIT_INSTANCE_NARROW = "PIT_INSTANCE_NARROW"
  val ATTR_PIT_AGGREGATE_REPORT = "PIT_AGGREGATE_REPORT"
  val ATTR_SQLDW_INSTANCE_NARROW = "SQLDW_INSTANCE_NARROW"
  val ATTR_SQLDW_AGGREGATE_REPORT = "SQLDW_AGGREGATE_REPORT"

  /*variable available for configuration*/
  val VARIABLE_AUDIT_ID = "VARIABLE_AUDIT_ID"

  /*Target write modes*/
  val TARGET_WRITE_MODE_APPEND = "APPEND"
  val TARGET_WRITE_MODE_OVERWRITE = "OVERWRITE"


  /*Dynamic UDF function types*/
  val FUNCTION_TYPE_1 = "FUNCTION_TYPE_1"
  val FUNCTION_TYPE_2 = "FUNCTION_TYPE_2"
  val FUNCTION_TYPE_3 = "FUNCTION_TYPE_3"
  val FUNCTION_TYPE_4 = "FUNCTION_TYPE_4"
  val FUNCTION_TYPE_5 = "FUNCTION_TYPE_5"

  /* RDBMS constants*/
  val DbUserName = "username"
  val DbPassword = "password"
  val DbDriver = "driver"
  val DbUrl = "dbUrl"

  /*Variable vs constant data type - also used in Add new stage*/
  val DATA_TYPE_VARIABLE = "VARIABLE"
  val DATA_TYPE_CONSTANT = "CONSTANT"


  /* RDBMS queries*/

  val QUERY_FETCH_STAGES = "SELECT stage_id, workflow_id, sequence_num, stage_name, description, created FROM gf_stage where workflow_id=? order by sequence_num "
  //  val QUERY_FETCH_STAGES = "select gts.stage_relation_id,gs.stage_id,gs.stage_name,gs.stage_description,gs.executor,gts.sequence_num from gif_template_stage gts  " +
  //    "inner join gif_stage gs on gts.stage_id=gs.stage_id where gts.template_id='?' order by gts.sequence_num"
  val QUERY_FETCH_WORKFLOW = "SELECT workflow_id, workflow_name, workflow_description, created_date FROM gf_workflow where workflow_name=? "
  val QUERY_FETCH_ATTRIBUTES = "SELECT attribute_id, stage_id, attribute_name, attribute_value, created FROM gf_stage_attribute where stage_id=?"
  val QUERY_STAGE_DETAILS = "select description from gf_stage where stage_id=?"
  val QUERY_CHECK_AUDIT_ENTRY = "select count(0) from audit_tbl where audit_id=?"
  val QUERY_CHECK_AUDIT_STEP_ENTRY = "select count(0) from audit_tbl where audit_id=? and step_id=?"
  val QUERY_FETCH_STEP_ID = "select step_id from gif_stage_step where stage_relation_id=? and source_system=? and table_name=? "
  val QUERY_UPDATE_AUDIT = "update audit_tbl set end_time = now() , status = ?, failure_details = ?,yarn_appl_id = ? where  audit_id = ? and step_id = ?"
  val QUERY_UPDATE_AUDIT_START = "update audit_tbl set end_time = now() , start_time = now(), status = ?, failure_details = ?,yarn_appl_id = ? where  audit_id = ? and step_id = ?"
  val QUERY_INSERT_AUDIT = "insert into  audit_tbl ( yarn_appl_id, audit_id, step_id, start_time, status ) values (?,?,?,now(),?)"

  val QUERY_RECORD_COUNT_HIVE_RECON = s"select count(0) from %s.%s where audit_id=?"
  val QUERY_RECORD_COUNT_GENERIC = s"select count(0) from %s.%s"
  val QUERY_RECORD_COUNT_Y = s"select count(0) from %s.%s where active='Y' "
  val QUERY_RECORD_COUNT_N = s"select count(0) from %s.%s where active='N' "
  val QUERY_RECORD_COUNT_R = s"select count(0) from %s.%s where active='R' "

  val QUERY_RECON_ENTRY = "insert into recon_tbl ( audit_id,recon_dt,meta_record_count,staging_record_count,Hist_table_Y_record_count,Hist_table_N_record_count,Hist_table_R_record_count,Records_Ingested_Y,Records_Ingested_N,Records_Ingested_R,Total_Records,Recon_Flag ) values (?,now(),?,?,?,?,?,?,?,?,?,?)"
  val QUERY_ANALYZE_TABLE = "analyze table %s.%s partition (active='Y',active='N',active='R') compute statistics"

  val QUERY_UPDATE_INGESTED_FILE_INFO = "update ingested_file_info set status=? where audit_id=?"

  val QUERY_FETCH_PIT_CONFIG = "select job_id, dq_id, frequency, last_run_date, next_run_date, business_use_case from pit_tracker_cfg where is_active = 'True' and business_use_case =?"

  val QUERY_FETCH_DQID_CONFIG = "select parent_id, parent_name, child_ids, business_usecase from gf_dqid_execute_cfg where is_active = 'True' and business_usecase = ?"

  val QUERY_FETCH_PARENT_CONFIG = "select parent_id, parent_name, child_ids, business_usecase from gf_dqid_execute_cfg where is_active = 'True'"

}
