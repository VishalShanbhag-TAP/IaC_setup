package com.telstra.dac.utils

import spray.json._


object WorkflowStagesAttributesParser {
  object WorkflowStagesAttributesProtocol extends DefaultJsonProtocol { //using spray.json._ module.
    implicit val workflowStageAttributes: JsonFormat[WorkflowStagesAttributes] = jsonFormat5(WorkflowStagesAttributes)

  }

  import WorkflowStagesAttributesProtocol._
  @throws(classOf[JsonParser.ParsingException])
  @throws(classOf[DeserializationException])
  @throws(classOf[IllegalArgumentException])
  def parse(json: String): List[WorkflowStagesAttributes] = {
    json.parseJson.convertTo[List[WorkflowStagesAttributes]]
  }

}
