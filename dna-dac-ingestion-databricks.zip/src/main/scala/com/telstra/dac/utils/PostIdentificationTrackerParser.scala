package com.telstra.dac.utils

import spray.json._


object PostIdentificationTrackerParser {
  object PostIdentificationTrackerProtocol extends DefaultJsonProtocol { //using spray.json._ module.
    implicit val postIdentificationTracker: JsonFormat[PostIdentificationTracker] = jsonFormat6(PostIdentificationTracker)

  }

  import PostIdentificationTrackerProtocol._
  @throws(classOf[JsonParser.ParsingException])
  @throws(classOf[DeserializationException])
  @throws(classOf[IllegalArgumentException])
  def parse(json: String): List[PostIdentificationTracker] = {
    json.parseJson.convertTo[List[PostIdentificationTracker]]
  }

}
