package com.telstra.dac.utils

import spray.json._

object ArgumentsParser {

  object ArgumentJsonProtocol extends DefaultJsonProtocol {
    implicit val mainArguments = jsonFormat(EnvironmentConfiguration, "EnvironmentName", "RunId", "WorkflowName", "JobName","DataBricksKVScope","CRL_Name","DQ_IDs","FilePath","FileType","FileName","WriteMode")

  }

  import ArgumentJsonProtocol._
  @throws(classOf[JsonParser.ParsingException])
  @throws(classOf[DeserializationException])
  @throws(classOf[IllegalArgumentException])
  def parse(json: String): EnvironmentConfiguration = {

    json.parseJson.convertTo[EnvironmentConfiguration]
  }

}
