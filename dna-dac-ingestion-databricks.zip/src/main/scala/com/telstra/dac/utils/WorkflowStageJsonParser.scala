
package com.telstra.dac.utils

import spray.json._

object WorkflowStageJsonParser { //argument json parser. what does it parse?

  object WorkflowStageProtocol extends DefaultJsonProtocol { //using spray.json._ module.
    //implicit val argumentFileFormat = jsonFormat(WorkflowConfiguration, "workflow_id", "workflow_name", "workflow_description", "created_date")
    implicit val workflowStage: JsonFormat[WorkflowStages] = jsonFormat6(WorkflowStages)

  }

  import WorkflowStageProtocol._
  @throws(classOf[JsonParser.ParsingException])
  @throws(classOf[DeserializationException])
  @throws(classOf[IllegalArgumentException])
  def parse(json: String): List[WorkflowStages] = {
    json.parseJson.convertTo[List[WorkflowStages]]
  }

}
