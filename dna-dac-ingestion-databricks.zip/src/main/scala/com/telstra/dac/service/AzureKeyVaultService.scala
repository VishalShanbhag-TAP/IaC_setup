package com.telstra.dac.service

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.dac.utils.{AKVSecrets, Constants}

object AzureKeyVaultService {

  /** Function to retrive specific KeyVault Secret
   *
   * @param credentialScope Scope of obtaining the Secrets
   * @param key key id of the secret
   * @return secret value as string
   */

  def getAppKeyVltSecret(scope: String, key: String): String = {
    dbutils.secrets.get(scope = scope, key = key)
  }


  /**
   *
   * @param dbScope
   * @param envName
   * @return AKVSecrets
   */
  def getAppKeyVltSecretCaseObj(dbScope: String,envName: String): AKVSecrets = {

      Constants.AKV_KEY_LIST.map(x=>x+envName).map(y=> getAppKeyVltSecret(dbScope,y)) match {

      case Array(a, b, c,d,e,f,g,h,i,j) => AKVSecrets(a, b, c,d,e,f,g,h,i,j)
      case _  => throw new IllegalArgumentException(s"Unknown key vaults key specified")

    }
  }

}







