package com.telstra.dac.service

// to be filled with functions to load and save dataframes and files
// may also contain decryption and unzipping functionality

trait AzureDataLakeService {

}
