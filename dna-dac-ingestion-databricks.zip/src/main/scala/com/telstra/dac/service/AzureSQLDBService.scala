package com.telstra.dac.service

import java.sql.{Connection, DriverManager, ResultSet, ResultSetMetaData, Statement}

import com.telstra.dac.DacApp

import scala.collection.mutable.ListBuffer
import scala.util.{Failure, Success, Try}

object AzureSQLDBService {

  //lazy val connString = s"jdbc:sqlserver://${akvSecrets.dac2SQLdbServer}:1433;database=${akvSecrets.dac2SQLdbDatabase};user=${akvSecrets.dac2JDBCUsername};password=${akvSecrets.dac2JDBCPassword};encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30"



  def withConnection [T] ( f: Connection => T, connString:String): Try[T] = {
    println("Opening DB connection")

    val conn = DriverManager.getConnection(connString)
    val result: Try[T] = Try(f(conn))
    println("Opened connection")

    conn.close()
    println("closing connection")
    result
  }
  // stmt.execute("CREATE TABLE EXAMPLE(ID INT PRIMARY KEY, DESCRIPTION VARCHAR(50))")
  def withStatement [T] (f: Statement => T,connString:String): Try[T] = {
    def statementFun(conn: Connection): T = {
      val stmt: Statement = conn.createStatement()
      try {
        f(stmt)
      }
      finally {
        stmt.close()
      }
    }
    withConnection( statementFun,connString)
  }
  // withResultSet(("select * from Example",resultSet  =>  itFun(new ResultsIterator(resultSet)
  def withResultSet [T] ( sql: String, f: ResultSet => T,connString:String): Try[T] = {
    def resultSetFun(stmt: Statement): T = {
      val resultSet: ResultSet = stmt.executeQuery(sql)

      // We do not need to wrap this in a Try Monad because we know we will be executing inside 'withConnection'
      // which does it for us.  Using another Try(...) here would just create a confusing second layer of structures
      // for the caller to sort through
      try {
        f(resultSet)
      }
      finally {
        resultSet.close()
      }
    }

    withStatement(resultSetFun,connString)
  }

  private class ResultsIterator (resultSet: ResultSet) extends Iterator[Map[String, AnyRef]] {
    private val columnNames: Seq[String] = {
      val rsmd: ResultSetMetaData = resultSet.getMetaData

      for (i <- 1 to rsmd.getColumnCount) yield rsmd.getColumnName(i)
    }
    println(columnNames)

    /**
     * Produces a Scala Map containing the Name->Value mappings of the current row data for the result set
     * @param resultSet JDBC ResultSet used to extract current row data
     * @return Scala immutable map containing row data of the ResultSet
     */
    private def buildRowMap(resultSet: ResultSet): Map[String, AnyRef] = {
      ( for (c <- columnNames) yield  c  ->   resultSet.getObject(c)  ).toMap

    }

    /**
     * Retrieves the next row of data from a result set.  Note that this method returns an Option monad
     * If the end of the result set has been reached, it will return None, otherwise it will return Some[Map[String, AnyRef]]
     *
     * @param resultSet JDBC ResultSet to extract row data from
     * @return Some[Map] if there is more row data, or None if the end of the resultSet has been reached
     */
    private def getNextRow(resultSet: ResultSet): Option[Map[String, AnyRef]] = {
      if (resultSet.next())
        Some(buildRowMap(resultSet))
      else
        None
    }

    /**
     * Member variable containing the next row.  We need to manage this state ourselves to defend against implementation
     * changes in how Scala iterators are used.  In particular, we do this to prevent attaching the Scala hasNext function
     * to the ResultSet.next method, which seems generally unsafe.
     */
    private var nextRow = getNextRow(resultSet)

    /**
     * Scala Iterator method called to test if we have more JDBC results
     * @return
     */
    override def hasNext = nextRow.isDefined

    /**
     * Scala Iterator method called to retrieve the next JDBC result
     * @return
     */
    override def next() = {
      // Extract the raw Map out of our Option[Map].  This is generally unsafe to do without risking an exception
      // but no one should be calling next without first making sure that hasNext returns true, so in our usage model
      // we should never invoke get on "None"
      val rowData = nextRow.get
      nextRow = getNextRow(resultSet)
      rowData
    }
  }
  def withResultsIterator [T] (sql: String, itFun: ResultsIterator => T,connString:String): Try[T] =
    withResultSet(sql, resultSet => itFun(new ResultsIterator(resultSet)),connString)

  private def escape(s: String) : String = {
    return s.replaceAll("\"" , "\\\\\"");
  }
  def toJson(o: Any) : String = {
    var json = new ListBuffer[String]()
    println("calling function")
    o match {
      case m: Map[_, _] => {
        for ((k, v) <- m) {
          var key = escape(k.asInstanceOf[String])
          v match {
            case a: Map[_, _] => json += "\"" + key + "\":" + toJson(a)
            case a: List[_] => json += "\"" + key + "\":" + toJson(a)
            case a: Int => json += "\"" + key + "\":" + a
            case a: Boolean => json += "\"" + key + "\":" + a
            case a: String => json += "\"" + key + "\":\"" + escape(a) + "\""
            case _ => ;
          }
        }
      }
      case m: List[_] => {
        var list = new ListBuffer[String]()
        for ( el <- m ) {
          el match {
            case a: Map[_,_] => list += toJson(a)
            case a: List[_] => list += toJson(a)
            case a: Int => list += a.toString()
            case a: Boolean => list += a.toString()
            case a: String => list += "\"" + escape(a) + "\""
            case _ => ;
          }
        }
        return "[" + list.mkString(",") + "]"
      }

      case _ => println("error")
    }
    return "{" + json.mkString(",") + "}"

  }

  //To do fix and throw proper error.

  def generateJson(sql: String,connString:String): String = {

    withResultsIterator(sql, it => it.toList,connString)match
    {
      case  Success(json) => { toJson(json)

      }
      case Failure(e) => "Error Connecting to DB"
    }

  }


  def generateSeq(sql: String,connString:String):String = {

    withResultsIterator(sql, it => it.next(),connString)match
    {
      case  Success(seq) => { seq("").toString

      }
      case Failure(e) => "Error Connecting to DB"
    }

  }
}
