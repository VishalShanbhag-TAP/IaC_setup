/*
package com.telstra.dac.service

import java.net.URI
import java.util.concurrent.Executors

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.microsoft.aad.adal4j.{AuthenticationContext, ClientCredential}
import com.microsoft.azure.storage.blob.CloudBlobClient
import com.microsoft.azure.storage.{CloudStorageAccount, StorageCredentialsToken}

// Yet to be customised, may not actually be necessary
//TODO: Fix the key names (make it env friendly), and put them in a constant file, and refer to constants from here.
trait AzureStorageService {

  def blobServiceSyncClient(tenantId: String, appId: String, appSecret: String, storageAccount: String): CloudBlobClient = {
    val account = CloudStorageAccount.parse(dbutils.secrets.get(scope = "adobe-dna-scope", key = "adlsConnString"))
    val cloudBlobClient:CloudBlobClient = account.createCloudBlobClient()
    cloudBlobClient
  }

  def getAuthToken(tenantId: String, appId: String, appSecret: String, storageAccount: String) = {

    try {
      val adAuthority = s"https://login.microsoftonline.com/${tenantId}"
      val resource = s"https://${storageAccount}.dfs.core.windows.net"
      val service = Executors.newFixedThreadPool(1)
      val context = new AuthenticationContext(adAuthority, false, service)
      val credential = new ClientCredential(appId, appSecret)
      val authResult = context.acquireToken(resource, credential, null)
      val token = authResult.get.getAccessToken
      service.shutdown()
      token
    } catch {
      case e: RuntimeException => e.getMessage
    }
  }

  def getStorageClient(storageAccount: String, token: String): CloudBlobClient = {
    val credentialsToken = new StorageCredentialsToken(storageAccount, token)
    val cloudBlobClient = new CloudBlobClient(new URI(s"https://${storageAccount}.dfs.core.windows.net/"),
      credentialsToken)
    cloudBlobClient
  }
}
*/
