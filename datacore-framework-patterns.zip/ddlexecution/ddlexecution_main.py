import sys
from pathlib import Path
import logging
from pyspark.sql import SparkSession
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext

# create tables from the script
def create_tables(spark, environment, rand_token,logger):
    try:
        list_of_files = dbutils.fs.ls(f"/FileStore/database/{environment}/{rand_token}")
        for sql_file in list_of_files:
            with open(f"/dbfs/FileStore/database/{environment}/{rand_token}/{sql_file.name}") as fr:
              stmt = fr.read().format(env=environment,ENV=environment)
            queries = stmt.split(";")
            logger.info("[APP-LOG] : Executing sql file - "+sql_file.name)
            for query in queries:
              logger.info("[APP-LOG] : Executing Query")
              logger.info(query)
              if query:
                results = spark.sql(query)
            dbutils.fs.rm(f"/dbfs/FileStore/database/{environment}/{rand_token}/{sql_file.name}")
        dbutils.fs.rm(f"dbfs:/FileStore/database/{environment}/{rand_token}",True)
    except Exception as error:
        logging.error(error, exc_info=True)
        logger.error("[APP-LOG] : Unexecuted files")
        unexecuted_files = [files.name for files in dbutils.fs.ls(f"/FileStore/database/{environment}/{rand_token}")]
        logger.error("[APP-LOG] : Not executed files - "+str(unexecuted_files))
        dbutils.fs.rm(f"dbfs:/FileStore/database/{environment}/{rand_token}",True)
        sys.exit(1)
        
if __name__=='__main__':
    try:
        environment = sys.argv[1]
        rand_token = sys.argv[2]
        
		# Create Spark Session
        spark = SparkSession.builder.appName('create-table').enableHiveSupport().getOrCreate()
        log4jLogger = sc._jvm.org.apache.log4j
        logger = log4jLogger.LogManager.getLogger(__name__)
        
        # Execute create table statments
        create_tables(spark,environment, rand_token,logger)
        
        logging.info("Job completed Successfully")
        
    except Exception as error:
        logging.error(error, exc_info=True)
        sys.exit(1)