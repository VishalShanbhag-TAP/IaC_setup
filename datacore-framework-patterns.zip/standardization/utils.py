import os


def get_dbutils(spark):
    try:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)
    except ImportError:
        import IPython
        dbutils = IPython.get_ipython().user_ns["dbutils"]
    return dbutils


def mount_data_dirs(spark,job_runtime_config,directory):
    dbutils = get_dbutils(spark)
    sp_application_id = dbutils.secrets.get("ipnd-databricks-scope", "databricks-mount-sp-client-id")
    sp_application_secret = dbutils.secrets.get("ipnd-databricks-scope", "databricks-mount-sp-client-secret")
    sp_tenant_id = dbutils.secrets.get("ipnd-databricks-scope", "databricks-mount-sp-tenant-id")

    container = job_runtime_config['CONTAINER']
    #directory = job_runtime_config['DIRECTORY']
    storage_account = job_runtime_config['STORAGE_ACCOUNT']

    mount_path = "/mnt/{}/{}".format(container, directory)

    adls_container = container
    adls_account = storage_account
    source_path = "abfss://{}@{}.dfs.core.windows.net/{}".format(adls_container, adls_account, directory)
    extra_configs = {"fs.azure.account.auth.type": "OAuth",
                     "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2"
                                                             ".ClientCredsTokenProvider",
                     "fs.azure.account.oauth2.client.id": sp_application_id,
                     "fs.azure.account.oauth2.client.secret": sp_application_secret,
                     "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/{}/oauth2/token".format(
                         sp_tenant_id)}

    if any(mount.mountPoint == mount_path for mount in dbutils.fs.mounts()):
        dbutils.fs.unmount(mount_path)
    #dbutils.fs.unmount(mount_path)
    dbutils.fs.mount(source_path, mount_path, "", None, extra_configs)
