import json
import os
from collections import OrderedDict

from common.common_utils import get_logger
from common.utils import Utils


class ColumnMapping:
    def __init__(self, column_name, data_type, timezone):
        self.column_name = column_name
        self.data_type = data_type
        self.timezone = timezone


class Standardised:
    def __init__(self, standardization_config, schema_json, job_runtime_config, spark):

        print(os.getcwd())
        self.standardization_config_json = standardization_config
        self.schema = schema_json
        self.spark = spark

        tzmapping_file_location = self.standardization_config_json['tzmapping']
        tzmapping_file_location = tzmapping_file_location.format(job_runtime_config['ENVIRONMENT_NAME'])
        self.tzmapping = self.load_timezone_mapping(tzmapping_file_location)

        self.job_runtime_config = job_runtime_config

        self.ENVIRONMENT_NAME = job_runtime_config['ENVIRONMENT_NAME']
        self.TASK_INSTANCE_ID = job_runtime_config['TASK_INSTANCE_ID']
        self.ODATE = job_runtime_config['ODATE']
        self.ADLS_URI_PREFIX = job_runtime_config['ADLS_URI_PREFIX']

        self.logger = get_logger(spark, "Standardised")

        self.utils = Utils(schema_json, job_runtime_config)
        self.staging_data_type_mapping = {'VARCHAR': 'STRING', 'CHAR': 'STRING', 'DECIMAL': 'DECIMAL',
                                          'INTEGER': 'INTEGER', 'SMALLINT': 'SMALLINT', 'BIGINT': 'BIGINT',
                                          'TIMESTAMP': 'STRING', 'DATE': 'STRING'}

        self.standard_data_type_mapping = {'VARCHAR': 'STRING', 'CHAR': 'STRING', 'DECIMAL': 'DECIMAL',
                                           'INTEGER': 'INTEGER', 'SMALLINT': 'INTEGER', 'BIGINT': 'BIGINT',
                                           'TIMESTAMP': 'TIMESTAMP', 'DATE': 'TIMESTAMP', 'BOOLEAN': 'INTEGER'}

        self.ssu_dict = {'retail': 'retail', 'wholesale': 'wholesale', 'transient': 'transient',
                         'corporate': 'corporate', 'enterprise': 'reference'}

        self.ssu_mapping_short_code = {'retail': 'R', 'wholesale': 'W', 'transient': 'T', 'corporate': 'C',
                                       'enterprise': 'E'}

        self.source_ssu = self.schema['Scope']['SSU']
        self.ssu_indicator = self.ssu_mapping_short_code[self.schema['Scope']['SSU']]
        self.source_system = self.schema['Scope']['SourceSystem']
        self.source_table_name = self.schema['Scope']['TableName']

        self.stg_db_name = "{}_BIDH{}_SDS_{}_STG".format(self.ENVIRONMENT_NAME, self.ssu_indicator,
                                                         self.source_system)
        self.std_db_name = "{}_BIDH{}_SDS_{}_WRK".format(self.ENVIRONMENT_NAME, self.ssu_indicator, self.source_system)

        self.stage_table_name = "{}_BIDH{}_SDS_{}_STG.{}".format(self.ENVIRONMENT_NAME, self.ssu_indicator,
                                                                 self.source_system, self.source_table_name)
        self.std_table_name = "{}_BIDH{}_SDS_{}_WRK.{}_Standardised".format(self.ENVIRONMENT_NAME, self.ssu_indicator,
                                                                            self.source_system, self.source_table_name)
        self.stg_table_relative_path = "/data/{}/SDS/staging/{}/{}/{}".format(
            self.ENVIRONMENT_NAME, self.ssu_dict[self.source_ssu.lower()], self.source_system.lower(),
            self.source_table_name.lower())

        self.std_table_relative_path = "/data/{}/SDS/standardised/{}/{}/{}_BIDH{}_SDS_{}_WRK/{" \
                                       "}_standardised".format(self.ENVIRONMENT_NAME,
                                                               self.source_ssu.lower(),
                                                               self.source_system.lower(),
                                                               self.ENVIRONMENT_NAME, self.ssu_indicator,
                                                               self.source_system.lower(),
                                                               self.source_table_name.lower())

    @staticmethod
    def load_timezone_mapping(tzmapping_file_location):
        return json.loads(open(tzmapping_file_location).read())

    def get_tz_mapping(self):
        return self.tzmapping

    def get_stage_table_name(self):
        return self.stage_table_name

    def get_std_table_name(self):
        return self.std_table_name

    def get_stg_table_relative_path(self):
        return self.stg_table_relative_path

    def get_std_table_relative_path(self):
        return self.std_table_relative_path

    def start_process(self):
        self.standardize_stagetable()
        self.standardize_standardtable()
        self.copy_from_stg_to_std()

    def generate_create_stage_table(self):
        altered_mappings = {}
        schema_mappings = self.schema["SourceColumns"]
        for col_mapping in schema_mappings:
            altered_mappings[col_mapping['ColumnName']] = col_mapping
        altered_mappings["FileId"] = {"ColumnName": "FileId", "DataType": "BIGINT", "Format": {}}
        altered_mappings["FileLineNumber"] = {"ColumnName": "FileLineNumber", "DataType": "BIGINT", "Format": {}}
        if self.utils.is_sequence_col_needed():
            altered_mappings["sequence"] = {"ColumnName": "sequence", "DataType": "INTEGER", "Format": {}}

        create_table_columns = ",".join(["{} {}".format(altered_mappings[col_name]['ColumnName'],
                                                        self.convert_data_type_staging(
                                                            altered_mappings[col_name]['DataType'],
                                                            self.staging_data_type_mapping, altered_mappings[col_name]))
                                         for
                                         col_name in
                                         altered_mappings])

        stg_table_path = "{}/data/{}/SDS/staging/{}/{}/{}".format(self.ADLS_URI_PREFIX,
                                                                  self.ENVIRONMENT_NAME,
                                                                  self.ssu_dict[
                                                                      self.source_ssu.lower()],
                                                                  self.source_system.lower(),
                                                                  self.source_table_name.lower())

        create_table_sql = "create table {}({}) USING PARQUET LOCATION '{}' ".format(self.stage_table_name,
                                                                                     create_table_columns,
                                                                                     stg_table_path)
        return create_table_sql

    def standardize_stagetable(self):
        create_stg_db = "create database if not exists  {}".format(self.stg_db_name)
        self.spark.sql(create_stg_db)
        drop_table = "drop table if exists {}".format(self.stage_table_name)
        self.logger.info(drop_table)
        self.spark.sql(drop_table)
        create_stage_table_sql = self.generate_create_stage_table()
        self.logger.info(create_stage_table_sql)
        self.spark.sql(create_stage_table_sql)

    def convert_data_type(self, data_type, data_type_mapping):
        if data_type in data_type_mapping.keys():
            return data_type_mapping[data_type]
        else:
            return data_type

    def convert_data_type_staging(self, data_type, data_type_mapping, column_json):
        if data_type.lower() == "decimal":
            return "decimal({},{})".format(column_json["MaxLength"], column_json["Format"]["DecimalPlace"])
        elif data_type in data_type_mapping.keys():
            return data_type_mapping[data_type]
        else:
            return data_type

    def standardize_standardtable(self):
        create_std_db = "create database if not exists  {}".format(self.std_db_name)
        self.spark.sql(create_std_db)

        drop_table = "drop table if exists {}".format(self.std_table_name)
        self.spark.sql(drop_table)
        create_table = self.generate_std_table_create_sql()
        print(create_table)
        self.logger.info(create_table)
        self.spark.sql(create_table)

    def generate_std_table_create_sql(self):
        schema_mappings = self.schema["SourceColumns"]
        altered_mappings = OrderedDict()
        for col_mapping in schema_mappings:
            col_name = col_mapping['ColumnName']
            if col_mapping['DataType'] == "TIMESTAMP":
                altered_mappings[col_name] = ColumnMapping(col_name, "TIMESTAMP", "")
                altered_mappings[col_name + "UTCDttm"] = ColumnMapping(col_name + "UTCDttm", "TIMESTAMP", "")
                altered_mappings[col_name + "MLTDttm"] = ColumnMapping(col_name + "MLTDttm", "TIMESTAMP", "")
            else:
                altered_mappings[col_name] = ColumnMapping(col_name, col_mapping['DataType'], "")
        altered_mappings["EffectiveStartUTCDttm"] = ColumnMapping("EffectiveStartUTCDttm", "TIMESTAMP", "")
        altered_mappings["FileId"] = ColumnMapping("FileId", "BIGINT", "")
        altered_mappings["FileLineNumber"] = ColumnMapping("FileLineNumber", "BIGINT", "")
        if self.utils.is_sequence_col_needed():
            altered_mappings["sequence"] = ColumnMapping("sequence", "INTEGER", "")

        altered_mappings["InsertTaskId"] = ColumnMapping("InsertTaskId", "INTEGER", "")
        create_table_columns = ",".join(["{} {}".format(altered_mappings[col_name].column_name,
                                                        self.convert_data_type(altered_mappings[col_name].data_type,
                                                                               self.standard_data_type_mapping)) for
                                         col_name in altered_mappings])
        std_table_path = "{}/data/{}/SDS/standardised/{}/{}/{}_BIDH{}_SDS_{}_WRK/{}_standardised".format(
            self.ADLS_URI_PREFIX, self.ENVIRONMENT_NAME, self.source_ssu.lower(), self.source_system.lower(),
            self.ENVIRONMENT_NAME,
            self.ssu_indicator, self.source_system.lower(), self.source_table_name.lower())
        create_table = "create table {}({}) USING PARQUET LOCATION '{}'".format(self.std_table_name,
                                                                                create_table_columns, std_table_path)
        return create_table

    def copy_from_stg_to_std(self):
        stg_to_std_sql = self.generate_stg_to_std_transform_sql()
        self.logger.info(stg_to_std_sql)
        # print(stg_to_std_sql)
        self.spark.sql(stg_to_std_sql)

    def get_timezone_for_column(self, column_mapping):
        if 'Format' in column_mapping.keys():
            if 'TimeZone' in column_mapping['Format'].keys():
                return column_mapping['Format']['TimeZone']
        return ""

    def generate_stg_to_std_transform_sql(self):
        altered_columns = []
        schema_mappings = self.schema["SourceColumns"]
        for column_mapping in schema_mappings:
            col_name = column_mapping['ColumnName']
            data_type = column_mapping['DataType']
            timezone = self.get_timezone_for_column(column_mapping)
            altered_columns.extend(self.convert_standardize_col(col_name, data_type, timezone))
        columns_to_select = ",".join(["{}".format(col_name) for col_name in altered_columns])
        if self.utils.is_sequence_col_needed():
            additional_cols = ",FileId,FileLineNumber,sequence,{}".format(self.TASK_INSTANCE_ID)
        else:
            additional_cols = ",FileId,FileLineNumber,{}".format(self.TASK_INSTANCE_ID)
        sql_effective_dttm = self.schema['CDC']['sql_EffectiveDttm']
        sql_effective_dttm_col = ""
        if len(sql_effective_dttm) == 0:
            sql_effective_dttm_col = "to_utc_timestamp(to_timestamp('{}','yyyyMMdd'),'Australia/Melbourne')".format(
                self.ODATE)
        elif sql_effective_dttm == 'EDWXPSTG_START_DT':
            sql_effective_dttm_col = "to_utc_timestamp({},'Australia/Melbourne')".format('EDWXPSTG_START_DT')
        else:
            sql_effective_dttm_col = self.get_utc_conv(sql_effective_dttm, self.get_timezone(sql_effective_dttm))
        sql_effective_dttm_col = sql_effective_dttm_col + " AS EffectiveStartUTCDttm"
        columns_to_select = columns_to_select + "," + sql_effective_dttm_col + additional_cols
        stg_to_std_sql = "insert overwrite table {} select {} from {} ".format(self.std_table_name, columns_to_select,
                                                                               self.stage_table_name)
        return stg_to_std_sql

    def get_timezone(self, column_name):
        schema_mappings = self.schema["SourceColumns"]
        for column_mapping in schema_mappings:
            col_name = column_mapping['ColumnName']
            if col_name == column_name:
                return column_mapping['Format']['TimeZone']

        return None

    def get_utc_expr(self, col_name, source_tz):
        return "{} as {}".format(self.get_utc_conv(col_name, source_tz), col_name + "UTCDttm")

    def get_mlt_expr(self, col_name, source_tz):
        return "from_utc_timestamp(to_utc_timestamp({},'{}'),'Australia/Melbourne') as {}".format(col_name, source_tz,
                                                                                                  col_name + "MLTDttm")

    def get_utc_conv(self, col_name, source_tz):
        return "to_utc_timestamp({},'{}')".format(col_name, source_tz)

    def convert_standardize_col(self, col_name, data_type, timezone):

        if data_type == "VARCHAR":
            return [col_name]
        elif data_type == "CHAR":
            return [col_name]
        elif data_type == "DECIMAL":
            return [col_name]
        elif data_type == "INTEGER":
            return [col_name]
        elif data_type == "SMALLINT":
            return [col_name]
        elif data_type == "BIGINT":
            return [col_name]
        elif data_type == "TIMESTAMP":
            source_tz = timezone
            if source_tz in self.tzmapping.keys():
                source_tz = self.tzmapping[source_tz]
            original_ts = self.get_utc_conv(col_name, source_tz) + " as " + col_name
            if source_tz in self.tzmapping.keys():
                source_tz = self.tzmapping[source_tz]
            utc_expr = self.get_utc_expr(col_name, source_tz)
            mlt_expr = self.get_mlt_expr(col_name, source_tz)
            return [original_ts, utc_expr, mlt_expr]
        elif data_type == "DATE":
            original_ts = "to_timestamp({},'yyyy-MM-dd') as {}".format(col_name, col_name)
            return [original_ts]
        elif data_type == "BOOLEAN":
            return ["cast({} as INTEGER)".format(col_name)]
        else:
            return [col_name]
