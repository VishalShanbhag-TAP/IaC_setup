from pyspark.sql import SparkSession

from common.common_utils import construct_job_config_objects
from standardization.standarization import Standardised

if __name__ == "__main__":
    standardization_config_json,schema_json,job_runtime_config,spark = construct_job_config_objects()
    data_standardizer = Standardised(standardization_config_json, schema_json, job_runtime_config, spark)
    data_standardizer.start_process()
