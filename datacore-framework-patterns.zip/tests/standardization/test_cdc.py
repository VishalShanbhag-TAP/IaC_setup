import json
import os
import datetime
import shutil

from pyspark.sql import SparkSession
from pyspark.sql import functions
from pyspark.sql.types import LongType, IntegerType, DecimalType, StringType

from changedatacapture.cdc import Cdc

employee_standard_json = './tests/standardization/employee_schema.json'
database_create = 'create database if not exists test_bidhr_sds_test_stg'
database_create_sfdc = 'create database if not exists test_bidhr_sds_sfdc_hist'
database_create_wrk = 'create database if not exists test_BIDHR_SDS_TEST_WRK'
database_create_hist = 'create database if not exists test_BIDHR_SDS_TEST_HIST'
cwd = os.getcwd().replace('\\', '/')
file_test = "file:///{}/TEST".format(cwd)

file_test_1 = "{}/TEST".format(cwd)
employee_keyed_table_path = "{}/datacore/data/test/SDS/keyed/test/test_BIDHR_SDS_TEST_WRK" \
                            "/employee_keyed".format(file_test)

employee_se_keyed_table_path = "{}/datacore/data/test/SDS/keyed/test/test_BIDHR_SDS_TEST_WRK" \
                               "/employee_se_keyed".format(file_test)

employee_standardized_table_path = "{}/datacore/data/test/SDS/standardised/test/test_BIDHR_SDS_TEST_WRK" \
                                   "/employee_standardised".format(file_test)

employee_history_table_path = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                              "/employee".format(file_test)

employee_temp_history_table_path = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                                   "/employee_temp".format(file_test)

employee_se_temp_history_table_path = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                                      "/employee_se_temp".format(file_test)

employee_temp_history_table_path_1 = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                                     "/employee_temp".format(file_test_1)

employee_keyed_table_create = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEE_keyed(empid STRING,empname STRING," \
                              "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                              "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                              "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn BIGINT," \
                              "smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                              "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER,dept_ik STRING, dept_lk " \
                              "STRING,cdc_flag STRING) USING PARQUET LOCATION " \
                              "'{}'".format(employee_keyed_table_path)

employee_se_keyed_table_create = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEE_SE_keyed(empid STRING,empname STRING," \
                                 "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                 "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                                 "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn BIGINT," \
                                 "smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                                 "FileId BIGINT,FileLineNumber BIGINT,sequence integer,InsertTaskId INTEGER,dept_ik STRING, dept_lk " \
                                 "STRING,cdc_flag STRING) USING PARQUET LOCATION " \
                                 "'{}'".format(employee_se_keyed_table_path)

employee_std_table_create = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEE_standardised(empid STRING,empname STRING," \
                            "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                            "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                            "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn BIGINT," \
                            "smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                            "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER " \
                            ", cdc_flag STRING) USING PARQUET LOCATION " \
                            "'{}'".format(employee_standardized_table_path)

employeep_standardized_table_path = "{}/datacore/data/test/SDS/standardised/test/test_BIDHR_SDS_TEST_WRK" \
                                    "/employeep_standardised".format(file_test)

employeep_std_table_create = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_standardised(empid STRING,empname STRING," \
                             "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                             "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                             "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn BIGINT," \
                             "smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                             "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER " \
                             ", cdc_flag STRING) USING PARQUET LOCATION " \
                             "'{}'".format(employeep_standardized_table_path)

employeep_seqinf_standardized_table_path = "{}/datacore/data/test/SDS/standardised/test/test_BIDHR_SDS_TEST_WRK" \
                                           "/employeep_seqenf_standardised".format(file_test)

employeep_seqinf_std_table_create = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_seqenf_standardised(empid STRING,empname STRING," \
                                    "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                    "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                                    "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn BIGINT," \
                                    "smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                                    "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER, sequence BIGINT, " \
                                    " cdc_flag STRING) USING PARQUET LOCATION " \
                                    "'{}'".format(employeep_seqinf_standardized_table_path)

employeep_full_standardized_table_path = "{}/datacore/data/test/SDS/standardised/test/test_BIDHR_SDS_TEST_WRK" \
                                         "/employeep_full_standardised".format(file_test)

employeep_full_std_table_create = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_full_standardised(empid STRING," \
                                  "empname STRING," \
                                  "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                  "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                                  "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn " \
                                  "BIGINT," \
                                  "smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                                  "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER " \
                                  ", cdc_flag STRING) USING PARQUET LOCATION " \
                                  "'{}'".format(employeep_full_standardized_table_path)

internaldenoise_table_name = "test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise"

employee_temp_history_table_create = "create table test_BIDHR_SDS_TEST_HIST.EMPLOYEE_TEMP(empid STRING,empname STRING," \
                                     "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                     "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm " \
                                     "TIMESTAMP," \
                                     "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn " \
                                     "BIGINT,smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                                     "effectiveendutcdttm TIMESTAMP,effectivestartutcdtprtnkey INTEGER," \
                                     "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER,dept_ik STRING, dept_lk " \
                                     "STRING,cdc_flag STRING) USING PARQUET PARTITIONED BY(effectivestartutcdtprtnkey) LOCATION" \
                                     "'{}'".format(employee_temp_history_table_path)

employee_se_temp_history_table_create = "create table test_BIDHR_SDS_TEST_HIST.EMPLOYEE_SE_TEMP(empid STRING,empname STRING," \
                                        "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                        "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm " \
                                        "TIMESTAMP," \
                                        "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn " \
                                        "BIGINT,smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                                        "effectiveendutcdttm TIMESTAMP,effectivestartutcdtprtnkey INTEGER," \
                                        "FileId BIGINT,FileLineNumber BIGINT,sequence integer,InsertTaskId INTEGER,dept_ik STRING, dept_lk " \
                                        "STRING,cdc_flag STRING) USING PARQUET PARTITIONED BY(effectivestartutcdtprtnkey) LOCATION" \
                                        "'{}'".format(employee_se_temp_history_table_path)

employeep_history_table_path = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                               "/employeep".format(file_test)

employeep_seqenf_history_table_path = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                                      "/employeep_seqenf".format(file_test)

employeep_temp_part_history_table_create = "create table test_BIDHR_SDS_TEST_HIST.EMPLOYEEP(empid STRING,empname STRING," \
                                           "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                           "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm " \
                                           "TIMESTAMP," \
                                           "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn " \
                                           "BIGINT,smallintcolumn INTEGER,datecolumn TIMESTAMP," \
                                           "cdc_flag STRING,FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER," \
                                           "effectivestartutcdttm TIMESTAMP, effectiveendutcdttm TIMESTAMP," \
                                           " publicationstartdttm TIMESTAMP," \
                                           "publicationenddttm TIMESTAMP,effectivestartutcdtprtnkey INTEGER) USING PARQUET " \
                                           " PARTITIONED BY(effectivestartutcdtprtnkey) LOCATION " \
                                           "'{}'".format(employeep_history_table_path)

employeep_seqenf_temp_part_history_table_create = "create table test_BIDHR_SDS_TEST_HIST.EMPLOYEEP_SEQENF(empid STRING,empname STRING," \
                                                  "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                                  "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm " \
                                                  "TIMESTAMP," \
                                                  "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn " \
                                                  "BIGINT,smallintcolumn INTEGER,datecolumn TIMESTAMP," \
                                                  "cdc_flag STRING,FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER,SEQUENCE BIGINT," \
                                                  "effectivestartutcdttm TIMESTAMP, effectiveendutcdttm TIMESTAMP," \
                                                  " publicationstartdttm TIMESTAMP," \
                                                  "publicationenddttm TIMESTAMP,effectivestartutcdtprtnkey INTEGER) USING PARQUET " \
                                                  " PARTITIONED BY(effectivestartutcdtprtnkey) LOCATION " \
                                                  "'{}'".format(employeep_seqenf_history_table_path)

employeep_full_history_table_path = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                                    "/employeep_full_TEMP".format(file_test)

employeep_full_temp_part_history_table_create = "create table test_BIDHR_SDS_TEST_HIST.EMPLOYEEP_full_TEMP(empid " \
                                                "STRING,empname STRING,empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                                                "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP," \
                                                "creationdateUTCDttm " \
                                                "TIMESTAMP," \
                                                "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING," \
                                                "bigintcolumn " \
                                                "BIGINT,smallintcolumn INTEGER,datecolumn TIMESTAMP," \
                                                "cdc_flag STRING,FileId BIGINT,FileLineNumber BIGINT,InsertTaskId " \
                                                "INTEGER," \
                                                "effectivestartutcdttm TIMESTAMP, effectiveendutcdttm TIMESTAMP," \
                                                " publicationstartdttm TIMESTAMP," \
                                                "publicationenddttm TIMESTAMP,effectivestartutcdtprtnkey INTEGER) " \
                                                "USING PARQUET " \
                                                " PARTITIONED BY(effectivestartutcdtprtnkey) LOCATION " \
                                                "'{}'".format(employeep_full_history_table_path)

employeep_full_table_path = "{}/datacore/data/test/SDS/hist/test/test_BIDHR_SDS_TEST_HIST" \
                            "/employeep_full".format(file_test)

employeep_full_table_create = "create table test_BIDHR_SDS_TEST_HIST.EMPLOYEEP_full(empid " \
                              "STRING,empname STRING,empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                              "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP," \
                              "creationdateUTCDttm " \
                              "TIMESTAMP," \
                              "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING," \
                              "bigintcolumn " \
                              "BIGINT,smallintcolumn INTEGER,datecolumn TIMESTAMP," \
                              "cdc_flag STRING,FileId BIGINT,FileLineNumber BIGINT,InsertTaskId " \
                              "INTEGER," \
                              "effectivestartutcdttm TIMESTAMP, effectiveendutcdttm TIMESTAMP," \
                              " publicationstartdttm TIMESTAMP," \
                              "publicationenddttm TIMESTAMP,effectivestartutcdtprtnkey INTEGER) " \
                              "USING PARQUET " \
                              " PARTITIONED BY(effectivestartutcdtprtnkey) LOCATION " \
                              "'{}'".format(employeep_full_table_path)


def spark():
    return SparkSession.builder \
        .master("local") \
        .appName("InternalDenoise_Test") \
        .getOrCreate()


def test_changedatacapture_multirow_withsamevalue():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empdept", functions.lit(None).cast(StringType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))

    assert cdc_denoise_df.count() == 1


def setup_tables(spark2):
    spark2.sql(database_create_wrk)
    spark2.sql(database_create)
    spark2.sql(database_create_sfdc)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_keyed"))
    spark2.sql(employee_keyed_table_create)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_SE_keyed"))
    spark2.sql(employee_se_keyed_table_create)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_standardised"))
    spark2.sql(employee_std_table_create)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_standardised"))
    spark2.sql(employeep_std_table_create)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_seqenf_standardised"))
    spark2.sql(employeep_seqinf_std_table_create)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_full_standardised"))
    spark2.sql(employeep_full_std_table_create)
    spark2.sql(database_create_hist)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_HIST.EMPLOYEE_TEMP"))
    spark2.sql(employee_temp_history_table_create)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_HIST.EMPLOYEEP_TEMP"))
    print(employeep_temp_part_history_table_create)
    shutil.rmtree(employee_temp_history_table_path_1)
    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_HIST.EMPLOYEEP"))
    spark2.sql(employeep_temp_part_history_table_create)

    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_HIST.EMPLOYEEP_SEQENF"))
    spark2.sql(employeep_seqenf_temp_part_history_table_create)

    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_HIST.EMPLOYEEP_full_TEMP"))
    spark2.sql(employeep_full_temp_part_history_table_create)

    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_HIST.EMPLOYEE_SE_TEMP"))
    spark2.sql(employee_se_temp_history_table_create)

    if os.path.exists(employee_temp_history_table_path_1):
        shutil.rmtree(employee_temp_history_table_path_1)

    if os.path.exists(employee_temp_history_table_path_1):
        shutil.rmtree(employee_temp_history_table_path_1)

    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_WRK.employee_denoised"))
    spark2.sql("drop table if exists {}".format("test_bidhr_sds_test_wrk.employee_internaldenoise"))

    spark2.sql("drop table if exists {}".format("test_BIDHR_SDS_TEST_HIST.EMPLOYEEP_full"))
    spark2.sql(employeep_full_table_create)


def test_changedatacapture_insert_followed_by_delete():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.legacy.allowNonEmptyLocationInCTAS", True).config("spark.sql.catalogImplementation",
                                                                            "hive").enableHiveSupport().getOrCreate()

    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)
    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 2
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    second_row = cdc_int_denoise_df.collect()[1]
    assert second_row["SDSMETA_IS_FIRST"] == 0
    assert second_row["SDSMETA_IS_CHANGE"] == 1


def test_changedatacapture_sequenceenabled_insert_followed_by_delete():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)
    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_sequenceenforcing_cdc.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_se_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 2
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    second_row = cdc_int_denoise_df.collect()[1]
    assert second_row["SDSMETA_IS_FIRST"] == 0
    assert second_row["SDSMETA_IS_CHANGE"] == 1


def test_changedatacapture_delete_followed_by_insert():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)
    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "INSERT"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 2
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    second_row = cdc_int_denoise_df.collect()[1]
    assert second_row["SDSMETA_IS_FIRST"] == 0
    assert second_row["SDSMETA_IS_CHANGE"] == 1


def test_changedatacapture_delete_followed_by_delete():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)
    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 2
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    second_row = cdc_int_denoise_df.collect()[1]
    assert second_row["SDSMETA_IS_FIRST"] == 0
    assert second_row["SDSMETA_IS_CHANGE"] == 1


def test_changedatacapture_delete_followed_by_delete_without_cdcflag():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)
    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1


def test_changedatacapture_multiple_rows_followed_by_delete():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)
    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"},

        {"empid": "2", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "DELETE"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 2
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1


def test_changedatacapture_changeoperationvalue_not_in_changeoperationignore():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)
    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "UU"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 0


def test_dummy():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()


def test_changedatacapture_final_output_multirow_different_values_for_tl():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_tl.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "1000",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 2
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    second_row = cdc_int_denoise_df.collect()[1]
    assert second_row["SDSMETA_IS_FIRST"] == 0
    assert second_row["SDSMETA_IS_CHANGE"] == 1

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))
    assert cdc_denoise_df.count() == 2
    assert cdc_denoise_df.first()["empdept"] == "100"

    cdc_affectedrecords_df = spark2.sql("select * from {} ".format(changedatacapture.get_affectedrecords_table_name()))
    cdc_affectedrecords_df.show()
    assert cdc_affectedrecords_df.count() == 2
    assert cdc_affectedrecords_df.first()["empdept"] == "100"

    cols = spark2.sql("select * from {} ".format(changedatacapture.get_stitched_table_name())).schema

    cols_to_exclude = ['publicationenddttm', 'effectiveendutcdttm']
    # for col in cols.fields:
    #     print(col.name)
    #     if col.name not in cols_to_exclude:
    #         df = spark2.sql("select {} from {} ".format(col.name, changedatacapture.get_stitched_table_name()))
    #         print(str(df.first()[col.name]))
    #         print(str(df.collect()[1][col.name]))

    select_cols = []
    for col in cols.fields:
        if col.name not in cols_to_exclude:
            select_cols.append(col.name)

    select_cols_str = ",".join(col for col in select_cols)
    cdc_stitchedrecords_df = spark2.sql(
        "select {} from {} ".format(select_cols_str, changedatacapture.get_stitched_table_name()))
    cdc_stitchedrecords_df.show()
    assert cdc_stitchedrecords_df.count() == 2
    assert cdc_stitchedrecords_df.first()["empid"] == "1"


def test_changedatacapture_final_output_multirow_same_values_for_tl():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_tl.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))
    assert cdc_denoise_df.count() == 1
    assert cdc_denoise_df.first()["empdept"] == "100"

    cdc_affectedrecords_df = spark2.sql("select * from {} ".format(changedatacapture.get_affectedrecords_table_name()))
    cdc_affectedrecords_df.show()
    assert cdc_affectedrecords_df.count() == 1
    assert cdc_affectedrecords_df.first()["empdept"] == "100"

    cols = spark2.sql("select * from {} ".format(changedatacapture.get_stitched_table_name())).schema

    cols_to_exclude = ['publicationenddttm', 'effectiveendutcdttm']
    # for col in cols.fields:
    #     print(col.name)
    #     if col.name not in cols_to_exclude:
    #         df = spark2.sql("select {} from {} ".format(col.name, changedatacapture.get_stitched_table_name()))
    #         print(str(df.first()[col.name]))
    #         print(str(df.collect()[1][col.name]))

    select_cols = []
    for col in cols.fields:
        if col.name not in cols_to_exclude:
            select_cols.append(col.name)

    select_cols_str = ",".join(col for col in select_cols)
    cdc_stitchedrecords_df = spark2.sql(
        "select {} from {} ".format(select_cols_str, changedatacapture.get_stitched_table_name()))
    cdc_stitchedrecords_df.show()
    assert cdc_stitchedrecords_df.count() == 1
    assert cdc_stitchedrecords_df.first()["empid"] == "1"


def test_changedatacapture_final_output_multirow_matchingvalue_with_history_for_tl():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_tl.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    emp_tmp_df = emp_tmp_df.withColumn("effectiveendutcdttm",
                                       functions.expr("cast('9999-12-31 23:59:59' as timestamp)"))
    emp_tmp_df = emp_tmp_df.withColumn("effectivestartutcdtprtnkey", functions.lit(20210831))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", emp_tmp_df.FileId.cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(500))
    emp_tmp_df.repartition(1).write.format("parquet").partitionBy("effectivestartutcdtprtnkey").mode("overwrite") \
        .save(employee_temp_history_table_path)
    print(employee_history_table_path)
    spark2.sql("msck repair table {} ".format(changedatacapture.get_history_table_name()))
    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1
    cdc_int_denoise_df.show()

    print(changedatacapture.get_history_table_name())
    spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name())).show()

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))
    assert cdc_denoise_df.count() == 0

    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name()))
    cdc_temp_history_df.show()
    assert cdc_temp_history_df.count() == 1


def test_changedatacapture_final_output_singlerow_nonmatchingvalue_with_history_for_tl():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_tl.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "101",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    emp_tmp_df = emp_tmp_df.withColumn("empdept", functions.lit("100"))
    emp_tmp_df = emp_tmp_df.withColumn("effectiveendutcdttm",
                                       functions.expr("cast('9999-12-31 23:59:59' as timestamp)"))
    emp_tmp_df = emp_tmp_df.withColumn("effectivestartutcdtprtnkey", functions.lit(20210831))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", emp_tmp_df.FileId.cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(500))
    emp_tmp_df.repartition(1).write.format("parquet").partitionBy("effectivestartutcdtprtnkey").mode("overwrite").save(
        employee_temp_history_table_path)

    spark2.sql("msck repair table {} ".format(changedatacapture.get_history_table_name()))
    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))
    assert cdc_denoise_df.count() == 1

    cdc_aff_df = spark2.sql("select * from {} ".format(changedatacapture.get_affectedrecords_table_name()))
    assert cdc_aff_df.count() == 2

    cdc_sti_df = spark2.sql("select * from {} ".format(changedatacapture.get_stitched_table_name()))
    assert cdc_sti_df.count() == 2

    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name()))
    cdc_temp_history_df.show()
    assert cdc_temp_history_df.count() == 1


def test_changedatacapture_final_output_multirow_same_values_for_tl():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_tl.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"},
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))
    assert cdc_denoise_df.count() == 1
    assert cdc_denoise_df.first()["empdept"] == "100"

    cdc_affectedrecords_df = spark2.sql("select * from {} ".format(changedatacapture.get_affectedrecords_table_name()))
    cdc_affectedrecords_df.show()
    assert cdc_affectedrecords_df.count() == 1
    assert cdc_affectedrecords_df.first()["empdept"] == "100"

    cols = spark2.sql("select * from {} ".format(changedatacapture.get_stitched_table_name())).schema

    cols_to_exclude = ['publicationenddttm', 'effectiveendutcdttm']
    # for col in cols.fields:
    #     print(col.name)
    #     if col.name not in cols_to_exclude:
    #         df = spark2.sql("select {} from {} ".format(col.name, changedatacapture.get_stitched_table_name()))
    #         print(str(df.first()[col.name]))
    #         print(str(df.collect()[1][col.name]))

    select_cols = []
    for col in cols.fields:
        if col.name not in cols_to_exclude:
            select_cols.append(col.name)

    select_cols_str = ",".join(col for col in select_cols)
    cdc_stitchedrecords_df = spark2.sql(
        "select {} from {} ".format(select_cols_str, changedatacapture.get_stitched_table_name()))
    cdc_stitchedrecords_df.show()
    assert cdc_stitchedrecords_df.count() == 1
    assert cdc_stitchedrecords_df.first()["empid"] == "1"


def test_changedatacapture_final_output_singlerow_matchingvalue_with_history_for_tl():
    spark2 = SparkSession.builder.master("local").appName("NoKeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_tl.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "dept_ik": "1", "dept_lk": "2", "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_keyed_table_path)

    emp_tmp_df = emp_tmp_df.withColumn("effectiveendutcdttm",
                                       functions.expr("cast('9999-12-31 23:59:59' as timestamp)"))
    emp_tmp_df = emp_tmp_df.withColumn("effectivestartutcdtprtnkey", functions.lit(20210831))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", emp_tmp_df.FileId.cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(500))
    emp_tmp_df.repartition(1).write.format("parquet").partitionBy("effectivestartutcdtprtnkey").mode("overwrite").save(
        employee_temp_history_table_path)

    spark2.sql("msck repair table {} ".format(changedatacapture.get_history_table_name()))
    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))
    assert cdc_denoise_df.count() == 0

    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name()))
    cdc_temp_history_df.show()
    assert cdc_temp_history_df.count() == 1


def test_wihtout_keymapping_changedatacapture_final_output_multirow_nonmatchingvalue_with_history_for_tl():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_nokeymap_cdc_tl.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "101",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_standardized_table_path)

    emp_tmp_df = emp_tmp_df.withColumn("empdept", functions.lit("100"))
    emp_tmp_df = emp_tmp_df.withColumn("effectiveendutcdttm",
                                       functions.expr("cast('9999-12-31 23:59:59' as timestamp)"))
    emp_tmp_df = emp_tmp_df.withColumn("effectivestartutcdtprtnkey", functions.lit(20210831))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", emp_tmp_df.FileId.cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(500))
    emp_tmp_df.repartition(1).write.format("parquet").partitionBy("effectivestartutcdtprtnkey").mode("overwrite").save(
        employee_temp_history_table_path)

    spark2.sql("select * from {} ".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_standardised")).show()

    spark2.sql("msck repair table {} ".format(changedatacapture.get_history_table_name()))

    changedatacapture.start_process()
    cdc_int_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_internaldenoise_table_name()))

    assert cdc_int_denoise_df.count() == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_CHANGE"] == 1
    assert cdc_int_denoise_df.first()["SDSMETA_IS_FIRST"] == 1

    cdc_denoise_df = spark2.sql("select * from {} ".format(changedatacapture.get_denoise_table_name()))
    assert cdc_denoise_df.count() == 1

    cdc_aff_df = spark2.sql("select * from {} ".format(changedatacapture.get_affectedrecords_table_name()))
    assert cdc_aff_df.count() == 2

    cdc_sti_df = spark2.sql("select * from {} ".format(changedatacapture.get_stitched_table_name()))
    assert cdc_sti_df.count() == 2

    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name()))
    cdc_temp_history_df.show()
    assert cdc_temp_history_df.count() == 1
    print(changedatacapture.generate_merge_statement())


def test_wihtout_keymapping_changedatacapture_multirow_nonmatchingvalue_with_history_for_insertonly():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_insertonly.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "101",
         "bigintcolumn": 100, "smallintcolumn": 23,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employeep_standardized_table_path)
    print(" finished setting up standardized table")
    spark2.sql("select * from {} ".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_standardised")).show()

    emp_tmp_df = emp_tmp_df.withColumn("empdept", functions.lit("100"))
    emp_tmp_df = emp_tmp_df.withColumn("effectiveendutcdttm",
                                       functions.expr("cast('9999-12-31 23:59:59' as timestamp)"))
    emp_tmp_df = emp_tmp_df.withColumn("effectivestartutcdtprtnkey", functions.lit(20210831))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000000))
    # emp_tmp_df = emp_tmp_df.withColumn("FileId", emp_tmp_df.FileId.cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(500))
    emp_tmp_df.repartition(1).write.format("parquet").partitionBy("effectivestartutcdtprtnkey").mode("overwrite").save(
        employeep_history_table_path)

    print(" number of records in history table....")

    spark2.sql("msck repair table {}".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df.show()

    changedatacapture.start_process()
    print(" number of records in history table post process....")
    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df.show()
    assert cdc_temp_history_df.count() == 2


def test_wihtout_changedatacapture_multirow_nonmatchingvalue_with_history_for_insertonly_seqenf():
    spark2 = SparkSession.builder.master("local").appName("cdctest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_insertonly_seqenf.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "101",
         "bigintcolumn": 100, "smallintcolumn": 23,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000001))
    emp_tmp_df = emp_tmp_df.withColumn("sequence", functions.lit(99).cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000001))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(501))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employeep_seqinf_standardized_table_path)
    print(" finished setting up standardized table")
    spark2.sql("select * from {} ".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_seqenf_standardised")).show()

    emp_tmp_df = emp_tmp_df.withColumn("empdept", functions.lit("100"))
    emp_tmp_df = emp_tmp_df.withColumn("effectiveendutcdttm",
                                       functions.expr("cast('9999-12-31 19:30:00' as timestamp)"))
    emp_tmp_df = emp_tmp_df.withColumn("effectivestartutcdtprtnkey", functions.lit(20210831))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("sequence", functions.lit(100).cast(LongType()))
    # emp_tmp_df = emp_tmp_df.withColumn("FileId", emp_tmp_df.FileId.cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(500))
    emp_tmp_df.repartition(1).write.format("parquet").partitionBy("effectivestartutcdtprtnkey").mode("overwrite").save(
        employeep_seqenf_history_table_path)

    print(" number of records in history table....")

    spark2.sql("msck repair table {}".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df.show()

    changedatacapture.start_process()
    print(" number of records in history table post process....")
    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df.show()
    cdc_temp_history_df = cdc_temp_history_df.drop("effectiveendutcdttm")
    cdc_temp_history_df = cdc_temp_history_df.drop("publicationenddttm")
    assert cdc_temp_history_df.first()["SEQUENCE"] == 99
    assert cdc_temp_history_df.collect()[1]["SEQUENCE"] == 100
    assert cdc_temp_history_df.count() == 2


def test_wihtout_keymapping_changedatacapture_multirow_nonmatchingvalue_with_history_for_full():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest"). \
        config("spark.sql.catalogImplementation", "hive").enableHiveSupport().getOrCreate()
    # spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    setup_tables(spark2)

    # spark2.sql("test_BIDHR_SDS_TEST_WRK.EMPLOYEE_InternalDenoise")
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open('./tests/standardization/employee_schema_all_datatypes_cdc_full.json')
    schema_json = json.load(f)
    changedatacapture = Cdc(schema_json, job_runtime_config, spark2)
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "101",
         "bigintcolumn": 100, "smallintcolumn": 23,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0),
         "cdc_flag": "I"}
    ]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employeep_full_standardized_table_path)
    print(" finished setting up standardized table")
    spark2.sql("select * from {} ".format("test_BIDHR_SDS_TEST_WRK.EMPLOYEEP_full_standardised")).show()

    emp_tmp_df = emp_tmp_df.withColumn("empdept", functions.lit("100"))
    emp_tmp_df = emp_tmp_df.withColumn("effectiveendutcdttm",
                                       functions.expr("cast('9999-12-31 23:59:59' as timestamp)"))
    emp_tmp_df = emp_tmp_df.withColumn("effectivestartutcdtprtnkey", functions.lit(20210831))
    emp_tmp_df = emp_tmp_df.withColumn("FileId", functions.lit(50000000000))
    # emp_tmp_df = emp_tmp_df.withColumn("FileId", emp_tmp_df.FileId.cast(LongType()))
    emp_tmp_df = emp_tmp_df.withColumn("FileLineNumber", functions.lit(50000000000))
    emp_tmp_df = emp_tmp_df.withColumn("InsertTaskId", functions.lit(500))
    emp_tmp_df.repartition(1).write.format("parquet").partitionBy("effectivestartutcdtprtnkey").mode("overwrite").save(
        employeep_full_history_table_path)

    print(" number of records in history table....")

    spark2.sql("msck repair table {}".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name_final()))
    cdc_temp_history_df.show()

    changedatacapture.start_process()
    print(" number of records in history table post process....")
    print(changedatacapture.generate_merge_statement())
    cdc_temp_history_df = spark2.sql("select * from {} ".format(changedatacapture.get_history_table_name_final()))
    print(" cdc_temp_history_df count....")
    print(cdc_temp_history_df)
    cdc_temp_history_df.show()
    # assert cdc_temp_history_df.count() == 1


