import datetime

import pytest
import json
import os

from pyspark.sql.types import StringType, TimestampType, LongType, BooleanType, IntegerType, DecimalType

from pyspark.sql import SparkSession

from standardization.standarization import Standardised

employee_standard_json = './tests/standardization/employee_schema.json'
australia_default_tz = 'Australia/Melbourne'
database_create = 'create database if not exists test_bidhr_sds_test_stg'
database_create_wrk = 'create database if not exists test_BIDHR_SDS_TEST_WRK'
database_create_sfdc = 'create database if not exists test_bidhr_sds_sfdc_hist'
database_create_sfdc_wrk = 'create database if not exists test_bidhr_sds_sfdc_wrk'
employee_select_query = 'select * from test_BIDHR_SDS_TEST_WRK.EMPLOYEE_Standardised'
cwd = os.getcwd().replace('\\', '/')
# cwd = os.getcwd()
file_test = "file:///{}/TEST".format(cwd)
file_path = "file:///{}/TEST/data/test/SDS".format(cwd)
date_value = "2021-01-01 01:00:00"
date_value_2 = "2021-08-12 01:00:00"

employee_table_output_path = file_path + "/staging/retail/test/employee"


def spark():
    return SparkSession.builder \
        .master("local") \
        .appName("StandardizerTest") \
        .getOrCreate()


def test_load_tzmapping_file():
    get_standardization_config()
    print(os.getcwd())
    tzjson = Standardised.load_timezone_mapping('./tests//standardization/tzmapping_config.json')
    print(type(tzjson.keys()))
    assert len(tzjson.keys()) == 1


def test_tzmapping_contents():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    tzjson = standardiser.get_tz_mapping()
    # print(type(tzjson.keys()))
    assert len(tzjson.keys()) == 1
    assert australia_default_tz in tzjson.keys()
    assert australia_default_tz == tzjson[australia_default_tz]


def test_stage_table_name_retail():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stage_table_name = standardiser.get_stage_table_name()
    expected_stage_table_name = 'test_BIDHR_SDS_TEST_STG.EMPLOYEE'
    assert returned_stage_table_name == expected_stage_table_name


def test_stage_table_name_enterprise():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_enterprise.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stage_table_name = standardiser.get_stage_table_name()
    expected_stage_table_name = 'test_BIDHE_SDS_TEST_STG.DEPT'
    assert returned_stage_table_name == expected_stage_table_name


def test_stage_table_name_wholesale():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_wholesale.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stage_table_name = standardiser.get_stage_table_name()
    expected_stage_table_name = 'test_BIDHW_SDS_TEST_STG.DEPT'
    assert returned_stage_table_name == expected_stage_table_name


def get_standardization_config():
    standardization_config = json.loads('{ "tzmapping":"./tests/standardization/tzmapping_config.json"}')
    return standardization_config


def test_stage_table_name_corporate():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_corporate.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stage_table_name = standardiser.get_stage_table_name()
    expected_stage_table_name = 'test_BIDHC_SDS_TEST_STG.DEPT'
    assert returned_stage_table_name == expected_stage_table_name


def test_stage_table_name_transient():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_transient.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stage_table_name = standardiser.get_stage_table_name()
    expected_stage_table_name = 'test_BIDHT_SDS_TEST_STG.DEPT'
    assert returned_stage_table_name == expected_stage_table_name


def test_std_table_name_retail():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_std_table_name = standardiser.get_std_table_name()
    expected_std_table_name = 'test_BIDHR_SDS_TEST_WRK.EMPLOYEE_Standardised'
    assert returned_std_table_name == expected_std_table_name


def test_std_table_name_enterprise():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_enterprise.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_std_table_name = standardiser.get_std_table_name()
    expected_std_table_name = 'test_BIDHE_SDS_TEST_WRK.DEPT_Standardised'
    assert returned_std_table_name == expected_std_table_name


def test_std_table_name_wholesale():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_wholesale.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_std_table_name = standardiser.get_std_table_name()
    expected_std_table_name = 'test_BIDHW_SDS_TEST_WRK.DEPT_Standardised'
    assert returned_std_table_name == expected_std_table_name


def test_std_table_name_corporate():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_corporate.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_std_table_name = standardiser.get_std_table_name()
    expected_std_table_name = 'test_BIDHC_SDS_TEST_WRK.DEPT_Standardised'
    assert returned_std_table_name == expected_std_table_name


def test_std_table_name_transient():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': ''}

    f = open('./tests/standardization/dept_schema_transient.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_std_table_name = standardiser.get_std_table_name()
    expected_std_table_name = 'test_BIDHT_SDS_TEST_WRK.DEPT_Standardised'
    assert returned_std_table_name == expected_std_table_name


def test_create_stg_table_sql():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': 'ADLS://TEST'}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stg_table_sql = standardiser.generate_create_stage_table()
    print(returned_stg_table_sql)
    expected_stg_table_sql = "create table test_BIDHR_SDS_TEST_STG.EMPLOYEE(empid STRING,empname STRING," \
                             "empage STRING,empsal STRING,joiningdate STRING,creationdate STRING,ispermanent BOOLEAN," \
                             "FileId BIGINT,FileLineNumber BIGINT) USING PARQUET LOCATION " \
                             "'ADLS://TEST/data/test/SDS/staging/retail/test/employee' "
    assert returned_stg_table_sql.replace("\n", '') == expected_stg_table_sql.rstrip("\n")


def test_create_std_table_sql():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': 'ADLS://TEST'}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stg_table_sql = standardiser.generate_std_table_create_sql()
    print(returned_stg_table_sql)
    expected_std_table_sql = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEE_Standardised(empid STRING,empname STRING," \
                             "empage STRING,empsal STRING,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                             "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                             "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,EffectiveStartUTCDttm TIMESTAMP," \
                             "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER) USING PARQUET " \
                             "LOCATION " \
                             "'ADLS://TEST/data/test/SDS/standardised/retail/test/test_BIDHR_SDS_test_WRK" \
                             "/employee_standardised'"
    print(len(expected_std_table_sql))
    assert returned_stg_table_sql == expected_std_table_sql


def test_stg_table_create():
    spark2 = SparkSession.builder.master("local").appName("StandardizerTest").getOrCreate()
    standardization_config = get_standardization_config()
    spark2.sql(database_create)

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': file_test}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, spark2)
    standardiser.standardize_stagetable()

    df = spark2.sql("select * from test_BIDHR_SDS_TEST_STG.EMPLOYEE")
    assert len(df.schema) == 9
    assert type(df.schema["empid"].dataType) == StringType
    assert type(df.schema["empname"].dataType) == StringType
    assert type(df.schema["empage"].dataType) == StringType
    assert type(df.schema["empsal"].dataType) == StringType
    assert type(df.schema["joiningdate"].dataType) == StringType
    assert type(df.schema["creationdate"].dataType) == StringType
    assert type(df.schema["ispermanent"].dataType) == BooleanType
    assert type(df.schema["FileLineNumber"].dataType) == LongType
    assert type(df.schema["FileId"].dataType) == LongType

    # df.show()


def test_std_table_create():
    spark2 = SparkSession.builder.master("local").appName("StandardizerTest").getOrCreate()
    standardization_config = get_standardization_config()
    spark2.sql(database_create_wrk)

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': file_test}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, spark2)
    standardiser.standardize_standardtable()

    df = spark2.sql(employee_select_query)
    assert len(df.schema) == 15
    assert type(df.schema["empid"].dataType) == StringType
    assert type(df.schema["empname"].dataType) == StringType
    assert type(df.schema["empage"].dataType) == StringType
    assert type(df.schema["empsal"].dataType) == StringType
    assert type(df.schema["joiningdate"].dataType) == TimestampType
    assert type(df.schema["joiningdateUTCDttm"].dataType) == TimestampType
    assert type(df.schema["joiningdateMLTDttm"].dataType) == TimestampType
    assert type(df.schema["creationdate"].dataType) == TimestampType
    assert type(df.schema["creationdateUTCDttm"].dataType) == TimestampType
    assert type(df.schema["creationdateMLTDttm"].dataType) == TimestampType
    assert type(df.schema["ispermanent"].dataType) == IntegerType
    assert type(df.schema["EffectiveStartUTCDttm"].dataType) == TimestampType
    assert type(df.schema["FileLineNumber"].dataType) == LongType
    assert type(df.schema["FileId"].dataType) == LongType
    assert type(df.schema["InsertTaskId"].dataType) == IntegerType


def test_std_table_insertion():
    spark2 = SparkSession.builder.master("local").appName("StandardizerTest").getOrCreate()
    standardization_config = get_standardization_config()
    spark2.sql(database_create_wrk)
    spark2.sql(database_create)

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': file_test}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, spark2)
    standardiser.standardize_stagetable()
    standardiser.standardize_standardtable()
    employee_data = [
        {"empid": "1", "empname": "one", "empage": "40", "empsal": "12", "joiningdate": date_value,
         "creationdate": date_value, "ispermanent": True}]
    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_table_output_path)
    standardiser.copy_from_stg_to_std()
    df_result = spark2.sql(employee_select_query)
    assert df_result.count() == 1
    assert df_result.first()['empid'] == "1"
    assert df_result.first()['empname'] == "one"
    assert df_result.first()['empage'] == "40"
    assert df_result.first()['empsal'] == "12"
    assert df_result.first()['joiningdate'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateUTCDttm'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateMLTDttm'] == datetime.datetime(2021, 1, 1, 1, 00, 00)

    assert df_result.first()['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)


def test_std_table_insertion_multi_row():
    spark2 = SparkSession.builder.master("local").appName("StandardizerTest").getOrCreate()
    standardization_config = get_standardization_config()
    spark2.sql(database_create_wrk)
    spark2.sql(database_create)

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, spark2)
    standardiser.standardize_stagetable()
    standardiser.standardize_standardtable()
    employee_data = [
        {"empid": "1", "empname": "one", "empage": "40", "empsal": "12", "joiningdate": date_value,
         "creationdate": date_value, "ispermanent": True},
        {"empid": "2", "empname": "two", "empage": "41", "empsal": "15", "joiningdate": date_value_2,
         "creationdate": date_value, "ispermanent": True}]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_table_output_path)
    standardiser.copy_from_stg_to_std()
    df_result = spark2.sql(employee_select_query)
    df_result.show()
    assert df_result.count() == 2
    assert df_result.first()['empid'] == "1"
    assert df_result.first()['empname'] == "one"
    assert df_result.first()['empage'] == "40"
    assert df_result.first()['empsal'] == "12"
    assert df_result.first()['joiningdate'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateUTCDttm'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateMLTDttm'] == datetime.datetime(2021, 1, 1, 1, 00, 00)

    assert df_result.first()['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)
    assert df_result.first()['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)

    assert df_result.first()['EffectiveStartUTCDttm'] == datetime.datetime(2021, 8, 11, 14, 0, 0)
    second_row = df_result.collect()[1]
    assert second_row['empid'] == "2"
    assert second_row['empname'] == "two"
    assert second_row['empage'] == "41"
    assert second_row['empsal'] == "15"
    assert second_row['joiningdate'] == datetime.datetime(2021, 8, 11, 15, 0)
    assert second_row['joiningdateUTCDttm'] == datetime.datetime(2021, 8, 11, 15, 0)
    assert second_row['joiningdateMLTDttm'] == datetime.datetime(2021, 8, 12, 1, 00, 00)

    assert second_row['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert second_row['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert second_row['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)


def test_std_table_insertion_multi_row_cdc_custom_date():
    spark2 = SparkSession.builder.master("local").appName("StandardizerTest").getOrCreate()
    standardization_config = get_standardization_config()
    spark2.sql(database_create_wrk)
    spark2.sql(database_create)
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}
    f = open('./tests/standardization/employee_schema_cdc_joiningdate.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, spark2)
    standardiser.standardize_stagetable()
    standardiser.standardize_standardtable()
    employee_data = [
        {"empid": "1", "empname": "one", "empage": "40", "empsal": "12", "joiningdate": date_value,
         "creationdate": date_value, "ispermanent": True},
        {"empid": "2", "empname": "two", "empage": "41", "empsal": "15", "joiningdate": date_value_2,
         "creationdate": date_value, "ispermanent": True}]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df.printSchema()
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_table_output_path)
    standardiser.copy_from_stg_to_std()
    df_result = spark2.sql(employee_select_query)
    df_result.show()
    assert df_result.count() == 2
    assert df_result.first()['empid'] == "1"
    assert df_result.first()['empname'] == "one"
    assert df_result.first()['empage'] == "40"
    assert df_result.first()['empsal'] == "12"
    assert df_result.first()['joiningdate'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateUTCDttm'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateMLTDttm'] == datetime.datetime(2021, 1, 1, 1, 00, 00)

    assert df_result.first()['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)
    assert df_result.first()['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)

    assert df_result.first()['EffectiveStartUTCDttm'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    second_row = df_result.collect()[1]
    assert second_row['empid'] == "2"
    assert second_row['empname'] == "two"
    assert second_row['empage'] == "41"
    assert second_row['empsal'] == "15"
    assert second_row['joiningdate'] == datetime.datetime(2021, 8, 11, 15, 0)
    assert second_row['joiningdateUTCDttm'] == datetime.datetime(2021, 8, 11, 15, 0)
    assert second_row['joiningdateMLTDttm'] == datetime.datetime(2021, 8, 12, 1, 00, 00)

    assert second_row['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert second_row['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert second_row['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)


def test_std_table_insertion_multi_row_cdc_custom_date_alldatatypes():
    spark2 = SparkSession.builder.master("local").appName("StandardizerTest").getOrCreate()
    standardization_config = get_standardization_config()
    spark2.sql(database_create_wrk)
    spark2.sql(database_create)
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}
    f = open('./tests/standardization/employee_schema_all_datatypes.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, spark2)
    standardiser.standardize_stagetable()
    standardiser.standardize_standardtable()
    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0, "joiningdate": date_value,
         "creationdate": date_value, "ispermanent": True, "empdept": "dept", "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": "2021-11-12"},
        {"empid": "2", "empname": "two", "empage": 51, "empsal": 25.0, "joiningdate": date_value_2,
         "creationdate": date_value, "ispermanent": True, "empdept": "dept1", "smallintcolumn": 28, "bigintcolumn": 110,
         "datecolumn": "2021-11-12"}]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(11, 5)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))
    # emp_tmp_df = emp_tmp_df.withColumn("datecolumn", emp_tmp_df.datecolumn.cast(DateType()))
    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_table_output_path)
    standardiser.copy_from_stg_to_std()

    df_result = spark2.sql(employee_select_query)
    df_result.show()
    df_result.printSchema()
    assert df_result.schema.fields[2].dataType == IntegerType()
    assert df_result.schema.fields[12].dataType == LongType()
    assert df_result.schema.fields[13].dataType == IntegerType()
    assert df_result.count() == 2
    assert df_result.first()['empid'] == "1"
    assert df_result.first()['empname'] == "one"
    assert df_result.first()['empage'] == 50
    assert df_result.first()['empsal'] == 20.0
    assert df_result.first()['empdept'] == "dept"
    assert df_result.first()['smallintcolumn'] == 23
    assert df_result.first()['bigintcolumn'] == 100
    assert df_result.first()['datecolumn'] == datetime.datetime(2021, 11, 12, 0, 0, 0)
    assert df_result.first()['joiningdate'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateUTCDttm'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert df_result.first()['joiningdateMLTDttm'] == datetime.datetime(2021, 1, 1, 1, 00, 00)

    assert df_result.first()['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert df_result.first()['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)
    assert df_result.first()['creationdateMLTDttm'] == datetime.datetime(2021, 1, 1, 6, 30, 00)

    assert df_result.first()['EffectiveStartUTCDttm'] == datetime.datetime(2021, 8, 11, 14, 0, 0)


def test_create_stg_table_sql_uppercase_env():
    standardization_config = get_standardization_config()

    job_runtime_config = {'ENVIRONMENT_NAME': 'TEST', 'TASK_INSTANCE_ID': '1', 'ODATE': 'yyyyddmm',
                          'ADLS_URI_PREFIX': 'ADLS://TEST'}

    f = open(employee_standard_json)
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, None)
    returned_stg_table_sql = standardiser.generate_create_stage_table()
    print(returned_stg_table_sql)
    expected_stg_table_sql = "create table TEST_BIDHR_SDS_TEST_STG.EMPLOYEE(empid STRING,empname STRING," \
                             "empage STRING,empsal STRING,joiningdate STRING,creationdate STRING,ispermanent BOOLEAN," \
                             "FileId BIGINT,FileLineNumber BIGINT) USING PARQUET LOCATION " \
                             "'ADLS://TEST/data/TEST/SDS/staging/retail/test/employee' "
    assert returned_stg_table_sql.replace("\n", '') == expected_stg_table_sql.rstrip("\n")


def test_std_table_insertion_account_custom_date_alldatatypes():
    spark2 = SparkSession.builder.master("local").appName("Account").getOrCreate()
    standardization_config = get_standardization_config()
    spark2.sql(database_create_sfdc_wrk)
    spark2.sql(database_create_sfdc)
    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}
    f = open('./tests/standardization/account_schema_all_datatypes_cdc.json')
    schema_json = json.load(f)

    standardiser = Standardised(standardization_config, schema_json, job_runtime_config, spark2)
    standardiser.standardize_stagetable()
    standardiser.standardize_standardtable()

