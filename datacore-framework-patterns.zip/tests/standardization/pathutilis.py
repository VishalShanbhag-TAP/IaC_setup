#package com.telstra.datacore.utils

from azure.keyvault.keys import keyvaults
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession
from pyspark.sql.window import Window



object PathUtils extends Logging {

  def mountDir(adlsContainer : StringType, adlsAccount : String, directory: String, mountPath : String, configs: Map[String, String]) = {

    logInfo(s"[APP_LOG] - mountDir: Storage Account: " + adlsAccount)
    logInfo(s"[APP_LOG] - mountDir: Container: " + adlsContainer)
    logInfo(s"[APP_LOG] - mountDir: Directory: " + directory)

    dbutils.fs.mount(
      source = s"""abfss://${adlsContainer}@${adlsAccount}.dfs.core.windows.net/${directory}""",
      mountPoint = mountPath,
      extraConfigs = configs)
  }

  def mountDatacorePaths(props: Properties): Unit = {

    logInfo(s"[APP_LOG] - mountDatacorePaths: Storage Account: " + props.getProperty("storageAccount"))
    logInfo(s"[APP_LOG] - mountDatacorePaths: Container: " + props.getProperty("container"))
    logInfo(s"[APP_LOG] - mountDatacorePaths: Directory: " + props.getProperty("directory"))

    spApplicationId = AzureKeyVaultService.getAppKeyVltSecret("ipnd-databricks-scope","databricks-mount-sp-client-id")
    spApplicationSecret = AzureKeyVaultService.getAppKeyVltSecret("ipnd-databricks-scope","databricks-mount-sp-client-secret")
    spTenantId = AzureKeyVaultService.getAppKeyVltSecret("ipnd-databricks-scope","databricks-mount-sp-tenant-id")

    logInfo(s"[APP_LOG] - mountDatacorePaths: Application Id: " + spApplicationId)
    logInfo(s"[APP_LOG] - mountDatacorePaths: Application Secret: " + spApplicationSecret)
    logInfo(s"[APP_LOG] - mountDatacorePaths: Tenant Id: " + spTenantId)

    config = Map(
      "fs.azure.account.auth.type" -> "OAuth",
      "fs.azure.account.oauth.provider.type" -> "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
      "fs.azure.account.oauth2.client.id" -> spApplicationId,
      "fs.azure.account.oauth2.client.secret" -> spApplicationSecret,
      "fs.azure.account.oauth2.client.endpoint" -> s"""https://login.microsoftonline.com/${spTenantId}/oauth2/token"""
    )

    #loop through each tier and create mount point if not existing already
    mountPath = s"""/mnt/${props.getProperty("container").toLowerCase}/${props.getProperty("directory").toLowerCase}"""
    if (!dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(mountPath)) {
      logInfo(s"[APP_LOG] - mountDatacorePaths Mounting ${mountPath} for the first time..")

      mountDir(props.getProperty("container"),
        props.getProperty("storageAccount"),
        props.getProperty("directory"),
        mountPath,
        config)
      }
      elif
      {
        logInfo(s"[APP_LOG] - mountDatacorePaths:Mount path: ${mountPath} exists already..")
      }
    }
}