import pytest
import pyspark
from pyspark.sql import SparkSession
from increment import increment_df


def test_answer():
    spark = SparkSession.builder.master("local").appName("Test").getOrCreate()
    print(type(spark))
    data = [{"counter": 1}]
    df = spark.createDataFrame(data)

    df1 = increment_df(df, "counter")
    assert df1.first()['counter'] == 2
