import datetime
import json
import os

from pyspark.sql import SparkSession
from pyspark.sql import functions
from pyspark.sql.types import LongType, IntegerType, DecimalType

from keymapping.keymapping import KeyMapping

employee_standard_json = './tests/standardization/employee_schema.json'
australia_default_tz = 'Australia/Melbourne'
database_create = 'create database if not exists test_bidhr_sds_test_stg'
database_create_wrk = 'create database if not exists test_BIDHR_SDS_TEST_WRK'
employee_select_query = 'select * from test_BIDHR_SDS_TEST_WRK.EMPLOYEE_Standardised'
cwd = os.getcwd().replace('\\', '/')
# cwd = os.getcwd()
file_test = "file:///{}/TEST".format(cwd)
file_path = "file:///{}/TEST/datacore/data/test/SDS".format(cwd)

employee_std_table_path = "{}/datacore/data/test/SDS/standardised/test/test_BIDHR_SDS_TEST_WRK" \
                          "/employee_standardised".format(file_test)

employee_std_table_create = "create table test_BIDHR_SDS_TEST_WRK.EMPLOYEE_Standardised(empid STRING,empname STRING," \
                            "empage INTEGER,empsal DECIMAL,joiningdate TIMESTAMP,joiningdateUTCDttm TIMESTAMP," \
                            "joiningdateMLTDttm TIMESTAMP,creationdate TIMESTAMP,creationdateUTCDttm TIMESTAMP," \
                            "creationdateMLTDttm TIMESTAMP,ispermanent INTEGER,empdept STRING,bigintcolumn BIGINT," \
                            "smallintcolumn INTEGER,datecolumn TIMESTAMP,EffectiveStartUTCDttm TIMESTAMP," \
                            "FileId BIGINT,FileLineNumber BIGINT,InsertTaskId INTEGER) USING PARQUET LOCATION " \
                            "'{}'".format(employee_std_table_path)

km_dept_std_table_path = "{}/datacore/data/test/SDS/km/test_bidht_sds_kmp.db" \
                         "/dept_km".format(file_test)

lkm_dept_std_table_path = "{}/datacore/data/test/SDS/km/test_BIDHT_SDS_LK.db" \
                          "/dept_lk".format(file_test)

keyed_table_name = "test_BIDHR_SDS_TEST_WRK.EMPLOYEE_keyed"

def spark():
    return SparkSession.builder \
        .master("local") \
        .appName("KeyMapperTest") \
        .getOrCreate()


def test_keyed_table_insertion_multi_row_cdc_custom_date_alldatatypes():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest").\
        config("spark.sql.catalogImplementation","hive").enableHiveSupport().getOrCreate()
    #def_expiry_date = datetime.datetime(9999, 12, 31, 23, 59, 59, tzinfo=datetime.timezone.utc)
    spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    spark2.sql(database_create_wrk)
    spark2.sql(database_create)
    spark2.sql("create database if not exists test_bidht_sds_kmp")
    spark2.sql("create database if not exists test_bidht_sds_lk")

    spark2.sql("drop table if exists test_BIDHR_SDS_TEST_WRK.EMPLOYEE_Standardised")
    spark2.sql("drop table if exists test_BIDHT_SDS_KMP.dept_km")
    spark2.sql("drop table if exists test_bidht_sds_lk.dept_lk")
    spark2.sql(employee_std_table_create)

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}
    f = open('./tests/standardization/employee_schema_all_datatypes.json')
    schema_json = json.load(f)

    keymapping = KeyMapping(schema_json, job_runtime_config, spark2)

    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0), }]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_std_table_path)

    dept_Data = [{"IkValue": "1", "deptname": "test", "SourceColumn1": "100", "DomainId": 10,
                  "PublicationEndDttm": "9999-12-31 23:59:59"},
                 {"IkValue": "120", "deptname": "test", "SourceColumn1": "100", "DomainId": 10,
                  "PublicationEndDttm": "2020-12-31 23:59:59"}
                 ]

    print(datetime.datetime.max)
    dept_tmp_df = spark2.createDataFrame(dept_Data)
    dept_tmp_df.show()
    dept_tmp_df = dept_tmp_df.withColumn("PublicationEndDttm",functions.expr("cast (PublicationEndDttm as timestamp)"))
    dept_tmp_df.repartition(1).write.option("path", km_dept_std_table_path).format("parquet").mode(
        "overwrite").saveAsTable("test_BIDHT_SDS_KMP.dept_km")

    dept_Data_lk = [{"LkValue": "2", "deptname": "test", "SourceColumn": "100"}]

    dept_Data_lk_df = spark2.createDataFrame(dept_Data_lk)
    dept_Data_lk_df.repartition(1).write.option("path", lkm_dept_std_table_path).format("parquet").mode(
        "overwrite").saveAsTable("test_BIDHT_SDS_LK.dept_lk")

    keymapping.copy_from_std_to_keyed()

    keyed_table_df = spark2.sql("select * from {}".format(keyed_table_name))
    assert keyed_table_df.count() == 1
    assert keyed_table_df.first()['dept_ik'] == "1"
    assert keyed_table_df.first()['dept_lk'] == "2"
    assert keyed_table_df.first()['empid'] == "1"
    assert keyed_table_df.first()['empname'] == "one"
    assert keyed_table_df.first()['empage'] == 50
    assert keyed_table_df.first()['empsal'] == 20.0

    assert keyed_table_df.first()['joiningdate'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert keyed_table_df.first()['joiningdateUTCDttm'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert keyed_table_df.first()['joiningdateMLTDttm'] == datetime.datetime(2021, 1, 1, 1, 00, 00)

    assert keyed_table_df.first()['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert keyed_table_df.first()['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert keyed_table_df.first()['creationdateMLTDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)

    assert keyed_table_df.first()['ispermanent'] == 1
    assert keyed_table_df.first()['empdept'] == "100"
    assert keyed_table_df.first()['smallintcolumn'] == 23
    assert keyed_table_df.first()['bigintcolumn'] == 100

    assert keyed_table_df.first()['datecolumn'] == datetime.datetime(2021, 11, 12, 0, 0, 0)
    assert keyed_table_df.first()['EffectiveStartUTCDttm'] == datetime.datetime(2021, 8, 11, 14, 0, 0)


def test_keyed_table_without_iks_insertion_multi_row_cdc_custom_date_alldatatypes():
    spark2 = SparkSession.builder.master("local").appName("KeyMapperTest").\
        config("spark.sql.catalogImplementation","hive").enableHiveSupport().getOrCreate()
    #def_expiry_date = datetime.datetime(9999, 12, 31, 23, 59, 59, tzinfo=datetime.timezone.utc)
    spark2.sql("select cast('9999-12-31 23:59:59' as timestamp)").show()
    spark2.sql(database_create_wrk)
    spark2.sql(database_create)
    spark2.sql("create database if not exists test_bidht_sds_kmp")
    spark2.sql("create database if not exists test_bidht_sds_lk")

    spark2.sql("drop table if exists test_BIDHR_SDS_TEST_WRK.EMPLOYEE_Standardised")
    spark2.sql("drop table if exists test_BIDHT_SDS_KMP.dept_km")
    spark2.sql("drop table if exists test_bidht_sds_lk.dept_lk")
    spark2.sql(employee_std_table_create)

    job_runtime_config = {'ENVIRONMENT_NAME': 'test', 'TASK_INSTANCE_ID': '1', 'ODATE': '20210812',
                          'ADLS_URI_PREFIX': file_test}
    f = open('./tests/standardization/employee_schema_all_datatypes_without_iks.json')
    schema_json = json.load(f)

    keymapping = KeyMapping(schema_json, job_runtime_config, spark2)

    employee_data = [
        {"empid": "1", "empname": "one", "empage": 50, "empsal": 20.0,
         "joiningdate": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateUTCDttm": datetime.datetime(2020, 12, 31, 14, 0, 0),
         "joiningdateMLTDttm": datetime.datetime(2021, 1, 1, 1, 00, 00),
         "creationdate": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateUTCDttm": datetime.datetime(2020, 12, 31, 19, 30, 0),
         "creationdateMLTDttm": datetime.datetime(2020, 12, 31, 19, 30, 0), "ispermanent": 1,
         "empdept": "100",
         "smallintcolumn": 23, "bigintcolumn": 100,
         "datecolumn": datetime.datetime(2021, 11, 12, 0, 0, 0),
         "EffectiveStartUTCDttm": datetime.datetime(2021, 8, 11, 14, 0, 0), }]

    emp_tmp_df = spark2.createDataFrame(employee_data)
    emp_tmp_df = emp_tmp_df.withColumn("empage", emp_tmp_df.empage.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("ispermanent", emp_tmp_df.ispermanent.cast(IntegerType()))
    emp_tmp_df = emp_tmp_df.withColumn("empsal", emp_tmp_df.empsal.cast(DecimalType(10, 0)))
    emp_tmp_df = emp_tmp_df.withColumn("smallintcolumn", emp_tmp_df.smallintcolumn.cast(IntegerType()))

    emp_tmp_df.repartition(1).write.format("parquet").mode("overwrite").save(employee_std_table_path)

    dept_Data = [{"IkValue": "1", "deptname": "test", "SourceColumn1": "100", "DomainId": 10,
                  "PublicationEndDttm": "9999-12-31 23:59:59"},
                 {"IkValue": "120", "deptname": "test", "SourceColumn1": "100", "DomainId": 10,
                  "PublicationEndDttm": "2020-12-31 23:59:59"}
                 ]

    print(datetime.datetime.max)
    dept_tmp_df = spark2.createDataFrame(dept_Data)
    dept_tmp_df.show()
    dept_tmp_df = dept_tmp_df.withColumn("PublicationEndDttm",functions.expr("cast (PublicationEndDttm as timestamp)"))
    dept_tmp_df.repartition(1).write.option("path", km_dept_std_table_path).format("parquet").mode(
        "overwrite").saveAsTable("test_BIDHT_SDS_KMP.dept_km")

    dept_Data_lk = [{"LkValue": "2", "deptname": "test", "SourceColumn": "100"}]

    dept_Data_lk_df = spark2.createDataFrame(dept_Data_lk)
    dept_Data_lk_df.repartition(1).write.option("path", lkm_dept_std_table_path).format("parquet").mode(
        "overwrite").saveAsTable("test_BIDHT_SDS_LK.dept_lk")

    keymapping.copy_from_std_to_keyed()

    keyed_table_df = spark2.sql("select * from {}".format(keyed_table_name))
    assert keyed_table_df.count() == 1
    assert keyed_table_df.first()['empid'] == "1"
    assert keyed_table_df.first()['empname'] == "one"
    assert keyed_table_df.first()['empage'] == 50
    assert keyed_table_df.first()['empsal'] == 20.0

    assert keyed_table_df.first()['joiningdate'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert keyed_table_df.first()['joiningdateUTCDttm'] == datetime.datetime(2020, 12, 31, 14, 0, 0)
    assert keyed_table_df.first()['joiningdateMLTDttm'] == datetime.datetime(2021, 1, 1, 1, 00, 00)

    assert keyed_table_df.first()['creationdate'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert keyed_table_df.first()['creationdateUTCDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)
    assert keyed_table_df.first()['creationdateMLTDttm'] == datetime.datetime(2020, 12, 31, 19, 30, 0)

    assert keyed_table_df.first()['ispermanent'] == 1
    assert keyed_table_df.first()['empdept'] == "100"
    assert keyed_table_df.first()['smallintcolumn'] == 23
    assert keyed_table_df.first()['bigintcolumn'] == 100

    assert keyed_table_df.first()['datecolumn'] == datetime.datetime(2021, 11, 12, 0, 0, 0)
    assert keyed_table_df.first()['EffectiveStartUTCDttm'] == datetime.datetime(2021, 8, 11, 14, 0, 0)
