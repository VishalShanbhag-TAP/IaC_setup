from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window


def increment_df(df1, columnname):
    df2 = df1.withColumn(columnname, F.col(columnname) + 1)
    return df2
