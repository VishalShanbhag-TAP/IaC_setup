import os
import logging
import logging.config


class KeyMapping:
    def __init__(self, schema_json, job_runtime_config, spark):

        print(os.getcwd())
        self.schema = schema_json
        self.spark = spark

        self.job_runtime_config = job_runtime_config

        self.ENVIRONMENT_NAME = job_runtime_config['ENVIRONMENT_NAME']
        self.ADLS_URI_PREFIX = job_runtime_config['ADLS_URI_PREFIX']

        self.logger = logging.getLogger(__name__)
        logging.basicConfig(level=logging.INFO, format="%(asctime)s: [%(levelname)s]: %(name)s: %(message)s")

        self.ssu_dict = {'retail': 'retail', 'wholesale': 'wholesale', 'transient': 'transient',
                         'corporate': 'corporate', 'enterprise': 'reference'}

        self.ssu_mapping_short_code = {'retail': 'R', 'wholesale': 'W', 'transient': 'T', 'corporate': 'C',
                                       'enterprise': 'E'}

        self.source_ssu = self.schema['Scope']['SSU']
        self.ssu_indicator = self.ssu_mapping_short_code[self.schema['Scope']['SSU']]
        self.source_system = self.schema['Scope']['SourceSystem']
        self.source_table_name = self.schema['Scope']['TableName']

        self.keyed_db_name = "{}_BIDH{}_SDS_{}_WRK".format(self.ENVIRONMENT_NAME,
                                                           self.ssu_indicator,
                                                           self.source_system)
        self.keyed_table_name = "{}_BIDH{}_SDS_{}_WRK.{}_keyed".format(self.ENVIRONMENT_NAME,
                                                                       self.ssu_indicator,
                                                                       self.source_system,
                                                                       self.source_table_name)
        self.keyed_table_relative_path = "{}/data/{}/SDS/keyed/{}/{}/{}_BIDH{}_SDS_{}_WRK/{" \
                                         "}_keyed".format(self.ADLS_URI_PREFIX, self.ENVIRONMENT_NAME,
                                                          self.source_ssu, self.source_system.lower(),
                                                          self.ENVIRONMENT_NAME, self.ssu_indicator,
                                                          self.source_system,
                                                          self.source_table_name.lower())

        self.std_table_name = self.std_table_name = "{}_BIDH{}_SDS_{}_WRK.{}_Standardised".format(self.ENVIRONMENT_NAME,
                                                                                                  self.ssu_indicator,
                                                                                                  self.source_system,
                                                                                                  self.source_table_name)

    def get_std_table_name(self):
        return self.std_table_name

    def get_keyed_table_name(self):
        return self.keyed_table_name

    def get_keyed_table_relative_path(self):
        return self.keyed_table_relative_path

    def start_process(self):
        self.copy_from_std_to_keyed()

    def create_keyed_table(self):
        create_std_db = "create database if not exists  {}".format(self.keyed_db_name)
        self.spark.sql(create_std_db)

        drop_table = "drop table if exists {}".format(self.keyed_table_name)
        self.spark.sql(drop_table)

    def copy_from_std_to_keyed(self):
        self.spark.sql("drop table if exists {}".format(self.keyed_table_name))
        std_to_keyed_sql = self.generate_std_to_keyed_transform_sql()
        self.logger.info(std_to_keyed_sql)
        # print(stg_to_std_sql)
        self.spark.sql(std_to_keyed_sql)

    def get_value(self, input_dict, key, default_value):
        if key in input_dict.keys():
            return input_dict[key]
        else:
            return default_value

    def generate_std_to_keyed_transform_sql(self):
        altered_columns = []
        schema_mappings = self.schema["SourceColumns"]
        join_clauses = []

        for column_mapping in schema_mappings:
            col_name = column_mapping['ColumnName']
            # data_type = column_mapping['DataType']
            col_nullable = self.get_value(column_mapping, 'Nullable', False)
            col_default = self.get_value(column_mapping, 'DefaultVal', None)
            # Handle default values for columns
            if col_nullable and col_default is not None:
                altered_columns.append("COALESCE({},'{}')".format(col_name, col_default))
            else:
                altered_columns.append("{}".format(col_name))
            if column_mapping['DataType'] == "TIMESTAMP":
                altered_columns.append("{}UTCDttm".format(col_name))
                altered_columns.append("{}MLTDttm".format(col_name))

        ik_mappings = self.schema["IntegrationKeys"]
        ik_counter = 0
        for ik_mapping in ik_mappings:
            ik_table_col_name = "IKMAP{}.IkValue".format(ik_counter)
            ik_col_integration_key = ik_mapping["col_IntegrationKey"]
            tbl_Keymap = ik_mapping["tbl_Keymap"]
            val_KeyDomain = ik_mapping["val_KeyDomain"]
            sql_NaturalKeys = ik_mapping["sql_NaturalKeys"]
            altered_columns.append("COALESCE({},-1) as {}".format(ik_table_col_name, ik_col_integration_key))
            join_clause_1 = " LEFT JOIN {}_BIDHT_SDS_KMP.{} IKMAP{}".format(self.ENVIRONMENT_NAME, tbl_Keymap,
                                                                            ik_counter)
            key_counter = 1
            join_clause_2 = ""
            for natural_key in sql_NaturalKeys:
                on_clause_for_column = " UPPER(TRIM(SRC.{})) = UPPER(IKMAP{}.SourceColumn{})".format(natural_key,
                                                                                                     ik_counter,
                                                                                                     key_counter)
                if key_counter == 1:
                    join_clause_2 = join_clause_2 + " {} {} ".format("ON", on_clause_for_column)
                else:
                    join_clause_2 = join_clause_2 + " {} {} ".format("AND", on_clause_for_column)

                key_counter = key_counter + 1
            join_clause_2 = join_clause_2 + " AND IKMAP{}.DomainId = {} ".format(ik_counter, val_KeyDomain)
            join_clause_2 = join_clause_2 + "AND IKMAP{}.PublicationEndDttm = cast('9999-12-31 23:59:59' as timestamp)".format(
                ik_counter)

            join_clause = join_clause_1 + join_clause_2
            join_clauses.append(join_clause)
            ik_counter = ik_counter + 1

        lk_mappings = self.schema["LightKeys"]["GeneratedLightKeys"]
        lk_counter = 0
        for lk_mapping in lk_mappings:
            lk_table_col_name = "LKMAP{}.LkValue".format(lk_counter)
            lk_col_light_key = lk_mapping["col_LightKey"]
            tbl_LightKeyMap = self.get_value(lk_mapping, "tbl_LightKeyMap", lk_col_light_key)
            sql_NaturalKeys = lk_mapping["sql_NaturalKeys"]
            altered_columns.append("COALESCE({},-1) as {}".format(lk_table_col_name, lk_col_light_key))
            join_clause_1 = " LEFT JOIN {}_BIDHT_SDS_LK.{} LKMAP{}".format(self.ENVIRONMENT_NAME, tbl_LightKeyMap,
                                                                           lk_counter)

            natural_key = sql_NaturalKeys[0]
            on_clause_for_column = " ON UPPER(TRIM(SRC.{})) = UPPER(LKMAP{}.SourceColumn)".format(natural_key,
                                                                                                  lk_counter)
            join_clause = join_clause_1 + on_clause_for_column
            join_clauses.append(join_clause)
            lk_counter = lk_counter + 1

        altered_columns.append("SRC.EffectiveStartUTCDttm")
        altered_columns.append("SRC.FileId")
        altered_columns.append("SRC.FileLineNumber")
        # if self.utils.is_sequence_col_needed():
        #     altered_columns.append("SRC.sequence")
        altered_columns.append("SRC.InsertTaskId")

        columns_to_select = ",".join(["{}".format(col_name) for col_name in altered_columns])
        join_clause_sql = " ".join(["{}".format(join_clause) for join_clause in join_clauses])

        std_to_keyed_sql = "CREATE TABLE {} USING PARQUET LOCATION '{}' AS select {} from {} SRC  {}  ".format(
            self.keyed_table_name, self.keyed_table_relative_path, columns_to_select, self.std_table_name,
            join_clause_sql)
        print(std_to_keyed_sql)
        return std_to_keyed_sql
