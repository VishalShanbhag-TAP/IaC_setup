import argparse
import json

from pyspark.sql import SparkSession

from common.common_utils import construct_job_config_objects
from keymapping.keymapping import KeyMapping

if __name__ == "__main__":
    standardization_config_json, schema_json, job_runtime_config,spark = construct_job_config_objects()

    data_keymapping = KeyMapping(schema_json, job_runtime_config, spark)
    data_keymapping.start_process()
