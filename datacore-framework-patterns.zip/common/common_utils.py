import argparse
import base64
import json
import logging

from pyspark.sql import SparkSession


def parse_cmd_args():
    """
    Parse command line arguments
    :return: parsed arguments
    """
    cmd_parser = argparse.ArgumentParser(description="Data Core - Standardization Module")
    cmd_parser.add_argument("JOB_JSON_PATH", help="path to the job json ")
    cmd_parser.add_argument("SCHEMA_JSON", help="schema json to be used")
    cmd_parser.add_argument("JOB_NAME", help="name of the job ")
    cmd_parser.add_argument("ODATE", help="date to be used ")
    cmd_parser.add_argument("ENVIRONMENT", help="ENVIRONMENT name to be used")
    cmd_parser.add_argument("JOB_RUN_ID", help="JOB_RUN_ID corresponding to this job run")
    cmd_parser.add_argument("TASK_RUN_ID", help="TASK_RUN_ID corresponding to this job run")
    cmd_args = cmd_parser.parse_args()

    return cmd_args


def get_dbutils(spark):
    try:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)
    except ImportError:
        import IPython
        dbutils = IPython.get_ipython().user_ns["dbutils"]
    return dbutils


def get_storage_account_config(spark):
    dbutils = get_dbutils(spark)
    encoded_storage_account_config = dbutils.secrets.get("datacore-akv-scope", "datacore-storage-accounts")
    # decode from base64
    storage_account_config_json = json.loads(base64.b64decode(encoded_storage_account_config).decode('utf-8'))
    return storage_account_config_json


def construct_job_config_objects():
    args = parse_cmd_args()

    spark = SparkSession.builder.appName(args.JOB_NAME).enableHiveSupport().getOrCreate()

    storage_account_config = get_storage_account_config(spark)
    data_storage_account_url = storage_account_config["dataStorageAccount"]["url"]
    data_storage_account_container = storage_account_config["dataStorageAccount"]["container"]
    metadata_storage_account_url = storage_account_config["metadataStorageAccount"]["url"]
    metadata_storage_account_container = storage_account_config["metadataStorageAccount"]["container"]

    standardization_config = "/dbfs/FileStore/patterns/{}/standardization_config.json".format(args.ENVIRONMENT)
    standardization_config_json = json.load(open(standardization_config))

    schema_location = args.SCHEMA_JSON
    schema_json = load_json(spark, schema_location)
    adls_prefix = "abfss://{}@{}/app_root/bidh".format(data_storage_account_container,
                                                       data_storage_account_url.split("//")[1])
    job_runtime_config = {'ODATE': args.ODATE, 'TASK_INSTANCE_ID': args.TASK_RUN_ID,
                          'ADLS_URI_PREFIX': adls_prefix,
                          'ENVIRONMENT_NAME': args.ENVIRONMENT, 'JOB_NAME': args.JOB_NAME}
    return standardization_config_json, schema_json, job_runtime_config, spark


def get_logger(spark, module):
    if spark is None:
        return logging.getLogger(module)
    log4jLogger = spark._sc._jvm.org.apache.log4j
    return log4jLogger.LogManager.getLogger(module)


def load_json(spark, standardization_config):
    config_rdd = spark.sparkContext.wholeTextFiles(standardization_config)
    standardization_config_json = json.loads(config_rdd.first()[1])
    return standardization_config_json
