ssu_dict = {'retail': 'retail', 'wholesale': 'wholesale', 'transient': 'transient',
            'corporate': 'corporate', 'enterprise': 'reference'}

ssu_mapping_short_code = {'retail': 'R', 'wholesale': 'W', 'transient': 'T', 'corporate': 'C',
                          'enterprise': 'E'}


class Utils:
    def __init__(self, schema_json, job_runtime_config):
        self.schema = schema_json
        self.job_runtime_config = job_runtime_config

        self.ENVIRONMENT_NAME = job_runtime_config['ENVIRONMENT_NAME']
        self.TASK_RUN_ID = job_runtime_config['TASK_INSTANCE_ID']
        self.ADLS_URI_PREFIX = job_runtime_config['ADLS_URI_PREFIX']
        self.source_ssu = self.schema['Scope']['SSU']
        self.ssu_indicator = ssu_mapping_short_code[self.schema['Scope']['SSU']]
        self.source_system = self.schema['Scope']['SourceSystem']
        self.source_table_name = self.schema['Scope']['TableName']

    def get_internal_denoise_table(self):
        return "{}_BIDH{}_SDS_{}_WRK.{}_internaldenoise".format(self.ENVIRONMENT_NAME,
                                                                self.ssu_indicator,
                                                                self.source_system,
                                                                self.source_table_name)

    def get_internal_denoise_db_name(self):
        return "{}_BIDH{}_SDS_{}_WRK".format(self.ENVIRONMENT_NAME, self.ssu_indicator, self.source_system)

    def get_internal_denoise_relative_path(self):
        return "{}/data/{}/SDS/keyed/{}/{}_BIDH{}_SDS_{}_WRK/{" \
               "}_internaldenoise".format(self.ADLS_URI_PREFIX, self.ENVIRONMENT_NAME,
                                          self.source_system.lower(),
                                          self.ENVIRONMENT_NAME, self.ssu_indicator,
                                          self.source_system,
                                          self.source_table_name.lower())

    def get_denoise_table(self):
        return "{}_BIDH{}_SDS_{}_WRK.{}_denoised".format(self.ENVIRONMENT_NAME,
                                                         self.ssu_indicator,
                                                         self.source_system,
                                                         self.source_table_name)

    def get_denoise_db_name(self):
        return "{}_BIDH{}_SDS_{}_WRK".format(self.ENVIRONMENT_NAME, self.ssu_indicator, self.source_system)

    def get_denoise_relative_path(self):
        return "{}/data/{}/SDS/keyed/{}/{}_BIDH{}_SDS_{}_WRK/{" \
               "}_denoised".format(self.ADLS_URI_PREFIX, self.ENVIRONMENT_NAME,
                                   self.source_system.lower(),
                                   self.ENVIRONMENT_NAME, self.ssu_indicator,
                                   self.source_system,
                                   self.source_table_name.lower())

    def get_affectedrecords_relative_path(self):
        return "{}/data/{}/SDS/keyed/{}/{}_BIDH{}_SDS_{}_WRK/{" \
               "}_affectedrecords".format(self.ADLS_URI_PREFIX, self.ENVIRONMENT_NAME,
                                          self.source_system.lower(),
                                          self.ENVIRONMENT_NAME, self.ssu_indicator,
                                          self.source_system,
                                          self.source_table_name.lower())

    def get_affectedrecords_table(self):
        return "{}_BIDH{}_SDS_{}_WRK.{}_affectedrecords".format(self.ENVIRONMENT_NAME,
                                                                self.ssu_indicator,
                                                                self.source_system,
                                                                self.source_table_name)

    def get_stitchedrecords_relative_path(self):
        return "{}/data/{}/SDS/keyed/{}/{}_BIDH{}_SDS_{}_WRK/{" \
               "}_stitchedrecords".format(self.ADLS_URI_PREFIX, self.ENVIRONMENT_NAME,
                                          self.source_system.lower(),
                                          self.ENVIRONMENT_NAME, self.ssu_indicator,
                                          self.source_system,
                                          self.source_table_name.lower())

    def get_stitchedrecords_table(self):
        return "{}_BIDH{}_SDS_{}_WRK.{}_stitchedrecords".format(self.ENVIRONMENT_NAME,
                                                                self.ssu_indicator,
                                                                self.source_system,
                                                                self.source_table_name)

    def get_keyed_table_name(self):
        return "{}_BIDH{}_SDS_{}_WRK.{}_keyed".format(self.ENVIRONMENT_NAME,
                                                      self.ssu_indicator,
                                                      self.source_system,
                                                      self.source_table_name)

    def get_env_name(self):
        return self.job_runtime_config['ENVIRONMENT_NAME']

    def get_adls_uri_prefix(self):
        return self.job_runtime_config['ADLS_URI_PREFIX']

    def get_value(self, input_dict, key, default_value):
        if key in input_dict.keys():
            return input_dict[key]
        else:
            return default_value

    def get_changetype(self):
        return self.get_value(self.get_value(self.schema, 'CDC', {}), 'ChangeType', "")

    def get_sql_ChangeOperationValue(self):
        return self.get_value(self.get_value(self.schema, 'CDC', {}), 'sql_ChangeOperationValue', "'I'")

    def get_val_ChangeOperationDelete(self):
        return self.get_value(self.get_value(self.schema, 'CDC', {}), 'val_ChangeOperationDelete', ["D"])

    def get_val_ChangeOperationDeleteStr(self):
        return ','.join("'{}'".format(delete_val_str) for delete_val_str in self.get_val_ChangeOperationDelete())

    def get_sql_EffectiveEndDttm(self):
        self.get_value(self.get_value(self.schema, 'CDC', {}), 'sql_EffectiveEndDttm', 'NA')

    def get_all_cdc_columns_excluding_metadata(self, use_prefix):
        source_cols = self.schema["SourceColumns"]
        column_list = []
        cdc_config = self.get_value(self.schema, 'CDC', {})
        sql_EffectiveEndDttm = self.get_value(cdc_config, 'sql_EffectiveEndDttm', 'NA')
        for column in source_cols:
            data_type = self.get_value(column, 'DataType', None)
            cdc = self.get_value(column, 'CDC', 'keep')
            if cdc != 'drop':
                column_list.append(use_prefix + column["ColumnName"])
                if data_type == 'TIMESTAMP':
                    column_list.append(use_prefix + column["ColumnName"] + "UTCDttm")
                    column_list.append(use_prefix + column["ColumnName"] + "MLTDttm")

        if sql_EffectiveEndDttm != 'NA' and sql_EffectiveEndDttm != '':
            column_list.append(use_prefix + sql_EffectiveEndDttm)

        integration_keys = self.get_value(self.schema, 'IntegrationKeys', {})
        for ik in integration_keys:
            ik_col = self.get_value(ik, 'col_IntegrationKey', '')
            column_list.append(use_prefix + ik_col)

        light_keys = self.get_value(self.get_value(self.schema, 'LightKeys', {}), 'GeneratedLightKeys', [])
        for lk in light_keys:
            lk_col = self.get_value(lk, 'col_LightKey', '')
            column_list.append(use_prefix + lk_col)

        return column_list

    def get_std_table_name(self):
        return "{}_BIDH{}_SDS_{}_WRK.{}_Standardised".format(self.ENVIRONMENT_NAME, self.ssu_indicator,
                                                             self.source_system, self.source_table_name)

    def is_keymapping_necessary(self):
        integration_keys = self.get_value(self.schema, 'IntegrationKeys', {})
        light_keys = self.get_value(self.get_value(self.schema, 'LightKeys', {}), 'GeneratedLightKeys', [])
        print(len(light_keys) > 0)
        print(len(integration_keys) > 0)
        return len(integration_keys) > 0 or len(light_keys) > 0

    def get_all_cdc_columns_str(self, use_prefix):
        return ",".join(col for col in self.get_all_cdc_columns(use_prefix))

    def get_all_cdc_columns(self, use_prefix):
        column_list = self.get_all_cdc_columns_excluding_metadata(use_prefix)
        addl_cols = self.get_cdc_addl_cols()
        for addl_col in addl_cols:
            column_list.append("{}{}".format(use_prefix, addl_col))
        return column_list

    def get_cdc_addl_cols(self):
        column_list = []
        column_list.append("fileid")
        column_list.append("filelinenumber")
        if self.is_sequence_col_needed():
            column_list.append("sequence")
        column_list.append("inserttaskid")
        column_list.append("effectivestartutcdttm")
        column_list.append("effectiveendutcdttm")
        column_list.append("publicationstartdttm")
        column_list.append("publicationenddttm")
        column_list.append("effectivestartutcdtprtnkey")
        return column_list

    def get_cdc_config(self):
        return self.schema["CDC"]

    def get_source_columns(self):
        return self.schema["SourceColumns"]

    def get_change_keys_join(self, left, right):
        change_keys = self.get_change_keys()
        ck_col_conditions = []
        for ck in change_keys:
            ck_col_conditions.append("{}.{} = {}.{}".format(left, ck, right, ck))

        return "AND".join(ck_col_str for ck_col_str in ck_col_conditions)

    def get_change_keys(self):
        change_keys = self.get_value(self.get_value(self.schema, "CDC", {}), 'col_ChangeKeys', [])
        return change_keys

    def generate_change_keys_str(self, use_prefix):
        change_keys = self.get_change_keys()
        change_keys_str = ",".join("{}.{}".format(use_prefix, ck) for ck in change_keys)
        return change_keys_str

    def generate_change_keys_with_alias_for_merge(self, use_prefix):
        ck_prefix = self.get_ck_prefix()
        change_keys = self.get_change_keys()
        ck_changed = []
        counter = 0;
        for ck in change_keys:
            ck_changed.append("{}{} as {}_{}".format(use_prefix, ck, ck_prefix, counter))
            counter = counter + 1

        change_keys_str = ",".join(ck for ck in ck_changed)
        return change_keys_str

    def generate_null_change_keys_with_alias_for_merge(self):
        ck_prefix = self.get_ck_prefix()
        change_keys = self.get_change_keys()
        ck_changed = []
        counter = 0;
        for ck in change_keys:
            ck_changed.append("null as {}_{}".format(ck_prefix, counter))
            counter = counter + 1

        change_keys_str = ",".join(ck for ck in ck_changed)
        return change_keys_str

    def generate_change_keys_join_with_alias_for_merge(self, left_prefix, right_prefix):
        ck_prefix = self.get_ck_prefix()
        change_keys = self.get_change_keys()
        ck_changed = []
        counter = 0;
        for ck in change_keys:
            ck_changed.append(" {}.{} = {}.{}_{} ".format(left_prefix, ck, right_prefix, ck_prefix, counter))
            counter = counter + 1

        change_keys_str = "AND".join(ck for ck in ck_changed)
        return change_keys_str

    def get_ck_prefix(self):
        ck_prefix = "FWK_MERGE_KEY"
        return ck_prefix

    def get_history_table_name_delta(self):
        return "{}_BIDH{}_SDS_{}_HIST.{}_TEMP".format(self.ENVIRONMENT_NAME,
                                                      self.ssu_indicator,
                                                      self.source_system,
                                                      self.source_table_name)

    def get_history_table_name_final(self):
        return "{}_BIDH{}_SDS_{}_HIST.{}".format(self.ENVIRONMENT_NAME,
                                                 self.ssu_indicator,
                                                 self.source_system,
                                                 self.source_table_name)

    def get_all_cdc_source_columns_exclude_cks_apply_clause(self, left, right, clause):
        source_cols = self.get_source_columns()
        column_list = []
        change_keys = self.get_change_keys()
        for column in source_cols:
            cdc_config_for_col = self.get_value(column, 'CDC', 'keep')
            column_name = column["ColumnName"]
            if cdc_config_for_col == 'keep':
                if column_name not in change_keys:
                    column_list.append(" {}.{} {} {}.{} ".format(left, column_name, clause, right, column_name))

        return column_list

    def is_sequence_col_needed(self):
        file_config = self.get_value(self.schema, 'File', {})
        return self.get_value(file_config, "SequenceEnforced", False)

    def generate_drop_table_sql(self, table):
        return "drop table if exists {}".format(table)
