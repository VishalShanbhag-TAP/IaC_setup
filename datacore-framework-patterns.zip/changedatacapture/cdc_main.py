import argparse
import json

from pyspark.sql import SparkSession

from changedatacapture.cdc import Cdc
from common.common_utils import construct_job_config_objects

if __name__ == "__main__":
    standardization_config_json, schema_json, job_runtime_config, spark = construct_job_config_objects()

    data_changedatacapture = Cdc(schema_json, job_runtime_config, spark)
    data_changedatacapture.start_process()
    if data_changedatacapture.utils.get_changetype() != 'Insertonly':
        spark.sql(data_changedatacapture.generate_merge_statement())
        spark.sql(data_changedatacapture.generate_updated_records())
