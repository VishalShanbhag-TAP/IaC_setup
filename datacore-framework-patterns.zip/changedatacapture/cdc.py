import os

from common.utils import Utils
from common.common_utils import get_logger


class Cdc:
    def __init__(self, schema_json, job_runtime_config, spark):

        print(os.getcwd())
        self.schema = schema_json
        self.spark = spark

        self.effectivestartutcdttm_n = "n.effectivestartutcdttm"
        self.fileid_n = "n.fileid"
        self.filelinenumber_n = "n.filelinenumber"
        self.sequence_n = "n.sequence"
        self.inserttaskid_n = "n.inserttaskid"
        self.publicationstartdttm = "now() as publicationstartdttm"
        self.publicationenddttm = "cast('9999-12-31 23:59:59' as timestamp) as publicationenddttm"

        self.job_runtime_config = job_runtime_config

        self.logger = get_logger(spark, "CDC")
        # logging.basicConfig(level=logging.INFO, format="%(asctime)s: [%(levelname)s]: %(name)s: %(message)s")

        self.utils = Utils(schema_json, job_runtime_config)

        self.temp_table_name = self.utils.get_history_table_name_delta()

        self.internaldenoise_db_name = self.utils.get_internal_denoise_db_name()
        self.internaldenoise_table_name = self.utils.get_internal_denoise_table()
        self.denoise_table_name = self.utils.get_denoise_table()

        self.internaldenoise_relative_path = self.utils.get_internal_denoise_relative_path()

        self.keyed_table_name = self.utils.get_keyed_table_name()

        self.ODATE = job_runtime_config['ODATE']

    def get_keyed_table_name(self):
        return self.keyed_table_name

    def get_internaldenoise_table_name(self):
        return self.internaldenoise_table_name

    def get_denoise_table_name(self):
        return self.denoise_table_name

    def get_history_table_name(self):
        return self.utils.get_history_table_name_delta()

    def get_history_table_name_final(self):
        return self.utils.get_history_table_name_final()

    def get_affectedrecords_table_name(self):
        return self.utils.get_affectedrecords_table()

    def get_stitched_table_name(self):
        return self.utils.get_stitchedrecords_table()

    def start_process(self):
        if self.utils.get_changetype() == "Insertonly":
            self.keyed_table_to_temp_table()
        else:
            self.clean_temp_table()
            self.copy_from_keyed_or_standard_to_internaldenoise()
            self.copy_from_internaldenoise_to_denoise()
            self.copy_from_denoise_to_affectedrecords()
            self.copy_from_affectedrecords_to_stitched()
            print(self.generate_merge_statement())
            print(self.generate_updated_records())

    def clean_temp_table(self):
        table_name = "create database if not exists  {}".format(self.internaldenoise_db_name)
        self.spark.sql(table_name)

        self.spark.sql(self.utils.generate_drop_table_sql(self.internaldenoise_table_name))

        self.spark.sql(self.utils.generate_drop_table_sql(self.denoise_table_name))

        self.spark.sql(self.utils.generate_drop_table_sql(self.utils.get_affectedrecords_table()))

        self.spark.sql(self.utils.generate_drop_table_sql(self.utils.get_stitchedrecords_table()))

    def copy_from_keyed_or_standard_to_internaldenoise(self):
        keyed_to_internaldenoise_sql = self.generate_keyed_or_standardized_to_internaldenoise_transform_sql()
        print(keyed_to_internaldenoise_sql)
        self.logger.info(keyed_to_internaldenoise_sql)
        self.spark.sql(keyed_to_internaldenoise_sql)

    def copy_from_internaldenoise_to_denoise(self):
        internaldenoise_to_denoise_sql = self.generate_internaldenoise_to_denoise_transform_sql()
        self.logger.info(internaldenoise_to_denoise_sql)
        print(internaldenoise_to_denoise_sql)
        self.spark.sql(internaldenoise_to_denoise_sql)

    def copy_from_denoise_to_affectedrecords(self):
        denoise_to_affected_records = self.generate_affected_records()
        self.logger.info(denoise_to_affected_records)
        print(denoise_to_affected_records)
        self.spark.sql(denoise_to_affected_records)

    def copy_from_affectedrecords_to_stitched(self):
        if self.utils.get_changetype() == "Full":
            affectedrecords_to_stitched = self.generate_stitched_records_for_full()
        else:
            affectedrecords_to_stitched = self.generate_stitched_records()
        self.logger.info(affectedrecords_to_stitched)
        print(affectedrecords_to_stitched)
        self.spark.sql(affectedrecords_to_stitched)

    def keyed_table_to_temp_table(self):
        keyed_to_temp_sql = self.generate_keyed_or_standardized_to_temp_table_transform_sql()
        print(keyed_to_temp_sql)
        self.logger.info(keyed_to_temp_sql)
        self.spark.sql(keyed_to_temp_sql)

    def generate_updated_records(self):
        final_table = self.utils.get_history_table_name_final()
        col_names = self.utils.get_all_cdc_columns_str('')
        temp_table_name = self.utils.get_history_table_name_delta()
        affectedrecords_table = self.utils.get_affectedrecords_table()

        updated_records_table_sql = "INSERT OVERWRITE {} partition(effectivestartutcdtprtnkey) select {} from {} " \
                                    "where effectivestartutcdtprtnkey in (select effectivestartutcdtprtnkey from {}) " \
            .format(final_table, col_names, temp_table_name, affectedrecords_table)
        return updated_records_table_sql

    def generate_merge_statement(self):
        stitched_table = self.utils.get_stitchedrecords_table()
        history_table = self.utils.get_history_table_name_delta()

        update_records_prefix = 'u.'
        ck_alias_for_update_merge = self.utils.generate_change_keys_with_alias_for_merge(update_records_prefix)
        update_cols = self.utils.get_all_cdc_columns_str(update_records_prefix)

        insert_records_prefix = 'i.'
        ck_alias_for_insert_merge = self.utils.generate_null_change_keys_with_alias_for_merge()
        insert_cols = self.utils.get_all_cdc_columns_str(insert_records_prefix)

        col_names = self.utils.get_all_cdc_columns_str('')
        col_names_for_insert = self.utils.get_all_cdc_columns_str('all_updates.')

        pkeys = self.spark.sql("SELECT DISTINCT effectivestartutcdtprtnkey FROM {}".format(stitched_table)).collect()

        self.spark.sql("SELECT DISTINCT effectivestartutcdtprtnkey FROM {}".format(stitched_table)).show()

        pkeystr = ",".join(str(key[0]) for key in pkeys)

        merge_sql = "MERGE INTO {} hist USING  ( select {},{} from {} u where u.METADATA_EXISTING_RECORD=true " \
                    "UNION ALL select {},{} from {} i where i.METADATA_EXISTING_RECORD=false ) all_updates ON " \
                    "hist.effectivestartutcdtprtnkey in ({}) AND " \
                    "{} " \
                    "WHEN MATCHED AND hist.effectiveendutcdttm = '9999-12-31 23:59:59' THEN UPDATE SET hist" \
                    ".effectiveendutcdttm = all_updates.effectiveendutcdttm " \
                    " WHEN NOT MATCHED THEN INSERT({}) VALUES({})".format(
            history_table, ck_alias_for_update_merge, update_cols, stitched_table,
            ck_alias_for_insert_merge, insert_cols, stitched_table, pkeystr,
            self.utils.generate_change_keys_join_with_alias_for_merge("hist", 'all_updates'),
            col_names, col_names_for_insert)
        return merge_sql

    def generate_stitched_records(self):
        cdc_all_cols_from_incr_table_str, stitched_table, stitched_table_relative_path, where_clause = self.generate_stitched_records_common()

        stitched_records_sql = "CREATE TABLE {} USING PARQUET LOCATION '{}' AS select {}," \
                               "METADATA_EXISTING_RECORD from {} n {}" \
            .format(
            stitched_table, stitched_table_relative_path, cdc_all_cols_from_incr_table_str,
            self.utils.get_affectedrecords_table(), where_clause)

        return stitched_records_sql

    def generate_stitched_records_for_full(self):
        cdc_all_cols_from_incr_table_str, stitched_table, stitched_table_relative_path, where_clause = self.generate_stitched_records_common()

        cdc_all_cols_from_incr_table_n1 = self.utils.get_all_cdc_columns_excluding_metadata(
            "n1.")
        cdc_all_cols_from_incr_table_n1.append("n1.effectivestartutcdttm")
        cdc_all_cols_from_incr_table_n1.append("to_utc_timestamp(CAST(unix_timestamp('{}', 'yyyyMMdd') AS TIMESTAMP) "
                                               "- interval 1 second, 'Australia/Melbourne') as effectiveendutcdttm".format(
            self.ODATE))
        cdc_all_cols_from_incr_table_n1.append("n1.fileid")
        cdc_all_cols_from_incr_table_n1.append("n1.filelinenumber")
        cdc_all_cols_from_incr_table_n1.append("n1.inserttaskid")
        if self.utils.is_sequence_col_needed():
            cdc_all_cols_from_incr_table_n1.append("n1.sequence")
        cdc_all_cols_from_incr_table_n1.append(self.publicationstartdttm)
        cdc_all_cols_from_incr_table_n1.append(self.publicationenddttm)
        cdc_all_cols_from_incr_table_n1.append("n1.effectivestartutcdtprtnkey")

        cdc_all_cols_from_incr_table_str_n1 = ",".join(column for column in cdc_all_cols_from_incr_table_n1)

        stitched_records_sql = "CREATE TABLE {} USING PARQUET LOCATION '{}' AS " \
                               " select {}," \
                               "METADATA_EXISTING_RECORD from {} n {} where METADATA_EXISTING_RECORD=false UNION ALL " \
                               " select {},METADATA_EXISTING_RECORD from {} n1 where METADATA_EXISTING_RECORD=true" \
            .format(
            stitched_table, stitched_table_relative_path, cdc_all_cols_from_incr_table_str,
            self.utils.get_affectedrecords_table(), where_clause, cdc_all_cols_from_incr_table_str_n1,
            self.utils.get_affectedrecords_table())

        return stitched_records_sql

    def generate_stitched_records_common(self):
        stitched_table = self.utils.get_stitchedrecords_table()
        stitched_table_relative_path = self.utils.get_stitchedrecords_relative_path()
        affectedrecords_table_prefix = 'n'
        chkeys_str = self.utils.generate_change_keys_str(affectedrecords_table_prefix)
        changetype = self.utils.get_changetype()
        changeop_value = self.utils.get_sql_ChangeOperationValue()
        where_clause = ""
        orderby_cols = ""
        if changetype == "TransactionLog":
            seq_col = ""
            if self.utils.is_sequence_col_needed():
                seq_col = ",n.sequence"

            orderby_cols = "n.effectivestartutcdttm, n.FileId, n.Filelinenumber {}".format(seq_col)
            where_clause = " WHERE {} NOT IN ({}) OR {} is NULL".format(changeop_value,
                                                                        self.utils.get_val_ChangeOperationDeleteStr(),
                                                                        changeop_value)
        else:
            orderby_cols = self.effectivestartutcdttm_n
        sql_effective_end_dttm = self.utils.get_sql_EffectiveEndDttm()
        cdc_schema_columns_from_incr_table = self.utils.get_all_cdc_columns_excluding_metadata(
            affectedrecords_table_prefix + ".")
        cdc_all_cols_from_incr_table = cdc_schema_columns_from_incr_table
        cdc_all_cols_from_incr_table.append(self.effectivestartutcdttm_n)
        if sql_effective_end_dttm == 'NA' or sql_effective_end_dttm is None:
            cdc_all_cols_from_incr_table.append("COALESCE( LEAD(effectivestartutcdttm - interval 1 second ) OVER ("
                                                "PARTITION BY  {} order by {}),cast('9999-12-31 23:59:59' as "
                                                "timestamp) ) effectiveendutcdttm".format(chkeys_str, orderby_cols))
        else:
            cdc_all_cols_from_incr_table.append("case when n.{} = '9999-12-31 00:00:00' then '9999-12-31 23:59:59' "
                                                "else to_utc_timestamp(concat(to_date({}),'23:59:59'), "
                                                "'Australia/Melbourne') end as effectiveendutcdttm".format(
                sql_effective_end_dttm, sql_effective_end_dttm))
        cdc_all_cols_from_incr_table.append(self.fileid_n)
        cdc_all_cols_from_incr_table.append(self.filelinenumber_n)
        cdc_all_cols_from_incr_table.append(self.inserttaskid_n)
        if self.utils.is_sequence_col_needed():
            cdc_all_cols_from_incr_table.append(self.sequence_n)
        cdc_all_cols_from_incr_table.append(self.publicationstartdttm)
        cdc_all_cols_from_incr_table.append(self.publicationenddttm)
        cdc_all_cols_from_incr_table.append("n.effectivestartutcdtprtnkey")
        cdc_all_cols_from_incr_table_str = ",".join(column for column in cdc_all_cols_from_incr_table)
        return cdc_all_cols_from_incr_table_str, stitched_table, stitched_table_relative_path, where_clause

    def generate_affected_records(self):
        affectedrecords_table = self.utils.get_affectedrecords_table()
        affectedrecords_table_relative_path = self.utils.get_affectedrecords_relative_path()

        incr_data_prefix = 'n'
        history_table_prefix = 'h'

        cdc_schema_columns_from_history_table = self.utils.get_all_cdc_columns_excluding_metadata(
            history_table_prefix + ".")

        if self.utils.is_sequence_col_needed():
            cdc_additional_cols_from_history_table = [
                "{}{}".format(history_table_prefix + ".", addl_column) for addl_column
                in
                ["effectivestartutcdttm", "effectiveendutcdttm", "fileid",
                 "filelinenumber", "inserttaskid", "sequence", "effectivestartutcdtprtnkey"]]
        else:
            cdc_additional_cols_from_history_table = [
                "{}{}".format(history_table_prefix + ".", addl_column) for addl_column
                in
                ["effectivestartutcdttm", "effectiveendutcdttm", "fileid",
                 "filelinenumber", "inserttaskid", "effectivestartutcdtprtnkey"]]

        cdc_all_cols_from_history_table = cdc_schema_columns_from_history_table + cdc_additional_cols_from_history_table

        cdc_all_cols_from_history_table_str = ",".join(column for column in cdc_all_cols_from_history_table)

        cdc_schema_columns_from_incr_table = self.utils.get_all_cdc_columns_excluding_metadata(incr_data_prefix + ".")

        cdc_all_cols_from_incr_table = cdc_schema_columns_from_incr_table
        cdc_all_cols_from_incr_table.append(self.effectivestartutcdttm_n)
        cdc_all_cols_from_incr_table.append("cast(NULL as timestamp) effectiveendutcdttm")
        cdc_all_cols_from_incr_table.append(self.fileid_n)
        cdc_all_cols_from_incr_table.append(self.filelinenumber_n)
        cdc_all_cols_from_incr_table.append(self.inserttaskid_n)
        if self.utils.is_sequence_col_needed():
            cdc_all_cols_from_incr_table.append(self.sequence_n)
        cdc_all_cols_from_incr_table.append("CAST(REPLACE(TO_DATE(n.effectivestartutcdttm),'-','') AS INT) "
                                            "effectivestartutcdtprtnkey")

        cdc_all_cols_from_incr_table_str = ",".join(column for column in cdc_all_cols_from_incr_table)
        if self.utils.get_changetype() == 'Full':
            affected_records_sql = "CREATE TABLE {} USING PARQUET LOCATION '{}' AS " \
                                   "select {}," \
                                   "true METADATA_EXISTING_RECORD from {} " \
                                   "h  " \
                                   " where h.effectiveendutcdttm = cast('9999-12-31 23:59:59' as timestamp)  " \
                                   " UNION  ALL " \
                                   " select {},false METADATA_EXISTING_RECORD  from {} n  " \
                .format(affectedrecords_table, affectedrecords_table_relative_path, cdc_all_cols_from_history_table_str,
                        self.utils.get_history_table_name_delta(), cdc_all_cols_from_incr_table_str,
                        self.utils.get_denoise_table())
        else:
            affected_records_sql = "CREATE TABLE {} USING PARQUET LOCATION '{}' AS " \
                                   "select {}," \
                                   "true METADATA_EXISTING_RECORD from {} " \
                                   "h " \
                                   " LEFT SEMI JOIN {} n ON ( " \
                                   " h.effectiveendutcdttm = cast('9999-12-31 23:59:59' as timestamp) AND {} ) " \
                                   " UNION  ALL " \
                                   " select {},false METADATA_EXISTING_RECORD  from {} n  " \
                .format(
                affectedrecords_table, affectedrecords_table_relative_path, cdc_all_cols_from_history_table_str,
                self.utils.get_history_table_name_delta(),
                self.utils.get_denoise_table(),
                self.utils.get_change_keys_join(history_table_prefix, incr_data_prefix),
                cdc_all_cols_from_incr_table_str, self.utils.get_denoise_table())

        return affected_records_sql

    def get_denoise_relative_path(self):
        return self.utils.get_denoise_relative_path()

    def generate_internaldenoise_to_denoise_transform_sql(self):

        self.utils.get_cdc_config()

        denoise_table_name = self.utils.get_denoise_table()
        denoise_relative_path = self.utils.get_denoise_relative_path()

        cdc_schema_columns = self.utils.get_all_cdc_columns_excluding_metadata('n.')

        if self.utils.is_sequence_col_needed():
            cdc_additional_cols = ["n.effectivestartutcdttm, cast(NULL as timestamp) AS effectiveendutcdttm",
                                   self.fileid_n, self.filelinenumber_n, self.inserttaskid_n, self.sequence_n]
        else:
            cdc_additional_cols = ["n.effectivestartutcdttm, cast(NULL as timestamp) AS effectiveendutcdttm",
                                   self.fileid_n, self.filelinenumber_n, self.inserttaskid_n]

        cdc_all_cols = cdc_schema_columns + cdc_additional_cols

        cdc_all_cols_str = ",".join(column for column in cdc_all_cols)

        incr_data_prefix = 'n'
        history_table_prefix = 'h'
        where_clause_col = self.utils.get_all_cdc_source_columns_exclude_cks_apply_clause(incr_data_prefix,
                                                                                          history_table_prefix,
                                                                                          '<=>')
        where_clause_source_col_str_for_updated_rows = "AND".join(column for column in where_clause_col)

        change_key_null_checks = []
        for ck in self.utils.get_change_keys():
            change_key_null_checks.append(" {} is NULL ".format(ck))

        where_clause_for_newly_inserted_row = "AND".join(
            " {}.{} ".format(history_table_prefix, change_key_null_check) for change_key_null_check in
            change_key_null_checks)
        cdc_type_where_condition = ""
        change_type = self.utils.get_changetype()

        if change_type == 'TransactionLog':
            cdc_type_where_condition = "AND n.SDSMETA_IS_FIRST = 1"

        internal_denoise_to_denoise_sql = "CREATE TABLE {} USING PARQUET LOCATION '{}' AS select {} from {} n LEFT " \
                                          "OUTER JOIN {} h ON ( " \
                                          "h.effectiveendutcdttm = cast('9999-12-31 23:59:59' as timestamp) AND {} ) " \
                                          "WHERE (({}) OR NOT ({}  {} )) ".format(
            denoise_table_name, denoise_relative_path, cdc_all_cols_str, self.utils.get_internal_denoise_table(),
            self.utils.get_history_table_name_delta(),
            self.utils.get_change_keys_join(incr_data_prefix, history_table_prefix),
            where_clause_for_newly_inserted_row,
            where_clause_source_col_str_for_updated_rows, cdc_type_where_condition)
        return internal_denoise_to_denoise_sql

    def generate_keyed_or_standardized_to_temp_table_transform_sql(self):
        source_table_to_use = self.utils.get_std_table_name()
        if self.utils.is_keymapping_necessary():
            source_table_to_use = self.utils.get_keyed_table_name()

        incr_data_prefix = 'n'

        cdc_schema_columns_from_incr_table = self.utils.get_all_cdc_columns_excluding_metadata(
            incr_data_prefix + ".")

        cdc_all_cols_from_incr_table = cdc_schema_columns_from_incr_table
        cdc_all_cols_from_incr_table.append(self.fileid_n)
        cdc_all_cols_from_incr_table.append(self.filelinenumber_n)
        cdc_all_cols_from_incr_table.append("{} as inserttaskid".format(self.utils.TASK_RUN_ID))
        if self.utils.is_sequence_col_needed():
            cdc_all_cols_from_incr_table.append(self.sequence_n)
        cdc_all_cols_from_incr_table.append(self.effectivestartutcdttm_n)
        cdc_all_cols_from_incr_table.append("cast('9999-12-31 23:59:59' as timestamp) as effectiveendutcdttm")
        cdc_all_cols_from_incr_table.append(self.publicationstartdttm)
        cdc_all_cols_from_incr_table.append(self.publicationenddttm)
        cdc_all_cols_from_incr_table.append("CAST(REPLACE(TO_DATE(n.effectivestartutcdttm),'-','') AS INT) "
                                            "effectivestartutcdtprtnkey")

        cdc_all_cols_from_inc_table_str = ",".join(column for column in cdc_all_cols_from_incr_table)

        keyed_to_final_table_sql = "INSERT INTO {} partition(effectivestartutcdtprtnkey) select {} from {} n".format(
            self.get_history_table_name_final(), cdc_all_cols_from_inc_table_str, source_table_to_use)

        return keyed_to_final_table_sql

    def generate_keyed_or_standardized_to_internaldenoise_transform_sql(self):
        cdc_config = self.schema["CDC"]
        source_cols = self.schema["SourceColumns"]
        source_table_to_use = self.utils.get_std_table_name()
        if self.utils.is_keymapping_necessary():
            source_table_to_use = self.utils.get_keyed_table_name()

        change_operation_value = self.utils.get_value(cdc_config, 'sql_ChangeOperationValue', "NA")
        change_operation_deletevalue = self.utils.get_value(cdc_config, 'val_ChangeOperationDelete', ["D"])
        change_operation_deletevalue_str = ",".join(
            "'{}'".format(deletevalue) for deletevalue in change_operation_deletevalue)

        change_operation_col_changekeys = self.utils.get_value(cdc_config, 'col_ChangeKeys', None)
        change_operation_col_changekeys_str = ",".join(
            "{}".format(change_key) for change_key in change_operation_col_changekeys)

        query_sdsmeta_is_change_flg = " CASE "
        if change_operation_value != "NA":
            change_operation_value_for_clause = self.utils.get_value(cdc_config, 'sql_ChangeOperationValue', "I")
            query_sdsmeta_is_change_flg = query_sdsmeta_is_change_flg + " WHEN {} IN ({}) THEN 1".format(
                change_operation_value_for_clause,
                change_operation_deletevalue_str)

            query_sdsmeta_is_change_flg = query_sdsmeta_is_change_flg + " WHEN LAG ({}) OVER (PARTITION BY {} ORDER BY " \
                                                                        "effectivestartutcdttm,FileId,FileLineNumber) " \
                                                                        "IN " \
                                                                        "({}) THEN 1".format(
                change_operation_value_for_clause, change_operation_col_changekeys_str,
                change_operation_deletevalue_str)

        query_sdsmeta_is_change_flg = query_sdsmeta_is_change_flg + " WHEN LAG ({}) OVER (PARTITION BY {} ORDER BY " \
                                                                    "effectivestartutcdttm,FileId,FileLineNumber) IS " \
                                                                    "NULL THEN 1".format(
            change_operation_col_changekeys[0], change_operation_col_changekeys_str)
        for column in source_cols:
            change_operation_col_columnname = column["ColumnName"]
            query_sdsmeta_is_change_flg = query_sdsmeta_is_change_flg + " WHEN LAG ({}) OVER (PARTITION BY {} ORDER BY " \
                                                                        "effectivestartutcdttm,FileId,FileLineNumber) " \
                                                                        "IS DISTINCT FROM {} THEN 1".format(
                change_operation_col_columnname, change_operation_col_changekeys_str, change_operation_col_columnname)
        query_sdsmeta_is_change_flg = query_sdsmeta_is_change_flg + " ELSE 0 END AS SDSMETA_IS_CHANGE"

        query_sdsmeta_is_first_flg = "  CASE "
        query_sdsmeta_is_first_flg = query_sdsmeta_is_first_flg + "WHEN LAG ({}) OVER (PARTITION BY {} ORDER BY " \
                                                                  "effectivestartutcdttm,FileId,FileLineNumber) IS " \
                                                                  "NULL THEN 1 ELSE 0 END AS SDSMETA_IS_FIRST".format(
            change_operation_col_changekeys[0],
            change_operation_col_changekeys_str)
        where_clause = ""
        if change_operation_value != "NA":
            change_operation_ignore_for_clause = self.utils.get_value(cdc_config, 'val_ChangeOperationIgnore',
                                                                      ["UO", "UU", "B"])
            change_operation_ignore_for_clause_str = ",".join(
                "'{}'".format(ignore) for ignore in change_operation_ignore_for_clause)
            where_clause = " WHERE {} NOT IN ({})".format(change_operation_value_for_clause,
                                                          change_operation_ignore_for_clause_str)

        keyed_to_internal_denoise_sql = "CREATE TABLE {} AS select * from (SELECT keyed.*, {} ,{} from {} keyed {" \
                                        "} ) cdc_flagged where SDSMETA_IS_CHANGE=1 ".format(
            self.get_internaldenoise_table_name(), query_sdsmeta_is_change_flg, query_sdsmeta_is_first_flg,
            source_table_to_use, where_clause)

        return keyed_to_internal_denoise_sql
