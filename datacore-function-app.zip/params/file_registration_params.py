import stringcase
from cerberus import Validator


class Struct:
    def __init__(self, dic):
        for k, v in dic.items():
            self.__dict__[stringcase.snakecase(k)] = v


class FileRegistrationParams:

    def __init__(self, schema, params):
        self.content = {key: params[key] for key in params.keys() if key in schema}
        self.__set_properties__()
        self.validator = Validator(schema)

    def validate(self):
        return self.validator.validate(self.content)

    def __set_properties__(self):
        for k, v in self.content.items():
            if k == "files":
                v = [Struct(entry) for entry in v]
            self.__dict__[stringcase.snakecase(k)] = v

    @property
    def file_extensions_as_str(self):
        return ",".join(self.file_extensions)

    @property
    def errors(self):
        return self.validator.errors


def is_sequential(files):
    sequence_numbers = sorted(f.sequence for f in files)
    for previous, current in zip(sequence_numbers, sequence_numbers[1:]):
        if current - previous != 1:
            return False
    return True


def next_sequence_number(files):
    last_file = next(iter(sorted(files, key=lambda f: f.sequence)), None)
    if last_file:
        seq = last_file.sequence
        if type(seq) == str and seq.isdigit():
            return int(seq)
        else:
            return seq
