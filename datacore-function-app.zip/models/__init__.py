import os
from functools import reduce
from datetime import datetime

from sqlalchemy import Column, Integer, String, ForeignKey, desc, UniqueConstraint, update, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

from shared import get_data_container_name

Base = declarative_base()

SCHEDULED = 'scheduled'
RUNNING = 'running'
FAILED = 'failed'
ABORTED = 'aborted'
COMPLETED = 'completed'
FORCE_COMPLETED = 'force_completed'

FILE_REGISTERED = 'registered'
FILE_COPIED = 'copied'
FILE_VALIDATION_SUCCESSFUL = 'validation_successful'
FILE_VALIDATION_FAILED = 'validation_failed'
STATE_FLOW = {
    FILE_REGISTERED: None,
    FILE_COPIED: FILE_REGISTERED,
    FILE_VALIDATION_FAILED: FILE_COPIED,
    FILE_VALIDATION_SUCCESSFUL: FILE_COPIED
}

UPSTREAM_ACTIVITY = 'UPSTREAM'
DOWNSTREAM_ACTIVITY = 'DOWNSTREAM'
ARCHIVE_ACTIVITY = 'ARCHIVE'

SOURCE = 'SOURCE'
DESTINATION = 'DESTINATION'

ADLS = 'ADLS'
CSA = 'CSA'
SFX = 'SFX'


class Environment(Base):
    __tablename__ = 'environments'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    type = Column(String)

    @classmethod
    def get(cls, session, primary_id):
        return (session.query(cls)
                .filter(cls.id == primary_id)
                .first())

    @classmethod
    def get_by_name(cls, session, name):
        return (session.query(cls)
                .filter(cls.name == name)
                .first())

    @classmethod
    def get_all(cls, session):
        return [env.name for env in session.query(Environment).all()]


class FileLocation(Base):
    __tablename__ = 'file_locations'

    id = Column(Integer, primary_key=True)
    environment_type = Column(String)
    target_type = Column(String)
    target_name = Column(String)
    path_pattern = Column(String)

    @classmethod
    def get(cls, session, environment_type, target_type, target_name):
        return (session.query(cls)
                .filter(cls.environment_type == environment_type,
                        cls.target_type == target_type,
                        cls.target_name == target_name)
                .first())


class JobRegistration(Base):
    __tablename__ = 'job_registrations'

    id = Column(Integer, primary_key=True)
    job_name = Column(String)
    source_system = Column(String)
    table_name = Column(String)
    db_cluster_size = Column(String)
    ssu = Column(String)
    direction = Column(String)
    environment_id = Column(Integer, ForeignKey(Environment.id))
    environment = relationship(Environment, foreign_keys=[environment_id])

    job_runs = relationship('JobRun')
    file_registrations = relationship('FileRegistration', lazy='dynamic')

    @classmethod
    def get(cls, session, name, env_name):
        return (session.query(JobRegistration)
                .join(Environment)
                .filter(JobRegistration.job_name == name, Environment.name == env_name)
                .order_by(JobRegistration.id.desc())
                .first())

    @property
    def source_name(self):
        return self.source_system

    @property
    def job_cluster_size(self):
        return self.db_cluster_size

    @property
    def jobname(self):
        return self.job_name

    @property
    def job_ssu(self):
        return self.ssu

    def resolve_path(self, path_pattern, run_time_replacements=None):
        replacements = [("<ENV>", self.environment.name),
                        ("<SOURCE_SYSTEM>", self.source_system),
                        ("<SSU>", self.ssu),
                        ("<TABLE_NAME>", self.table_name)]
        if isinstance(run_time_replacements, list):
            replacements.extend(run_time_replacements)
        return reduce(lambda a, kv: a.replace(*kv), replacements, path_pattern)

    def storage_account_job_file_path(self):
        return os.path.join(
            self.__storage_account_base_path(),
            'job',
            f"{self.job_name}.job.json"
        )

    def storage_account_schema_file_path(self):
        return os.path.join(
            self.__storage_account_base_path(),
            'schema',
            self.table_name.lower(),
            f"{self.table_name}.schema.json"
        )

    def __storage_account_base_path(self):
        return os.path.join(
            'metadata',
            self.environment.type,
            self.environment.name,
            self.direction.lower(),
            self.source_system.lower(),
        )

    def register_files(self, session, params, source_file_location, destination_file_location):
        registered_files = []
        for file in params.files:
            file_name = file.file_name.replace(".*", "")
            file_registration = FileRegistration(
                job_registration_id=self.id,
                o_date=params.o_date,
                job_run_id=params.job_run_id,
                file_pattern=params.file_pattern,
                source_file_location=source_file_location,
                destination_file_location=destination_file_location,
                activity=params.activity,
                file_extensions=params.file_extensions_as_str,
                file_name=file_name,
                environment=self.environment,
                sequence=file.sequence,
                status=FILE_REGISTERED,
            )
            registered_files.append(file_registration)

        session.add_all(registered_files)
        session.commit()
        return registered_files


class JobRun(Base):
    __tablename__ = 'job_runs'

    id = Column(Integer, primary_key=True)
    status = Column(String)
    job_run_uuid = Column(String)
    o_date = Column(String)
    job_registration_id = Column(Integer, ForeignKey(JobRegistration.id))
    job_registration = relationship(JobRegistration, foreign_keys=[job_registration_id])
    # Azure Function Invocation ID
    operation_uuid = Column(String)
    db_cluster_id = Column(String)
    custom_db_cluster_id = Column(String)
    environment_id = Column(Integer, ForeignKey(Environment.id))
    environment = relationship(Environment, foreign_keys=[environment_id])
    task_runs = relationship('TaskRun')
    previous_job_run_id = Column(Integer, ForeignKey('job_runs.id'))
    previous_job_run = relationship('JobRun', uselist=False)
    started_at = Column(DateTime)
    ended_at = Column(DateTime)

    UniqueConstraint('previous_job_run_id', 'job_registration_id')

    def to_dict(self):
        return {
            'id': self.id,
            'jobRunUuid': self.job_run_uuid,
            'status': self.status,
            'taskRuns': [t.to_dict() for t in self.task_runs]
        }

    @classmethod
    def get(cls, session, primary_id):
        return (session.query(cls)
                .filter(cls.id == primary_id)
                .first())

    @classmethod
    def get_last_job_run(cls, session, env_name, o_date, job_registration):
        return (session
                .query(JobRun)
                .join(Environment)
                .filter(JobRun.job_registration_id == job_registration.id,
                        Environment.name == env_name,
                        JobRun.o_date == o_date)
                .order_by(desc(JobRun.id))
                .first())

    @classmethod
    def create(cls, session, job_reg, environment, operation_uuid, o_date, previous_job_run, status=SCHEDULED):
        job_run = JobRun(
            status=status,
            job_registration_id=job_reg.id,
            environment_id=environment.id,
            operation_uuid=operation_uuid,
            previous_job_run=previous_job_run,
            o_date=o_date
        )
        session.add(job_run)
        session.commit()
        return job_run

    @property
    def name(self):
        return self.job_registration.job_name

    @property
    def cluster_id(self):
        return self.db_cluster_id

    @property
    def custom_cluster_id(self):
        return self.custom_db_cluster_id

    @property
    def job_reg_id(self):
        return self.job_registration_id

    def is_running(self):
        return self.status in [SCHEDULED, RUNNING]

    def add_task_runs(self, session, tasks):
        def make_task_run(t):
            return TaskRun(
                name=t['name'],
                job_run_id=self.id,
                status=SCHEDULED
            )

        for task in tasks:
            self.task_runs.append(make_task_run(task))
        session.add(self)
        session.commit()

    def set_status(self, session, status, job_run_uuid=None):
        if job_run_uuid:
            self.job_run_uuid = job_run_uuid
        self.status = status
        if status == RUNNING:
            self.started_at = datetime.now()
        if status in (FAILED, COMPLETED, ABORTED):
            self.ended_at = datetime.now()
        session.add(self)
        session.commit()

    def update_db_cluster_id(self, session, cluster_id):
        self.db_cluster_id = cluster_id
        session.add(self)
        session.commit()

    def update_custom_db_cluster_id(self, session, cluster_id):
        self.custom_db_cluster_id = cluster_id
        session.add(self)
        session.commit()

    @property
    def source_system(self):
        return self.job_registration.source_system

    def get_job_run_params(self, session, job_params, container_name):
        run_time_params = {
            'jobRunId': self.id,
            'oDate': self.o_date,
            'jobName': self.job_registration.job_name,
            'environment': self.environment.name,
            'sourceSystem': self.job_registration.source_system,
            'tableName': self.job_registration.table_name
        }
        #
        job_run_params = {**job_params, **run_time_params}
        for task_config in job_run_params['tasks']:
            task_name = task_config.get('name')
            task = next((task for task in self.task_runs if task.name == task_name), None)
            task_config.update({'taskRunId': task.id, 'taskRunStatus': task.status})
            if task_config['name'] == 'CopyData':
                for name in [SOURCE, DESTINATION]:
                    lower_name = name.lower()
                    file_loc = self.file_location(session, name, task_config['parameters'][lower_name])
                    if file_loc:
                        task_config['parameters'][f"{lower_name}Container"] = container_name
                        task_config['parameters'][f"{lower_name}Path"] = self.path(file_loc.path_pattern)
        return job_run_params

    def path(self, path_pattern):
        return self.job_registration.resolve_path(path_pattern, [('<ODATE>', self.o_date)])

    def file_location(self, session, target_type, target_name):
        return FileLocation.get(session, self.environment.type, target_type, target_name)

    def cancel(self, session):
        self.status = FAILED
        for task_run in self.task_runs:
            task_run.cancel()
        session.add(self)
        session.commit()
        session.commit()

    def force_complete(self, session, soft=True):
        if self.status in [COMPLETED, FORCE_COMPLETED] or (soft and self.status in [RUNNING, SCHEDULED]):
            return

        self.status = FORCE_COMPLETED
        for task_run in self.task_runs:
            task_run.force_complete()
        session.add(self)
        session.commit()

    def has_task_completed(self, name):
        return any(t.status == COMPLETED and t.name == name for t in self.task_runs)

    def has_completed(self):
        return self.status == COMPLETED


class TaskRun(Base):
    __tablename__ = 'task_runs'

    id = Column(Integer, primary_key=True)
    name = Column(String)
    status = Column(String)
    task_run_uuid = Column(String)
    activity_run_uuid = Column(String)
    job_run_id = Column(Integer, ForeignKey(JobRun.id))
    job_run = relationship(JobRun, foreign_keys=[job_run_id])
    started_at = Column(DateTime)
    ended_at = Column(DateTime)

    @property
    def environment(self):
        return self.job_run.environment

    @classmethod
    def get(cls, session, primary_id):
        return (session.query(cls)
                .filter(cls.id == primary_id)
                .first())

    def register_files(self, session, params, source_file_location, destination_file_location):
        for file in params.files:
            file_registration = FileRegistration(
                task_run_id=self.id,
                job_run_id=self.job_run.id,
                file_pattern=params.file_pattern,
                source_file_location=source_file_location,
                destination_file_location=destination_file_location,
                activity=params.activity,
                file_extensions=params.file_extensions_as_str,
                file_name=file.file_name,
                record_count=file.record_count,
                environment=self.environment,
                sequence=file.sequence,
                status=FILE_REGISTERED,
            )
            self.file_registrations.append(file_registration)

        session.add(self)
        session.commit()

    def set_status(self, session, status, task_run_uuid=None):
        if task_run_uuid:
            self.task_run_uuid = task_run_uuid
        self.status = status
        if status == RUNNING:
            self.started_at = datetime.now()
        if status in (FAILED, COMPLETED, ABORTED):
            self.ended_at = datetime.now()
        session.add(self)
        session.commit()

    def cancel(self):
        if self.status == RUNNING:
            self.status = FAILED
        if self.status == SCHEDULED:
            self.status = ABORTED

    def force_complete(self):
        if self.status != COMPLETED:
            self.status = FORCE_COMPLETED

    def to_dict(self):
        return {
            'id': self.id,
            'taskRunUuid': self.task_run_uuid,
            'status': self.status
        }


class Pipeline(Base):
    __tablename__ = 'pipelines'

    id = Column(Integer, primary_key=True)
    slug = Column(String)
    resource_group_name = Column(String)
    factory_name = Column(String)
    name = Column(String)

    @classmethod
    def get(cls, session, primary_id):
        return (session.query(cls)
                .filter(cls.id == primary_id)
                .first())

    @classmethod
    def bootstrap(cls, session):
        return (session
                .query(Pipeline)
                .filter_by(slug='bootstrap')
                .first())

    def run_config(self):
        return [
            self.resource_group_name,
            self.factory_name,
            self.name
        ]


class FileRegistration(Base):
    __tablename__ = 'file_registrations'

    id = Column(Integer, primary_key=True)
    o_date = Column(String)
    file_name = Column(String)
    record_count = Column(Integer)
    sequence = Column(Integer)
    file_pattern = Column(String)
    file_extensions = Column(String)
    status = Column(String)
    activity = Column(String)

    job_registration_id = Column(Integer, ForeignKey(JobRegistration.id))
    job_registration = relationship(JobRegistration, foreign_keys=[job_registration_id])

    job_run_id = Column(Integer, ForeignKey(JobRun.id))
    job_run = relationship(JobRun, foreign_keys=[job_run_id])

    environment_id = Column(Integer, ForeignKey(Environment.id))
    environment = relationship(Environment, foreign_keys=[environment_id])

    source_file_location_id = Column(Integer, ForeignKey(FileLocation.id))
    source_file_location = relationship(FileLocation, foreign_keys=[source_file_location_id])

    destination_file_location_id = Column(Integer, ForeignKey(FileLocation.id))
    destination_file_location = relationship(FileLocation, foreign_keys=[destination_file_location_id])

    def to_dict(self):
        return {
            'id': self.id,
            'jobRunId': self.job_run_id,
            'jobRegistrationId': self.job_registration_id,
            'oDate': self.o_date,
            'fileName': self.file_name,
            'filePattern': self.file_pattern,
            'fileExtensions': self.file_extensions_list,
            'recordCount': self.record_count,
            'sequence': self.sequence,
            'status': self.status,
            'activity': self.activity
        }

    @property
    def file_extensions_list(self):
        if self.file_extensions:
            return self.file_extensions.split(',')

    @file_extensions_list.setter
    def file_extensions_list(self, file_ext_list):
        if isinstance(file_ext_list, list):
            self.file_extensions = ",".join(file_ext_list)

    @property
    def data_file_name(self):
        data_file_ext = next(ext for ext in self.file_extensions_list if ext not in (['.eot', '.ctl']))
        file_name = self.file_name.replace(".*", "")
        if data_file_ext:
            return f"{file_name}.{data_file_ext}"
        else:
            return file_name

    @classmethod
    def get(cls, session, primary_id):
        return (session.query(cls)
                .filter(cls.id == primary_id)
                .first())

    @classmethod
    def update_status(cls, session, job_registration, o_date, status, job_run_id):
        previous_status = STATE_FLOW[status]
        stmt = update(FileRegistration).where(
            FileRegistration.job_registration == job_registration,
            FileRegistration.o_date == o_date,
            FileRegistration.status == previous_status
        ).values(status=status, job_run_id=job_run_id).execution_options(synchronize_session="fetch")
        result = session.execute(stmt)
        return result.rowcount

    @classmethod
    def last_sequence(cls, session, job_name, env_name, status):
        file_reg = (session.query(FileRegistration)
                    .join(JobRegistration)
                    .join(Environment)
                    .filter(JobRegistration.job_name == job_name,
                            Environment.name == env_name,
                            FileRegistration.status == status)
                    .order_by(FileRegistration.sequence.desc())
                    .first())
        if file_reg and file_reg.sequence:
            return file_reg.sequence
        else:
            return None

    @classmethod
    def all(cls, session, job_name, o_date, env_name, status):
        return (session.query(FileRegistration)
                .join(JobRegistration)
                .join(Environment)
                .filter(JobRegistration.job_name == job_name,
                        Environment.name == env_name,
                        FileRegistration.o_date == o_date,
                        FileRegistration.status == status)
                .all())


class KeymapLocks(Base):
    __tablename__ = 'keymap_locks'

    id = Column(Integer, primary_key=True)
    environment_name = Column(String)
    keymap_table = Column(String)
    job_run_id = Column(Integer, ForeignKey(JobRun.id))
    job_run = relationship(JobRun, foreign_keys=[job_run_id])
    task_run_id = Column(Integer, ForeignKey(TaskRun.id))
    task_run = relationship(TaskRun, foreign_keys=[task_run_id])
    status = Column(String)

    @classmethod
    def acquire_lock(cls, session, environment, keymap_table, job_run_id, task_run_id):
        lock = KeymapLocks(
            environment_name=environment,
            keymap_table=keymap_table,
            job_run_id=job_run_id,
            task_run_id=task_run_id,
            status="locked"
        )

        session.add(lock)
        session.commit()

        return lock

    @classmethod
    def release_lock(cls, session, environment, keymap_table, job_run_id, task_run_id):
        lock = (session.query(cls)
                .filter(cls.environment_name == environment,
                        cls.keymap_table == keymap_table,
                        cls.job_run_id == job_run_id,
                        cls.task_run_id == task_run_id)
                .first())

        session.delete(lock)
        session.commit()

    @classmethod
    def get(cls, session, environment, keymap_table, status="locked"):
        return (session.query(cls)
                .filter(cls.environment_name == environment,
                        cls.keymap_table == keymap_table,
                        cls.status == status)
                .first())

    @classmethod
    def get_by_job_task_id(cls, session, environment, keymap_table, job_run_id, task_run_id, status="locked"):
        return (session.query(cls)
                .filter(cls.environment_name == environment,
                        cls.keymap_table == keymap_table,
                        cls.job_run_id == job_run_id,
                        cls.task_run_id == task_run_id,
                        cls.status == status)
                .first())

    @property
    def keymap_table_name(self):
        return self.keymap_table

    @property
    def job_id(self):
        return self.job_run_id

    @property
    def task_id(self):
        return self.task_run_id
