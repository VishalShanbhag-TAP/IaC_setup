import logging

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from force_complete_job_run.force_complete_job_run_params import ForceCompleteJobRunParams
from models import JobRun
from shared import failure_response, success_response, create_session


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        p = ForceCompleteJobRunParams(req.get_json())
        if not p.validate():
            return failure_response(p.errors)

        credential = ManagedIdentityCredential()

        session = create_session(credential)
        job_run = JobRun.get(session, p.job_run_id)

        job_run.force_complete(session, p.soft)

        return success_response(job_run.to_dict())

    except Exception as exception:
        logging.exception(exception)
        return failure_response(dict([(type(exception).__name__, str(exception))]))
