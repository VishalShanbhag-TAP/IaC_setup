import stringcase
from cerberus import Validator

FORCE_COMPLETE_JOB_RUN_SCHEMA = {
    'jobRunId': {
        'type': 'integer',
        'coerce': int,
        'required': True
    },
    'soft': {
        'type': 'boolean',
        'required': True
    }
}


class ForceCompleteJobRunParams:

    def __init__(self, params):
        self.content = {key: params.get(key) for key in FORCE_COMPLETE_JOB_RUN_SCHEMA}
        self.__set_properties__()
        self.validator = Validator(FORCE_COMPLETE_JOB_RUN_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    def __set_properties__(self):
        for k, v in self.content.items():
            self.__dict__[stringcase.snakecase(k)] = v

    @property
    def errors(self):
        return self.validator.errors
