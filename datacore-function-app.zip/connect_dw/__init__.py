import pyodbc
import requests

#Generate AAD token
def get_aad_token(tenant_id, db_sp_client_id, db_sp_client_secret, resource_id):
    endpoint = f'https://login.microsoftonline.com/{tenant_id}/oauth2/token'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    payload = f"grant_type=client_credentials&client_id={db_sp_client_id}&client_secret={db_sp_client_secret}&resource={resource_id}"
    response = requests.post(endpoint, headers=headers, data=payload)

    if response.status_code == 200:
        aad_token = response.json()["access_token"]
        return aad_token
    else:
        return "INVALID"


server = 'tcp-azu0001-ase-sql-bidw-dev01-loadaccess.database.windows.net'
database = 'tcp-azu0001-ase-sdw-bidw-dev01-d01'
username = 'BIDW_DATACORE_FRAMEWORK_NPRD_SP_001'
password = get_aad_token('49dfc6a3-5fb7-49f4-adea-c54e725bb854', '745d434d-18ac-4ad8-8bc4-b0fd30ff156f', 'TqA7Q~VUA~djNO1rMqBDlbj01HHtHk6CHu2C9', 'https://ossrdbms-aad.database.windows.net')
driver= '{ODBC Driver 17 for SQL Server}'

with pyodbc.connect('DRIVER='+driver+';SERVER=tcp:'+server+';PORT=1433;DATABASE='+database+';UID='+username+';PWD='+ password) as conn:
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM test.test_table WHERE filelinenumber = 400")
        row = cursor.fetchone()
        while row:
            print (str(row[0]) + " " + str(row[1]))
            row = cursor.fetchone()
