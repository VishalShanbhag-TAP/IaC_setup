from models import FILE_REGISTERED, FILE_COPIED, FILE_VALIDATION_FAILED, FILE_VALIDATION_SUCCESSFUL
from shared import validate_o_date

UPDATE_FILE_REGISTRATION_STATUS_SCHEMA = {
    'jobName': {'type': 'string', 'required': True},
    'jobRunId': {
        'type': 'integer',
        'coerce': int,
        'required': True
    },
    'oDate': {
        'type': 'string',
        'check_with': validate_o_date,
        'required': True,
        'coerce': str
    },
    'environment': {'type': 'string', 'required': True},
    'status': {
        'type': 'string',
        'allowed': [FILE_REGISTERED, FILE_VALIDATION_FAILED, FILE_VALIDATION_SUCCESSFUL, FILE_COPIED],
        'required': True
    }
}
