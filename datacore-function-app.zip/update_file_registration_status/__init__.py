import logging

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from exceptions import JobException
from models import FileRegistration, JobRegistration
from params.file_registration_params import FileRegistrationParams
from services import get_job_registration
from shared import failure_response, success_response, create_session
from update_file_registration_status.update_file_registration_status_schema import \
    UPDATE_FILE_REGISTRATION_STATUS_SCHEMA


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        req_params = {**req.get_json(), **req.route_params}
        params = FileRegistrationParams(UPDATE_FILE_REGISTRATION_STATUS_SCHEMA, req_params)
        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()

        session = create_session(credential)

        job_registration = get_job_registration(session, params.job_name, params.environment)
        row_count = FileRegistration.update_status(session,
                                                   job_registration,
                                                   params.o_date,
                                                   params.status,
                                                   params.job_run_id)

        return success_response(json_response(params, row_count))

    except JobException as je:
        logging.exception(je)
        return failure_response(je.error)
    except Exception as exception:
        return failure_response(dict([(type(exception).__name__, str(exception))]))


def json_response(params, row_count):
    return {
        'jobName': params.job_name,
        'jobRunId': params.job_run_id,
        'oDate': params.o_date,
        'environment': params.environment,
        'rowsUpdated': row_count,
        'status': params.status
    }
