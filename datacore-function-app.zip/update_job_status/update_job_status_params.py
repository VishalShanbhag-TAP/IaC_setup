from datetime import datetime

from cerberus import Validator

from models import FAILED, COMPLETED, RUNNING, SCHEDULED

UUID_REGEX = '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'

UPDATE_JOB_STATUS_SCHEMA = {
    'jobRunId': {
        'type': 'integer',
        'coerce': int,
        'required': True
    },
    'jobRunUuid': {
        'type': 'string',
        'regex': UUID_REGEX,
        'required': True
    },
    'status': {
        'type': 'string',
        'allowed': [FAILED, COMPLETED, RUNNING, SCHEDULED],
        'required': True
    }
}


class UpdateJobStatusParams:

    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in UPDATE_JOB_STATUS_SCHEMA}
        self.validator = Validator(UPDATE_JOB_STATUS_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def job_run_id(self):
        return self.content.get('jobRunId')

    @property
    def job_run_uuid(self):
        return self.content.get('jobRunUuid')

    @property
    def status(self):
        return self.content.get('status')

    @property
    def errors(self):
        return self.validator.errors
