import logging

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from models import FAILED, JobRun
from shared import failure_response, create_secret_client, success_response, create_session
from update_job_status.update_job_status_params import UpdateJobStatusParams


def main(req: func.HttpRequest) -> func.HttpResponse:
    job_run = None
    params = None
    session = None

    try:
        params = UpdateJobStatusParams(req.get_json())
        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()

        session = create_session(credential)

        job_run = JobRun.get(session, params.job_run_id)
        job_run.set_status(session, params.status, params.job_run_uuid)

        return success_response({'jobRunUuid': params.job_run_uuid})

    except Exception as exception:
        logging.exception(exception)
        if job_run:
            job_run.set_status(session, FAILED, params.job_run_uuid)
        return failure_response(dict([(type(exception).__name__, str(exception))]))
