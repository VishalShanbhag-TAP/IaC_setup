create sequence pipelines_seq;

create table pipelines
(
   id int default nextval ('pipelines_seq')
      constraint pipeline_pk
         primary key,
   slug varchar(10) not null,
   resource_group_name varchar(50) not null,
   factory_name varchar(50) not null,
   name varchar(50) not null,
   created_date_time timestamp(3) default current_timestamp,
   modified_date_time timestamp(3) default current_timestamp,
   constraint pipeline_uc UNIQUE (slug)
);


 grant delete, insert, references, select, trigger, truncate, update on pipeliens_seq to azfunction_datacoreappmeta_writer;

alter sequence pipelines_seq owner to "aBIDH_-_CC_Application_Administrator_DEV";

grant select, update, usage on sequence pipelines_seq to azfunction_datacoreappmeta_writer;

