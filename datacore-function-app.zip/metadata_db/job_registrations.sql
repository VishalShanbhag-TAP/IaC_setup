create sequence job_registrations_seq;

create table job_registrations
(
   id int default nextval ('job_registrations_seq')
      constraint job_registration_pk
         primary key,
   job_name varchar(30) not null,
   environment_id int not null
      constraint environment_id_fk
        references environments (id),
   direction varchar(20) not null,
   source_system varchar(20) not null,
   table_name varchar(20) not null,
   db_cluster_size varchar(10) not null,
   created_date_time timestamp default current_timestamp,
   modified_date_time timestamp default current_timestamp,
   constraint job_registration_uc UNIQUE (job_name, environment_id)
)

grant delete, insert, references, select, trigger, truncate, update on job_registrations to azfunction_datacoreappmeta_writer;

alter sequence job_registrations_seq owner to "aBIDH_-_CC_Application_Administrator_DEV";

grant select, update, usage on sequence job_registrations_seq to azfunction_datacoreappmeta_writer;

