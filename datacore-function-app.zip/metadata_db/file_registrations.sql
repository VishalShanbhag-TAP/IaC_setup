create sequence file_registrations_seq;

create table file_registrations
(
	id integer default nextval('file_registrations_seq'::regclass) not null
		constraint file_registrations_pk
			primary key,
	o_date varchar(10),
	file_name varchar(300),
	record_count integer,
	sequence integer,
	file_pattern varchar(300),
	file_extensions varchar(20),
	status varchar(30),
	activity varchar(20),
	job_registration_id integer not null
		constraint file_registrations__job_registrations_id_fk
			references job_registrations,
	environment_id integer not null
		constraint file_registrations__environments_id_fk
			references environments,
	source_file_location_id integer not null
		constraint file_registrations__source_file_locations_id_fk
			references file_locations,
	destination_file_location_id integer not null
		constraint file_registrations__destination_file_locations_id_fk
			references file_locations,
	created_date_time timestamp default CURRENT_TIMESTAMP,
	modified_date_time timestamp default CURRENT_TIMESTAMP,
	job_run_id integer
		constraint file_registrations_job_runs_id_fk
			references job_runs
);

alter table file_registrations owner to "aBIDH_-_CC_Application_Administrator_DEV";

create unique index file_registrations_file_name_uindex
	on file_registrations (file_name);

grant delete, insert, references, select, trigger, truncate, update on file_registrations to azfunction_datacoreappmeta_writer;

alter sequence file_registrations_seq owner to "aBIDH_-_CC_Application_Administrator_DEV";

grant select, update, usage on sequence file_registrations_seq to azfunction_datacoreappmeta_writer;




