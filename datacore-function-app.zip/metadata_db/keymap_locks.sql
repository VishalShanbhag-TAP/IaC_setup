create sequence keymap_locks_sequence;

create table keymap_locks
(
    id               int default nextval('keymap_locks_sequence')
        constraint keymap_locks_pk
            primary key,
    environment_name varchar(3),
    keymap_table     varchar(200),
    job_run_id       integer,
    task_run_id      integer,
    status           varchar(10)
);

grant delete, insert, references, select, trigger, truncate, update on keymap_locks_sequence to azfunction_datacoreappmeta_writer;
