create sequence file_locations_sequence;

create table file_locations
(
    id                 int       default nextval('file_locations_sequence')
        constraint file_locations_pk
            primary key,
    environment_type   varchar(3),
    target_type        varchar(12),
    target_name        varchar(12),
    path_pattern       varchar(200),
    created_date_time  timestamp default current_timestamp,
    modified_date_time timestamp default current_timestamp

);

grant delete, insert, references, select, trigger, truncate, update on file_locations to azfunction_datacoreappmeta_writer;

alter sequence file_locations_sequence owner to "aBIDH_-_CC_Application_Administrator_DEV";

grant select, update, usage on sequence file_locations_sequence to azfunction_datacoreappmeta_writer;

