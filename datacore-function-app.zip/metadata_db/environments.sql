create sequence environments_seq;

create table environments
(
   id int default nextval ('environments_seq')
      constraint environment_pk
         primary key,
   name varchar(3) not null,
   type varchar(4) not null,
   created_date_time timestamp default current_timestamp,
   modified_date_time timestamp default current_timestamp,
   constraint environment_uc UNIQUE (name)
);

grant delete, insert, references, select, trigger, truncate, update on environments to azfunction_datacoreappmeta_writer;

alter sequence environments_seq owner to "aBIDH_-_CC_Application_Administrator_DEV";

grant select, update, usage on sequence environments_seq to azfunction_datacoreappmeta_writer;

