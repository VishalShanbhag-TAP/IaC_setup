create sequence task_runs_seq;

create table task_runs
(
   id int default nextval ('task_runs_seq')
      constraint task_run_pk
         primary key,
   job_run_id int not null
      constraint task_runs__job_run_id_fk
        references job_runs (id),
   name varchar(50),     
   pipeline_name varchar(36),     
   task_run_uuid varchar(36),    
   activity_run_uuid varchar(36),    
   status varchar(16),
   start_date_time timestamp,
   end_date_time timestamp,
   created_date_time timestamp default current_timestamp,
   modified_date_time timestamp default current_timestamp
)

grant delete, insert, references, select, trigger, truncate, update on task_runs_seq to azfunction_datacoreappmeta_writer;

alter sequence task_runs_seq owner to "aBIDH_-_CC_Application_Administrator_DEV";

grant select, update, usage on sequence task_runs_seq to azfunction_datacoreappmeta_writer;

