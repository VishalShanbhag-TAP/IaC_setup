create sequence job_runs_seq;

create table job_runs
(
   id int default nextval ('job_runs_seq')
      constraint job_run_pk
         primary key,
   job_registration_id int not null
      constraint job_runs__job_registration_id_fk
        references job_registrations (id),
   environment_id int not null
      constraint job_runs__environment_id_fk
         references environments (id),
   job_run_uuid varchar(36),
   operation_uuid varchar(36),
   db_cluster_id varchar(50),
   custom_db_cluster_id varchar(50),
   status varchar(16),
   o_date varchar(10),
   previous_job_run_id integer
       constraint job_runs_job_runs_id_fk
           references job_runs (id),

   start_date_time timestamp,
   end_date_time timestamp,

   created_date_time timestamp default current_timestamp,
   modified_date_time timestamp default current_timestamp
)

grant delete, insert, references, select, trigger, truncate, update on job_runs to azfunction_datacoreappmeta_writer;

alter sequence job_runs_seq owner to "aBIDH_-_CC_Application_Administrator_DEV";

grant select, update, usage on sequence job_runs_seq to azfunction_datacoreappmeta_writer;

