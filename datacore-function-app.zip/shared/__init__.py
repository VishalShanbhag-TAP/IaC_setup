import json
import logging
import os
import re
import base64
import urllib
import urllib.parse
from datetime import datetime

import azure.functions as func
from azure.keyvault.secrets import SecretClient
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.storage.filedatalake import DataLakeFileClient, DataLakeServiceClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

host_name = os.environ.get('POSTGRES_HOST_NAME')
user_name = os.environ.get('POSTGRES_USER_NAME')
db_name = os.environ.get('POSTGRES_DB_NAME')


def create_session(credential):
    token = credential.get_token('https://ossrdbms-aad.database.windows.net').token
    encoded_user_name = urllib.parse.quote(user_name)
    db_url = f"postgresql+psycopg2://{encoded_user_name}:{token}@{host_name}/{db_name}?sslmode=require"
    engine = create_engine(db_url, isolation_level="AUTOCOMMIT")
    return sessionmaker(bind=engine)()


def create_secret_client(token_credential):
    return SecretClient(
        vault_url=os.environ["VAULT_URL"],
        credential=token_credential
    )


def create_df_mgmt_client(token_credential, subscription_id):
    return DataFactoryManagementClient(
        credential=token_credential,
        subscription_id=subscription_id
    )


def get_data_storage_accounts_config(encoded_payload):
    config = base64.b64decode(encoded_payload)
    return json.loads(config)


def create_metadata_dl_file_client(storage_cfg, file_path, token_credential):
    url, container = __get_storage_config(storage_cfg, "metadataStorageAccount")
    return create_dl_file_client(url, container, file_path, token_credential)


def create_data_dl_file_client(storage_cfg, file_path, token_credential):
    url, container = __get_storage_config(storage_cfg, "dataStorageAccount")
    logging.info(f"Storage account details: url: {url}, container: {container}, file_path: {file_path}")
    return create_dl_file_client(url, container, file_path, token_credential)


def create_dl_file_client(url, container, file_path, token_credential):
    logging.info(f"Storage account details: url: {url}, container: {container}, file_path: {file_path}")
    return DataLakeFileClient(
        account_url=url,
        file_system_name=container,
        file_path=file_path,
        credential=token_credential
    )


def get_data_container_name(storage_cfg):
    cfg = storage_cfg.get("dataStorageAccount", {})
    return cfg.get("container")


def __get_storage_config(storage_cfg, name):
    cfg = storage_cfg.get(name, {})
    url = cfg.get("url")
    container = cfg.get("container")
    return url, container


def create_dl_service_client(storage_cfg, token_credential):
    url, container = __get_storage_config(storage_cfg, "dataStorageAccount")
    return DataLakeServiceClient(
        account_url=url,
        credential=token_credential
    )


def get_dl_file_system_client(service_client, storage_cfg):
    url, container = __get_storage_config(storage_cfg, "dataStorageAccount")
    return service_client.get_file_system_client(file_system=container)


def get_db_domain_name():
    return os.environ.get("DB_DOMAIN_NAME")


def success_response(response, headers=None, status_code=200):
    logging.info(response)
    return func.HttpResponse(
        json.dumps(response),
        mimetype='application/json',
        charset='utf-8',
        headers=headers,
        status_code=status_code
    )


def failure_response(response):
    logging.error(response)
    return func.HttpResponse(
        json.dumps({'errors': response}),
        mimetype='application/json',
        charset='utf-8',
        status_code=400
    )


def validate_o_date(field, value, error):
    if not re.match(r"^\d{8}$", value):
        error(field, f"'{value}' does not match format of 'YYYYMMDD'.")
    try:
        datetime.strptime(value, '%Y%m%d')
    except ValueError:
        error(field, f"'{value}' cannot be converted into a valid date.")
