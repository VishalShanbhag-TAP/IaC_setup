import logging

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from models import FAILED, TaskRun
from shared import failure_response, success_response, create_session
from update_task_status.update_task_status_params import UpdateTaskStatusParams


def main(req: func.HttpRequest) -> func.HttpResponse:
    task_run = None
    params = None
    session = None

    try:
        params = UpdateTaskStatusParams(req.get_json())
        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()

        session = create_session(credential)
        task_run = TaskRun.get(session, params.task_run_id)
        task_run.set_status(session, params.status, params.task_run_uuid)

        return success_response({'taskRunId': task_run.id,
                                 'taskRunUuid': task_run.task_run_uuid,
                                 'status': task_run.status})

    except Exception as exception:
        logging.exception(exception)
        if task_run:
            task_run.set_status(session, FAILED, params.task_run_uuid)
        return failure_response(dict([(type(exception).__name__, str(exception))]))
