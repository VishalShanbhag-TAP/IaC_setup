from datetime import datetime

from cerberus import Validator

from models import FAILED, COMPLETED, RUNNING, SCHEDULED

UUID_REGEX = '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'

UPDATE_TASK_STATUS_SCHEMA = {
    'taskRunId': {
        'type': 'integer',
        'coerce': int,
        'required': True
    },
    'taskRunUuid': {
        'type': 'string',
        'regex': UUID_REGEX,
        'required': False
    },
    'status': {
        'type': 'string',
        'allowed': [FAILED, COMPLETED, RUNNING, SCHEDULED],
        'required': True
    }
}


class UpdateTaskStatusParams:

    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in UPDATE_TASK_STATUS_SCHEMA}
        self.validator = Validator(UPDATE_TASK_STATUS_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def task_run_id(self):
        return self.content.get('taskRunId')

    @property
    def task_run_uuid(self):
        return self.content.get('taskRunUuid')

    @property
    def status(self):
        return self.content.get('status')

    @property
    def errors(self):
        return self.validator.errors
