import pyodbc
import requests
import logging

#Generate AAD token
def get_aad_token(tenant_id, db_sp_client_id, db_sp_client_secret, resource_id):
    endpoint = f'https://login.microsoftonline.com/{tenant_id}/oauth2/token'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    payload = f"grant_type=client_credentials&client_id={db_sp_client_id}&client_secret={db_sp_client_secret}&resource={resource_id}"
    response = requests.post(endpoint, headers=headers, data=payload)

    if response.status_code == 200:
        aad_token = response.json()["access_token"]
        return aad_token
    else:
        return "INVALID"


server = 'tcp-azu0001-ase-sql-bidw-dev01-loadaccess.database.windows.net'
database = 'tcp-azu0001-ase-sdw-bidw-dev01-d01'
username = 'BIDW_DATACORE_FRAMEWORK_NPRD_SP_001'
password = get_aad_token('49dfc6a3-5fb7-49f4-adea-c54e725bb854', '745d434d-18ac-4ad8-8bc4-b0fd30ff156f', 'TqA7Q~VUA~djNO1rMqBDlbj01HHtHk6CHu2C9', 'https://ossrdbms-aad.database.windows.net')
driver= '{ODBC Driver 17 for SQL Server}'

with pyodbc.connect('DRIVER='+driver+';SERVER=tcp:'+server+';PORT=1433;DATABASE='+database+';UID='+username+';PWD='+ password) as conn:
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM test.test_table WHERE filelinenumber = 400")
        row = cursor.fetchone()
        while row:
            print (str(row[0]) + " " + str(row[1]))
            row = cursor.fetchone()





def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    controlTable = "BIDW_LD_AUDIT.JobControlTable"

    "adlsSourceTable" = "BIDW${schemaJson.scope.ssuCharacter}_LD_SDS_${schemaJson.scope.sourceSystem}_EXTERNAL_HIST.${schemaJson.scope.tableName}",

    getAdlsMaxTimestamp = query = s"SELECT max(publicationstartdttm) FROM $adlsSourceTable"

        while (resultData.next()) {
        statusResult += resultData.getString(1)
        }

        statusResult match {
        case x if x.length != 1 => {
            logger.info(s"Max timestamp returned null value setting current timestamp as default")
            getCurrentTimestamp(purpose = "controlTable")
        }
        case y => if ( y(0) == null || y(0).isEmpty) {
            logger.info(s"Max timestamp returned null value setting current timestamp as default")
            getCurrentTimestamp(purpose = "controlTable")
        } else y(0)

    
    lastSuccessfulExecutionDttm = ControlTableUtils.getLastSuccessfulExecutionDttm()

    ControlTableUtils.updateExecutionDttm(argumentJson, controlTable, controlMJobId, "LastExecutionDttm", maxTimestamp, connection)
    logger.info(s"LastExecutionDttm in $controlTable updated with $maxTimestamp value")


    ControlTableUtils.updateExecutionDttm(argumentJson, controlTable, controlMJobId, "LastExecutionDttm", maxTimestamp, connection)
    logger.info(s"LastExecutionDttm in $controlTable updated with $maxTimestamp value")


    Drop Create staging table 
        delete BIDW${schemaJson.scope.ssuCharacter}_LD_SDS_${schemaJson.scope.sourceSystem}_WRK.${schemaJson.scope.tableName}_${argumentJson.jobInstanceId}
        create BIDW${schemaJson.scope.ssuCharacter}_LD_SDS_${schemaJson.scope.sourceSystem}_WRK.${schemaJson.scope.tableName}_${argumentJson.jobInstanceId}

    insertDeltaData(): Unit = {
        println("Inserting delta data into staging table" + destinationTable)
        val allColumnsOutput = allColumns(schemaJson)

        execute(sqldwConnection,
        s"""
            INSERT INTO ${destinationTable} (${ColumnGenerator.asNames(schemaJson)})
            SELECT ${ColumnGenerator.asNames(schemaJson)} FROM ${sourceTable}
            WHERE PUBLICATIONSTARTDTTM > '${lastSuccessfulExecutionDttm}'
        """
        )

