from unittest.mock import Mock
# from invoke_spark_jar_task import invoke_spark_jar_task_params

import pytest
from assertpy import assert_that

from invoke_spark_jar_task.invoke_spark_jar_task_params import InvokeSparkJarTaskParams, INVOKE_SPARK_JAR_TASK_SCHEMA
# import invoke_spark_jar_task.invoke_spark_jar_task_params

SPARK_TASK_PARAMS = {
    'oDate': '20210715',
    'environment': 'E01',
    'taskName': 'ConformInterface',
    'jobRunId': 1,
    'taskRunId': 5,
    'mainClass': 'ConformInterface'
}

def test_spark_params_valid():
    spark_task_params = InvokeSparkJarTaskParams(SPARK_TASK_PARAMS)
    result = spark_task_params.validate()
    assert result 


def test_odate():
    spark_task_params = InvokeSparkJarTaskParams(SPARK_TASK_PARAMS)
    assert spark_task_params.o_date == '20210715'

def test_environment():
    spark_task_params = InvokeSparkJarTaskParams(SPARK_TASK_PARAMS)
    assert spark_task_params.environment == 'E01'

def test_name():
    spark_task_params = InvokeSparkJarTaskParams(SPARK_TASK_PARAMS)
    assert spark_task_params.task_name == 'ConformInterface'

def test_job_run_id():
    spark_task_params = InvokeSparkJarTaskParams(SPARK_TASK_PARAMS)
    assert spark_task_params.job_run_id == 1

def test_task_run_id():
    spark_task_params = InvokeSparkJarTaskParams(SPARK_TASK_PARAMS)
    assert spark_task_params.task_run_id == 5

def test_main_class():
    spark_task_params = InvokeSparkJarTaskParams(SPARK_TASK_PARAMS)
    assert spark_task_params.main_class == 'ConformInterface'