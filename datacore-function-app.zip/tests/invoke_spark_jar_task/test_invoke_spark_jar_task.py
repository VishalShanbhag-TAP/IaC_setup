import json
from unittest.mock import Mock
import requests
from datetime import datetime

import azure.functions as func
import pytest

from invoke_spark_jar_task import main, get_executable_path, create_cluster, get_cluster_status, restart_cluster, \
    get_aad_token, get_cluster_config, check_and_get_working_cluster, get_tenant_id, get_adb_sp_client_id_name, \
        get_adb_sp_client_id, get_adb_sp_client_secret_name, get_adb_sp_client_secret, get_adb_cluster_id, \
            get_metastore_sp_client_id
from tests.factories import JobRegistrationFactory, JobRunFactory


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('invoke_spark_jar_task', sqlalchemy_session)


@pytest.fixture(autouse=True)
def mock_access(mocker):
    mocker.patch('invoke_spark_jar_task.create_secret_client', return_value=Mock(value="XX"))
    mocker.patch.dict('os.environ', {'VAULT_URL': "https://vault_url"})

@pytest.fixture(autouse=True)
def mock_storage_config(mocker):
    storage_cfg = {
        "metadataStorageAccount": {
            "url": "https://tcp0014nsdcorchmetanprod.dfs.core.windows.net",
            "container": "datacore"
        },
        "dataStorageAccount": {
            "url": "https://tcpazbiddc1ntcpdevds1.dfs.core.windows.net",
            "container": "biddevdatalake01"
        },
        "ADBLogStorageAccount": {
            "url": "https://tcp0014nsdatacoresplunk.dfs.core.windows.net",
            "container": "datacore-adb"
        }
    }
    return mocker.patch('invoke_spark_jar_task.get_data_storage_accounts_config', return_value=storage_cfg)

@pytest.fixture
def valid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps(
            {'oDate': '20121212', 'environment': 'E01', 'taskName': 'ConformInterface', 'jobRunId': 1, 'taskRunId': 1,
             'mainClass': 'jarclass'}).encode(),
        url='/job_run')


@pytest.fixture
def invalid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps(
            {'oDate': '20121212', 'environment': None, 'taskName': 'ConformInterface', 'jobRunId': 1, 'taskRunId': 1,
             'mainClass': 'jarclass'}).encode(),
        url='/job_run')


def test_validation_failure(invalid_req):
    resp = main(invalid_req)
    result = json.loads(resp.get_body())
    assert 'environment' in result['errors']
    assert resp.status_code == 400


def test_get_job_by_id_failure(valid_req):
    resp = main(valid_req)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'get_current_job': ["Unable to get the current job run id 1 in environment E01"]}}
    assert resp.status_code == 400


def test_get_jar_path_ci():
    jar_path = get_executable_path('ConformInterface', 'IPND', 'E01')
    assert jar_path == "dbfs:/FileStore/jars/E01/datacore_conform_interface.jar"


def test_get_py_path_standardise():
    py_path = get_executable_path('StandardiseColumns', 'IPND', 'E01')
    assert py_path == "dbfs:/FileStore/patterns/E01/standarization_main.py"

def test_get_jar_path_augment_keymap():
    jar_path = get_executable_path('AugmentKeyMap', 'IPND', 'E01')
    assert jar_path == "dbfs:/FileStore/patterns/E01/augment_keymap_main.py"

def test_get_py_path_keymap_apply():
    py_path = get_executable_path('KeyMapApply', 'IPND', 'E01')
    assert py_path == "dbfs:/FileStore/patterns/E01/keymapping_main.py"

def test_get_py_path_cdc():
    py_path = get_executable_path('ChangeDataCapture', 'IPND', 'E01')
    assert py_path == "dbfs:/FileStore/patterns/E01/cdc_main.py"

def test_get_custom_jar_path(mocker):
    jar_path = get_executable_path('SparkJAR', 'IPND', 'E01')
    assert jar_path == "dbfs:/FileStore/jars/E01/IPND/IPND.jar"


# def test_create_cluster_failure(valid_req, mocker, job_registration_fixture):
def test_create_cluster_failure(valid_req, mocker):
    JobRunFactory.create(db_cluster_id=None)
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value='db_access_token_1234')
    mocker.patch('invoke_spark_jar_task.create_cluster', return_value="INVALID")

    resp = main(valid_req)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'cluster_create': ["Could not create cluster for job 1"]}}
    assert resp.status_code == 400

def test_aad_token_failure(sqlalchemy_session, valid_req, mocker):
    JobRunFactory.create()
    mocker.patch('invoke_spark_jar_task.get_tenant_id', return_value="test_tenant_id")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_id_name', return_value="test_client_id_name")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_id', return_value="test_client_id")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_secret_name', return_value="test_secret_name")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_secret', return_value="test_secret")
    mocker.patch('invoke_spark_jar_task.get_adb_cluster_id', return_value="test_cluster_id")

    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="INVALID") 

    response = main(valid_req)
    result = json.loads(response.get_body())

    assert result == {'errors': {'dbAccessToken': ["Unable to get the DB access token"]}}
    assert response.status_code == 400

def test_create_cluster_failure(sqlalchemy_session, valid_req, mocker):
    JobRunFactory.create()
    mocker.patch('invoke_spark_jar_task.get_tenant_id', return_value="test_tenant_id")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_id_name', return_value="test_client_id_name")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_id', return_value="test_client_id")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_secret_name', return_value="test_secret_name")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_secret', return_value="test_secret")
    mocker.patch('invoke_spark_jar_task.get_adb_cluster_id', return_value=None)

    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="test_aad_token")
    mocker.patch('invoke_spark_jar_task.create_cluster', return_value="INVALID") 

    response = main(valid_req)
    result = json.loads(response.get_body())

    assert result == {'errors': {'cluster_create': ["Could not create cluster for job 1"]}}
    assert response.status_code == 400

def test_create_cluster_success(sqlalchemy_session, valid_req, mocker):
    JobRunFactory.create()
    mocker.patch('invoke_spark_jar_task.get_tenant_id', return_value="test_tenant_id")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_id_name', return_value="test_client_id_name")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_id', return_value="test_client_id")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_secret_name', return_value="test_secret_name")
    mocker.patch('invoke_spark_jar_task.get_adb_sp_client_secret', return_value="test_secret")
    mocker.patch('invoke_spark_jar_task.get_adb_cluster_id', return_value=None)

    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="test_aad_token")
    mocker.patch('invoke_spark_jar_task.create_cluster', return_value="test_cluster_id") 

    response = main(valid_req)
    result = json.loads(response.get_body())

    assert result == {
            'clusterId': "test_cluster_id",
            'executablePath': "dbfs:/FileStore/jars/E01/datacore_conform_interface.jar",
            'mainClass': "jarclass",
            'jobConfigPath': "abfss://datacore@tcp0014nsdcorchmetanprod.dfs.core.windows.net/metadata/dev/E02/inbound/interface/job/JOB.job.json",
            'schemaPath': "abfss://datacore@tcp0014nsdcorchmetanprod.dfs.core.windows.net/metadata/dev/E02/inbound/interface/schema/data_set/data_set.schema.json",
            'jobName': "JOB",
            'jobRunId': 1,
            'taskRunId': 1
        }
    assert response.status_code == 200

def test_check_and_get_working_cluster_success(mocker):
    mocker.patch('invoke_spark_jar_task.get_cluster_status', return_value='TERMINATED')
    mocker.patch('invoke_spark_jar_task.create_cluster', return_value='cluster1234')
    cluster_id = check_and_get_working_cluster('vault', 'sp_client_id_name', 'sp_client_secret_name', 'tenant_id', 'access_token', 'cluster_id', 'environment', 'source_system', 'job_name', 'job_run_id', 'cluster_size')
    assert 'cluster1234' == cluster_id

def test_check_and_get_working_cluster_fail1(mocker):
    mocker.patch('invoke_spark_jar_task.get_cluster_status', return_value='TERMINATED')
    mocker.patch('invoke_spark_jar_task.create_cluster', return_value='INVALID')
    cluster_id = check_and_get_working_cluster('vault', 'sp_client_id_name', 'sp_client_secret_name', 'tenant_id', 'access_token', 'cluster_id', 'environment', 'source_system', 'job_name', 'job_run_id', 'cluster_size')
    assert 'fail1' == cluster_id

def test_check_and_get_working_cluster_fail2(mocker):
    mocker.patch('invoke_spark_jar_task.get_cluster_status', return_value='RESTARTING')
    mocker.patch('invoke_spark_jar_task.restart_cluster', return_value='INVALID')
    cluster_id = check_and_get_working_cluster('vault', 'sp_client_id_name', 'sp_client_secret_name', 'tenant_id', 'access_token', 'cluster_id', 'environment', 'source_system', 'job_name', 'job_run_id', 'cluster_size')
    assert 'fail2' == cluster_id

def test_crete_cluster(mocker):
    mocker.patch('requests.post', return_value=Mock(status_code=200, json=lambda: {'cluster_id': '1234'}))
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_id', return_value="test_metastore_sp_client_id")
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_secret', return_value="test_metastore_sp_client_secret")
    mocker.patch('invoke_spark_jar_task.get_metastore_postgres_host_name', return_value="test_metastore_postgres_host_name")
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="test_aad_token")

    return_val = create_cluster('vault', 'sp_client_id_name','sp_client_secret_name','tenant_id', 'access_token', 'E01', 'source_system', 'QBIS000001', 1, 'S')
    assert return_val == '1234'


def test_get_cluster_status(mocker):
    mocker.patch('requests.post', return_value=Mock(status_code=200, json=lambda: {'state': 'RUNNING'}))

    return_val = get_cluster_status('token', '1234')
    assert return_val == 'RUNNING'


def test_restart_cluster(mocker):
    mocker.patch('requests.post', return_value=Mock(status_code=200, json=lambda: {'state': 'RUNNING'}))

    return_val = restart_cluster('token', '1234')
    assert return_val == '1234'


def test_get_small_cluster_config(mocker):
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_id', return_value="test_metastore_sp_client_id")
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_secret', return_value="test_metastore_sp_client_secret")
    mocker.patch('invoke_spark_jar_task.get_metastore_postgres_host_name', return_value="test_metastore_postgres_host_name")
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="test_aad_token")
    
    metastore_pg_user = "azdatabricks_metastore_writer@test_metastore_postgres_host_name"
    metastore_access_token = "test_aad_token"
    metastore_connection_url = f"jdbc:postgresql://test_metastore_postgres_host_name.postgres.database.azure.com:5432/dc_metastore?user={metastore_pg_user}&password={metastore_access_token}&sslmode=require"

    cluster_config = get_cluster_config('vault', 'sp_client_id_name', 'sp_client_secret_name', 'tenant_id', 'E01', 'source_system', "QBIS000001", "1234", "S")
    log_location = "dbfs:/mnt/datacore-adb/logs/E01/source_system/QBIS000001_1234"
    client_id = "{{secrets/datacore-akv-scope/" + "sp_client_id_name" + "}}"
    client_secret = "{{secrets/datacore-akv-scope/" + "sp_client_secret_name" + "}}"
    endpoint = "https://login.microsoftonline.com/" + "tenant_id" + "/oauth2/token"

    spark_config = {
        "spark.hadoop.fs.azure.account.auth.type": "OAuth",
        "spark.hadoop.fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "spark.hadoop.fs.azure.account.oauth2.client.id": client_id,
        "spark.hadoop.fs.azure.account.oauth2.client.secret": client_secret,
        "spark.hadoop.fs.azure.account.oauth2.client.endpoint": endpoint,
        "spark.hadoop.javax.jdo.option.ConnectionURL": "{{secrets/datacore-akv-scope/datacore-metastore-connection-url}}",
        "spark.hadoop.javax.jdo.option.ConnectionUserName": "{{secrets/datacore-akv-scope/datacore-metastore-pg-user}}",
        "spark.hadoop.javax.jdo.option.ConnectionPassword": "{{secrets/datacore-akv-scope/datacore-metastore-pg-pwd}}",
        "spark.hadoop.javax.jdo.option.ConnectionDriverName": "org.postgresql.Driver",
        "spark.sql.hive.metastore.version": "0.13.0",
        "spark.hadoop.datanucleus.autoCreateSchema": "true",
        "spark.hadoop.datanucleus.autoCreateTables": "true",
        "spark.hadoop.datanucleus.fixedDatastore": "false"
    }

    assert cluster_config == {"cluster_name": "dc_source_system_QBIS000001_1234",
                              "spark_version": "9.1.x-scala2.12",
                              "node_type_id": "Standard_E4s_v4",
                              "spark_conf": spark_config,
                              "autoscale": {
                                  "min_workers": 3,
                                  "max_workers": 5
                              },
                              "autotermination_minutes": 10,
                              "cluster_log_conf": {
                                  "dbfs": {"destination": log_location}
                              }
                            }


def test_get_medium_cluster_config(mocker):
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_id', return_value="test_metastore_sp_client_id")
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_secret', return_value="test_metastore_sp_client_secret")
    mocker.patch('invoke_spark_jar_task.get_metastore_postgres_host_name', return_value="test_metastore_postgres_host_name")
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="test_aad_token")
    
    metastore_pg_user = "azdatabricks_metastore_writer@test_metastore_postgres_host_name"
    metastore_access_token = "test_aad_token"
    metastore_connection_url = f"jdbc:postgresql://test_metastore_postgres_host_name.postgres.database.azure.com:5432/dc_metastore?user={metastore_pg_user}&password={metastore_access_token}&sslmode=require"

    cluster_config = get_cluster_config('vault', 'sp_client_id_name', 'sp_client_secret_name', 'tenant_id', 'E01', 'source_system', "QBIS000001", "1234", "M")
    # today_date = datetime.today().strftime('%Y%m%d')
    log_location = "dbfs:/mnt/datacore-adb/logs/E01/source_system/QBIS000001_1234"
    client_id = "{{secrets/datacore-akv-scope/" + "sp_client_id_name" + "}}"
    client_secret = "{{secrets/datacore-akv-scope/" + "sp_client_secret_name" + "}}"
    endpoint = "https://login.microsoftonline.com/" + "tenant_id" + "/oauth2/token"

    spark_config = {
        "spark.hadoop.fs.azure.account.auth.type": "OAuth",
        "spark.hadoop.fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "spark.hadoop.fs.azure.account.oauth2.client.id": client_id,
        "spark.hadoop.fs.azure.account.oauth2.client.secret": client_secret,
        "spark.hadoop.fs.azure.account.oauth2.client.endpoint": endpoint,
        "spark.hadoop.javax.jdo.option.ConnectionURL": "{{secrets/datacore-akv-scope/datacore-metastore-connection-url}}",
        "spark.hadoop.javax.jdo.option.ConnectionUserName": "{{secrets/datacore-akv-scope/datacore-metastore-pg-user}}",
        "spark.hadoop.javax.jdo.option.ConnectionPassword": "{{secrets/datacore-akv-scope/datacore-metastore-pg-pwd}}",
        "spark.hadoop.javax.jdo.option.ConnectionDriverName": "org.postgresql.Driver",
        "spark.sql.hive.metastore.version": "0.13.0",
        "spark.hadoop.datanucleus.autoCreateSchema": "true",
        "spark.hadoop.datanucleus.autoCreateTables": "true",
        "spark.hadoop.datanucleus.fixedDatastore": "false"
    }

    assert cluster_config == {"cluster_name": "dc_source_system_QBIS000001_1234",
                              "spark_version": "9.1.x-scala2.12",
                              "node_type_id": "Standard_E4s_v4",
                              "spark_conf": spark_config,
                              "autoscale": {
                                  "min_workers": 4,
                                  "max_workers": 8
                              },
                              "autotermination_minutes": 10,
                              "cluster_log_conf": {
                                  "dbfs": {"destination": log_location}
                              }
                            }


def test_get_large_cluster_config(mocker):
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_id', return_value="test_metastore_sp_client_id")
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_secret', return_value="test_metastore_sp_client_secret")
    mocker.patch('invoke_spark_jar_task.get_metastore_postgres_host_name', return_value="test_metastore_postgres_host_name")
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="test_aad_token")
    
    metastore_pg_user = "azdatabricks_metastore_writer@test_metastore_postgres_host_name"
    metastore_access_token = "test_aad_token"
    metastore_connection_url = f"jdbc:postgresql://test_metastore_postgres_host_name.postgres.database.azure.com:5432/dc_metastore?user={metastore_pg_user}&password={metastore_access_token}&sslmode=require"

    cluster_config = get_cluster_config('vault', 'sp_client_id_name', 'sp_client_secret_name', 'tenant_id', 'E01', 'source_system', "QBIS000001", "1234", "L")
    # today_date = datetime.today().strftime('%Y%m%d')
    log_location = "dbfs:/mnt/datacore-adb/logs/E01/source_system/QBIS000001_1234"
    client_id = "{{secrets/datacore-akv-scope/" + "sp_client_id_name" + "}}"
    client_secret = "{{secrets/datacore-akv-scope/" + "sp_client_secret_name" + "}}"
    endpoint = "https://login.microsoftonline.com/" + "tenant_id" + "/oauth2/token"

    spark_config = {
        "spark.hadoop.fs.azure.account.auth.type": "OAuth",
        "spark.hadoop.fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "spark.hadoop.fs.azure.account.oauth2.client.id": client_id,
        "spark.hadoop.fs.azure.account.oauth2.client.secret": client_secret,
        "spark.hadoop.fs.azure.account.oauth2.client.endpoint": endpoint,
        "spark.hadoop.javax.jdo.option.ConnectionURL": "{{secrets/datacore-akv-scope/datacore-metastore-connection-url}}",
        "spark.hadoop.javax.jdo.option.ConnectionUserName": "{{secrets/datacore-akv-scope/datacore-metastore-pg-user}}",
        "spark.hadoop.javax.jdo.option.ConnectionPassword": "{{secrets/datacore-akv-scope/datacore-metastore-pg-pwd}}",
        "spark.hadoop.javax.jdo.option.ConnectionDriverName": "org.postgresql.Driver",
        "spark.sql.hive.metastore.version": "0.13.0",
        "spark.hadoop.datanucleus.autoCreateSchema": "true",
        "spark.hadoop.datanucleus.autoCreateTables": "true",
        "spark.hadoop.datanucleus.fixedDatastore": "false"
    }

    assert cluster_config == {"cluster_name": "dc_source_system_QBIS000001_1234",
                              "spark_version": "9.1.x-scala2.12",
                              "node_type_id": "Standard_E8s_v4",
                              "spark_conf": spark_config,
                              "autoscale": {
                                  "min_workers": 6,
                                  "max_workers": 10
                              },
                              "autotermination_minutes": 10,
                              "cluster_log_conf": {
                                  "dbfs": {"destination": log_location}
                              }
                            }


def test_get_xlarge_cluster_config(mocker):
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_id', return_value="test_metastore_sp_client_id")
    mocker.patch('invoke_spark_jar_task.get_metastore_sp_client_secret', return_value="test_metastore_sp_client_secret")
    mocker.patch('invoke_spark_jar_task.get_metastore_postgres_host_name', return_value="test_metastore_postgres_host_name")
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value="test_aad_token")
    
    metastore_pg_user = "azdatabricks_metastore_writer@test_metastore_postgres_host_name"
    metastore_access_token = "test_aad_token"
    metastore_connection_url = f"jdbc:postgresql://test_metastore_postgres_host_name.postgres.database.azure.com:5432/dc_metastore?user={metastore_pg_user}&password={metastore_access_token}&sslmode=require"

    cluster_config = get_cluster_config('vault', 'sp_client_id_name', 'sp_client_secret_name', 'tenant_id', 'E01', 'source_system', "QBIS000001", "1234", "XL")
    # today_date = datetime.today().strftime('%Y%m%d')
    log_location = "dbfs:/mnt/datacore-adb/logs/E01/source_system/QBIS000001_1234"
    client_id = "{{secrets/datacore-akv-scope/" + "sp_client_id_name" + "}}"
    client_secret = "{{secrets/datacore-akv-scope/" + "sp_client_secret_name" + "}}"
    endpoint = "https://login.microsoftonline.com/" + "tenant_id" + "/oauth2/token"

    spark_config = {
        "spark.hadoop.fs.azure.account.auth.type": "OAuth",
        "spark.hadoop.fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "spark.hadoop.fs.azure.account.oauth2.client.id": client_id,
        "spark.hadoop.fs.azure.account.oauth2.client.secret": client_secret,
        "spark.hadoop.fs.azure.account.oauth2.client.endpoint": endpoint,
        "spark.hadoop.javax.jdo.option.ConnectionURL": "{{secrets/datacore-akv-scope/datacore-metastore-connection-url}}",
        "spark.hadoop.javax.jdo.option.ConnectionUserName": "{{secrets/datacore-akv-scope/datacore-metastore-pg-user}}",
        "spark.hadoop.javax.jdo.option.ConnectionPassword": "{{secrets/datacore-akv-scope/datacore-metastore-pg-pwd}}",
        "spark.hadoop.javax.jdo.option.ConnectionDriverName": "org.postgresql.Driver",
        "spark.sql.hive.metastore.version": "0.13.0",
        "spark.hadoop.datanucleus.autoCreateSchema": "true",
        "spark.hadoop.datanucleus.autoCreateTables": "true",
        "spark.hadoop.datanucleus.fixedDatastore": "false"
    }

    assert cluster_config == {"cluster_name": "dc_source_system_QBIS000001_1234",
                              "spark_version": "9.1.x-scala2.12",
                              "node_type_id": "Standard_E8s_v4",
                              "spark_conf": spark_config,
                              "autoscale": {
                                  "min_workers": 10,
                                  "max_workers": 14
                              },
                              "autotermination_minutes": 10,
                              "cluster_log_conf": {
                                  "dbfs": {"destination": log_location}
                              }
                            }


def test_recreate_cluster_failure(valid_req, mocker):
    jr = JobRegistrationFactory.create()
    JobRunFactory.create(job_registration=jr, db_cluster_id=1234)
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value='db_access_token_1234')

    # mocker.patch('invoke_spark_jar_task.JobRun.get_cluster_for_job', return_value="123")
    mocker.patch('invoke_spark_jar_task.get_cluster_status', return_value="NOTAVAILABLE")
    mocker.patch('invoke_spark_jar_task.create_cluster', return_value="INVALID")

    resp = main(valid_req)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'cluster_recreate': ["Could not recreate cluster for job 1 with return value fail1"]}}
    assert resp.status_code == 400


def test_restart_cluster_failure(valid_req, mocker):
    JobRunFactory.create()
    mocker.patch('invoke_spark_jar_task.get_aad_token', return_value='db_access_token_1234')
    mocker.patch('invoke_spark_jar_task.create_cluster', return_value=1234)
    mocker.patch('invoke_spark_jar_task.get_cluster_status', return_value="UNKNOWN")
    mocker.patch('invoke_spark_jar_task.restart_cluster', return_value="INVALID")

    resp = main(valid_req)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'cluster_recreate': ["Could not recreate cluster for job 1 with return value fail2"]}}
    assert resp.status_code == 400


def test_get_aad_token(mocker):
    mocker.patch('requests.post', return_value=Mock(status_code=200, json=lambda: {'access_token': 'aad_token_1234'}))

    return_val = get_aad_token('tenant_id_1', 'db_sp_client_id_1', 'db_sp_client_secret_1', 'resource_id')
    assert return_val == 'aad_token_1234'

def test_get_tenant_id(mocker):
    mocker.patch('invoke_spark_jar_task.get_vault_secret', return_value='test_tenant_id')
    tenant_id = get_tenant_id('vault')
    assert tenant_id == 'test_tenant_id'

def test_get_adb_sp_client_id_name_framework():
    client_id = get_adb_sp_client_id_name('ConformInterface', 'test_source_name')
    assert client_id == 'datacore-adb-sp-client-id'

def test_get_adb_sp_client_id_name_usecase(mocker):
    client_id_name = get_adb_sp_client_id_name('SparkJAR', 'test_source_name')
    assert client_id_name == 'datacore-adb-test_source_name-sp-client-id'

def test_get_adb_sp_client_id(mocker):
    mocker.patch('invoke_spark_jar_task.get_vault_secret', return_value='test_client_id')
    client_id = get_adb_sp_client_id('vault', 'db_sp_client_id_name')
    assert client_id == 'test_client_id'

def test_get_adb_sp_client_secret_name_framework():
    client_id = get_adb_sp_client_secret_name('ConformInterface', 'test_source_name')
    assert client_id == 'datacore-adb-sp-client-secret'

def test_get_adb_sp_client_secret_name_usecase(mocker):
    client_id_name = get_adb_sp_client_secret_name('SparkJAR', 'test_source_name')
    assert client_id_name == 'datacore-adb-test_source_name-sp-client-secret'

def test_get_adb_sp_client_secret(mocker):
    mocker.patch('invoke_spark_jar_task.get_vault_secret', return_value='test_client_secret')
    client_secret = get_adb_sp_client_secret('vault', 'db_sp_client_id_name')
    assert client_secret == 'test_client_secret'

def test_get_adb_cluster_id_framework():
    cluster_id = get_adb_cluster_id('ConformInterface', 'cluster_id', 'custom_cluster_id')
    assert cluster_id == 'cluster_id'

def test_get_adb_cluster_id_usecase():
    cluster_id = get_adb_cluster_id('SparkJAR', 'cluster_id', 'custom_cluster_id')
    assert cluster_id == 'custom_cluster_id'

def test_get_metastore_sp_client_id(mocker):
    mocker.patch('invoke_spark_jar_task.get_vault_secret', return_value='test_metastore_sp_client_id')
    client_id = get_metastore_sp_client_id('vault', 'db_sp_client_id_name')
    assert client_id == 'test_metastore_sp_client_id'

def test_get_metastore_sp_client_secret(mocker):
    mocker.patch('invoke_spark_jar_task.get_vault_secret', return_value='test_metastore_sp_client_secret')
    client_id = get_metastore_sp_client_id('vault', 'db_sp_client_secret_name')
    assert client_id == 'test_metastore_sp_client_secret'