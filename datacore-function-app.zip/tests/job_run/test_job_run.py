import json
from unittest.mock import Mock

from tests.factories import EnvironmentFactory, JobRegistrationFactory, PipelineFactory, JobRunFactory, TaskRunFactory

import azure.functions as func
import pytest
from assertpy import assert_that
from azure.core.exceptions import ResourceNotFoundError

from models import Environment, RUNNING, ABORTED, FAILED, COMPLETED, JobRun, DOWNSTREAM_ACTIVITY
from job_run import main, remove_completed_tasks

JOB_PARAMS = {
    'name': 'JOB',
    'jobType': 'STORED_PRC',
    'ssu': 'retail',
    'sourceSystem': 'IPND',
    'tableName': 'table',
    'tasks': [
        {
            'name': 'CopyData',
            'parameters': {
                "activity": DOWNSTREAM_ACTIVITY,
                'source': "ADLS",
                'destination': "CSA",
                'sequenceEnforced': False,
                'filePattern': "TEST_*",
                'fileExtensions': ["dat", "ctl"],
                'compression': False
            }
        },
        {
            'name': 'ConformInterface',
            'parameters': {
                'mainClass': 'ConformInterface'
            }
        }
    ]
}

JOB_WITHOUT_TASKS = {
    **JOB_PARAMS,
    "tasks": []
}


@pytest.fixture
def ctx():
    return Mock(invocation_id="id")


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('job_run', sqlalchemy_session)


@pytest.fixture(autouse=True)
def mock_storage_config(mocker):
    storage_cfg = {
        "metadataStorageAccount": {
            "url": "https://tcp0014nsdcorchmetanprod.dfs.core.windows.net",
            "container": "datacore"
        }
    }
    return mocker.patch('job_run.get_data_storage_accounts_config', return_value=storage_cfg)


@pytest.fixture(autouse=True)
def mock_access(mocker):
    mocker.patch('job_run.create_secret_client', return_value=Mock(value="XX"))
    mocker.patch.dict('os.environ', {'VAULT_URL': "https://vault_url"})
    mocker.patch.dict('os.environ', {'METADATA_STORAGE_URL': "https://metadata.storage.url"})


@pytest.fixture(autouse=True)
def patch_metadata_dl_file_client(mocker):
    download_mock = Mock(**{'readall.return_value': json.dumps(JOB_PARAMS)})
    mocker.patch('job_run.create_metadata_dl_file_client',
                 return_value=Mock(**{'download_file.return_value': download_mock}))


@pytest.fixture(autouse=True)
def patch_df_mgmt_client(mocker):
    pipelines_mock = Mock(**{'create_run.return_value': Mock(run_id='xyz')})
    mocker.patch('job_run.create_df_mgmt_client', return_value=Mock(pipelines=pipelines_mock))


@pytest.fixture
def req(job_name, o_date, environment, retry=False):
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobName': job_name, 'oDate': o_date, 'environment': environment, 'retry': retry}).encode(),
        url='/job_run')


@pytest.fixture
def valid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobName': 'JOB', 'oDate': '20121212', 'environment': 'E01'}).encode(),
        url='/job_run')


@pytest.fixture
def create_retry_req():
    def _retry_req_(retry=True):
        return func.HttpRequest(
            method='POST',
            body=json.dumps({'jobName': 'JOB', 'oDate': '20121212', 'environment': 'E01', 'retry': retry}).encode(),
            url='/job_run')

    return _retry_req_


@pytest.mark.parametrize("job_name, o_date, environment", [('job', '2020', None)])
def test_validation_failure(req, ctx):
    resp = main(req, ctx)
    result = json.loads(resp.get_body())
    assert 'oDate' in result['errors']
    assert resp.status_code == 400


def test_environment_failure(valid_req, ctx):
    EnvironmentFactory.create(name="E02")

    resp = main(valid_req, ctx)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'environment': ["'E01' is not allowed. Must be one of ['E02']"]}}
    assert resp.status_code == 400


def test_job_registration_failure(valid_req, ctx, sqlalchemy_session):
    EnvironmentFactory.create_batch(2)
    e02 = Environment.get_by_name(sqlalchemy_session, "E02")
    JobRegistrationFactory.create(job_name="JOB", environment=e02)

    resp = main(valid_req, ctx)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'jobRegistration': ["'JOB' has not been registered for environment 'E01'."]}}
    assert resp.status_code == 400


def test_last_job_failure(valid_req, ctx):
    jr = JobRegistrationFactory.create(job_name="JOB")
    JobRunFactory.create(status=RUNNING, job_registration=jr, o_date="20121212", environment=jr.environment)

    resp = main(valid_req, ctx)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'jobRun': ["'#1' has not completed running."]}}
    assert resp.status_code == 400


def test_job_json_retrieval_failure(valid_req, ctx, mocker):
    metadata_dl_file_client = mocker.patch('job_run.create_metadata_dl_file_client')
    dl_file_client_mock_instance = metadata_dl_file_client.return_value
    dl_file_client_mock_instance.download_file.side_effect = ResourceNotFoundError("x not found")

    JobRegistrationFactory.create(job_name="JOB")
    PipelineFactory.create()

    resp = main(valid_req, ctx)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'jobRegistration': "'metadata/dev/E01/inbound/interface/job/JOB.job.json' not found."}}
    assert resp.status_code == 400


def test_pipeline_not_found_failure(valid_req, ctx):
    JobRegistrationFactory.create(job_name="JOB")

    resp = main(valid_req, ctx)
    result = json.loads(resp.get_body())
    assert result == {'errors': {'pipeline': "not found with name 'bootstrap'."}}
    assert resp.status_code == 400


def test_task_params_empty_failure(valid_req, ctx, mocker):
    download_mock = Mock(**{'readall.return_value': json.dumps(JOB_WITHOUT_TASKS)})
    mocker.patch('job_run.create_metadata_dl_file_client',
                 return_value=Mock(**{'download_file.return_value': download_mock}))

    JobRegistrationFactory.create(job_name="JOB")
    PipelineFactory.create()

    resp = main(valid_req, ctx)

    result = json.loads(resp.get_body())
    assert_that({'tasks': ['min length is 1']}).is_subset_of(result['errors'])
    assert resp.status_code == 400


def test_task_params_absent_failure(valid_req, ctx, mocker):
    JobRegistrationFactory.create()
    JobRunFactory.create(status=RUNNING)
    PipelineFactory.create()

    download_mock = Mock(**{'readall.return_value': json.dumps({})})
    mocker.patch('job_run.create_metadata_dl_file_client',
                 return_value=Mock(**{'download_file.return_value': download_mock}))

    resp = main(valid_req, ctx)
    result = json.loads(resp.get_body())
    assert_that(result).contains_key('errors')
    assert_that({'tasks': ['required field']}).is_subset_of(result['errors'])
    assert resp.status_code == 400


def test_job_run_success(valid_req, ctx):
    env = EnvironmentFactory.create()
    JobRegistrationFactory.create(job_name="JOB", environment=env)
    PipelineFactory.create()

    resp = main(valid_req, ctx)
    result = json.loads(resp.get_body())
    assert result == {'jobRun': {'id': 1, 'uuid': 'xyz'}}
    assert resp.status_code == 202


@pytest.mark.parametrize("states, exp_count", [
    ((FAILED, [COMPLETED, FAILED, ABORTED]), 2),
    ((COMPLETED, [COMPLETED, COMPLETED, COMPLETED]), 0)])
def test_remove_completed_tasks(states, exp_count, sqlalchemy_session):
    job_state, task_states = states
    jr = JobRunFactory.create(status=job_state)
    for status in task_states:
        TaskRunFactory.create(status=status, job_run=jr)

    job_config = {
        'tasks': [
            {'name': 'Task 1'},
            {'name': 'Task 2'},
            {'name': 'Task 3'}
        ]
    }

    job_run = JobRun.get(sqlalchemy_session, 1)
    result = remove_completed_tasks(job_config, job_run)
    assert_that(result['tasks']).is_length(exp_count)


@pytest.mark.parametrize("exp_result, exp_status_code, retry", [
    ({'jobRun': {'id': 2, 'uuid': 'xyz'}}, 202, True),
    ({'errors': {'jobRun': ["'#1' has completed successfully and cannot be rerun."]}}, 400, False)
])
def test_retry(exp_result, exp_status_code, retry, create_retry_req, ctx):
    e = EnvironmentFactory.create(name="E01")
    job_reg = JobRegistrationFactory.create(environment=e)
    JobRunFactory.create(status=COMPLETED, job_registration=job_reg, environment=e)
    PipelineFactory.create()

    resp = main(create_retry_req(retry), ctx)
    result = json.loads(resp.get_body())
    assert_that(exp_result).is_equal_to(result)
    assert_that(exp_status_code).is_equal_to(resp.status_code)
