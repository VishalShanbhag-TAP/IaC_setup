from unittest.mock import Mock

from assertpy import assert_that

from job_run import JobRunParams

import pytest

valid_params = [
    ({'jobName': 'one', 'oDate': '20000101', 'environment': 'E01'}),
    ({'jobName': 'two', 'oDate': '19990101', 'environment': 'E01', 'retry': True}),
]


@pytest.mark.parametrize("doc", valid_params)
def test_validator_success(doc):
    params = JobRunParams(doc)
    params.validate()
    assert params.validate()


@pytest.mark.parametrize("retry", [False, True])
def test_retry_is_false(retry):
    params = JobRunParams({'retry': retry})
    assert_that(params.retry).is_equal_to(retry)

invalid_params = [
    ({'jobName': 'one', 'oDate': '2001', 'environment': 'E01'}),
    ({}),
    ({'jobName': 'on', 'oDate': '1999-12-12'})
]

@pytest.mark.parametrize("doc", invalid_params)
def test_validator_failure(doc):
    params = JobRunParams(doc)
    assert not params.validate()
