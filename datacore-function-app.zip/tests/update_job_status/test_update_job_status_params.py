from update_job_status.update_job_status_params import UpdateJobStatusParams


import pytest

valid_params = [
    ({
        'jobRunId': 1,
        'jobRunUuid': '54116e25-8212-4c0c-b1bb-5fd5b2988796',
        'status': 'failed'
    }),
]


@pytest.mark.parametrize("doc", valid_params)
def test_validator_success(doc):
    params = UpdateJobStatusParams(doc)
    assert params.validate()


invalid_params = [
    ({'jobRunId': 1, 'jobRunUuid': 1, 'status': 'FAILED'}),
    ({}),
    ({
        'jobRunId': 1,
        # Invalid UUID
        'jobRunUuid': '54116e25-8212-4c0c-b1bb65fd5b2988796',
        'status': 'failed'
    }),
    ({
        'jobRunId': 1,
        'jobRunUuid': '54116e25-8212-4c0c-b1bb-5fd5b2988796',
        # Invalid status ( must be lower case )
        'status': 'FAILED'
    }),
]


@pytest.mark.parametrize("doc", invalid_params)
def test_validator_failure(doc):
    params = UpdateJobStatusParams(doc)
    assert not params.validate()




