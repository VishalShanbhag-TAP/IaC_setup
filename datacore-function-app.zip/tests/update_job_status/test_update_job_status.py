import json
import azure.functions as func
import pytest
from unittest.mock import Mock

from tests.factories import TaskRunFactory
from update_job_status import main


@pytest.fixture(autouse=True)
def mock_access(mocker):
    mocker.patch('update_job_status.create_secret_client', return_value=Mock(value="XX"))
    mocker.patch.dict('os.environ', {'VAULT_URL': "https://vault_url"})


@pytest.fixture(autouse=True)
def mock_create_session(mocker, sqlalchemy_session):
    return mocker.patch('update_job_status.create_session', return_value=sqlalchemy_session)


@pytest.fixture
def req(task_run_id, task_run_uuid, status):
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobRunId': task_run_id, 'jobRunUuid': task_run_uuid, 'status': status}).encode(),
        url='/update_job_status')


@pytest.mark.parametrize("task_run_id, task_run_uuid, status", [('d', '2x', None)])
def test_validation_failure(req):
    resp = main(req)
    result = json.loads(resp.get_body())
    assert 'jobRunId' in result['errors']
    assert 'jobRunUuid' in result['errors']
    assert 'status' in result['errors']
    assert resp.status_code == 400


@pytest.mark.parametrize("task_run_id, task_run_uuid, status",
                         [('1', '54116e25-8212-4c0c-b1bb-5fd5b2988796', 'failed')])
def test_update_task_success(req, task_run_uuid, status):
    TaskRunFactory.create(task_run_uuid=task_run_uuid, status=status)
    resp = main(req)
    result = json.loads(resp.get_body())
    assert result == {'jobRunUuid': '54116e25-8212-4c0c-b1bb-5fd5b2988796'}
    assert resp.status_code == 200
