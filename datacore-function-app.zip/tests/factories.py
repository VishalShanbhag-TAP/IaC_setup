import inspect
import re
import sys

import factory
from factory.fuzzy import FuzzyInteger

from models import Environment, FileRegistration, JobRun, TaskRun, JobRegistration, SCHEDULED, Pipeline, FileLocation, \
    UPSTREAM_ACTIVITY, FILE_REGISTERED, KeymapLocks
from tests import common


class EnvironmentFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = Environment
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    name = factory.Sequence(lambda n: f"E0{n + 1}")
    type = "dev"


class JobRegistrationFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = JobRegistration
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    job_name = "JOB"
    environment = factory.SubFactory(EnvironmentFactory)
    source_system = "interface"
    direction = "inbound"
    table_name = "data_set"
    ssu = "retail"


class JobRunFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = JobRun
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    status = SCHEDULED
    o_date = "20121212"
    db_cluster_id = 1

    environment = factory.SubFactory(EnvironmentFactory)
    job_registration = factory.SubFactory(JobRegistrationFactory)


class TaskRunFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = TaskRun
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    name = factory.Sequence(lambda n: f"Task {n + 1}")
    status = SCHEDULED

    job_run = factory.SubFactory(JobRunFactory)


class PipelineFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = Pipeline
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    slug = "bootstrap"
    resource_group_name = "rgn"
    factory_name = "fn"
    name = "main"


class FileLocationFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = FileLocation
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    environment_type = 'dev'
    target_type = 'SOURCE'
    target_name = 'ADLS'
    path_pattern = '/data/<ENV>/outbound/<SSU>/<SOURCE_SYSTEM>/<TABLE_NAME>'


class FileRegistrationFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = FileRegistration
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    file_name = factory.Sequence(lambda n: f"File{n + 1}")
    file_pattern = "TEST_<YYYYMMDD>_*"
    file_extensions = "dat, eot, ctl"
    status = FILE_REGISTERED
    activity = UPSTREAM_ACTIVITY
    record_count = FuzzyInteger(100, 200)
    sequence = factory.Sequence(lambda n: n + 1)

    job_run = factory.SubFactory(JobRunFactory)
    job_registration = factory.SubFactory(JobRegistrationFactory)
    environment = factory.SubFactory(EnvironmentFactory)
    source_file_location = factory.SubFactory(FileLocationFactory)
    destination_file_location = factory.SubFactory(FileLocationFactory)

class KeymapLocksFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        model = KeymapLocks
        sqlalchemy_session = common.Session

    id = factory.Sequence(lambda n: n + 1)
    environment_name = "E01"
    keymap_table = "test_keymap_table"
    # job_run = factory.SubFactory(JobRunFactory)
    # task_run = factory.SubFactory(TaskRunFactory)
    # job_run_id = 1
    # task_run_id = 5
    status = "locked"


# Reset the sequence for all factories
def reset_all_sequences():
    for name, obj in inspect.getmembers(sys.modules[__name__]):
        if re.match(".*Factory", name):
            obj.reset_sequence()
