from unittest.mock import Mock

import pytest
from assertpy import assert_that

from release_lock.release_lock_params import ReleaseLockParams

RELEASE_LOCK_PARAMS = {
    'jobRunId': 1,
    'taskRunId': 5,
    'environmentName': 'E01',
    'keymapTable': 'test_keymap_table'
}

def test_release_lock_params_valid():
    release_lock_params = ReleaseLockParams(RELEASE_LOCK_PARAMS)
    result = release_lock_params.validate()
    assert result

def test_job_run_id():
    release_lock_params = ReleaseLockParams(RELEASE_LOCK_PARAMS)
    assert release_lock_params.job_run_id == 1

def test_task_run_id():
    release_lock_params = ReleaseLockParams(RELEASE_LOCK_PARAMS)
    assert release_lock_params.task_run_id == 5

def test_environment():
    release_lock_params = ReleaseLockParams(RELEASE_LOCK_PARAMS)
    assert release_lock_params.environment_name == 'E01'

def test_keymap_table():
    release_lock_params = ReleaseLockParams(RELEASE_LOCK_PARAMS)
    assert release_lock_params.keymap_table == 'test_keymap_table'