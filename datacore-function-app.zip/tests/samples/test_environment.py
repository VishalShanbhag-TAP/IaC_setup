from tests.conftest import *
from tests.factories import EnvironmentFactory


def test_environment():
    env = EnvironmentFactory()
    assert env.name == "E01"
