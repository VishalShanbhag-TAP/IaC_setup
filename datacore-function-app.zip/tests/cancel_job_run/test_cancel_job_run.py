import json
import azure.functions as func
import pytest
from unittest.mock import Mock

from cancel_job_run import main
from tests.factories import TaskRunFactory, JobRunFactory, PipelineFactory


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('cancel_job_run', sqlalchemy_session)


@pytest.fixture(autouse=True)
def mock_access(mocker):
    mocker.patch('cancel_job_run.create_secret_client', return_value=Mock(value="XX"))
    mocker.patch.dict('os.environ', {'VAULT_URL': "https://vault_url"})


@pytest.fixture(autouse=True)
def patch_df_mgmt_client(mocker):
    pipelines_mock = Mock(**{'cancel.return_value': Mock(run_id='xyz')})
    mocker.patch('cancel_job_run.create_df_mgmt_client', return_value=Mock(pipelines=pipelines_mock))


@pytest.fixture
def req(task_run_id):
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'taskRunId': task_run_id}).encode(),
        url='/cancel_job_run')


@pytest.mark.parametrize("task_run_id", [()])
def test_validation_failure(req):
    resp = main(req)
    result = json.loads(resp.get_body())
    assert 'taskRunId' in result['errors']
    assert resp.status_code == 400


@pytest.mark.parametrize("task_run_id", [1])
def test_update_task_success(req):
    job_run = JobRunFactory.create(job_run_uuid='abc')
    TaskRunFactory.create(task_run_uuid='def', job_run=job_run)
    PipelineFactory.create()

    resp = main(req)
    result = json.loads(resp.get_body())
    assert result == {'jobRunUuid': 'abc', 'taskRunUuid': 'def'}
    assert resp.status_code == 200
