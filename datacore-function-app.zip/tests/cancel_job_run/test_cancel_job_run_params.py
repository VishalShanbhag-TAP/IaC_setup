import pytest

from cancel_job_run import CancelJobRunParams


def test_validator_success():
    doc = {'taskRunId': 1}
    params = CancelJobRunParams(doc)
    assert params.validate()


def test_validator_failure():
    params = CancelJobRunParams({})
    assert not params.validate()
