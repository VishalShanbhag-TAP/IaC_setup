import pytest
import sqlalchemy

from models import Base
from tests import common
from tests.factories import reset_all_sequences

engine = sqlalchemy.create_engine('sqlite://')
common.Session.configure(bind=engine, autocommit=False, autoflush=True)
Base.metadata.create_all(engine)


@pytest.fixture(autouse=True)
def sqlalchemy_session():
    s = common.Session()
    yield s
    s.rollback()
    for table in reversed(Base.metadata.sorted_tables):
        s.execute(table.delete())


@pytest.fixture(autouse=True)
def reset_factory_sequences():
    reset_all_sequences()


@pytest.fixture(autouse=True)
def module_name():
    return ""


@pytest.fixture
def create_mock_session(mocker):
    def _create_mock_session(module_name, session):
        return mocker.patch(f"{module_name}.create_session", return_value=session)
    return _create_mock_session
