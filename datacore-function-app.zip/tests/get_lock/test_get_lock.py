import json
import azure.functions as func
import pytest
from assertpy import assert_that
from unittest.mock import Mock

from tests.factories import KeymapLocksFactory
from get_lock import main

@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('get_lock', sqlalchemy_session)

@pytest.fixture
def valid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobRunId': 1, 'taskRunId': 5, 'environmentName': 'E01', 'keymapTable': 'test_keymap_table'}).encode(),
        url='/get_lock')

def test_keymap_lock_acquire_success(valid_req):
    response = main(valid_req)
    result = json.loads(response.get_body())

    assert result == {"keymap_table": "test_keymap_table", "lock_acquired": "true"}
    assert response.status_code == 200

def test_keymap_lock_acquire_failure(valid_req):
    KeymapLocksFactory.create()

    response = main(valid_req)
    print(json.loads(response.get_body()))
    result = json.loads(response.get_body())

    assert result == {"keymap_table": "test_keymap_table", "lock_acquired": "false"}
    assert response.status_code == 200

