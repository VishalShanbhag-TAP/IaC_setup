from unittest.mock import Mock

import pytest
from assertpy import assert_that

from get_lock.get_lock_params import GetLockParams, GET_LOCK_SCHEMA

GET_LOCK_PARAMS = {
    'jobRunId': 1,
    'taskRunId': 5,
    'environmentName': 'E01',
    'keymapTable': 'test_keymap_table'
}

def test_get_lock_params_valid():
    get_lock_params = GetLockParams(GET_LOCK_PARAMS)
    result = get_lock_params.validate()
    assert result

def test_job_run_id():
    get_lock_params = GetLockParams(GET_LOCK_PARAMS)
    assert get_lock_params.job_run_id == 1

def test_task_run_id():
    get_lock_params = GetLockParams(GET_LOCK_PARAMS)
    assert get_lock_params.task_run_id == 5

def test_environment():
    get_lock_params = GetLockParams(GET_LOCK_PARAMS)
    assert get_lock_params.environment_name == 'E01'

def test_keymap_table():
    get_lock_params = GetLockParams(GET_LOCK_PARAMS)
    assert get_lock_params.keymap_table == 'test_keymap_table'