from unittest.mock import Mock
import pytest
from assertpy import assert_that

from generate_ctl.generate_ctl_params import GenerateCtlParams

GENERATE_CTL_PARAMS = {
    'jobName': "JOB",
    "oDate": "20121212",
    "environmentName": "E01"
}


def test_generate_ctl_params_valid():
    generate_ctl_params = GenerateCtlParams(GENERATE_CTL_PARAMS)
    result = generate_ctl_params.validate()
    assert_that(result).is_true()
