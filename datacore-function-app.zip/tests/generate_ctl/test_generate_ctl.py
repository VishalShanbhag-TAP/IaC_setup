import json
from unittest.mock import Mock
import requests

import azure.functions as func
import pytest
from assertpy import *

from tests.factories import JobRunFactory
from generate_ctl import main

DATA_FILE = """HDRIPNDUPRASS1000000520200217014124\nsampledata\nTRL0000005202002170141240000010\n"""


@pytest.fixture(autouse=True)
def mock_create_session(mocker, sqlalchemy_session):
    return mocker.patch('generate_ctl.create_session', return_value=sqlalchemy_session)


@pytest.fixture(autouse=True)
def mock_storage_config(mocker):
    storage_cfg = {
        "metadataStorageAccount": {
            "url": "https://tcp0014nsdcorchmetanprod.dfs.core.windows.net",
            "container": "datacore"
        }
    }
    return mocker.patch('generate_ctl.get_data_storage_accounts_config', return_value=storage_cfg)


@pytest.fixture(autouse=True)
def mock_access(mocker):
    mocker.patch('generate_ctl.create_secret_client', return_value=Mock(value="XX"))
    mocker.patch.dict('os.environ', {'VAULT_URL': "https://vault_url"})


@pytest.fixture(autouse=True)
def mock_dl_service_client(mocker):
    return mocker.patch('generate_ctl.create_dl_service_client').return_value


@pytest.fixture
def valid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobName': "JOB", "oDate": "20121212", "environmentName": "E01"}).encode(),
        url='/generate_ctl')


@pytest.fixture
def invalid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobName': "JOB", "oDate": "20121212", "environmentName": "E01"}).encode(),
        url='/generate_ctl')


def test_job_registration_failure(sqlalchemy_session, invalid_req):
    JobRunFactory.create()
    response = main(invalid_req)
    result = json.loads(response.get_body())
    assert result == {'errors': {'jobRegistration': ["'JOB' has not been registered for environment 'E01'."]}}
    assert response.status_code == 400
