import json
import azure.functions as func
import pytest
from assertpy import assert_that

from tests.factories import TaskRunFactory
from update_task_status import main


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('update_task_status', sqlalchemy_session)


@pytest.fixture
def req(task_run_id, task_run_uuid, status):
    payload = {
        'taskRunId': task_run_id,
        'status': status
    }
    if task_run_uuid:
        payload['taskRunUuid'] = task_run_uuid
    return func.HttpRequest(
        method='POST',
        body=json.dumps(payload).encode(),
        url='/update_task_status')



@pytest.mark.parametrize("task_run_id, task_run_uuid, status", [('d', '2x', None)])
def test_validation_failure(req):
    resp = main(req)
    result = json.loads(resp.get_body())
    assert 'taskRunId' in result['errors']
    assert 'taskRunUuid' in result['errors']
    assert 'status' in result['errors']
    assert resp.status_code == 400


@pytest.mark.parametrize("task_run_id, task_run_uuid, status", [
    (1, '54116e25-8212-4c0c-b1bb-5fd5b2988796', 'failed'),
    (1, None, 'completed')
])
def test_update_task_success(req, task_run_uuid, task_run_id, status):
    TaskRunFactory.create(task_run_uuid =task_run_uuid)
    resp = main(req)
    result = json.loads(resp.get_body())
    assert_that(result).contains_entry({'status': status})
    assert_that(result).contains_entry({'taskRunId': task_run_id})
    assert_that(result).contains_entry({'taskRunUuid': task_run_uuid})
    assert_that(resp.status_code).is_equal_to(200)
