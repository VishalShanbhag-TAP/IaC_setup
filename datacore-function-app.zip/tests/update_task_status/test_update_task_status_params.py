from update_task_status.update_task_status_params import UpdateTaskStatusParams


import pytest

valid_params = [
    ({
        'taskRunId': 1,
        'taskRunUuid': '54116e25-8212-4c0c-b1bb-5fd5b2988796',
        'status': 'failed'
    }),
]


@pytest.mark.parametrize("doc", valid_params)
def test_validator_success(doc):
    params = UpdateTaskStatusParams(doc)
    assert params.validate()


invalid_params = [
    ({'taskRunId': 1, 'taskRunUuid': 1, 'status': 'FAILED'}),
    ({}),
    ({
        'taskRunId': 1,
        # Invalid UUID
        'taskRunUuid': '54116e25-8212-4c0c-b1bb65fd5b2988796',
        'status': 'failed'
    }),
    ({
        'taskRunId': 1,
        'taskRunUuid': '54116e25-8212-4c0c-b1bb-5fd5b2988796',
        # Invalid status ( must be lower case )
        'status': 'FAILED'
    }),
]


@pytest.mark.parametrize("doc", invalid_params)
def test_validator_failure(doc):
    params = UpdateTaskStatusParams(doc)
    assert not params.validate()




