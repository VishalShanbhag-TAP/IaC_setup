import json

import azure.functions as func
import pytest
from assertpy import assert_that

from force_complete_job_run import main
from models import FORCE_COMPLETED, SCHEDULED
from tests.factories import JobRunFactory, TaskRunFactory


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('force_complete_job_run', sqlalchemy_session)


@pytest.fixture
def req(job_run_id, soft):
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobRunId': job_run_id, 'soft': soft}).encode(),
        url='/force_complete_job_run')


@pytest.mark.parametrize("job_run_id, soft", [(None, None)])
def test_validation_failure(req):
    resp = main(req)
    result = json.loads(resp.get_body())
    assert 'jobRunId' in result['errors']
    assert resp.status_code == 400


@pytest.mark.parametrize("job_run_id, soft, exp_status", [(1, True, SCHEDULED), (1, False, FORCE_COMPLETED)])
def test_force_complete_post(req, exp_status):
    jr = JobRunFactory.create()
    TaskRunFactory.create(job_run=jr)

    resp = main(req)
    result = json.loads(resp.get_body())
    assert_that(result).contains_value(exp_status)
    assert_that(result).contains('taskRuns')
    assert_that(result['taskRuns']).extracting('status').contains(exp_status)

    assert resp.status_code == 200
