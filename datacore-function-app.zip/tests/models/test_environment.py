import factory
import pytest
from assertpy import assert_that

from tests.factories import EnvironmentFactory

from models import Environment


def test_get(sqlalchemy_session):
    EnvironmentFactory.create()
    e = Environment.get(sqlalchemy_session, 1)
    assert e.name == "E01"
    assert e.type == "dev"


def test_get_by_name(sqlalchemy_session):
    EnvironmentFactory.create()
    e = Environment.get_by_name(sqlalchemy_session, "E01")
    assert e.name == "E01"


def test_get_all(sqlalchemy_session):
    EnvironmentFactory.create_batch(2)
    envs = Environment.get_all(sqlalchemy_session)
    assert_that(envs).is_equal_to(["E01", "E02"])
