import pytest
from assertpy import assert_that

from models import JobRegistration, FILE_REGISTERED, UPSTREAM_ACTIVITY, SOURCE, DESTINATION
from tests.factories import JobRegistrationFactory, EnvironmentFactory, JobRunFactory, FileLocationFactory
from tests.register_files.params_fixture import params, payload


def test_get_last_by_name_and_env(sqlalchemy_session):
    e = "E01"
    jn = "JOB"
    source_name = "b"

    env = EnvironmentFactory.create(name=e)
    JobRegistrationFactory.create(environment=env, job_name=jn, source_system=source_name)

    jr = JobRegistration.get(sqlalchemy_session, jn, e)
    assert_that(jr).is_not_none()
    assert_that(jr.source_system).is_equal_to(source_name)
    assert_that(jr.storage_account_job_file_path()).is_equal_to("metadata/dev/E01/inbound/b/job/JOB.job.json")
    assert_that(jr.storage_account_schema_file_path()).is_equal_to("metadata/dev/E01/inbound/b/schema/data_set/data_set.schema.json")


def test_job_runs_relationship(sqlalchemy_session):
    job_reg = JobRegistrationFactory.create()
    JobRunFactory.create_batch(2, job_registration=job_reg)
    jr = JobRegistration.get(sqlalchemy_session, "JOB", "E01")
    assert_that(jr.job_runs).is_length(2)


def test_register_files(sqlalchemy_session, params):
    tr = JobRegistrationFactory.create()
    source_file_location = FileLocationFactory.create(target_type='SOURCE', target_name='CSA')
    destination_file_location = FileLocationFactory.create(target_type='DESTINATION', target_name='ADLS')
    file_registrations = tr.register_files(sqlalchemy_session, params, source_file_location, destination_file_location)
    assert_that(file_registrations).extracting('job_registration_id').is_equal_to([1, 1])
    assert_that(file_registrations).extracting('file_pattern').contains_only("TEST_<YYYYMMDD>_*")
    assert_that(file_registrations).extracting('source_file_location').contains_only(source_file_location)
    assert_that(file_registrations).extracting('destination_file_location').contains_only(destination_file_location)
    assert_that(file_registrations).extracting('file_name').is_equal_to(['/file/a_name.txt', '/file/b_name.txt'])
    assert_that(file_registrations).extracting('sequence').is_equal_to([2, 3])
    assert_that(file_registrations).extracting('status').contains_only(FILE_REGISTERED)
    assert_that(file_registrations).extracting('activity').contains_only(UPSTREAM_ACTIVITY)
    assert_that(file_registrations).extracting('environment_id').contains_only(1)


def test_resolve_path(sqlalchemy_session):
    job_reg = JobRegistrationFactory.create()
    resolved_path = job_reg.resolve_path("<ENV>/<SOURCE_SYSTEM>/<SSU>/<TABLE_NAME>/<ODATE>", [('<ODATE>', '20121212')])
    assert_that(resolved_path).is_equal_to("E01/interface/retail/data_set/20121212")


