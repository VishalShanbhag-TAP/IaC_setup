import pytest
from assertpy import assert_that

from models import Pipeline
from tests.factories import PipelineFactory


def test_get(sqlalchemy_session):
    PipelineFactory.create()
    pl = Pipeline.get(sqlalchemy_session, 1)
    assert_that(pl).is_not_none()


def test_bootstrap(sqlalchemy_session):
    PipelineFactory.create()
    pl = Pipeline.bootstrap(sqlalchemy_session)
    assert_that(pl).is_instance_of(Pipeline)


def test_run_config():
    pl = PipelineFactory.build()
    assert pl.run_config() == ['rgn', 'fn', 'main']
