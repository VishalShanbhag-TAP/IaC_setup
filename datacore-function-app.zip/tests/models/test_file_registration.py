import pytest
from assertpy import assert_that

from models import FileRegistration, UPSTREAM_ACTIVITY, FILE_REGISTERED, JobRegistration, FILE_COPIED
from params.file_registration_params import FileRegistrationParams
from register_files import FILE_REGISTRATION_SCHEMA
from tests.factories import FileRegistrationFactory, JobRegistrationFactory


@pytest.fixture
def file_registration_params():
    params = {
        'taskRunId': 1,
        'jobRunId': 1,
        'oDate': '20121212',
        'filePattern': 'TEST_<YYYYMMDD>_*',
        'source': 'CSA',
        'destination': 'CSA',
        'activity': UPSTREAM_ACTIVITY,
        'fileExtensions': ['.csv', '.eot'],
        'files': [
            {
                'fileName': '/file/a_name.txt',
                'recordCount': 1,
                'sequence': '1',
                'status': FILE_REGISTERED
            },
            {
                'fileName': '/file/b_name.txt',
                'recordCount': 1,
                'sequence': '1',
                'status': FILE_REGISTERED
            }
        ]
    }
    return FileRegistrationParams(FILE_REGISTRATION_SCHEMA, params)


def test_to_get(sqlalchemy_session):
    frg = FileRegistrationFactory.create()
    assert_that(FileRegistration.get(sqlalchemy_session, frg.id)).is_instance_of(FileRegistration)


def test_to_dict():
    frg = FileRegistrationFactory.build()
    frg_dict = frg.to_dict()
    assert_that(frg_dict).contains_entry({'fileName': 'File1'})
    assert_that(frg_dict).contains_key('fileName', 'id', 'recordCount', 'sequence')


@pytest.mark.parametrize("batch_size, exp_seq", [(2, 2), (0, None)])
def test_last_sequence(sqlalchemy_session, batch_size, exp_seq):
    job_name = "JOB"
    o_date = "20121212"
    jr = JobRegistrationFactory.create(job_name=job_name)
    FileRegistrationFactory.create_batch(batch_size, job_registration=jr, o_date=o_date)
    seq = FileRegistration.last_sequence(sqlalchemy_session, job_name, "E01", FILE_REGISTERED)
    assert_that(seq).is_equal_to(exp_seq)


@pytest.mark.parametrize("batch_size, exp_count", [(2, 2), (0, 0)])
def test_all(sqlalchemy_session, batch_size, exp_count):
    job_name = "JOB"
    o_date = "20121212"
    jr = JobRegistrationFactory.create(job_name=job_name)
    FileRegistrationFactory.create_batch(2, job_registration=jr, o_date="20000000")
    FileRegistrationFactory.create_batch(batch_size, job_registration=jr, o_date=o_date)
    file_reg = FileRegistration.all(sqlalchemy_session, job_name, o_date, "E01", FILE_REGISTERED)
    assert_that(file_reg).is_length(exp_count)


def test_update_status(sqlalchemy_session):
    job_name = "JOB"
    o_date = "20121212"
    jr = JobRegistrationFactory.create(job_name=job_name)
    FileRegistrationFactory.create_batch(3, job_registration=jr, o_date=o_date, status=FILE_REGISTERED)
    row_count = FileRegistration.update_status(sqlalchemy_session, jr, o_date, FILE_COPIED, 22)
    file_reg = FileRegistration.get(sqlalchemy_session, 1)
    assert_that(file_reg.job_run_id).is_equal_to(22)
    assert_that(row_count).is_equal_to(3)


def test_data_file_name(sqlalchemy_session):
    file_registration = FileRegistrationFactory.create()
    assert_that(file_registration.data_file_name).is_equal_to("File1.dat")
