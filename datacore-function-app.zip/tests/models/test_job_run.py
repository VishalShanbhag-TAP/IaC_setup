import pytest
from assertpy import assert_that

from models import RUNNING, COMPLETED, FAILED, ABORTED, FORCE_COMPLETED, JobRun, SCHEDULED, SOURCE, DESTINATION, CSA, \
    ADLS
from tests.factories import JobRunFactory, TaskRunFactory, EnvironmentFactory, JobRegistrationFactory, \
    FileLocationFactory


@pytest.fixture(autouse=True)
def mock_storage_config(mocker):
    storage_cfg = {
        "metadataStorageAccount": {
            "url": "https://tcp0014nsdcorchmetanprod.dfs.core.windows.net",
            "container": "datacore"
        },
        "dataStorageAccount": {
            "url": "https://tcpazbiddc1ntcpdevds1.dfs.core.windows.net",
            "container": "biddevdatalake01"
        }
    }
    return mocker.patch('job_run.get_data_storage_accounts_config', return_value=storage_cfg)


@pytest.fixture
def create_job_run(sqlalchemy_session):
    def _create_job_run(task_run_number):
        job_run = JobRunFactory.create()
        TaskRunFactory.create_batch(task_run_number, job_run=job_run)
        return JobRun.get(sqlalchemy_session, job_run.id)

    return _create_job_run


@pytest.fixture
def create_job_run_with_task_runs(sqlalchemy_session):
    def _create_job_run_with_task_runs(job_run_state, task_runs_states):
        job_run = JobRunFactory.create(status=job_run_state)
        for status in task_runs_states:
            TaskRunFactory.create(job_run=job_run, status=status)
        return JobRun.get(sqlalchemy_session, job_run.id)

    return _create_job_run_with_task_runs


def test_get(create_job_run):
    j = create_job_run(3)
    assert j.name == "JOB"
    assert_that(j.task_runs).is_length(3)


def test_get_last_job(sqlalchemy_session):
    env_name = "E01"
    o_date = "20121212"
    env = EnvironmentFactory.create(name=env_name)
    job_reg = JobRegistrationFactory.create(environment=env)
    JobRunFactory.create_batch(3, environment=env, o_date=o_date, job_registration=job_reg)
    last_job_run = JobRun.get_last_job_run(sqlalchemy_session, env_name, o_date, job_reg)
    assert last_job_run.id == 3


def test_create(sqlalchemy_session):
    env = EnvironmentFactory.create()
    job_reg = JobRegistrationFactory.create()

    jr = JobRun.create(sqlalchemy_session, job_reg, env, "ABC", "20200101", None, RUNNING)
    assert jr.status == RUNNING
    assert jr.operation_uuid == "ABC"
    assert jr.o_date == "20200101"
    assert_that(jr.id).is_type_of(int)


def test_job_name(sqlalchemy_session):
    job_reg = JobRegistrationFactory.create(job_name="BLAH")
    JobRunFactory.create(job_registration=job_reg)
    j = JobRun.get(sqlalchemy_session, 1)
    assert j.name == "BLAH"


@pytest.mark.parametrize("status", [COMPLETED, FAILED, FORCE_COMPLETED, ABORTED])
def test_is_running_is_true(status):
    job_run = JobRunFactory.build(status=status)
    assert_that(job_run.is_running()).is_false()


@pytest.mark.parametrize("status", [RUNNING, SCHEDULED])
def test_is_running_is_false(status):
    job_run = JobRunFactory.build(status=status)
    assert_that(job_run.is_running()).is_true()


def test_add_task_runs(sqlalchemy_session):
    tasks = [
        {"name": "Task 1"},
        {"name": "Task 2"}
    ]
    job_run = JobRunFactory.create()
    job_run.add_task_runs(sqlalchemy_session, tasks)
    assert_that(job_run.task_runs).is_length(2)


def test_set_status(sqlalchemy_session):
    job_run = JobRunFactory.create()
    job_run.set_status(sqlalchemy_session, RUNNING, "DEF")
    assert_that(job_run.status).is_equal_to(RUNNING)
    assert_that(job_run.job_run_uuid).is_equal_to("DEF")


def test_get_job_run_params(sqlalchemy_session):
    job_params = {
        "ssu": "retail",
        "tableName": "test_data",
        "tasks": [
            {
                "name": "CopyData",
                "parameters": {
                    "source": "CSA",
                    "destination": "ADLS",
                }
            },
            {
                "name": "ConformInterface",
                "parameters": {
                    "mainClass": "ConformInterface"
                }
            },
        ]
    }
    environment = EnvironmentFactory.create()
    job_registration = JobRegistrationFactory.create(environment=environment)
    job_run = JobRunFactory.create(environment=environment, job_registration=job_registration)
    for target_type, target_name in [(tt, tn) for tt in [SOURCE, DESTINATION] for tn in [CSA, ADLS]]:
        FileLocationFactory.create(
            target_type=target_type,
            target_name=target_name,
            path_pattern=f"/<ENV>/{target_name}/{target_type.lower()}/<SSU>/<SOURCE_SYSTEM>"
        )

    job_run.add_task_runs(sqlalchemy_session, job_params["tasks"])

    expected_keys = [
        'name',
        'parameters'
    ]

    params = job_run.get_job_run_params(sqlalchemy_session, job_params, "container")
    assert_that(params).contains_entry({'jobRunId': 1})
    assert_that(params).contains_entry({'oDate': '20121212'})
    assert_that(params).contains_entry({'jobName': 'JOB'})
    assert_that(params).contains_entry({'sourceSystem': 'interface'})
    assert_that(params).contains_entry({'ssu': 'retail'})
    assert_that(params).contains_entry({'environment': 'E01'})
    assert_that(params['tasks']).is_length(2)
    assert_that(params['tasks']).extracting('taskRunId').is_equal_to([1, 2])
    first_task = params['tasks'][0]
    assert_that(first_task).contains_key(*expected_keys)
    first_task_params = first_task['parameters']
    (assert_that(first_task_params['sourceContainer']).is_equal_to('container'))
    (assert_that(first_task_params['sourcePath']).is_equal_to('/E01/CSA/source/retail/interface'))
    (assert_that(first_task_params['destinationContainer']).is_equal_to('container'))
    (assert_that(first_task_params['destinationPath']).is_equal_to('/E01/ADLS/destination/retail/interface'))


def test_cancel(sqlalchemy_session):
    job_run = JobRunFactory.create(status=RUNNING)
    for status in [COMPLETED, RUNNING, SCHEDULED]:
        TaskRunFactory.create(job_run=job_run, status=status)
    jr = JobRun.get(sqlalchemy_session, job_run.id)
    jr.cancel(sqlalchemy_session)

    assert_that(jr.task_runs).is_length(3)
    assert_that(jr.status).is_equal_to(FAILED)
    assert_that(jr.task_runs).extracting('status').is_equal_to([COMPLETED, FAILED, ABORTED])


@pytest.mark.parametrize("job_run_states, soft_force, expected_job_run_states", [
    (
            (RUNNING, [COMPLETED, RUNNING, SCHEDULED]),
            False,
            (FORCE_COMPLETED, [COMPLETED, FORCE_COMPLETED, FORCE_COMPLETED])
    ),
    (
            (FAILED, [COMPLETED, FAILED, ABORTED]),
            True,
            (FORCE_COMPLETED, [COMPLETED, FORCE_COMPLETED, FORCE_COMPLETED])
    ),
    (
            (RUNNING, [COMPLETED, RUNNING, SCHEDULED]),
            True,
            (RUNNING, [COMPLETED, RUNNING, SCHEDULED]),
    ),
])
def test_force_complete(create_job_run_with_task_runs, job_run_states, soft_force, expected_job_run_states,
                        sqlalchemy_session):
    job_run = create_job_run_with_task_runs(*job_run_states)
    job_run.force_complete(sqlalchemy_session, soft_force)
    exp_job_run_state, exp_task_run_states = expected_job_run_states
    assert_that(job_run.status).is_equal_to(exp_job_run_state)
    assert_that(job_run.task_runs).extracting('status').is_equal_to(exp_task_run_states)


def test_job_run_to_dict(create_job_run_with_task_runs):
    job_run = create_job_run_with_task_runs(RUNNING, [COMPLETED, RUNNING])
    job_run_dict = job_run.to_dict()
    assert_that(job_run_dict).contains_value(RUNNING)
    assert_that(job_run_dict['taskRuns']).extracting('status').is_equal_to([COMPLETED, RUNNING])


def test_path(sqlalchemy_session):
    JobRegistrationFactory.create()
    file_loc = FileLocationFactory.create(target_type="SOURCE", target_name="ADLS")
    job_run = JobRunFactory.create()
    source_path = job_run.path(file_loc.path_pattern)
    assert_that(source_path).is_equal_to("/data/E03/outbound/retail/interface/data_set")
