import pytest
from assertpy import assert_that

from models import FAILED, RUNNING, ABORTED, COMPLETED, TaskRun, SCHEDULED, FILE_REGISTERED, UPSTREAM_ACTIVITY
from tests.factories import TaskRunFactory, FileLocationFactory
from tests.register_files.params_fixture import params, payload


def test_get(sqlalchemy_session):
    TaskRunFactory.create()
    t = TaskRun.get(sqlalchemy_session, 1)
    assert_that(t.name).is_equal_to("Task 1")


def test_set_status(sqlalchemy_session):
    t = TaskRunFactory.create()
    t.set_status(sqlalchemy_session, FAILED, "DEF")
    sqlalchemy_session.refresh(t)
    assert_that(t.status).is_equal_to(FAILED)
    assert_that(t.task_run_uuid).is_equal_to("DEF")


@pytest.mark.parametrize("status, expected_status", [(RUNNING, FAILED), (SCHEDULED, ABORTED), (COMPLETED, COMPLETED)])
def test_cancel_success(status, expected_status):
    tr = TaskRunFactory.create(status=status)
    tr.cancel()
    assert tr.status == expected_status


