from assertpy import assert_that

from models import FileLocation
from tests.factories import FileLocationFactory


def test_get(sqlalchemy_session):
    FileLocationFactory.create()
    file_location = FileLocation.get(sqlalchemy_session, "dev", "SOURCE", "ADLS")
    assert_that(file_location).is_not_none()