import json

import azure.functions as func
import pytest
from assertpy import assert_that

from models import FILE_COPIED, FILE_REGISTERED
from tests.factories import FileRegistrationFactory, JobRegistrationFactory
from update_file_registration_status import main
from tests.register_files.params_fixture import params, payload


@pytest.fixture
def payload():
    return {
        'jobName': "JOB",
        'jobRunId': 2,
        "oDate": "20121212",
        "environment": "E01",
        "status": FILE_COPIED
    }


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('update_file_registration_status', sqlalchemy_session)


@pytest.fixture
def req(payload):
    return func.HttpRequest(
        method='POST',
        body=json.dumps(payload).encode(),
        url=f"/file_registrations/status")


@pytest.mark.parametrize("payload", [{}])
def test_failure_with_empty_params(req):
    resp = main(req)
    json.loads(resp.get_body())
    assert resp.status_code == 400


def test_success(req):
    jr = JobRegistrationFactory.create(job_name="JOB")
    FileRegistrationFactory.create(job_registration=jr,
                                   o_date="20121212",
                                   environment=jr.environment,
                                   status=FILE_REGISTERED)
    resp = main(req)
    result = json.loads(resp.get_body())
    assert_that(result).contains_key('jobName', 'jobRunId', 'oDate', 'environment', 'rowsUpdated', 'status')
    assert_that(result).contains_entry({'status': FILE_COPIED})
    assert_that(result).contains_entry({'rowsUpdated': 1})
    assert resp.status_code == 200
