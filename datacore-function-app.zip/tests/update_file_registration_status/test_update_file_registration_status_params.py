import pytest

from models import FILE_REGISTERED
from params.file_registration_params import FileRegistrationParams
from update_file_registration_status.update_file_registration_status_schema import \
    UPDATE_FILE_REGISTRATION_STATUS_SCHEMA

VALID_PARAMS_LIST = [
    {
        'jobName': "JOB",
        'jobRunId': 3,
        "oDate": "20121212",
        "environment": "E01",
        'status': FILE_REGISTERED
    }
]

INVALID_PARAMS_LIST = [
    {},
    {
        'jobName': "JOB",
        'jobRunId': 3,
        "oDate": "201",
        "environment": "E01",
        'fileStatus': 'blah'
    }
]


@pytest.fixture
def params(doc):
    return FileRegistrationParams(UPDATE_FILE_REGISTRATION_STATUS_SCHEMA, doc)


@pytest.mark.parametrize("doc", VALID_PARAMS_LIST)
def test_validator_success(params):
    assert params.validate()


@pytest.mark.parametrize("doc", INVALID_PARAMS_LIST)
def test_validator_failure(params):
    assert not params.validate()
