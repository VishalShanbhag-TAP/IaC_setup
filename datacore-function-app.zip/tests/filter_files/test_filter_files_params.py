from assertpy import assert_that

from filter_files import FilterFilesParams

import pytest

valid_params = {
    'jobRunId': 1,
    'taskRunId': 1,
    'fileList': [
        'A_20121212_BLAH.dat',
        'A_20121212_BLAH.eot',
    ],
    'oDate': '20211213',
    'filePattern': 'File_XYZ_<YYYYMMDD>_*',
    'fileExtensions': ['dat', 'ctl', 'eot'],
    'compression': 'True',
    'sequenceEnforced': 'True'
}


@pytest.fixture
def incomplete_params(key):
    return {k: valid_params[k] for k in valid_params if k != key}


@pytest.fixture
def invalid_params(key):
    params_copy = valid_params.copy()
    params_copy[key] = ''
    return params_copy


@pytest.fixture
def params_without_a_sequence():
    params_copy = valid_params.copy()
    params_copy['filePattern'] = "Product_<YYYYMMDD>*"
    params_copy['fileList'] = [
        "Product_20211213114049.dat",
        "Product_20211213114049.eot"
    ]
    return params_copy


@pytest.fixture
def modified_params():
    def __modified_params(key, value):
        params_copy = valid_params.copy()
        params_copy[key] = value
        return params_copy

    return __modified_params


def test_success():
    params = FilterFilesParams(valid_params)
    assert params.validate()


@pytest.mark.parametrize("key", ['oDate'])
def test_failure_for_invalid_params(invalid_params):
    params = FilterFilesParams(invalid_params)
    assert not params.validate()


@pytest.mark.parametrize("key", ['oDate'])
def test_failure_for_incomplete_params(incomplete_params):
    params = FilterFilesParams(incomplete_params)
    assert not params.validate()


def test_file_list_names():
    params = FilterFilesParams(valid_params)
    assert params.file_list == ['A_20121212_BLAH.dat', 'A_20121212_BLAH.eot']


def test_empty_file_extensions(modified_params):
    params = FilterFilesParams(modified_params('fileExtensions', []))
    assert_that(params.group_size).is_equal_to(1)


@pytest.mark.parametrize("file_pattern, o_date_pattern", [('File_XYZ_<YYYYMMDD>_*', '<YYYYMMDD>'), ('File_XYZ', '')])
def test__filter_file_params(modified_params, file_pattern, o_date_pattern):
    params = FilterFilesParams(modified_params('filePattern', file_pattern))
    result = params._get_filename_date_pattern()
    assert_that(result).is_equal_to(o_date_pattern)


@pytest.mark.parametrize("o_date_pattern, expected_o_date", [('<YYYYMMDD>', '20211213'), ('', '')])
def test__get_formatted_odate(o_date_pattern, expected_o_date):
    params = FilterFilesParams(valid_params)
    result = params._get_formatted_odate(o_date_pattern)
    assert_that(result).is_equal_to(expected_o_date)
