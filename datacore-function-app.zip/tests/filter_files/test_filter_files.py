import json
from unittest.mock import Mock
import azure.functions as func

import pytest
from assertpy import assert_that

from filter_files import FilterFilesParams, create_regex_filter, organise_files, contiguous_groups, main, \
    file_pattern_list

# from filter_files.filter_files_params import get_filename_date_pattern, get_formatted_odate

valid_params = {
    "jobRunId": 1,
    "taskRunId": 2,
    "fileList": [
        "File_XYZ_20121212_01.dat",
        "File_XYZ_20121212_01.eot",
        "File_XYZ_20121212_01.ctl",
    ],
    "oDate": "20121212",
    "filePattern": "File_XYZ_<YYYYMMDD>_*",
    "fileExtensions": ["dat", "ctl", "eot"],
    "compression": True,
    "sequenceEnforced": True
}


def modified_params(params):
    copied_params = valid_params.copy()
    copied_params.update(params)
    return copied_params


@pytest.fixture
def params_without_a_sequence(file_pattern, file_list):
    params_copy = valid_params.copy()
    params_copy['filePattern'] = file_pattern
    params_copy['fileList'] = file_list
    params_copy['sequenceEnforced'] = False
    return params_copy


@pytest.fixture
def params_factory():
    def _params_factory(pattern, file_list):
        params_copy = valid_params.copy()
        params_copy['filePattern'] = pattern
        params_copy['fileList'] = file_list
        return params_copy

    return _params_factory


@pytest.fixture
def req(params):
    return func.HttpRequest(
        method='POST',
        body=json.dumps(params).encode(),
        url='/update_task'
    )


def test_filter_regex():
    params = FilterFilesParams(valid_params)
    fr = create_regex_filter(params.file_pattern, params.file_pattern_replacements)
    assert fr == "File_XYZ_20121212_(?P<sequence>.*)(?P<extension>.dat|.ctl|.eot)"


def test_organise_files():
    params = FilterFilesParams(valid_params)
    fr = create_regex_filter('a_<YYYYMMDD>_*', params.file_pattern_replacements)
    file_list_names = ['a_20121212_1.dat', 'a_20121212_1.eot', 'a_20121212_2.dat', 'a_20121212_2.eot',
                       'a_20121212_3.dat']
    assert organise_files(file_list_names, fr, 2, params.file_extensions, params.sequence_enforced) == [
        ['a_20121212_1.dat', 'a_20121212_1.eot'],
        ['a_20121212_2.dat', 'a_20121212_2.eot']
    ]


def test_organise_files_with_empty_extensions():
    new_params = modified_params({'fileExtensions': []})
    p = FilterFilesParams(new_params)
    fr = create_regex_filter('IPNDUPRASS1.*', p.file_pattern_replacements)
    file_list_names = ['IPNDUPRASS1.0007239', 'IPNDUPRASS1.0007241']
    assert organise_files(file_list_names, fr, p.group_size, p.file_extensions, False) == [
        ['IPNDUPRASS1.0007239'], ['IPNDUPRASS1.0007241']]


def test_file_pattern_list():
    regex = 'a_2012_(?P<sequence>.*)(?P<extensions>.txt|.ctl|.eot)'
    wildcard_list = file_pattern_list(
        [['a_2012_1.txt', 'a_2012_1.ctl'], ['a_2012_2.txt', 'a_2012_2.ctl']],
        regex,
        True,
        ['txt', 'ctl']
    )
    assert_that(wildcard_list).is_length(2)
    assert_that(wildcard_list).contains({'fileName': 'a_2012_1.*', 'sequence': 1})


def test_file_pattern_list_without_extensions():
    new_params = modified_params({'fileExtensions': []})
    p = FilterFilesParams(new_params)
    regex = create_regex_filter('a_2012_*', p.file_pattern_replacements)
    wildcard_list = file_pattern_list(
        [['a_2012_1'], ['a_2012_2']],
        regex,
        True,
        []
    )
    assert_that(wildcard_list).is_length(2)
    assert_that(wildcard_list).contains({'fileName': 'a_2012_1', 'sequence': 1})


def test_file_pattern_list_2():
    payload = {
        "fileList": ['IPNDUPRASS1.001', 'IPNDUPRASS1.002', 'IPNDUPRASS1.003', 'IPNDUPRASS1.004'],
        "filePattern": "IPNDUPRASS1.*",
        "fileExtensions": [],
        "sequenceEnforced": False
    }

    new_params = modified_params(payload)
    p = FilterFilesParams(new_params)
    fr = create_regex_filter('IPNDUPRASS1.*', p.file_pattern_replacements)
    wildcard_list = file_pattern_list(
        [['IPNDUPRASS1.001'], ['IPNDUPRASS1.002'], ['IPNDUPRASS1.003'], ['IPNDUPRASS1.004']],
        fr,
        p.sequence_enforced,
        p.file_extensions
    )
    assert_that(wildcard_list).is_length(4)
    assert_that(wildcard_list).contains({'fileName': 'IPNDUPRASS1.001', 'sequence': -1})


def test_organise_files_with_contiguous_groups():
    params = FilterFilesParams(valid_params)
    fr = create_regex_filter('a_<YYYYMMDD>_*', params.file_pattern_replacements)
    file_list_names = ['a_20121212_1.dat', 'a_20121212_1.eot', 'a_20121212_3.dat', 'a_20121212_3.eot']
    assert organise_files(file_list_names, fr, 2, params.file_extensions, params.sequence_enforced) == [
        ['a_20121212_1.dat', 'a_20121212_1.eot']]


def test_contiguous_groups():
    params = FilterFilesParams(valid_params)
    fr = create_regex_filter('a_<YYYYMMDD>_*', params.file_pattern_replacements)
    sorted_groups = [['a_20121212_T1.dat'], ['a_20121212_T2.dat'], ['a_20121212_T4.dat'], ['a_20121212_T5.dat']]
    assert contiguous_groups(sorted_groups, fr) == [['a_20121212_T1.dat'], ['a_20121212_T2.dat']]


@pytest.mark.parametrize("params", [{}])
def test_validation_failure(req):
    resp = main(req)
    result = json.loads(resp.get_body())
    assert len(result['errors'].keys()) == 8
    assert resp.status_code == 400


@pytest.mark.parametrize("params", [valid_params])
def test_environment_failure(req):
    resp = main(req)
    result = json.loads(resp.get_body())
    expected_item = {'fileName': 'File_XYZ_20121212_01.*', 'sequence': 1}
    assert_that(result).contains_key('filePatternList')
    assert_that(result['filePatternList']).contains(expected_item)
    assert resp.status_code == 200


@pytest.mark.parametrize("file_pattern, file_list",
                         [
                             ["Product_<YYYYMMDD>*", ['Product_20121212114049.dat', 'Product_20121212114049.eot']],
                             ["cncswv<ddMMyyyy>*", ['cncswv12122012.dat', 'cncswv12122012.eot']],
                         ])
def test_file_pattern_replacement(file_pattern, file_list, params_without_a_sequence):
    p = FilterFilesParams(params_without_a_sequence)
    fr = create_regex_filter(p.file_pattern, p.file_pattern_replacements)
    assert organise_files(p.file_list, fr, 2, p.file_extensions, p.sequence_enforced) == [file_list]
