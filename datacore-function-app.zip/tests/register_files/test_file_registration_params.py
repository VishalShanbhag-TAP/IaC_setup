from assertpy import assert_that

from models import FILE_REGISTERED
from params.file_registration_params import next_sequence_number, FileRegistrationParams, is_sequential
from register_files import FILE_REGISTRATION_SCHEMA
from .params_fixture import params, payload


def test_validator_success(params):
    assert params.validate()


def test_properties(params):
    assert isinstance(params.files, list)
    assert_that(params.job_name).is_equal_to("JOB")
    assert_that(params.job_run_id).is_equal_to(1)
    assert_that(params.environment).is_equal_to("E01")
    assert_that(params.o_date).is_equal_to("20121212")
    assert_that(params.file_pattern).is_equal_to('TEST_<YYYYMMDD>_*')
    assert_that(params.files).is_length(2)
    file = params.files[0]
    assert_that(file.file_name).is_equal_to('/file/a_name.txt')
    assert_that(file.record_count).is_equal_to(1)
    assert_that(file.sequence).is_equal_to(2)
    assert_that(file.status).is_equal_to(FILE_REGISTERED)


def test_validator_failure():
    params = FileRegistrationParams(FILE_REGISTRATION_SCHEMA, {})
    assert not params.validate()


def test_next_sequence_number(params):
    seq_no = next_sequence_number(params.files)
    assert_that(seq_no).is_equal_to(2)


def test_is_sequential(params):
    is_seq = is_sequential(params.files)
    assert_that(is_seq).is_true()
