import pytest

from models import UPSTREAM_ACTIVITY, FILE_REGISTERED
from params.file_registration_params import FileRegistrationParams
from register_files import FILE_REGISTRATION_SCHEMA


@pytest.fixture
def payload():
    return {
        'jobName': 'JOB',
        'jobRunId': 1,
        'oDate': '20121212',
        'filePattern': 'TEST_<YYYYMMDD>_*',
        'environment': 'E01',
        'sequenceEnforced': False,
        'source': 'CSA',
        'destination': 'ADLS',
        'activity': UPSTREAM_ACTIVITY,
        'fileExtensions': ['csv', 'oet'],
        'files': [
            {
                'fileName': '/file/a_name.txt',
                'recordCount': 1,
                'sequence': 2,
                'status': FILE_REGISTERED
            },
            {
                'fileName': '/file/b_name.txt',
                'recordCount': 1,
                'sequence': 3,
                'status': FILE_REGISTERED
            }
        ]
    }


@pytest.fixture
def payload_with_seq_enforced(payload):
    payload['sequenceEnforced'] = True
    return payload



@pytest.fixture
def params(payload):
    return FileRegistrationParams(FILE_REGISTRATION_SCHEMA, payload)
