import json
import azure.functions as func
import pytest
from assertpy import assert_that

from models import FILE_REGISTERED, SOURCE, DESTINATION, UPSTREAM_ACTIVITY, FILE_COPIED
from register_files import main
from ..factories import TaskRunFactory, FileLocationFactory, EnvironmentFactory, JobRunFactory, FileRegistrationFactory, \
    JobRegistrationFactory
from .params_fixture import payload, payload_with_seq_enforced


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('register_files', sqlalchemy_session)


@pytest.fixture
def context_setup():
    def _setup():
        env = EnvironmentFactory.create()
        job_reg = JobRegistrationFactory.create(environment=env)
        source = FileLocationFactory.create(target_type=SOURCE, target_name='CSA')
        dest = FileLocationFactory.create(target_type=DESTINATION, target_name='ADLS')
        return env, job_reg, source, dest

    return _setup


@pytest.fixture
def req(payload):
    return func.HttpRequest(
        method='POST',
        body=json.dumps(payload).encode(),
        url='/register_files')


@pytest.fixture
def req_with_seq_enforced(payload_with_seq_enforced):
    return func.HttpRequest(
        method='POST',
        body=json.dumps(payload_with_seq_enforced).encode(),
        url='/register_files')


@pytest.fixture
def invalid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps({}).encode(),
        url='/register_files')


def test_validation_success(req, context_setup):
    context_setup()
    resp = main(req)
    file_registrations = json.loads(resp.get_body())
    file_registrations = file_registrations['fileRegistrations']
    assert_that(file_registrations).is_length(2)
    assert_that(file_registrations).extracting('filePattern').contains_only("TEST_<YYYYMMDD>_*")
    assert_that(file_registrations).extracting('fileExtensions').contains_only(['csv', 'oet'])
    assert_that(file_registrations).extracting('fileName').is_equal_to(['/file/a_name.txt', '/file/b_name.txt'])
    assert_that(file_registrations).extracting('sequence').is_equal_to([2, 3])
    assert_that(file_registrations).extracting('status').contains_only(FILE_REGISTERED)
    assert_that(file_registrations).extracting('oDate').contains_only("20121212")
    assert_that(file_registrations).extracting('jobRunId').contains_only(1)
    assert_that(file_registrations).extracting('activity').contains_only(UPSTREAM_ACTIVITY)
    assert resp.status_code == 201


def test_validation_failure(invalid_req, context_setup):
    context_setup()
    resp = main(invalid_req)
    result = json.loads(resp.get_body())
    assert_that(result).contains_key('errors')
    assert resp.status_code == 400


def test_sequence_failure(req_with_seq_enforced, context_setup):
    env, job_reg, source, dest = context_setup()
    FileRegistrationFactory.create(job_registration=job_reg,
                                   environment=env,
                                   source_file_location=source,
                                   destination_file_location=dest,
                                   status=FILE_COPIED,
                                   sequence=22)

    resp = main(req_with_seq_enforced)
    result = json.loads(resp.get_body())

    assert_that(result).contains('errors')
    assert_that(result['errors']).contains_entry({'taskRun': ["The next sequence number '2' does not follow '22'"]})
    assert_that(resp.status_code).is_equal_to(400)


def test_sequence_success(req_with_seq_enforced, context_setup):
    env, job_reg, source, dest = context_setup()
    FileRegistrationFactory.create(job_registration=job_reg,
                                   environment=env,
                                   source_file_location=source,
                                   destination_file_location=dest,
                                   sequence=1,
                                   status=FILE_COPIED)
    resp = main(req_with_seq_enforced)
    result = json.loads(resp.get_body())
    assert_that(resp.status_code).is_equal_to(201)
