import json
import azure.functions as func
import pytest
from unittest.mock import Mock

from job_run_status import main
from models import JobRun, COMPLETED
from tests.factories import JobRunFactory


@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('job_run_status', sqlalchemy_session)


@pytest.fixture
def req(job_run_id):
    return func.HttpRequest(
        method='GET',
        body=b'',
        route_params={'job_run_id': job_run_id},
        url=f"/job_runs/{job_run_id}/status")


@pytest.mark.parametrize("job_run_id", ["1"])
def test_validation_failure(req):
    JobRunFactory.create(status=COMPLETED)
    resp = main(req)
    result = json.loads(resp.get_body())
    assert result == {'jobRun': {'id': 1, 'status': 'completed'}}
    assert resp.status_code == 200
