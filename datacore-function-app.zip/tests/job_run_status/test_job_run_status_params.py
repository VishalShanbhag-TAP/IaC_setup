from job_run_status.job_run_status_params import JobRunStatusParams

import pytest

valid_params = [
    ({
        'job_run_id': 1
    }),
]


@pytest.mark.parametrize("doc", valid_params)
def test_validator_success(doc):
    params = JobRunStatusParams(doc)
    assert params.validate()
