import json
import azure.functions as func
import pytest
from assertpy import assert_that
from unittest.mock import Mock

from read_schema import main
from tests.factories import JobRunFactory

@pytest.fixture(autouse=True)
def mock_create_session(create_mock_session, sqlalchemy_session):
    create_mock_session('read_schema', sqlalchemy_session)

@pytest.fixture
def valid_req():
    return func.HttpRequest(
        method='POST',
        body=json.dumps({'jobRunId': 1, 'taskRunId': 5, 'environmentName': 'E01'}).encode(),
        url='/read_Schema')

@pytest.fixture(autouse=True)
def mock_access(mocker):
    mocker.patch('read_schema.create_secret_client', return_value=Mock(value="XX"))
    mocker.patch.dict('os.environ', {'VAULT_URL': "https://vault_url"})

@pytest.fixture(autouse=True)
def mock_storage_config(mocker):
    storage_cfg = {
        "metadataStorageAccount": {
            "url": "https://tcp0014nsdcorchmetanprod.dfs.core.windows.net",
            "container": "datacore"
        },
        "dataStorageAccount": {
            "url": "https://tcpazbiddc1ntcpdevds1.dfs.core.windows.net",
            "container": "biddevdatalake01"
        },
        "ADBLogStorageAccount": {
            "url": "https://tcp0014nsdatacoresplunk.dfs.core.windows.net",
            "container": "datacore-adb"
        }
    }
    return mocker.patch('read_schema.get_data_storage_accounts_config', return_value=storage_cfg)

def test_get_current_job_failure(valid_req, mocker):
    response = main(valid_req)
    result = json.loads(response.get_body())
    assert result == {'errors': {'get_current_job': ["Unable to get the current job run id 1 in environment E01"]}}
    assert response.status_code == 400

def test_read_schema(valid_req, mocker):
    JobRunFactory.create()

    content = {'Scope': {'SSU': 'test_ssu', 'SourceSystem': 'test_source_system', 'TableName': 'test_table_name'}, 'IntegrationKeys': 'test_integration_keys', 'LightKeys': {'GeneratedLightKeys': 'test_generated_lightkeys'}}
    download_mock = Mock(**{'readall.return_value': json.dumps(content)})
    mocker.patch('read_schema.create_dl_file_client',
                 return_value=Mock(**{'download_file.return_value': download_mock}))
    
    # mocker.patch('read_schema.create_dl_file_client', return_value="test_dl_file_client")
    # mocker.patch('read_schema.get_schema_config', return_value=Mock(status_code=200, json=lambda: {'Scope': {'SSU': 'test_ssu', 'SourceSystem': 'test_source_system', 'TableName': 'test_table_name'}, 'IntegrationKeys': 'test_integration_keys', 'LightKeys': {'GeneratedLightKeys': 'test_generated_lightkeys'}}))
    # mocker.patch('read_schema.get_schema_config', return_value={'Scope': {'SSU': 'test_ssu', 'SourceSystem': 'test_source_system', 'TableName': 'test_table_name'}, 'IntegrationKeys': 'test_integration_keys', 'LightKeys': {'GeneratedLightKeys': 'test_generated_lightkeys'}})
    response = main(valid_req)
    result = json.loads(response.get_body())

    assert result == {'jobRunId': 1, 'taskRunId': 5, 'environment': 'E01', 'ssu': 'test_ssu', 'sourceSystem': 'test_source_system', 'tableName': 'test_table_name', 'integrationKeys': 'test_integration_keys', 'lightKeys': 'test_generated_lightkeys'}
    assert response.status_code == 200