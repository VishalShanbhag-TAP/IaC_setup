from cerberus import Validator

JOB_RUN_STATUS = {
    'job_run_id': {
        'type': 'integer',
        'coerce': int,
        'required': True
    }
}


class JobRunStatusParams:

    def __init__(self, params):
        self.content = {key: params.get(key) for key in params if key in JOB_RUN_STATUS}
        self.validator = Validator(JOB_RUN_STATUS)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def job_run_id(self):
        return self.content.get('job_run_id')

    @property
    def errors(self):
        return self.validator.errors
