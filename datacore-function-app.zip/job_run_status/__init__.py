import logging

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from job_run_status.job_run_status_params import JobRunStatusParams
from models import JobRun
from shared import failure_response, success_response, create_session


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        params = JobRunStatusParams(req.route_params)
        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()
        session = create_session(credential)

        job_run = JobRun.get(session, params.job_run_id)

        return success_response({'jobRun': {'id': job_run.id, 'status': job_run.status}})

    except Exception as exception:
        logging.exception(exception)
        return failure_response(dict([(type(exception).__name__, str(exception))]))
