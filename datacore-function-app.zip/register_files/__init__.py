import logging

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from exceptions import JobException
from register_files.file_registration_schema import FILE_REGISTRATION_SCHEMA
from models import TaskRun, FileRegistration, FileLocation, SOURCE, DESTINATION, JobRegistration, FILE_COPIED
from params.file_registration_params import next_sequence_number, FileRegistrationParams, is_sequential
from shared import failure_response, success_response, create_session


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        params = FileRegistrationParams(FILE_REGISTRATION_SCHEMA, req.get_json())
        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()

        session = create_session(credential)

        job_registration = JobRegistration.get(session, params.job_name, params.environment)
        if job_registration is None:
            msg = f"Job Registration entry has not been made for job name '#{params.job_name}' in '{params.environment}'"
            return failure_response({'JobRegistration': [msg]})

        logging.info(f"Enforcing Sequence: {params.sequence_enforced}")
        if params.sequence_enforced:
            last_seq_no = FileRegistration.last_sequence(session, params.job_name, params.environment, FILE_COPIED)
            if last_seq_no is not None:
                logging.info(f"The last sequence number used for job name '#{params.job_name}' in '{params.environment}' was '{last_seq_no}'")
                if not is_sequential(params.files):
                    msg = f"The given files are not sequential"
                    return failure_response({'taskRun': [msg]})

                next_seq_no = next_sequence_number(params.files)
                logging.info(f"The next provided sequence number is {next_seq_no}")
                if next_seq_no - last_seq_no != 1:
                    msg = f"The next sequence number '{next_seq_no}' does not follow '{last_seq_no}'"
                    return failure_response({'taskRun': [msg]})

        env_type = job_registration.environment.type
        source_file_location = get_file_location(session, env_type, SOURCE, params.source)
        destination_file_location = get_file_location(session, env_type, DESTINATION, params.destination)
        file_registrations = job_registration.register_files(
            session,
            params,
            source_file_location,
            destination_file_location
        )

        file_registrations = [fr.to_dict() for fr in file_registrations]
        return success_response({'fileRegistrations': file_registrations}, status_code=201)

    except Exception as exception:
        return failure_response(dict([(type(exception).__name__, str(exception))]))


def get_file_location(session, env_type, target_type, target_name):
    file_location = FileLocation.get(session, env_type, target_type, target_name)
    if not file_location:
        raise JobException(f"File Location not present for {env_type, target_type, target_name}")
    return file_location
