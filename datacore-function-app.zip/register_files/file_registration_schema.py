from shared import validate_o_date

LOCATIONS = ['CSA', 'SFX', 'ADLS']
ACTIVITIES = ['DOWNSTREAM', 'UPSTREAM', 'ARCHIVE']

FILE_REGISTRATION_SCHEMA = {
    'jobName': {'type': 'string', 'required': True},
    'jobRunId': {
        'type': 'integer', 'coerce': int,
        'required': True
    },
    'oDate': {
        'type': 'string',
        'check_with': validate_o_date,
        'required': True,
        'coerce': str
    },
    'filePattern': {'type': 'string', 'required': True},
    'environment': {'type': 'string', 'required': True},
    'source': {'type': 'string', 'required': True, 'allowed': LOCATIONS},
    'destination': {'type': 'string', 'required': True, 'allowed': LOCATIONS},
    'activity': {'type': 'string', 'required': True, 'allowed': ACTIVITIES},
    'sequenceEnforced': {'type': 'boolean', 'coerce': bool},
    'fileExtensions': {
        'type': 'list',
        'schema': {
            'type': 'string',
            'regex': '[a-z]{3,4}'
        }
    },
    'files': {
        'type': 'list',
        'required': True,
        'schema': {
            'type': 'dict',
            'schema': {
                'fileName': {'type': 'string', 'required': True},
                'recordCount': {'type': 'integer'},
                'sequence': {'type': 'integer'},
                'status': {'type': 'string'}
            }
        },
    }
}
