# Azure Function App: datacore-functions

Target Language
: Python

Target Version
: 3.8.6

Function App Name
: datacore-functions


# Infrastructure Dependencies


1. Create a System MSI for **datacore-functions**
2. **Storage Account**: Assign role **Storage Blob Data Contributer** to **datacore-function**
3. **Sql Server**: Assign role **Contributor** to **datacore-function**
4. **Sql Server DB**: Execute following:

    ```sql
    CREATE USER "datacore-functions" FROM EXTERNAL PROVIDER;
    ALTER ROLE "db_datareader" ADD MEMBER "datacore-functions";
    ALTER ROLE "db_datawriter" ADD MEMBER "datacore-functions";
    ```
5. **Key Vault**: Assign role **Reader** to **datacore-function**
6. **Azure Data Factory**: Assign role **Data Factory Contributor** to **datacore-function**



## Creating Azure Functions

[Creating Azure Functions Documentation](https://docs.microsoft.com/en-us/azure/azure-functions/create-first-function-vs-code-python)

## Python Library Requirements

```bash
$ pip install -r requirements.txt
$ pip install -r requirements.dev.txt # dev only
```

## Running Test
```bash
$ pytest
```

## Installing Project under Windows

Software to make your life easier:
* [VS Code](https://code.visualstudio.com/)  
* [VS Code Azure Tools Extension](https://code.visualstudio.com/docs/azure/extensions)
* [Anaconda](https://www.anaconda.com/)
* [Azure Function Core Tools](https://docs.microsoft.com/en-us/azure/azure-functions/functions-run-local?tabs=windows%2Ccsharp%2Cbash)


## Having trouble with Python imports in VS Code?

* Open User Settings in VS Code
* Search Pylance


## Resources

* [Python SDK Releases](https://azure.github.io/azure-sdk/releases/latest/all/python.html)
* [Azure for Python Developers](https://docs.microsoft.com/en-us/azure/developer/python/)




