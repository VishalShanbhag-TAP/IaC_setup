import json
import logging
import os

import azure.functions as func
from azure.core.exceptions import ResourceNotFoundError
from azure.identity import ManagedIdentityCredential

from exceptions import JobException, JobRunException
from job_run.job_run_params import JobRunParams, JobParams
from models import JobRun, Environment, JobRegistration, Pipeline, RUNNING, FAILED
from services import get_job_registration
from shared import failure_response, create_secret_client, create_metadata_dl_file_client, create_df_mgmt_client, \
    success_response, create_session, get_data_container_name, get_data_storage_accounts_config

MAIN_PIPELINE_NAME = 'Main'


def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    job_run = None
    session = None

    try:
        logging.info("Job Run Started.")
        params = get_params(req.get_json())

        credential = ManagedIdentityCredential()
        vault = create_secret_client(credential)
        logging.info("Managed Identity Retrieved.")

        session = create_session(credential)
        logging.info("DB Session Created.")

        storage_cfg = get_data_storage_accounts_config(vault.get_secret("datacore-storage-accounts").value)
        logging.info("Retrieved Data Storage Accounts Config.")

        environment = get_environment(session, params.environment)
        logging.info(f"Environment: {environment.name}.")

        job_reg = get_job_registration(session, params.job_name, params.environment)
        logging.info(f"Job Registration: {job_reg.job_name}.")

        last_job = get_last_job(session, params.environment, params.o_date, job_reg, params.retry)
        job_run = JobRun.create(session, job_reg, environment, context.invocation_id, params.o_date, last_job)
        logging.info(f"Job Run Created: #{job_run.id}.")

        job_config_path = job_reg.storage_account_job_file_path()
        logging.info(f"Job Configuration Path: {job_config_path}.")

        adls_file_client = create_metadata_dl_file_client(storage_cfg, job_config_path, credential)
        logging.info(f"ADLS Client Retrieved.")

        adf_client = create_df_mgmt_client(credential, vault.get_secret("datacore-subscription-id").value)
        logging.info(f"ADLS Client Retrieved.")

        pipeline = get_pipeline(session, adf_client)
        logging.info(f"Pipeline Retrieved.")

        logging.info("Configuring Job")
        job_config = get_job_config(params, adls_file_client, job_config_path, last_job)
        job_params = get_job_params(job_config)
        job_run.add_task_runs(session, job_params.tasks)

        logging.info("Creating a run")
        container_name = get_data_container_name(storage_cfg)
        jr_params = job_run.get_job_run_params(session, job_config, container_name)
        logging.info(f"Job run params: {jr_params}")
        run_response = adf_client.pipelines.create_run(*pipeline.run_config(), parameters=jr_params)

        job_run.set_status(session, RUNNING, run_response.run_id)
        status_url = f"https://{os.environ.get('WEBSITE_HOSTNAME')}/api/job_runs/{job_run.id}/status"

        return success_response(
            {'jobRun': {'id': job_run.id, 'uuid': run_response.run_id}},
            headers={'Location': status_url},
            status_code=202
        )

    except JobException as je:
        logging.exception(je)
        return failure_response(je.error)
    except JobRunException as jre:
        if job_run:
            job_run.set_status(session, jre.status)
            return failure_response(jre.error)
    except Exception as exception:
        logging.exception(exception)
        if job_run:
            job_run.set_status(session, FAILED)
        return failure_response(dict([(type(exception).__name__, str(exception))]))


def get_params(json_req):
    params = JobRunParams(json_req)
    if not params.validate():
        raise JobException(params.errors)
    return params


def get_environment(session, name):
    environment = Environment.get_by_name(session, name)

    if environment:
        return environment
    else:
        msg = f"'{name}' is not allowed. Must be one of {Environment.get_all(session)}"
        raise JobException({'environment': [msg]})


def get_last_job(session, environment, o_date, job_reg, retry):
    last_job = JobRun.get_last_job_run(session, environment, o_date, job_reg)
    if last_job and last_job.is_running():
        msg = f"'#{last_job.id}' has not completed running."
        raise JobException({'jobRun': [msg]})

    if last_job and last_job.has_completed() and not retry:
        msg = f"'#{last_job.id}' has completed successfully and cannot be rerun."
        raise JobException({'jobRun': [msg]})


def get_job_config(params, file_client, file_path, last_job):
    logging.info("Downloading Job Params")
    try:
        download = file_client.download_file()
        downloaded_bytes = download.readall()
        job_config = json.loads(downloaded_bytes)
        if params.retry:
            job_config = remove_completed_tasks(job_config, last_job)

    except ResourceNotFoundError as e:
        logging.exception(e)
        raise JobRunException(FAILED, {'jobRegistration': f"'{file_path}' not found."})

    return job_config


def get_job_params(job_config):
    job_params = JobParams(job_config)
    if not job_params.validate():
        logging.error(f"VALIDATION FAILED: f{job_params.errors}")
        raise JobRunException(FAILED, job_params.errors)
    return job_params


def get_pipeline(session, df_client):
    pipeline = Pipeline.bootstrap(session)
    if pipeline is None:
        raise JobRunException(FAILED, {'pipeline': "not found with name 'bootstrap'."})

    main_pipeline = df_client.pipelines.get(pipeline.resource_group_name, pipeline.factory_name, MAIN_PIPELINE_NAME)
    if not main_pipeline:
        raise JobRunException(FAILED, {'pipeline': "cannot be found in Azure Data Factory"})

    return pipeline


def remove_completed_tasks(job_config, last_job):
    if not last_job:
        return job_config

    job_config['tasks'] = [task for task in job_config['tasks'] if not last_job.has_task_completed(task['name'])]
    return job_config
