from cerberus import Validator

from models import UPSTREAM_ACTIVITY, DOWNSTREAM_ACTIVITY, ARCHIVE_ACTIVITY, ADLS, SFX, CSA
from shared import validate_o_date

JOB_RUN_SCHEMA = {
    'jobName': {
        'type': 'string',
        'required': True,
        'coerce': str
    },
    'oDate': {
        'type': 'string',
        'check_with': validate_o_date,
        'required': True,
        'coerce': str
    },
    'environment': {
        'type': 'string',
        'required': True,
        'coerce': str
    },
    "retry": {
        'type': 'boolean',
        'required': False,
        'default': False
    },
}


class JobRunParams:

    def __init__(self, params):
        self.content = {key: (params.get(key) or JOB_RUN_SCHEMA[key].get('default')) for key in JOB_RUN_SCHEMA}
        self.validator = Validator(JOB_RUN_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def job_name(self):
        return self.content.get('jobName')

    @property
    def environment(self):
        return self.content.get('environment')

    @property
    def o_date(self):
        return self.content.get('oDate')

    @property
    def retry(self):
        return self.content.get('retry')

    @property
    def errors(self):
        return self.validator.errors


COPY_DATA_PIPELINES = ['CopyData']
COPY_DATA_SCHEMA = {
    'name': {'type': 'string', 'required': True,
             'allowed': COPY_DATA_PIPELINES},
    'description': {'type': 'string', 'required': False},
    'parameters': {
        'required': True,
        'schema': {
            "activity": {'type': 'string', 'required': True,
                         'allowed': [UPSTREAM_ACTIVITY, DOWNSTREAM_ACTIVITY, ARCHIVE_ACTIVITY]},
            "source": {'type': 'string', 'required': True, 'allowed': [ADLS, SFX, CSA]},
            "destination": {'type': 'string', 'required': True, 'allowed': [ADLS, SFX, CSA]},
            "sequenceEnforced": {'type': 'boolean', 'required': True, 'default': False},
            "filePattern": {'type': 'string', 'required': True},
            "fileExtensions": {'type': 'list', 'required': True},
            "compression": {'type': 'boolean', 'default': False, 'required': True}
        }
    }
}

SPARK_APP_PIPELINES = ['ConformInterface', 'StandardiseColumns', 'AugmentKeyMap', 'KeyMapApply', 'ChangeDataCapture', 'SparkJAR', 'SparkPY', 'GenerateMeta']
SPARK_APP_SCHEMA = {
    'name': {'type': 'string', 'required': True, 'allowed': SPARK_APP_PIPELINES},
    'description': {'type': 'string', 'required': False},
    'parameters': {
        'type': 'dict',
        'required': True,
        'schema': {
            'mainClass': {'type': 'string', 'required': True}
        }
    }
}

JOB_SCHEMA = {
    'name': {'type': 'string', 'required': True},
    'description': {'type': 'string'},
    'ssu': {'type': 'string', 'required': True},
    'sourceSystem': {'type': 'string', 'required': True},
    'tableName': {'type': 'string', 'required': True},
    'tasks': {
        'type': 'list',
        'minlength': 1,
        'required': True,
        'schema': {
            'type': 'dict',
            'oneof_schema': [COPY_DATA_SCHEMA, SPARK_APP_SCHEMA]
        },
        'allow_unknown': True
    },
}


class JobParams:

    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in JOB_SCHEMA}
        self.validator = Validator(JOB_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def source(self):
        return self.content.get('source')

    @property
    def tasks(self):
        return self.content.get('tasks')

    @property
    def errors(self):
        return self.validator.errors
