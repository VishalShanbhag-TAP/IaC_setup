import logging
import os
import re
from itertools import groupby
from pathlib import Path

import azure.functions as func

from filter_files.filter_files_params import FilterFilesParams
from shared import failure_response, success_response


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        p = FilterFilesParams(req.get_json())
        if not p.validate():
            return failure_response(p.errors)

        regex_filter = create_regex_filter(p.file_pattern, p.file_pattern_replacements)
        logging.info(f"regex_filter:{regex_filter}")
        organised_files = organise_files(p.file_list, regex_filter, p.group_size, p.file_extensions,
                                         p.sequence_enforced)
        logging.info(f"Files to process:{organised_files}")
        if organised_files:
            return success_response(
                {'filePatternList': file_pattern_list(organised_files, regex_filter, p.sequence_enforced, p.file_extensions)})
        else:
            return failure_response("No files to be processed")

    except Exception as exception:
        logging.exception(exception)
        return failure_response(dict([(type(exception).__name__, str(exception))]))


def create_regex_filter(pattern, replacements):
    if replacements:
        return create_regex_filter(re.sub(*replacements[0], pattern), replacements[1:])
    else:
        return pattern


def organise_files(file_list_names, regex_filter, group_count, file_extensions, sequence_enforced):
    # Regex used to filter names
    filtered_file_list_names = [name for name in file_list_names if re.match(regex_filter, name)]
    # Sort
    sorted_files = sorted(filtered_file_list_names)

    logging.info(f"sorted_files:{sorted_files}")

    def _group_by_name(name):
        return os.path.splitext(name)[0] if file_extensions else name

    # Group based on name excluding extension
    groups = []
    for k, g in groupby(sorted_files, _group_by_name):
        groups.append(list(g))

    # Eliminate groups where count does not match expected group count
    valid_groups = [g for g in groups if len(g) == group_count]

    # We only want to return contiguous_groups if the sequence has been enforced
    return contiguous_groups(valid_groups, regex_filter) if sequence_enforced else valid_groups


def file_pattern_list(organised_files, regex_filter, sequence_enforced, file_extensions):
    """
    :param organised_files: Multi-dimensional list, e.g [["a.data", "a.ctl"], ["b.data", "b.ctl"]]
    :param regex_filter:
    :param sequence_enforced
    :return: list, e.g. [{ 'fileName': 'a', 'sequence': 1 }]
    """

    def file_sequence(file_name):
        m = re.match(regex_filter, file_name)
        return m and int(m['sequence'])

    def file_record(file_set, sequence_enforced_):
        sample_fn = file_set[0]
        name = f"{Path(sample_fn).stem}.*" if Path(sample_fn).suffix[1:] in file_extensions else sample_fn

        if sequence_enforced_:
            return {'fileName': name, 'sequence': file_sequence(sample_fn)}
        else:
            return {'fileName': name, 'sequence': -1}

    return [file_record(file_set, sequence_enforced) for file_set in organised_files]


def contiguous_groups(sorted_groups, pattern):
    x = None
    for i, g in enumerate(sorted_groups):
        match = re.match(pattern, g[0])
        if match and 'sequence' in match.groupdict():
            seq = match['sequence']
            seq_match = re.search(r'\d+', seq)
            if seq_match:
                y = int(seq_match[0])
                if x is None:
                    x = y
                elif y - x != 1:
                    return sorted_groups[0:i]
                else:
                    x = y

    return sorted_groups
