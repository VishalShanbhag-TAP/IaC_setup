import re

from cerberus import Validator
from functools import reduce

from shared import validate_o_date

FILTER_FILES_SCHEMA = {
    'jobRunId': {
        'type': 'integer', 'coerce': int,
        'required': True
    },
    'taskRunId': {
        'type': 'integer', 'coerce': int,
        'required': True
    },
    'fileList': {
        'type': 'list',
        'schema': {
            'type': 'string',
        },
        'required': True
    },
    'oDate': {
        'type': 'string',
        'check_with': validate_o_date,
        'required': True
    },
    'filePattern': {
        'type': 'string',
        'minlength': 3,
        'required': True
    },
    'fileExtensions': {
        'type': 'list',
        'minlength': 0,
        'required': True
    },
    'compression': {
        'type': 'boolean', 'coerce': bool,
        'required': True
    },
    'sequenceEnforced': {
        'type': 'boolean', 'coerce': bool,
        'required': True
    }

}


class FilterFilesParams:

    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in FILTER_FILES_SCHEMA}
        self.validator = Validator(FILTER_FILES_SCHEMA)

    def get(self, value):
        return self.content.get(value)

    @property
    def job_run_id(self):
        return self.get('jobRunId')

    @property
    def task_run_id(self):
        return self.get('taskRunId')

    @property
    def file_list(self):
        return self.get('fileList')

    @property
    def file_pattern(self):
        return self.get('filePattern')

    @property
    def o_date(self):
        return self.get('oDate')

    @property
    def file_extensions(self):
        return self.get('fileExtensions')

    @property
    def sequence_enforced(self):
        return self.get('sequenceEnforced')

    @property
    def group_size(self):
        return len(self.file_extensions) or 1

    @property
    def file_compressed(self):
        return self.get('fileCompressed')

    @property
    def file_pattern_replacements(self):
        file_extensions_regex = '|'.join([f'.{x}' for x in self.file_extensions])
        filename_date_pattern = self._get_filename_date_pattern()
        odate_substitution = self._get_formatted_odate(filename_date_pattern)

        return [
            (r'\*', '(?P<sequence>.*)'),
            (filename_date_pattern, odate_substitution),
            (r'(.)$', f'\\1(?P<extension>{file_extensions_regex})')
        ]

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def errors(self):
        return self.validator.errors

    def _get_filename_date_pattern(self):
        match = re.search(r'(<.*>)', self.file_pattern)
        return match.group(0) if match else ""

    def _get_formatted_odate(self, filename_date_pattern):
        year = self.o_date[0:4]
        month = self.o_date[4:6]
        day = self.o_date[6:]

        replacements = [(">", ""),
                        ("<", ""),
                        ("dd", day),
                        ("DD", day),
                        ("mm", month),
                        ("MM", month),
                        ("yyyy", year),
                        ("YYYY", year)
                        ]
        return reduce(lambda a, kv: a.replace(*kv), replacements, filename_date_pattern)
