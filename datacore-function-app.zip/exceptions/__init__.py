class JobRunException(Exception):
    def __init__(self, status, error):
        self.status = status
        self.error = error
        super().__init__(self.error)


class JobException(Exception):
    def __init__(self, error):
        self.error = error
        super().__init__(self.error)

