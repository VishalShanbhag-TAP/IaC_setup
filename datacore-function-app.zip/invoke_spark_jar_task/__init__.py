import os
import logging
import requests
import base64
from datetime import datetime
from functools import reduce

import azure.functions as func
from databricks_api import DatabricksAPI
from azure.identity import ManagedIdentityCredential

from exceptions import JobException
from invoke_spark_jar_task.invoke_spark_jar_task_params import InvokeSparkJarTaskParams
from shared import failure_response, create_secret_client, success_response, create_session, \
    get_db_domain_name, get_data_storage_accounts_config
from models import JobRun


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        params = InvokeSparkJarTaskParams(req.get_json())

        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()
        vault = create_secret_client(credential)

        session = create_session(credential)

        job_run = JobRun.get(session, params.job_run_id)
        if job_run is None:
            msg = f"Unable to get the current job run id {params.job_run_id} in environment {params.environment}"
            return failure_response({'get_current_job': [msg]})

        job_reg = job_run.job_registration

        #Get the job.json path and schema.json paths
        storage_cfg = get_data_storage_accounts_config(vault.get_secret("datacore-storage-accounts").value)
        config = storage_cfg.get("metadataStorageAccount", {})
        url = config.get("url")
        storage_account_name = url.split("//")[1]
        container = config.get("container")
        storage_url_prefix = f"abfss://{container}@{storage_account_name}"

        job_config_path = os.path.join(storage_url_prefix, job_reg.storage_account_job_file_path())
        schema_path = os.path.join(storage_url_prefix, job_reg.storage_account_schema_file_path())

        #Get executable path JAR or PY code for the given task name
        executable_path = get_executable_path(params.task_name, job_reg.source_name, params.environment)

        # Read the cluster size from the JobRegistration table
        # For operational issues, the cluster size can be manually changed in the database
        cluster_size = job_reg.job_cluster_size
        
        # Get the cluster id if there was a cluster created previously for this job
        # tenant_id = vault.get_secret("datacore-azure-tenant-id").value
        tenant_id = get_tenant_id(vault)
        db_sp_client_id_name = get_adb_sp_client_id_name(params.task_name, job_reg.source_name)
        db_sp_client_id = get_adb_sp_client_id(vault, db_sp_client_id_name)

        db_sp_client_secret_name = get_adb_sp_client_secret_name(params.task_name, job_reg.source_name)
        db_sp_client_secret = get_adb_sp_client_secret(vault, db_sp_client_secret_name)

        cluster_id = get_adb_cluster_id(params.task_name, job_run.cluster_id, job_run.custom_cluster_id)

        #Get the access token for the Service Principal
        adb_resource = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"
        db_access_token = get_aad_token(tenant_id, db_sp_client_id, db_sp_client_secret, adb_resource)
        if db_access_token == "INVALID":
            msg = "Unable to get the DB access token"
            return failure_response({'dbAccessToken': [msg]})

        if cluster_id is None:
            # Previously there is no cluster created for this job
            cluster_id = create_cluster(vault, db_sp_client_id_name, db_sp_client_secret_name, tenant_id, db_access_token, params.environment, job_reg.source_name, job_reg.jobname, params.job_run_id, cluster_size)

            if cluster_id == "INVALID":
                msg = f"Could not create cluster for job {params.job_run_id}"
                return failure_response({'cluster_create': [msg]})

        else:
            # There was a previous task that has run in DB cluster
            cluster_id = check_and_get_working_cluster(vault, db_sp_client_id_name, db_sp_client_secret_name, tenant_id, db_access_token, cluster_id, params.environment, job_reg.source_name, job_reg.jobname, params.job_run_id, cluster_size)

            if "fail" in cluster_id:
                msg = f"Could not recreate cluster for job {params.job_run_id} with return value {cluster_id}"
                return failure_response({'cluster_recreate': [msg]})

        if params.task_name == 'SparkJAR' or params.task_name == 'SparkPY':
            #Update the custom ADB cluster id for the JAR/PY
            job_run.update_custom_db_cluster_id(session, cluster_id)
        else:
            #Update the custom ADB cluster id for Framework job
            job_run.update_db_cluster_id(session, cluster_id)

        response = {
            'clusterId': cluster_id,
            'executablePath': executable_path,
            'mainClass': params.main_class,
            'jobConfigPath': job_config_path,
            'schemaPath': schema_path,
            'jobName': job_run.name,
            'jobRunId': params.job_run_id,
            'taskRunId': params.task_run_id
        }

        return success_response(response, status_code=200)

    except JobException as je:
        logging.exception(je)
        return failure_response(je.error)
    except Exception as exception:
        logging.exception(exception)
        return failure_response(dict([(type(exception).__name__, str(exception))]))


###############################################################################
#
# Methods
#
###############################################################################

# Create DB cluster
def create_cluster(vault, sp_client_id_name, sp_client_secret_name, tenant_id, access_token, environment, source_name, job_name, job_instance_id, cluster_size):
    cluster_json = get_cluster_config(vault, sp_client_id_name, sp_client_secret_name, tenant_id, environment, source_name, job_name, job_instance_id, cluster_size)
    domain = get_db_domain_name()

    response = requests.post(
        f'https://{domain}/api/2.0/clusters/create',
        json=cluster_json,
        headers={'Authorization': f'Bearer {access_token}'}
    )

    if response.status_code == 200:
        return response.json()['cluster_id']
    else:
        return "INVALID"



# Get DB cluster configuration based on the cluster size
def get_cluster_config(vault, sp_client_id_name, sp_client_secret_name, tenant_id, environment, source_name, job_name, job_instance_id, cluster_size):
    name = "dc_" + source_name + "_" + job_name + "_" + str(job_instance_id)
    log_location = f"dbfs:/mnt/datacore-adb/logs/{environment}/{source_name}/{job_name}_{job_instance_id}"
    spark_version = "9.1.x-scala2.12"
    small_node_type = "Standard_E4s_v4"
    large_node_type = "Standard_E8s_v4"
    cluster_config = None
    client_id = "{{secrets/datacore-akv-scope/" + sp_client_id_name + "}}"
    client_secret = "{{secrets/datacore-akv-scope/" + sp_client_secret_name + "}}"
    endpoint = "https://login.microsoftonline.com/" + tenant_id + "/oauth2/token"

    spark_config = {
        "spark.hadoop.fs.azure.account.auth.type": "OAuth",
        "spark.hadoop.fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "spark.hadoop.fs.azure.account.oauth2.client.id": client_id,
        "spark.hadoop.fs.azure.account.oauth2.client.secret": client_secret,
        "spark.hadoop.fs.azure.account.oauth2.client.endpoint": endpoint,
        "spark.hadoop.javax.jdo.option.ConnectionURL": "{{secrets/datacore-akv-scope/datacore-metastore-connection-url}}",
        "spark.hadoop.javax.jdo.option.ConnectionUserName": "{{secrets/datacore-akv-scope/datacore-metastore-pg-user}}",
        "spark.hadoop.javax.jdo.option.ConnectionPassword": "{{secrets/datacore-akv-scope/datacore-metastore-pg-pwd}}",
        "spark.hadoop.javax.jdo.option.ConnectionDriverName": "org.postgresql.Driver",
        "spark.sql.hive.metastore.version": "0.13.0",
        "spark.hadoop.datanucleus.autoCreateSchema": "true",
        "spark.hadoop.datanucleus.autoCreateTables": "true",
        "spark.hadoop.datanucleus.fixedDatastore": "false"
    }

    if cluster_size == "S":
        cluster_config = {"cluster_name": name,
                          "spark_version": spark_version,
                          "node_type_id": small_node_type,
                          "spark_conf": spark_config,
                          "autoscale": {
                              "min_workers": 3,
                              "max_workers": 5
                          },
                          "autotermination_minutes": 10,
                          "cluster_log_conf" : {
                              "dbfs" : { "destination" : log_location}
                            }
                          }
    elif cluster_size == "M":
        cluster_config = {"cluster_name": name,
                          "spark_version": spark_version,
                          "node_type_id": small_node_type,
                          "spark_conf": spark_config,
                          "autoscale": {
                              "min_workers": 4,
                              "max_workers": 8
                          },
                          "autotermination_minutes": 10,
                          "cluster_log_conf" : {
                              "dbfs" : { "destination" : log_location}
                            }
                          }
    elif cluster_size == "L":
        cluster_config = {"cluster_name": name,
                          "spark_version": spark_version,
                          "node_type_id": large_node_type,
                          "spark_conf": spark_config,
                          "autoscale": {
                              "min_workers": 6,
                              "max_workers": 10
                          },
                          "autotermination_minutes": 10,
                          "cluster_log_conf" : {
                              "dbfs" : { "destination" : log_location}
                            }
                          }
    elif cluster_size == "XL":
        cluster_config = {"cluster_name": name,
                          "spark_version": spark_version,
                          "node_type_id": large_node_type,
                          "spark_conf": spark_config,
                          "autoscale": {
                              "min_workers": 10,
                              "max_workers": 14
                          },
                          "autotermination_minutes": 10,
                          "cluster_log_conf" : {
                              "dbfs" : { "destination" : log_location}
                            }
                          }
    return cluster_config


# Get the cluster status. Make sure it is running else needs to be restarted
def get_cluster_status(access_token, cluster_id):
    data_json = {"cluster_id": cluster_id}
    domain = get_db_domain_name()
    response = requests.post(
        f'https://{domain}/api/2.0/clusters/get',
        json=data_json,
        headers={'Authorization': f'Bearer {access_token}'}
    )

    if response.status_code == 200:
        return response.json()['state']
    else:
        return "NOTAVAILABLE"


# Restart the cluster if it is terminated
def restart_cluster(access_token, cluster_id):
    data_json = {"cluster_id": cluster_id}
    domain = get_db_domain_name()

    response = requests.post(
        f'https://{domain}/api/2.0/clusters/restart',
        json=data_json,
        headers={'Authorization': f'Bearer {access_token}'}
    )

    if response.status_code == 200:
        return cluster_id
    else:
        return "INVALID"

#Check and get the working ADB cluster
def check_and_get_working_cluster(vault, sp_client_id_name, sp_client_secret_name, tenant_id, access_token, cluster_id, environment, source_system, job_name, job_run_id, cluster_size):
    # Check if the cluster is "RUNNING" OR "TERMINATED"
    status = get_cluster_status(access_token, cluster_id)

    # If cluster is TERMINATED re-create a new cluster
    # Cluster status is not available, so create a new cluster
    if status == "NOTAVAILABLE" or status == "TERMINATED":
        cluster_id = create_cluster(vault, sp_client_id_name, sp_client_secret_name, tenant_id, access_token, environment, source_system, job_name, job_run_id, cluster_size)
        if cluster_id == "INVALID":
            return "fail1"
    elif status != "RUNNING":
        cluster_id = restart_cluster(access_token, cluster_id)
        if cluster_id == "INVALID":
            return "fail2"

    return cluster_id


# get the JAR/PY path to run in the DB cluster
def get_executable_path(task_name, source_name, environment_name):
    if task_name == "ConformInterface":
        return f"dbfs:/FileStore/jars/{environment_name}/datacore_conform_interface.jar"
    elif task_name == "StandardiseColumns":
        return f"dbfs:/FileStore/patterns/{environment_name}/standarization_main.py"
    elif task_name == "AugmentKeyMap":
        return f"dbfs:/FileStore/patterns/{environment_name}/augment_keymap_main.py"
    elif task_name == "KeyMapApply":
        return f"dbfs:/FileStore/patterns/{environment_name}/keymapping_main.py"
    elif task_name == "ChangeDataCapture":
        return f"dbfs:/FileStore/patterns/{environment_name}/cdc_main.py"
    elif task_name == "SparkJAR":
        source_system = source_name
        return f"dbfs:/FileStore/jars/{environment_name}/{source_system}/{source_system}.jar"

def get_tenant_id(vault):
    return get_vault_secret(vault, "datacore-azure-tenant-id")

def get_adb_sp_client_id_name(task_name, source_system):
    if task_name == 'SparkJAR' or task_name == 'SparkPY':
        #This is a custom task, so get the usecase specific SP details
        return f"datacore-adb-{source_system}-sp-client-id"
    else:
        return "datacore-adb-sp-client-id"

def get_adb_sp_client_id(vault, db_sp_client_id_name):
    return get_vault_secret(vault, db_sp_client_id_name)

def get_adb_sp_client_secret_name(task_name, source_system):
    if task_name == 'SparkJAR' or task_name == 'SparkPY':
        #This is a custom task, so get the usecase specific SP details
        return f"datacore-adb-{source_system}-sp-client-secret"
    else:
        return "datacore-adb-sp-client-secret"

def get_adb_sp_client_secret(vault, db_sp_client_secret_name):
    return get_vault_secret(vault, db_sp_client_secret_name)

def get_adb_cluster_id(task_name, cluster_id, custom_cluster_id):
    if task_name == 'SparkJAR' or task_name == 'SparkPY':
        return custom_cluster_id
    else:
        return cluster_id

def get_metastore_sp_client_id(vault, db_sp_client_id_name):
    return get_vault_secret(vault, db_sp_client_id_name)

def get_metastore_sp_client_secret(vault, db_sp_client_secret_name):
    return get_vault_secret(vault, db_sp_client_secret_name)

def get_metastore_postgres_host_name():
    return os.environ.get('METASTORE_POSTGRES_HOST_NAME')

#Get the secret value from vault
def get_vault_secret(vault, secret):
    return vault.get_secret(secret).value

#Generate AAD token
def get_aad_token(tenant_id, db_sp_client_id, db_sp_client_secret, resource_id):
    endpoint = f'https://login.microsoftonline.com/{tenant_id}/oauth2/token'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    payload = f"grant_type=client_credentials&client_id={db_sp_client_id}&client_secret={db_sp_client_secret}&resource={resource_id}"
    response = requests.post(endpoint, headers=headers, data=payload)

    if response.status_code == 200:
        aad_token = response.json()["access_token"]
        return aad_token
    else:
        return "INVALID"