from cerberus import Validator

INVOKE_SPARK_JAR_TASK_SCHEMA = {
    'oDate': {'type': 'string', 'required': True},
    'environment' : {'type': 'string', 'required': True},
    'taskName': {'type': 'string', 'required': True},
    'jobRunId': {'type': 'integer', 'required': True},
    'taskRunId': {'type': 'integer', 'required': True},
    'mainClass' : {'type': 'string', 'required': True}
}

class InvokeSparkJarTaskParams:
    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in INVOKE_SPARK_JAR_TASK_SCHEMA}
        self.validator = Validator(INVOKE_SPARK_JAR_TASK_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def errors(self):
        return self.validator.errors
    
    @property
    def o_date(self):
        return self.content.get('oDate')

    @property
    def environment(self):
        return self.content.get('environment')

    @property
    def task_name(self):
        return self.content.get('taskName')

    @property
    def job_run_id(self):
        return self.content.get('jobRunId')
    
    @property
    def task_run_id(self):
        return self.content.get('taskRunId')
    
    @property
    def main_class(self):
        return self.content.get('mainClass')

    