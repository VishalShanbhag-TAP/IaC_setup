import json
import os
import logging
from functools import reduce

import azure.functions as func

from azure.core.exceptions import ResourceNotFoundError
from azure.identity import ManagedIdentityCredential
from exceptions import JobException, JobRunException
from read_schema.read_schema_params import ReadSchemaParams
from models import FAILED, JobRun
from shared import failure_response, create_secret_client, create_dl_file_client, create_df_mgmt_client, \
    success_response, create_session, get_data_storage_accounts_config


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        logging.info('Python HTTP trigger function lock_keymap_table processed a request.')

        params = ReadSchemaParams(req.get_json())

        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()
        session = create_session(credential)
        vault = create_secret_client(credential)

        storage_cfg = get_data_storage_accounts_config(vault.get_secret("datacore-storage-accounts").value)
        config = storage_cfg.get("metadataStorageAccount", {})
        meta_storage_account_url = config.get("url")
        meta_container = config.get("container")

        job_run = JobRun.get(session, params.job_run_id)
        if job_run is None:
            msg = f"Unable to get the current job run id {params.job_run_id} in environment {params.environment_name}"
            return failure_response({'get_current_job': [msg]})

        job_reg = job_run.job_registration

        schema_path = job_reg.storage_account_schema_file_path()
        adls_file_client = create_dl_file_client(meta_storage_account_url, meta_container, schema_path, credential)

        schema_config = get_schema_config(adls_file_client, schema_path)

        ssu = schema_config["Scope"]["SSU"].lower()
        source_system = schema_config["Scope"]["SourceSystem"].lower()
        table_name = schema_config["Scope"]["TableName"].lower()
        integration_keys = schema_config["IntegrationKeys"]
        light_keys = schema_config["LightKeys"]["GeneratedLightKeys"]
        
        response = {
            'jobRunId': params.job_run_id,
            'taskRunId': params.task_run_id,
            'environment': params.environment_name,
            'ssu': ssu,
            'sourceSystem': source_system,
            'tableName': table_name,
            'integrationKeys': integration_keys,
            'lightKeys': light_keys
        }

        return success_response(response, status_code=200)

    except JobRunException as jre:
        if job_run:
            job_run.set_status(session, jre.status)
            return failure_response(jre.error)



def get_schema_config(file_client, schema_path):
    logging.info("Downloading Schema Params")
    try:
        download = file_client.download_file()
        contents = download.readall()
        schema_config = json.loads(contents)
    except ResourceNotFoundError as e:
        logging.exception(e)
        raise JobRunException(FAILED, {'jobRegistration': f"'{schema_path}' not found."})
    
    return schema_config