from cerberus import Validator

READ_SCHEMA_SCHEMA = {
    'jobRunId': {'type': 'integer', 'required': True},
    'taskRunId': {'type': 'integer', 'required': True},
    'environmentName': {'type': 'string', 'required': True}
}


class ReadSchemaParams:
    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in READ_SCHEMA_SCHEMA}
        self.validator = Validator(READ_SCHEMA_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def errors(self):
        return self.validator.errors

    @property
    def job_run_id(self):
        return self.content.get('jobRunId')

    @property
    def task_run_id(self):
        return self.content.get('taskRunId')

    @property
    def environment_name(self):
        return self.content.get('environmentName')
