from cerberus import Validator

GET_LOCK_SCHEMA = {
    'jobRunId': {'type': 'integer', 'required': True},
    'taskRunId': {'type': 'integer', 'required': True},
    'environmentName': {'type': 'string', 'required': True},
    'keymapTable': {'type': 'string', 'required': True}
}


class GetLockParams:
    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in GET_LOCK_SCHEMA}
        self.validator = Validator(GET_LOCK_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def errors(self):
        return self.validator.errors

    @property
    def job_run_id(self):
        return self.content.get('jobRunId')

    @property
    def task_run_id(self):
        return self.content.get('taskRunId')

    @property
    def environment_name(self):
        return self.content.get('environmentName')

    @property
    def keymap_table(self):
        return self.content.get('keymapTable')
