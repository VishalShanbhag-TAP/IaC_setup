import json
import os
import logging
from functools import reduce

from sqlalchemy.sql.expression import false, true

import azure.functions as func

from azure.identity import ManagedIdentityCredential
from get_lock.get_lock_params import GetLockParams
from models import KeymapLocks
from shared import failure_response, success_response, create_session


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function get_lock processed a request.')

    params = GetLockParams(req.get_json())

    if not params.validate():
        return failure_response(params.errors)

    credential = ManagedIdentityCredential()
    session = create_session(credential)
    lock_acquired = "false"
    
    lock = KeymapLocks.get(session, params.environment_name, params.keymap_table, "locked")

    if lock is None:
        #This job can acquire the lock
        try:
            new_lock = KeymapLocks.acquire_lock(session, params.environment_name, params.keymap_table, params.job_run_id, params.task_run_id)
            if new_lock:
                lock_acquired = "true"
        except Exception as e:
            logging.exception(e)
            logging.info(f"IntegrityError on keymap_locks table for keymap table {params.keymap_table}")
            lock_acquired = "false"
    else:
        #Lock already present
        logging.info(f"Lock on {lock.keymap_table_name} is held by job #{lock.job_id} task #{lock.task_id}")
        
    response = {
        "keymap_table": params.keymap_table,
        "lock_acquired": lock_acquired,
    }

    return success_response(response, status_code=200)