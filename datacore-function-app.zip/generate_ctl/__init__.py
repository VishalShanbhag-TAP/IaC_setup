import os
import logging
from functools import reduce

import azure.functions as func

from azure.core.exceptions import ResourceNotFoundError
from azure.identity import ManagedIdentityCredential

from exceptions import JobException
from generate_ctl.generate_ctl_params import GenerateCtlParams
from services import get_job_registration
from shared import failure_response, create_secret_client, \
    success_response, create_dl_service_client, create_session, get_dl_file_system_client, \
    create_data_dl_file_client, get_data_storage_accounts_config
from models import FileRegistration, COMPLETED, FILE_COPIED


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        logging.info('Python HTTP trigger function processed a request.')

        params = GenerateCtlParams(req.get_json())

        if not params.validate():
            return failure_response(params.errors)

        credential = ManagedIdentityCredential()
        session = create_session(credential)
        vault = create_secret_client(credential)
        storage_cfg = get_data_storage_accounts_config(vault.get_secret("datacore-storage-accounts").value)

        job_reg = get_job_registration(session, params.job_name, params.environment_name)

        # for each copied file for a given jobName
        for file_registration in job_reg.file_registrations.filter(FileRegistration.status == FILE_COPIED):
            file_name = file_registration.data_file_name

            destination_file_location = file_registration.destination_file_location
            destination_file_path = job_reg.resolve_path(destination_file_location.path_pattern)
            adls_path = os.path.join(destination_file_path, file_name)
            
            logging.info(f"DEBUG INFO - adlspath = {adls_path}")

            file_client = create_data_dl_file_client(storage_cfg, adls_path, credential)

            try:
                download = file_client.download_file()
                lines = download.readall()
            except ResourceNotFoundError as e:
                logging.exception(e)
                return failure_response({'FileRead': f"{adls_path} not found."})

            # Now you can read and interpret the data from the file
            split_lines = lines.splitlines()
            header_line = str(split_lines[0], 'utf-8')
            trailer_line = str(split_lines[-1], 'utf-8')

            dl_service_client = create_dl_service_client(storage_cfg, credential)
            dl_filesystem_client = get_dl_file_system_client(dl_service_client, storage_cfg)
            dl_ctl_directory_client = dl_filesystem_client.get_directory_client(destination_file_path)

            # Now generate the CTL file in the location
            generate_ctl_file(dl_ctl_directory_client, job_reg.source_name, file_name, trailer_line)

            # The meta file containing HDR and TRL placed at the same location as final data
            meta_file_path = job_reg.resolve_path("/app_root/bidh/data/<ENV>/SDS/database/<SSU>/<SOURCE_SYSTEM>/<TABLE_NAME>/meta")

            dl_meta_directory_client = dl_filesystem_client.get_directory_client(meta_file_path)
            # COMMENT meta_file_name = file_name.split('.')[0] + ".meta"
            meta_file_name = file_name + ".meta"

            # Now write the header and trailer records to a meta location
            write_header_trailer(dl_meta_directory_client, meta_file_name, header_line, trailer_line)

        return success_response({'status': COMPLETED}, status_code=200)

    except JobException as je:
        logging.exception(je)
        return failure_response(je.error)
    except Exception as exception:
        logging.exception(exception)
        return failure_response(dict([(type(exception).__name__, str(exception))]))


def generate_ctl_file(dl_ctl_directory_client, source_system, file_name, trailer_line):
    ctl_file_name = file_name.split('.')[0] + ".ctl"
    file_creation_end = trailer_line[10:24]
    file_rec_count = trailer_line[24:31]
    extract_date = file_creation_end[0:8]

    separator = '|'
    ctl_sequence = (file_rec_count, extract_date, file_name, source_system)
    file_content = separator.join(ctl_sequence)

    logging.info(f"CTL Content: {file_content}")

    ctl_file_client = dl_ctl_directory_client.create_file(ctl_file_name)
    ctl_file_client.append_data(data=file_content, offset=0, length=len(file_content))
    ctl_file_client.flush_data(len(file_content))


def write_header_trailer(dl_meta_directory_client, meta_file_name, header_line, trailer_line):
    line_separator = '\n'
    meta_sequence = (header_line, trailer_line)
    file_content = line_separator.join(meta_sequence)

    logging.info(f"META Content: {file_content}")

    meta_file_client = dl_meta_directory_client.create_file(meta_file_name)
    meta_file_client.append_data(data=file_content, offset=0, length=len(file_content))
    meta_file_client.flush_data(len(file_content))
