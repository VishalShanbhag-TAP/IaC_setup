from cerberus import Validator

from shared import validate_o_date

GENERATE_CTL_SCHEMA = {
    'jobName': {'type': 'string', 'required': True},
    'oDate': {
        'type': 'string',
        'check_with': validate_o_date,
        'required': True,
        'coerce': str
    },
    'environmentName': {'type': 'string', 'required': True}
}


class GenerateCtlParams:
    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in GENERATE_CTL_SCHEMA}
        self.validator = Validator(GENERATE_CTL_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def errors(self):
        return self.validator.errors

    @property
    def job_name(self):
        return self.content.get('jobName')

    @property
    def o_date(self):
        return self.content.get('oDate')

    @property
    def environment_name(self):
        return self.content.get('environmentName')
