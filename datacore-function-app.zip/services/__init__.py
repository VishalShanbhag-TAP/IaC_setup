from exceptions import JobException
from models import JobRegistration


def get_job_registration(session, job_name, env_name):
    job_reg = JobRegistration.get(session, job_name, env_name)

    if job_reg:
        return job_reg
    else:
        msg = f"'{job_name}' has not been registered for environment '{env_name}'."
        raise JobException({'jobRegistration': [msg]})
