from cerberus import Validator

CANCEL_JOB_RUN_SCHEMA = {
    'taskRunId': {
        'type': 'integer',
        'coerce': int,
        'required': True
    }
}


class CancelJobRunParams:

    def __init__(self, params):
        self.content = {key: params[key] for key in params.keys() if key in CANCEL_JOB_RUN_SCHEMA}
        self.validator = Validator(CANCEL_JOB_RUN_SCHEMA)

    def validate(self):
        return self.validator.validate(self.content)

    @property
    def task_run_id(self):
        return self.content.get('taskRunId')

    @property
    def errors(self):
        return self.validator.errors
