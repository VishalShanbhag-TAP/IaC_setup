import logging

import azure.functions as func
from azure.identity import ManagedIdentityCredential

from cancel_job_run.cancel_job_run_params import CancelJobRunParams
from models import TaskRun, Pipeline
from shared import failure_response, create_secret_client, success_response, create_df_mgmt_client, create_session


def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        p = CancelJobRunParams(req.get_json())
        if not p.validate():
            return failure_response(p.errors)

        credential = ManagedIdentityCredential()
        vault = create_secret_client(credential)

        session = create_session(credential)
        task_run = TaskRun.get(session, p.task_run_id)
        job_run = task_run.job_run

        df_client = create_df_mgmt_client(credential, vault.get_secret("datacore-subscription-id").value)

        main_pipeline = Pipeline.bootstrap(session)
        df_client.pipeline_runs.cancel(
            main_pipeline.resource_group_name,
            main_pipeline.factory_name,
            job_run.job_run_uuid
        )

        job_run.cancel(session)

        return success_response({'jobRunUuid': job_run.job_run_uuid, 'taskRunUuid': task_run.task_run_uuid})

    except Exception as exception:
        logging.exception(exception)
        return failure_response(dict([(type(exception).__name__, str(exception))]))
