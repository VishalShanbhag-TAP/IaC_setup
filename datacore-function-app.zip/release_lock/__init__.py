import json
import os
import logging
from functools import reduce

from sqlalchemy.sql.expression import false, true

import azure.functions as func

from azure.identity import ManagedIdentityCredential
from release_lock.release_lock_params import ReleaseLockParams
from models import KeymapLocks
from shared import failure_response, success_response, create_session


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function get_lock processed a request.')

    params = ReleaseLockParams(req.get_json())

    if not params.validate():
        return failure_response(params.errors)

    credential = ManagedIdentityCredential()
    session = create_session(credential)
    lock_released = "false"
    
    lock = KeymapLocks.get_by_job_task_id(session, params.environment_name, params.keymap_table, params.job_run_id, params.task_run_id, "locked")

    if lock:
        # Lock is present, release the lock now
        try:
            KeymapLocks.release_lock(session, params.environment_name, params.keymap_table, params.job_run_id, params.task_run_id)
            lock_released = "true"
        except Exception as e:
            logging.exception(e)
            logging.error(f"lockReleaseError: Unable to release the lock on keymap table {params.keymap_table}")
            lock_released = "false"
    else:
        # No lock present
        logging.error(f"Lock on {params.keymap_table} held by job #{params.job_run_id} task #{params.task_run_id} is not found")
        lock_released = "true"
        
    response = {
        "keymap_table": params.keymap_table,
        "lock_released": lock_released,
    }

    return success_response(response, status_code=200)