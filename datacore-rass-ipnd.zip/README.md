# Introduction 
RASSP-IPND project is responsible for generating IPND upload file to report RASS-P address service updates to IPND manager. During this process, it utilises AddresSQ unstructured APIs to derive structured addresses of services from corresponding unstructured addresses sent by RASS-P.

# Getting Started

1. Installation process
* Set HTTP_PROXY environment variable in your local PC as below (if windows)
  * set HTTP_PROXY=http://<d-number>:@http-gw.tcif.telstra.com.au:8080
* Clone the code from Azure Repo, "datacore-rass-ipnd", in "DataCore-Delivery" project to your local repository

2. Software dependencies
* Refer to pom.xml for all software dependencies
 
3.References
* Detailed design of the solution
  * https://confluence.tools.telstra.com/display/SEG/Detailed+Design+-+RASS-P+address+updates+to+IPND
* Azure Devops
  * https://confluence.tools.telstra.com/display/SEG/Datacore+-+Azure+DevOps

# Build and Test
It is better to use mvn command line to build and run unit tests cases.

* mvn clean   [ Clean the build ]
* mvn compile [ Compile the build ]
* mvn package [ Generate .jar package ] 
* mvn test    [ Run all JUNIT test cases ]
* mvn verify  [ To compile, package and run test cases in one go ]

# Secure Code Scans
Refer to code scan reports after successful build and run of all test cases as below.
All tools require the user to be onboarded to the project to get access to the tool and reports.
1. Coverity
* Project Details
  * Project: RASSP-IPND-WorkSpace-Scala
  * Stream: WorkSpace-Scala
* Tool Access Link
  * https://lxappconn004.in.telstra.com.au:8443/reports.htm#v15940/p10730
* Support 
  * Raise ticket similar to this here: https://jira.tools.telstra.com/browse/SCBE-4538
2. Sonarqube
* There is an existing issue due to which Sonarqube results are picked by the tool for Scala correctly
* Tool Access Link
  * https://sonarqube.tools.telstra.com/dashboard?id=rasspipnd-addressmatcher
* Support 
  * Create JIRA like this : https://jira.tools.telstra.com/browse/JETPACK-1650
* Access reports locally
  * Using Jacoco plugin at target/jacoco-ut/index.html
  * Using Scoverage plugin at target/site/scoverage/index.html
3. Sourceclear
* Project Details
  * Workspace Name: RASSP-IPND
* Tool Access Link
  * https://sca.analysiscenter.veracode.com/workspaces/3OOu4aV/issues
* Support
  * Use JIRA as in here: https://jira.tools.telstra.com/browse/SCBE-5036
  * https://confluence.tools.telstra.com/display/DEVSECOPS/GET%3A+Agent+Based+Scan

# Contribute

* The unit test coverage could be improved by adding more test cases covering the code that hasn't been covered by existing test cases.
* Test code is at src/test/scala

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)