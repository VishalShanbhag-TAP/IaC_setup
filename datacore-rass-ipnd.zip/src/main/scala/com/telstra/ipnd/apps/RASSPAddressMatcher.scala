package com.telstra.ipnd.apps

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

import com.telstra.ipnd.AbstractApp
import com.telstra.ipnd.parser.AddressParsingImpl
import com.telstra.ipnd.utils.Constants.serviceAddressState
import com.telstra.ipnd.utils.Constants.serviceBuildingProperty
import com.telstra.ipnd.utils.PathUtils
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.max

/**
 * Starting the address matching application. Which will implement the below steps
 * //sequence of steps to follow.
 * //1. rasspData = read the rassp data with all columns
 * //2. select distinct "service building address" and "state"
 * //2a. perform lookup to address SQ
 * //2b. parse the response. //logic for retry in case of timeout, //max retries
 * //2c. lookupData = store the lookup data with parsed columns from address sq response + "service building address" and "state"
 * //3. left outer join rasspData with lookupData on columns "service building address" and "state"
 * //3a. if joined successfull, replace the column value from lookupData to the corresponding data in rasspData
 * //3b. if not joined, take as is and write the records seperately as well.
 *
 * //4. store the joined result form step 3
 * //5. extract generation: lpad the columns and extract it based on storing.
 *
 * @author d941294(Kumar,Amit)
 */
object RASSPAddressMatcher extends AbstractApp with Serializable {

  override def execute(opts: Map[String, String], spark: SparkSession): Unit = {

    val log = LoggerFactory.getLogger(getClass)
    val inputParquetPath = PathUtils.ingestedPath(opts)

    /**
     * Read partition data for given ODATE (prev day in UTC) and
     * select rows that are inserted by a latest task ID
     * The partition may have duplicates when same ODATE is run multiple times
     * with remediate RASS extract file
     */
    log.info(s"Reading the input RASS-P table from ${opts("rassTableName")} ")
    val rassQuery = s"select * from ${opts("rassTableName")} where effectivestartutcdtprtnkey=${opts("prevOdate")}"
    val rassppart = spark.sql(s"$rassQuery").drop("effectivestartutcdtprtnkey")
    val latestInsTaskId: Int = rassppart.select(max("inserttaskid")).collect()(0).getInt(0)
    val rasspdata = rassppart.filter(s"inserttaskid = $latestInsTaskId")

    log.info(s"Input Query: $rassQuery")
    val distinctServiceBuilding = rasspdata.select(serviceBuildingProperty, serviceAddressState).distinct().coalesce(opts.getOrElse("coalesceValue", "10").toInt)
    distinctServiceBuilding.persist(StorageLevel.MEMORY_AND_DISK)
    log.info(s"Distinct RASS-P addresses found: ${distinctServiceBuilding.count()}")

    val addressParsingImpl = new AddressParsingImpl(opts)
    //read the schema file of the json addressSQ response
    log.info("Starting to create the addressSQ response schema from input encoded schema")
    val schemFinal = addressParsingImpl.getDecodedSchema(opts("responseSchema"))

    //perform address lookup and produce the dataset with response appended into it
    log.info("Starting to perform API calls to AddressSQ for each unique address in RASS-P input file")
    val addressLookupDataset = addressParsingImpl.performApiCall(distinctServiceBuilding)
    addressLookupDataset.persist(StorageLevel.MEMORY_AND_DISK)
    //save the addressLookupDatset for lineage purpose
    val addressLookupDataPath = PathUtils.addressLookupDataPath(opts)
    log.info(s"Starting to save the AddressSQ response for lookup data $addressLookupDataPath")
    addressLookupDataset.write.mode(SaveMode.Overwrite).parquet(addressLookupDataPath)

    val mappedDataset = addressParsingImpl.performMappingToColumn(addressLookupDataset, schemFinal).withColumnRenamed("SERVICE ADDRESS STREET NAME 1","SERVICESTREETNAME1")

    //join this dataset with the full data
    val joinedData = addressParsingImpl.performJoin(mappedDataset, rasspdata)
    joinedData.persist(StorageLevel.MEMORY_AND_DISK)

    //logic to create the select columns after successful join
    val selectJoinColumn = addressParsingImpl.parseSelectColumns(rasspdata.schema.fieldNames.toSeq, mappedDataset.schema.fieldNames.toSeq)
    val selectNotUpdated = rasspdata.schema.fieldNames.toSeq.map(field => col(s"left.$field"))
    //perform filter and update the columns as per the IPNd requirements
    val finalResult = addressParsingImpl.filterAndUpdate(joinedData, selectJoinColumn, selectNotUpdated)
    //write the match failed records
    val matchFailPath = PathUtils.matchFailedDataPath(opts)

    log.info(s"Starting to save the match failed records in the location $matchFailPath")
    val matchFailData = finalResult._2
    matchFailData.persist(StorageLevel.MEMORY_AND_DISK)
    matchFailData.write.mode(SaveMode.Overwrite).parquet(matchFailPath)

    //sucess records
    val enrichedDataPath = PathUtils.enrichedDataPath(opts)
    log.info(s"Starting to save the final enriched records in the location $enrichedDataPath")
    finalResult._1.union(matchFailData).write.mode(SaveMode.Overwrite).parquet(enrichedDataPath)

    log.info(s"Total address matches    : ${finalResult._1.count()}")
    log.info(s"Total address mismatches : ${matchFailData.count()}")
    log.info(s"Address matching process is complete!")
  }
}