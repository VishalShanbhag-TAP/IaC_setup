package com.telstra.ipnd.apps

import scala.io.Source

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.slf4j.LoggerFactory

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.ipnd.AbstractApp
import com.telstra.ipnd.parser.DownStreamProcessing
import com.telstra.ipnd.utils.PathUtils
import java.time.LocalDateTime

import java.time.format.DateTimeFormatter
/**
 * Class to create the down stream file for the IPND after address matching are performed based on odate
 * Steps to be implemented
 * 1. Read all the rows for the folder or table for the given oDate
 * 2. Identify all the unique fileIds for the given odate
 * 3. Identify the mapping of unique fileIds to the filename to get the sequence number and create the outputfile name
 * 4. filter all the rows for each fileID
 * 	4a. order the rows using the filenumber
 * 	4b. apply padding for creating the fixed-width file
 * 	4b. write the order rows in the output folder in the same sequence with the file name identified in step3
 * 5. continue to step4 for remaining fileIds
 *
 * @author d941294(Kumar,Amit)
 */
object IPNDDownStreamFileGeneration extends AbstractApp with Serializable {

  override def execute(opts: Map[String, String], spark: SparkSession): Unit = {

    val log = LoggerFactory.getLogger(getClass)
    val schemaText = Source.fromInputStream(getClass.getClassLoader.getResourceAsStream("properties/ingestion_schema.json")).mkString

    val enrichedDataPath = PathUtils.enrichedDataPath(opts)
    log.info(s"Reading the enriched data from the path $enrichedDataPath")
    val enrichedDataset = spark.read.parquet(enrichedDataPath)
    val uniqueFileIds = enrichedDataset.select("fileId", "SEQUENCE").distinct().collectAsList()
    log.info(s"The file IDs for which output file will be generated are ${uniqueFileIds}")

    val downStreamProcessing = new DownStreamProcessing(opts)
    val fileNameMapping = downStreamProcessing.mapFileIdToName(uniqueFileIds)
    var isFirstFile: Boolean = true

    //perform the outout file data generation
    fileNameMapping.foreach(file => {
      val transformData = downStreamProcessing.transformOutFileFormat(enrichedDataset.where(col("fileId").equalTo(file._1)).orderBy("FileLineNumber"), schemaText)

      //add the header and trailer read from file
      //RASS-P_<nnnnnnn>_IPNDUP_YYYYMMDD.dat.meta
      val metadatFilepath = s"${PathUtils.fileMetaDatapath(opts)}/RASS-P_${file._2.split("\\.")(1)}_IPNDUP_${opts("oDate")}.dat.meta"
      log.info(s"Starting to read the header and trailer for file ${file._1} from location $metadatFilepath")
      val hdrTrlContent = spark.read.textFile(metadatFilepath).collectAsList()

      val finalDataset = downStreamProcessing.appendHeaderTrailer(hdrTrlContent.get(0), hdrTrlContent.get(1), transformData)
      val ipndOutputFilePath = PathUtils.ipndOutputFilePath(opts)

      //save the file
      if (isFirstFile) {
        log.info(s"Save the first file in the location $ipndOutputFilePath")
        finalDataset.write.option("header", "false").mode(SaveMode.Overwrite).text(ipndOutputFilePath)
        isFirstFile = false
      } else {
        log.info(s"Save the consecutive file in the location $ipndOutputFilePath")
        finalDataset.write.option("header", "false").mode(SaveMode.Append).text(ipndOutputFilePath)
      }

      val outputFileNameIPND = file._2
      log.info(s"Final name of the file in the location $ipndOutputFilePath is $outputFileNameIPND")
      //rename and delete the file
      dbutils.fs.ls(ipndOutputFilePath).foreach(file => {
        if (file.name.startsWith("part-")) {
          dbutils.fs.mv(s"${file.path}", s"$ipndOutputFilePath/$outputFileNameIPND")
        } else {
          if (!file.name.startsWith("IPNDUPRASS1"))
            dbutils.fs.rm(s"${file.path}", false)
        }
      })
    })
    log.info(s"Downstream IPND Upload file generation is complete!")
  }

}