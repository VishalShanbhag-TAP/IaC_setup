package com.telstra.ipnd.utils

import java.nio.file.Paths
import java.util.concurrent.TimeUnit

import org.apache.http.HttpStatus
import org.slf4j.LoggerFactory

import com.google.gson.JsonParser

import nl.altindag.ssl.SSLFactory
import nl.altindag.ssl.util.PemUtils
import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import okhttp3.ConnectionSpec
import okhttp3.TlsVersion
import okhttp3.CipherSuite
import java.util.Collections

/**
 * Utility class to make the API call to OKAPI.
 * @author Kumar,Amit(d941294)
 */
object HttpUtils extends Serializable {

  val log = LoggerFactory.getLogger(getClass)
  var httpClient: OkHttpClient = null
  val jsonParser = new JsonParser

  /**
   * Function to create or get the http client
   */
  def getOrCreateHttpClient(certValue: String, keyValue: String , httpClientCallTimeOut: Int): OkHttpClient = synchronized {

    if (httpClient == null) {
      log.info("client is not available. Going to create new with required certifcate")
      log.info(s"Reading the certificates from $certValue path ${Paths.get(certValue)}")
      log.info(s"Reading the keys from $keyValue path ${Paths.get(keyValue)}")

      //adding this for okhttp
      val spec = new ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
        .tlsVersions(TlsVersion.TLS_1_2)
        .cipherSuites(
          CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
          CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256,
          CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384)
        .build()

      val keyManager = PemUtils.loadIdentityMaterial(Paths.get(certValue), Paths.get(keyValue))
      val sslFactory: SSLFactory = SSLFactory.builder()
        .withIdentityMaterial(keyManager)
        .withDefaultTrustMaterial()
        .withSystemTrustMaterial()
        .build()

      httpClient = new OkHttpClient().newBuilder().connectionSpecs(Collections.singletonList(spec))
        .sslSocketFactory(sslFactory.getSslSocketFactory, sslFactory.getTrustManager().get)
        .callTimeout( httpClientCallTimeOut, TimeUnit.SECONDS)
        .build()
      log.info("Successfully creatd the http client")
      httpClient

    }
    log.info("Client is existing. Returning the existing client, new cnfigurations will not take effect...")
    httpClient
  }

  /**
   * Function to make call to api with the oauth token
   */
  def makeHttpCall(apiUrl: String, token: String, requestBody: String, httpClient: OkHttpClient): Response = {

    val mediaType = MediaType.parse("application/json")
    val body = RequestBody.create(requestBody, mediaType)
    val request = new Request.Builder()
      .url(apiUrl)
      .method("POST", body)
      .addHeader("Authorization", s"Bearer $token")
      //added this only for testing of addresssql
      //.addHeader("green", "true")
      //remove above seeting when actual api are ready
      .addHeader("Content-Type", "application/json")
      .build()
    log.info(s"making the request for ${request.body().toString()}")
    httpClient.newCall(request).execute()

  }

  /**
   * Function to get the ouath token
   */
  def getToken(clientId: String, clientSecret: String, oauthUrl: String, httpClient: OkHttpClient): String = {

    val mediaType = MediaType.parse("application/x-www-form-urlencoded")
    val body = RequestBody.create(s"client_id=$clientId&client_secret=$clientSecret&grant_type=client_credentials".getBytes, mediaType)
    val request = new Request.Builder()
      .url(oauthUrl)
      .method("POST", body)
      .addHeader("Content-Type", "application/x-www-form-urlencoded")
      .build()

    log.info("making the request for oauth token")
    val tokenResponse = httpClient.newCall(request).execute()
    if (!tokenResponse.isSuccessful())
      throw new RuntimeException(s"The api call to fetch the token is not successfull. Aborting... $tokenResponse")
    if (tokenResponse.code() != HttpStatus.SC_OK)
      throw new RuntimeException(s"The api call to fetch the token is not successfull with code ${tokenResponse.code()}. Aborting... $tokenResponse")
    val token = jsonParser.parse(tokenResponse.body().string()).getAsJsonObject.get("access_token").getAsString
    token
  }

}