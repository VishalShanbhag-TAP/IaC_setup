package com.telstra.ipnd.utils

/**
 * Object class for holding the constants values
 *
 * @author d941294(Kumar,Amit)
 */
object Constants {

  val serviceAddressState = "serviceaddressstate"
  val serviceBuildingProperty = "servicebuildingproperty"
  val apiAddressResponse = "apiaddressresponse"
  val valueApiAddressResponse = "valueapiaddressresponse"
  val rasspDataAlias = "left"
  val lookupDataAlias = "right"
  val listCode = "LISTCODE"
  val partCol = "effectivestartutcdtprtnkey"
  val abfss = "abfss://"
  val dsfFolder= "processed_date"
}