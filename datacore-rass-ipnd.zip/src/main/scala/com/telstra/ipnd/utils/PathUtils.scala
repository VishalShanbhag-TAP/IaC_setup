package com.telstra.ipnd.utils

import java.nio.file.Paths

import org.apache.spark.internal.Logging

object PathUtils {

  def ssuFolderName(ssu: String): String = ssu match {
    case "retail"     => "retail"
    case "wholesale"  => "wholesale"
    case "transient"  => "transient"
    case "enterprise" => "reference"
  }

  def ingestedPath(opts: Map[String, String]): String = {
    s"${Constants.abfss}${
      Paths.get(opts("adlsBasePath"), opts("env"), "SDS", "database",
        //"landing",
        ssuFolderName(opts("ssu")).toLowerCase,
        opts("sourceSystem").toLowerCase,
        databaseName(opts),
        opts("tableName").toLowerCase,
        s"effectivestartutcdtprtnkey=${opts("prevOdate")}").toString
    }"
  }

  def databaseName(opts: Map[String, String]): String = {
    opts("env") +
      "_bidh" +
      Character.toString(opts("ssu").charAt(0)).toLowerCase() +
      "_SDS_" +
      opts("sourceSystem").toLowerCase +
      "_hist"
  }

  def addressLookupDataPath(opts: Map[String, String]): String = {
    s"${Constants.abfss}${
      Paths.get(opts("adlsBasePath"), opts("env"), "SDS", //"inbound",
        "database",
        ssuFolderName(opts("ssu")).toLowerCase,
        opts("sourceSystem").toLowerCase,
        //appSchemaOptions.reader.tableName.toLowerCase
        opts("addressLookupDataName"),
        s"${Constants.partCol}"+"="+ s"${opts("prevOdate")}").toString
    }"
  }

  def enrichedDataPath(opts: Map[String, String]): String = {
    s"${Constants.abfss}${
      Paths.get(opts("adlsBasePath"), opts("env"), "SDS", //"inbound",
        "database",
        ssuFolderName(opts("ssu")).toLowerCase,
        opts("sourceSystem").toLowerCase,
        opts("enrichedDataName").toLowerCase(),
        s"${Constants.partCol}" +"="+ s"${opts("prevOdate")}").toString
    }"
  }

  def matchFailedDataPath(opts: Map[String, String]): String = {
    s"${Constants.abfss}${
      Paths.get(opts("adlsBasePath"), opts("env"), "SDS", //"inbound",
        "database",
        ssuFolderName(opts("ssu")).toLowerCase,
        opts("sourceSystem").toLowerCase,
        opts("matchFailureDataName"),
        s"${Constants.partCol}" +"="+ s"${opts("prevOdate")}").toString
    }"
  }

  def ipndOutputFilePath(opts: Map[String, String]): String = {
    s"${Constants.abfss}${
      Paths.get(opts("adlsBasePath"), opts("env"), "DSF", //"inbound",
        "send",
        ssuFolderName(opts("ssu")).toLowerCase,
        opts("sourceSystem").toLowerCase,
        opts("ipndFilePath"),
        s"${Constants.dsfFolder}" +"="+ s"${opts("oDate")}").toString
    }"
  }

  def fileMetaDatapath(opts: Map[String, String]): String = {
    s"${Constants.abfss}${
      Paths.get(opts("adlsBasePath"), opts("env"), "SDS", //"inbound",
        "database",
        ssuFolderName(opts("ssu")).toLowerCase,
        opts("sourceSystem").toLowerCase,
        opts("tableName").toLowerCase,
        "meta").toString
    }"
  }

}