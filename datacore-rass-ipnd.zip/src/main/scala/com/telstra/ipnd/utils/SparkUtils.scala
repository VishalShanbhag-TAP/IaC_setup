package com.telstra.ipnd.utils

import org.apache.spark.SparkConf
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession

/**
 * Trait that provides the management of a SparkSession
 */
trait SparkUtils {

  @transient private var _sparkSession: SparkSession = _

  /**
   * Returns a single accessible SparkSession
   * @param props
   * @tparam T this is for serializerClass, which is of type Class[T]
   * @return Spark session
   */
  def getSparkSession[T](appName: String): SparkSession = {

    val conf = new SparkConf()
    conf.setAppName(appName)

    _sparkSession = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()
    sparkSession
  }

  def sparkSession: SparkSession = _sparkSession
}