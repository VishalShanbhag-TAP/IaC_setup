package com.telstra.ipnd

import java.util.InputMismatchException
import java.util.Properties
import scala.collection.JavaConverters.propertiesAsScalaMapConverter
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory
import com.telstra.ipnd.services.AzureKeyVaultService
import com.telstra.ipnd.utils.SparkUtils

import java.util.Base64
import com.google.gson.JsonParser

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * This is the base class for actual application, manages the SparkSession at the beginning of the code
 */
abstract class AbstractApp
  extends SparkUtils
  with AzureKeyVaultService {

  def main(args: Array[String]): Unit = {

    val log = LoggerFactory.getLogger(getClass)
    if (args.length != 7) {
      log.error(" Insufficient input arguments! ")
      throw new InputMismatchException(s"Required number of arguments are not passed. Expected 7 found ${args.length}")
    }

    /**
     * Set input arguments to opts
     *
     * jobRunId, oDate, environment, taskType, taskRunId, mainClass
     */

    // odate-1 implementation to get the correct partition
    val ingestionOdate = args(3).toString()
    val odateTimeStampString= s"${ingestionOdate} " + "00:00:00"
    val odateTimeStamp = LocalDateTime.parse(odateTimeStampString, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"))
    val prevOdateDateTime = odateTimeStamp.minusDays(1)
    val prevOdate =  prevOdateDateTime.format(DateTimeFormatter.ofPattern("yyyyMMdd"))


    val jobJsonPath = args(0).toString()
    val schemaJsonPath = args(1).toString()
    val jobName = args(2).toString()
    val oDate = args(3).toString()
    val env = args(4).toString()
    val jobRunId = args(5).toString()
    val taskRunId = args(6).toString()

    //parse the schema properties file
    log.info(s"Starting the execution for odate $oDate. Reading properties file.")
    val prop = new Properties()
    prop.load(getClass.getClassLoader.getResourceAsStream("properties/app.properties"))

    //Start a sparkSession
    val spark = getSparkSession(s"RassIpndAddapp-$jobName")

    //get the secrets from the keyvault
    val keyVaultScope = prop.getProperty("keyVaultScope")
    log.info(s"Reading the secrets from keyvault with scope $keyVaultScope")
    val clientId = getAppKeyVltSecret(keyVaultScope, prop.getProperty("clientIdName"))
    val clientSecret = getAppKeyVltSecret(keyVaultScope, prop.getProperty("clientSecretName"))
    val storageAccDetails = new String(Base64.getDecoder.decode(getAppKeyVltSecret(keyVaultScope, prop.getProperty("storageAccSecName"))))
    log.info(s"the details of the storage from AKV: $storageAccDetails")
    
    val parser = new JsonParser
    val parsedData = parser.parse(storageAccDetails).getAsJsonObject.get("dataStorageAccount")
    val account = parsedData.getAsJsonObject.get("url").getAsString
    val container = parsedData.getAsJsonObject.get("container").getAsString
    val adlsBasePath = s"${account.replace("https://", s"$container@")}${prop.getProperty("adlsBaseSuffix")}"
    log.info(s"The base path for the data in ADLS is $adlsBasePath")

    //use the url as per the environment
    var oauthUrl: String = null
    var apiUrl: String = null
    if (env.equalsIgnoreCase("prd")) {
      oauthUrl = prop.getProperty("oauthUrlName")
      apiUrl = prop.getProperty("apiUrlName")
    } else {
      oauthUrl = prop.getProperty("oauthUrlNameNonPrd")
      apiUrl = prop.getProperty("apiUrlNameNonPrd")
    }

    val httpClientCallTimeOut = prop.getProperty("httpsCallTimeoutSec")
    val rassTableName = env.toUpperCase()++"_"++prop.getProperty("rassSchema")++"."++prop.getProperty("rassTable")

    //create the final opts
    val opts = Map[String, String]("jobJsonPath" -> jobJsonPath, "schemaJsonPath" -> schemaJsonPath, "jobName" -> jobName,
      "oDate" -> oDate, "prevOdate" -> prevOdate ,"env" -> env, "jobRunId" -> jobRunId, "taskRunId" -> taskRunId, "clientId" -> clientId,
      "clientSecret" -> clientSecret, "oauthUrl" -> oauthUrl, "apiUrl" -> apiUrl, "adlsBasePath" -> adlsBasePath ,"rassTableName" -> rassTableName
      , "httpClientCallTimeOut" -> httpClientCallTimeOut) ++ prop.asScala

    // call application code
    execute(opts, spark)
  }

  /**
   * Application specific functionality
   *
   * @param props
   * @param spark
   */
  def execute(opts: Map[String, String], spark: SparkSession)

}

