package com.telstra.ipnd.services

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.slf4j.LoggerFactory

trait AzureKeyVaultService {

  /**
   * Function to retrive specific KeyVault Secret
   *
   * @param credentialScope Scope of obtaining the Secrets
   * @param key key id of the secret
   * @return secret value as string
   */
  def getAppKeyVltSecret(credentialScope: String, key: String): String = {
    val log = LoggerFactory.getLogger(getClass)
    log.info(s"Accessing the secret ${key.trim()} with scope ${credentialScope.trim()}")
    dbutils.secrets.get(credentialScope.trim(), key.trim())
  }
}