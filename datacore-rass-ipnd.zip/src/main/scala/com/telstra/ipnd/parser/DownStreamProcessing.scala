package com.telstra.ipnd.parser

import java.util.List

import scala.collection.JavaConversions.`deprecated iterableAsScalaIterable`

import org.apache.spark.sql.Column
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat
import org.apache.spark.sql.functions.rpad
import org.slf4j.LoggerFactory
import com.google.gson.JsonParser

/**
 * Class to do the processing for creating the down stream file.
 *
 * @author d941294(Kumar,Amit)
 */
class DownStreamProcessing(opts: Map[String, String]) {

  val log = LoggerFactory.getLogger(getClass)

  /**
   * Identify the mapping of unique fileIds to the filename to get the sequence number and create the outputfile name
   * mapping and return
   */
  def mapFileIdToName(fileIds: List[Row]): Map[String, String] = {

    //create the file name in the format IPNDUPRASS1.<nnnnnnn>
    fileIds.map(row => {
      s"${row.get(0)}" -> s"IPNDUPRASS1.${"%07d".format((row.get(1).toString()).toInt)}"
    }).toMap
  }

  /**
   * 4a. order the rows using the filenumber
   * 	4b. apply padding for creating the fixed-width file
   */
  def transformOutFileFormat(fileData: Dataset[Row], schemaText: String): Dataset[Row] = {

    val parser = new JsonParser
    val resultParsed = parser.parse(schemaText).getAsJsonObject.get("SourceColumns")
    val schemaArray = resultParsed.getAsJsonArray
    val concatColumns: Seq[Column] = schemaArray.map(cols => {
      val columnName = cols.getAsJsonObject.get("ColumnName").getAsString.toLowerCase()
      val maxLength = Integer.valueOf(cols.getAsJsonObject.get("MaxLength").getAsString)
      rpad(col(columnName), maxLength, " ")
    }).toSeq

    fileData.na.fill("").select(concat(concatColumns: _*).alias("concatValue"), col("filelinenumber"))
  }

  def appendHeaderTrailer(headerContent: String, trailerContent: String, transformedDataset: Dataset[Row]): Dataset[Row] = {
    val dataSeq = Seq((headerContent, 1), (trailerContent, 9999999))
    val sparkSession = transformedDataset.sparkSession
    import sparkSession.implicits._
    val headTailDf = dataSeq.toDF("concatValue", "filelinenumber")
    transformedDataset.union(headTailDf).coalesce(1).orderBy("filelinenumber").drop("filelinenumber")
  }
}