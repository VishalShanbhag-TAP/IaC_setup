package com.telstra.ipnd.parser

import scala.util.Try
import org.apache.http.HttpStatus
import org.apache.spark.sql.Column
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.RowFactory
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.catalyst.parser.LegacyTypeStringParser
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.explode
import org.apache.spark.sql.functions.from_json
import org.apache.spark.sql.functions.get_json_object
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.types.DataType
import org.apache.spark.sql.types.DataTypes
import org.slf4j.LoggerFactory
import com.telstra.ipnd.utils.Constants.apiAddressResponse
import com.telstra.ipnd.utils.Constants.serviceAddressState
import com.telstra.ipnd.utils.Constants.serviceBuildingProperty
import com.telstra.ipnd.utils.Constants.valueApiAddressResponse
import com.telstra.ipnd.utils.Constants.rasspDataAlias
import com.telstra.ipnd.utils.Constants.lookupDataAlias
import com.telstra.ipnd.utils.HttpUtils
import okhttp3.{OkHttpClient, Response}


/**
 * Class for parsing and matching the address
 *
 * @author d941294(Kumar,Amit)
 */
class AddressParsingImpl(opts: Map[String, String]) extends Serializable {

  val log = LoggerFactory.getLogger(getClass)

  /** Produce a StructType schema object from a encoded Schema */
  def getDecodedSchema(encodedSchema: String): ArrayType = {
    val schema = new String(java.util.Base64.getDecoder.decode(encodedSchema))
    Try(DataType.fromJson(schema)).getOrElse(LegacyTypeStringParser.parseString(schema)) match {
      case arrayType: ArrayType => arrayType
      case _                    => throw new RuntimeException(s"Failed parsing StructType: $schema")
    }
  }

  /**
   * Function to male the api call and append the response to each of the rows
   */
  def performApiCall(addressDataset: Dataset[Row]): Dataset[Row] = {

    val updatedSchema = addressDataset.schema.add(apiAddressResponse, DataTypes.StringType, true)
    log.debug(s"total number of partitions are ${addressDataset.rdd.getNumPartitions}")
    val mappedDataset = addressDataset.mapPartitions(partition => {
      val httpClient = HttpUtils.getOrCreateHttpClient(opts("cerPath"), opts("keyPath"), opts.getOrElse("httpsCallTimeoutSec", "15").toInt)
      var token = HttpUtils.getToken(opts("clientId"), opts("clientSecret"), opts("oauthUrl"), httpClient)
      partition.map(row => {
        //create the json request body, put the request body in below format
        val requestBody = s"""{ "data": { "searchOptions": {
            "responseFormats": ["${opts("responseFormats").split(",").mkString("\",\"")}"]},
            "searchData": {"addressLine1": "${row.mkString(",")}"}
            }}"""
        log.debug(s"the request body generated is ${row.mkString(",")}")
        var apiResString: String = null
        do {
          if (apiResString != null) {
            if (apiResString.contains("need_retry_token")) {
              token = HttpUtils.getToken(opts("clientId"), opts("clientSecret"), opts("oauthUrl"), httpClient)
            }
            val startTime = System.currentTimeMillis()
            apiResString = apiCallprocess(token, requestBody, httpClient, apiResString)
            log.debug(s"time taken to complete the API call is:${System.currentTimeMillis() - startTime} ms")
          } else {
            val startTime = System.currentTimeMillis()
            apiResString = apiCallprocess(token, requestBody, httpClient, "initial:0")
            log.debug(s"time taken to complete the API call is:${System.currentTimeMillis() - startTime} ms")
          }
        } while (apiResString.startsWith("need_retry"))
        RowFactory.create(row.getString(0), row.getString(1), apiResString)
      })
    })(RowEncoder(updatedSchema))

    mappedDataset
  }

  /**
   * This function will flatten the json response into column
   */
  def performMappingToColumn(addressLookupDatset: Dataset[Row], schema: ArrayType): Dataset[Row] = {

    //filter the rows for which the resultcount>1 or implement l0gic if need for multiple match
    log.info("Performing the column mapping from json")
    val mappedColDf = addressLookupDatset.where(get_json_object(col(apiAddressResponse), "$.data.resultCount").equalTo("1"))
      .select(col(serviceBuildingProperty), col(serviceAddressState), col(apiAddressResponse),
        explode(from_json(get_json_object(col(apiAddressResponse), "$.data.IPND"), schema,
          Map { "mode" -> "FAILFAST" })).as(valueApiAddressResponse))

    mappedColDf.select(serviceBuildingProperty, serviceAddressState, apiAddressResponse,
      s"$valueApiAddressResponse.directoryAddress.*", s"$valueApiAddressResponse.serviceAddress.*")
  }

  /**
   * Perform the join of the rassp dataset with the address lookup
   */
  def performJoin(mappedLookup: Dataset[Row], rassPDataset: Dataset[Row]): Dataset[Row] = {

    val joined = rassPDataset.alias(rasspDataAlias).join(mappedLookup.alias(lookupDataAlias), Seq(serviceBuildingProperty, serviceAddressState), "leftouter")
    joined
  }


  /**
   * filter and update the colums based on the conditions
   */
  def filterAndUpdate(joinedData: Dataset[Row], selectUpdated:Seq[Column], selectNotUpdated: Seq[Column]): Tuple2[Dataset[Row], Dataset[Row]] = {

    val notUpdated = joinedData.where(col(s"$lookupDataAlias.$serviceBuildingProperty").isNull)
      .select(selectNotUpdated: _*).withColumn("isMatched", lit("false"))

    //logic for the matched records
    val updatedData = joinedData.where(col(s"$lookupDataAlias.$serviceBuildingProperty").isNotNull).select(selectUpdated: _*).withColumn("isMatched", lit("true"))

    val updatedDataCols =  updatedData.schema.fieldNames.toSeq
    val renamedCols =  updatedDataCols.map(x=>x.replaceAll(" ", "")).toSeq
    val updatedDataColRenamedDF =  updatedData.toDF(renamedCols:_*)

    new Tuple2(updatedDataColRenamedDF, notUpdated)
  }

  def parseSelectColumns(rasspColumns: Seq[String], lookupColumns: Seq[String]): Seq[Column] = {
    val lookupColumnsEn: Map[String, String] = lookupColumns.map(row => row.replaceAll(" ", "") -> row).toMap
    val directoryAddressCol = lookupColumnsEn.filter(_._1.startsWith("directory"))
    val resultColumn: Seq[Column] = rasspColumns.map(column => {

      if (lookupColumnsEn.contains(column) && !column.equals(serviceAddressState)) {
        if (directoryAddressCol.contains(column)) {
          col(s"$rasspDataAlias.$column")
        } else {
          col(s"$lookupDataAlias.${lookupColumnsEn(column)}")
        }
      } else {
        col(column)
      }

    })
    resultColumn

  }

  def apiCallprocess(token: String, requestBody: String, httpClient: OkHttpClient, retryCount: String): String = {
    val rcount = retryCount.split("\\:")(1).toInt
    val confRetryCount = (opts.getOrElse("retryCount", "5")).toInt
    val failRsp =
      s"""{"status": 408, "code": 408, "data": {"resultCount": 0,
         |"IPND": [{"serviceAddress": {"SERVICE BUILDING TYPE": "", "SERVICE BUILDING 1ST NUMBER": "", "SERVICE BUILDING 1ST SUFFIX": "", "SERVICE BUILDING 2ND NUMBER": "",
         |"SERVICE BUILDING 2ND SUFFIX": "", "SERVICE BUILDING FLOOR TYPE": "", "SERVICE BUILDING FLOOR NR": "", "SERVICE BUILDING FLOOR NR SUFFIX": "",
         |"SERVICE BUILDING PROPERTY": "", "SERVICE BUILDING LOCATION": "", "SERVICE STREET HOUSE NR 1": "", "SERVICE STREET HOUSE NR 1 SUFFIX": "",
         |"SERVICE STREET HOUSE NR 2": "", "SERVICE STREET HOUSE NR 2 SUFFIX": "", "SERVICE ADDRESS STREET NAME 1": "", "SERVICE STREET TYPE 1": "", "SERVICE STREET SUFFIX 1": "",
         |"SERVICE STREET NAME 2": "", "SERVICE STREET TYPE 2": "ST", "SERVICE STREET SUFFIX 2": "", "SERVICE ADDRESS LOCALITY": "", "SERVICE ADDRESS STATE": "",
         |"SERVICE ADDRESS POSTCODE": ""}, "directoryAddress": {"DIRECTORY BUILDING TYPE": "", "DIRECTORY BUILDING 1ST NUMBER": "", "DIRECTORY BUILDING 1ST SUFFIX": "",
         |"DIRECTORY BUILDING 2ND NUMBER": "", "DIRECTORY BUILDING 2ND SUFFIX": "", "DIRECTORY BUILDING FLOOR TYPE": "", "DIRECTORY BUILDING FLOOR NR": "",
         |"DIRECTORY BUILDING FLOOR NR SUFFIX": "", "DIRECTORY BUILDING PROPERTY": "", "DIRECTORY BUILDING LOCATION": "", "DIRECTORY STREET HOUSE NR 1": "",
         |"DIRECTORY STREET HOUSE NR 1 SUFFIX": "", "DIRECTORY STREET HOUSE NR 2": "", "DIRECTORY STREET HOUSE NR 2 SUFFIX": "", "DIRECTORY ADDRESS STREET NAME 1": "",
         |"DIRECTORY STREET TYPE 1": "", "DIRECTORY STREET SUFFIX 1": "", "DIRECTORY STREET NAME 2": "", "DIRECTORY STREET TYPE 2": "", "DIRECTORY STREET SUFFIX 2": "",
         |"DIRECTORY ADDRESS LOCALITY": "", "DIRECTORY ADDRESS STATE": "", "DIRECTORY ADDRESS POSTCODE": ""}}]},
         |"request": {"params": $requestBody, "method": "POST", "path": "/multi-format-v2/unstructured/address-transform"}, "requestId": "", "correlationId": "", "timestamp": "", "time": ""}""".stripMargin

    if (rcount < confRetryCount) {
      var apiResponse: Response = null
      try {
        apiResponse = HttpUtils.makeHttpCall(opts("apiUrl"), token, requestBody, httpClient)
      } catch {
        case _: Throwable => {
          log.error("Caught an exception, retrying the API call")
          return s"need_retry:${rcount + 1}"
        }
      }

      val successcode = apiResponse.code()
      if (successcode == HttpStatus.SC_OK) {
        log.debug(s"the api call for $requestBody is successful")
        apiResponse.body().string()
      } else if (successcode == HttpStatus.SC_UNAUTHORIZED) {
        //token expired retry, refresh token
        log.info(s"retrying for token refresh for the request body $requestBody")
        s"need_retry_token:${rcount + 1}"
      } else if (successcode == HttpStatus.SC_INTERNAL_SERVER_ERROR || successcode == 429) {
        //internal server error need_retry OR quota limit need_retry
        log.info(s"retrying for internal server error for the request body $requestBody")
        if (rcount + 1 == confRetryCount) {
          apiResponse.body().string()
        } else {
          s"need_retry:${rcount + 1}"
        }
      } else {
        log.error(s"Unhandled successcode: $successcode")
        apiResponse.body().string()
      }
    } else {
      failRsp
    }
  }
}