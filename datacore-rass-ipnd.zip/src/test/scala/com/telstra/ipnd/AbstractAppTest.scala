package com.telstra.ipnd

import org.junit.runner.RunWith
import org.powermock.modules.junit4.PowerMockRunner
import com.telstra.ipnd.apps.RASSPAddressMatcher
import org.junit.Test
import org.powermock.core.classloader.annotations.PowerMockIgnore
import org.junit.rules.ExpectedException
import org.junit.Rule

@RunWith(classOf[PowerMockRunner])
@PowerMockIgnore(Array("org.apache.*", "akka.*", "scala.*", "org.codehaus.*", "com.univocity.*", "com.google.*",
  "javax.xml.*", "com.sun.org.*","org.slf4j.*"))
class AbstractAppTest {

  val args:Array[String] = Array("jobJsonPath","src/test/resources/Addressmatcher_Schema.json","jobName","oDate","prevOdate" ,"env","jobRunId","taskRunId")
  @Rule
  val expectedException: ExpectedException = ExpectedException.none()

  @Test
  def mainTest() {
    expectedException.expect(classOf[Exception])
    val rass = RASSPAddressMatcher.main(args)

  }

}