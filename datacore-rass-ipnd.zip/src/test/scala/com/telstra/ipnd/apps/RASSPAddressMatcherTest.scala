package com.telstra.ipnd.apps

import org.junit.runner.RunWith
import org.powermock.core.classloader.annotations.PowerMockIgnore
import org.powermock.modules.junit4.PowerMockRunner
import org.junit.Test
import org.junit.Before
import org.apache.spark.sql.SparkSession
import org.junit.Rule
import org.junit.rules.ExpectedException
import org.apache.hadoop.security.UserGroupInformation
import scala.io.Source
import java.io.PrintWriter
import org.junit.BeforeClass
import org.junit.After

@RunWith(classOf[PowerMockRunner])
@PowerMockIgnore(Array("org.apache.*", "akka.*", "scala.*", "org.codehaus.*", "com.univocity.*", "com.google.*",
  "javax.xml.*", "com.sun.org.*","org.slf4j.*"))
class RASSPAddressMatcherTest {

  val opts:Map[String,String] = Map("adlsBasePath"->"target","oDate"->"20211012",
      "schemaJsonPath"->"src/test/resources/ingestion_schema.json","env" ->"target",
      "ssu"->"retail","sourceSystem"->"rassp","enrichedDataName"-> "rass_address_enriched", "tableName" -> "rassp_data",
      "responseSchema" -> Source.fromFile("src/test/resources/schema.json").mkString,
      "addressLookupDataName" -> "rass_address_lookup", "matchFailureDataName" -> "rass_address_matchfailure",
      "cerPath"-> "","keyPath"-> "keyPath")
  var spark:SparkSession = _
  @Rule
  val expectedException: ExpectedException = ExpectedException.none()

  @Before
  def init() {

    val pwRass = new PrintWriter("src/test/resources/rasspdatafull.txt")
    pwRass.println("publicnumber,effectivestartutcdttm,effectiveendutcdttm,effectivestartmltdttm,effectiveendmltdttm,effectivestartmltdt,effectiveendmltdt,servicestatuscode,pendingflag,cancelpendingflag,customername1,customername2,longname,customertitle,findingname1,findingname2,findingtitle,servicebuildingtype,servicebuilding1stnr,servicebuilding1stsuffix,servicebuilding2ndnr,servicebuilding2ndsuffix,servicebuildingfloortype,servicebuildingfloornr,servicebuildingfloornrsuffix,servicebuildingproperty,servicebuildinglocation,servicestreethousenr1,servicestreethousenr1suffix,servicestreethousenr2,servicestreethousenr2suffix,servicestreetname1,servicestreettype1,servicestreetsuffix1,servicestreetname2,servicestreettype2,servicestreetsuffix2,serviceaddresslocality,serviceaddressstate,serviceaddresspostcode,directorybuildingtype,directorybuilding1stnr,directorybuilding1stsuffix,directorybuilding2ndnr,directorybuilding2ndsuffix,directorybuildingfloortype,directorybuildingfloornr,directorybuildingfloornrsuffix,directorybuildingproperty,directorybuildinglocation,directorystreethousenr1,directorystreethousenr1suffix,directorystreethousenr2,directorystreethousenr2suffix,directorystreetname1,directorystreettype1,directorystreetsuffix1,directorystreetname2,directorystreettype2,directorystreetsuffix2,directoryaddresslocality,directoryaddressstate,directoryaddresspostcode,listcode,usagecode,typeofservice,customercontactname1,customercontactname2,customercontactnr,carriageserviceprovidercode,dataprovidercode,transactiondate,servicestatusdate,alternateaddressflag,priorpublicnumber,fileid,filelinenumber,inserttaskid,updatetaskid,publicationstartdttm,publicationenddttm,ssutypecode,effectivestartutcdtprtnkey")
    pwRass.println("03921xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,WERRIBEE AGED CARE TRUNK                ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,240 HOPPERS LANE     WERRIBEE           ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY    ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY                   ,VIC,0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,UL,B,NULL,SAM WEBB 04050xxxxx                     ,NULL,00000000000000000000,002,TELSTR,20171005000000,20171005000000,T,NULL,95531,2,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317")
    pwRass.println("08923xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,AUST POST KELMSCOTT POST SHOP           ,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2788 ALBANY HWY      KELMSCOTT          ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY    ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY                   ,WA ,0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE            ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,N/A,0000,LE,B,NULL,ROSLYN HENDRY 08923xxxxx                ,NULL,00000000000000000000,002,TELSTR,20190521000000,20190521000000,T,NULL,95531,20962,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317")
    pwRass.println("18005xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,GROW (NT)                               ,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6 ALBION ST          HARRIS PARK        ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY    ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY                   ,NSW,0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE            ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,N/A,0000,LE,B,NULL,SHRUTHI RIJESH 07339xxxxx               ,NULL,00000000000000000000,002,TELSTR,20060523000000,20060524000000,T,NULL,95531,22871,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317")
    pwRass.close()

    spark = SparkSession.builder.master("local[*]")
    .config("spark.hadoop.fs.defaultFS", "file:///").config("hive.metastore.warehouse.dir", "target/spark-warehouse")
    .config("spark.sql.warehouse.dir", "target/spark-warehouse").getOrCreate()
    spark.sparkContext.setLogLevel("Error")

//    spark.read.option("header", "true").csv("src/test/resources/rasspdatafull.txt")
//     .write.mode("overwrite").parquet(s"target/target/SDS/standardised/retail/rassp/rassp_data")
  }
  @Test
  def executeTest() {
//    expectedException.expect(classOf[Exception])
//    RASSPAddressMatcher.execute(opts, spark)
  }

  @After
  def shutdown() {
    spark.stop()
  }
}