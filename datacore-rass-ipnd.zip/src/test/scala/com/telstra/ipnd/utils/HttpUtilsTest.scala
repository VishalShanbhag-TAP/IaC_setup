package com.telstra.ipnd.utils

import org.junit.runner.RunWith
import org.powermock.modules.junit4.PowerMockRunner
import org.junit.Test
import org.powermock.core.classloader.annotations.PowerMockIgnore

import scala.io.Source
import org.junit.Assert
import com.google.gson.JsonParser
import nl.altindag.ssl.exception.GenericKeyStoreException
import org.junit.Rule
import org.junit.rules.ExpectedException

@RunWith(classOf[PowerMockRunner])
@PowerMockIgnore(Array("org.apache.http.conn.ssl.*", "javax.net.ssl.*", "javax.crypto.*", "javax.security.auth.x500.X500Principal"))
class HttpUtilsTest {

  val apiUrl = "https://slot1.org009.t-dev.telstra.net/v3/address/unstructured/address-transform"
  val oauthUrl = "https://slot1.org009.t-dev.telstra.net/v2/oauth/token"
  //Below will be masked for checkin
  val clientId = "***"
  val clientSecret = "***"

  //please update the certificate before running in local
  val certValue = "src/test/resources/rass-ipnd_okapi_telstra_com.cer"
  val keyValue = "src/test/resources/rass-ipnd_okapi_telstra_com.key"
  val callTimeout = 15

  @Rule
  val expectedException: ExpectedException = ExpectedException.none()
@Test
  def dummy(): Unit = {
  println("This is a dummy testcase")
}

//  @Test
  def getOrCreateHttpClientTest() {
    val httpClient = HttpUtils.getOrCreateHttpClient(certValue, keyValue, callTimeout)
    Assert.assertNotNull(httpClient)
  }

  //@Test
  def getTokenTest() {

    val httpClient = HttpUtils.getOrCreateHttpClient(certValue, keyValue, callTimeout)
    Assert.assertNotNull(httpClient)
    val tokenString = HttpUtils.getToken(clientId, clientSecret, oauthUrl, httpClient)
    println("token is " + tokenString)
    //println("abc "+tokenString.headers())
    Assert.assertNotNull(tokenString)
  }

  //@Test
  def makeHttpCallTest() {
    val httpClient = HttpUtils.getOrCreateHttpClient(certValue, keyValue, callTimeout)
    Assert.assertNotNull(httpClient)
    val token = HttpUtils.getToken(clientId, clientSecret, oauthUrl, httpClient)
    Assert.assertNotNull(token)
    //val tokenString = tokenResponse.body().string()
    println(s"tokenString is $token")
    /*val parser = new JsonParser
   val token = parser.parse(tokenString).getAsJsonObject.get("access_token").getAsString*/
    val requestBody = "{\"address\" :\"200 Pacific Highway,Crows Nest\"}"
    val response = HttpUtils.makeHttpCall(apiUrl, token, requestBody, httpClient)
    println(response.body().string())
  }
}