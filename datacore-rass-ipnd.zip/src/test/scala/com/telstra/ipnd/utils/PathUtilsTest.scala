package com.telstra.ipnd.utils

import org.junit.runner.RunWith
import org.powermock.modules.junit4.PowerMockRunner
import org.junit.Test
import org.junit.Assert

@RunWith(classOf[PowerMockRunner])
class PathUtilsTest {

  val opts:Map[String,String] = Map("adlsBasePath"->"app_root/bidh/data",
      "env"->"E01","sourceSystem"->"RASS","tableName"->"rassp","ssu" -> "transient",
      "addressLookupDataName"->"rass_address_lookup","matchFailureDataName"->"rass_address_matchfailure",
      "enrichedDataName"->"rass_address_enriched","oDate"->"20211027","prevOdate"->"20211026","ssuCharacter"->"T",
      "dataSource"->"rass","ipndFilePath"->"rass_ipnd_files")
  @Test
  def ingestedPathTest() {
    val inputPath = PathUtils.ingestedPath(opts)
    Assert.assertNotNull(inputPath)
  }

  @Test
  def addressLookupDataPathTest() {
    val inputPath = PathUtils.addressLookupDataPath(opts)
    Assert.assertNotNull(inputPath)
  }

  @Test
  def enrichedDataPathTest() {
    val inputPath = PathUtils.enrichedDataPath(opts)
    Assert.assertNotNull(inputPath)
  }

  @Test
  def matchFailedDataPathTest() {
    val inputPath = PathUtils.matchFailedDataPath(opts)
    Assert.assertNotNull(inputPath)
  }

  @Test
  def ipndOutputFilePathTest() {
    val inputPath = PathUtils.ipndOutputFilePath(opts)
    Assert.assertNotNull(inputPath)
  }

  @Test
  def fileMetaDatapathTest() {
    val inputPath = PathUtils.fileMetaDatapath(opts)
    Assert.assertNotNull(inputPath)
  }

  @Test
  def databaseNameTest() {
    val inputPath = PathUtils.databaseName(opts)
    Assert.assertNotNull(inputPath)
    Assert.assertEquals("E01_bidht_SDS_rass_hist", inputPath)
  }
}