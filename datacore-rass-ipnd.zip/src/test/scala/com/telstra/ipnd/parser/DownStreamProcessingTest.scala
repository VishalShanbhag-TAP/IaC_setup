package com.telstra.ipnd.parser

import scala.io.Source

import org.apache.spark.sql.SparkSession
import org.junit.Assert
import org.junit.Test
import org.junit.runner.RunWith
import org.powermock.core.classloader.annotations.PowerMockIgnore
import org.powermock.modules.junit4.PowerMockRunner
import org.junit.Before
import java.io.PrintWriter
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row

@RunWith(classOf[PowerMockRunner])
@PowerMockIgnore(Array("org.apache.*", "akka.*", "scala.*", "org.codehaus.*", "com.univocity.*", "com.google.*",
  "javax.xml.*", "com.sun.org.*", "org.apache.http.conn.ssl.*", "javax.net.ssl.*", "javax.crypto.*", "javax.security.auth.x500.X500Principal"))
class DownStreamProcessingTest {

  val opts: Map[String, String] = Map("" -> "")
  val downStreamProcessing = new DownStreamProcessing(opts)
  var spark: SparkSession = _
  var fileData: Dataset[Row] = _
  val schemaText = Source.fromFile("src/test/resources/ingestion_schema.json").mkString

  @Before
  def init() {
    val matOtWr = new PrintWriter("src/test/resources/matcheroutput.csv")
    matOtWr.println("publicnumber|effectivestartutcdttm|effectiveendutcdttm|effectivestartmltdttm|effectiveendmltdttm|effectivestartmltdt|effectiveendmltdt|servicestatuscode|pendingflag|cancelpendingflag|customername1|customername2|longname|customertitle|findingname1|findingname2|findingtitle|servicebuildingtype|servicebuilding1stnr|servicebuilding1stsuffix|servicebuilding2ndnr|servicebuilding2ndsuffix|servicebuildingfloortype|servicebuildingfloornr|servicebuildingfloornrsuffix|servicebuildingproperty|servicebuildinglocation|servicestreethousenr1|servicestreethousenr1suffix|servicestreethousenr2|servicestreethousenr2suffix|servicestreetname1|servicestreettype1|servicestreetsuffix1|servicestreetname2|servicestreettype2|servicestreetsuffix2|serviceaddresslocality|serviceaddressstate|serviceaddresspostcode|directorybuildingtype|directorybuilding1stnr|directorybuilding1stsuffix|directorybuilding2ndnr|directorybuilding2ndsuffix|directorybuildingfloortype|directorybuildingfloornr|directorybuildingfloornrsuffix|directorybuildingproperty|directorybuildinglocation|directorystreethousenr1|directorystreethousenr1suffix|directorystreethousenr2|directorystreethousenr2suffix|directorystreetname1|directorystreettype1|directorystreetsuffix1|directorystreetname2|directorystreettype2|directorystreetsuffix2|directoryaddresslocality|directoryaddressstate|directoryaddresspostcode|listcode|usagecode|typeofservice|customercontactname1|customercontactname2|customercontactnr|carriageserviceprovidercode|dataprovidercode|transactiondate|servicestatusdate|alternateaddressflag|priorpublicnumber|fileid|filelinenumber|inserttaskid|updatetaskid|publicationstartdttm|publicationenddttm|ssutypecode|effectivestartutcdtprtnkey|isMatched|SequenceNo")
    matOtWr.println("03921xxxxx          |2021-03-17 13:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00|9999-12-31 00:00:00|C                |F          |F                |WERRIBEE AGED CARE TRUNK                ||||    |    |    |                   |   |                        |   |                        |                        |                      |                            |                       |                       |240                  |                           |                     |                           |SEE BUILDING PROPERTY    |LANE              |                    |                  |LANE              |                    |WERRIBEE              |VIC                |3030                  |    |     |         |     |         |         |       |             |        |        |      |            |      |            |   |   |     |   |   |     |       |    |       |UL      |B        ||SAM WEBB 04050xxxxx                     |   |00000000000000000000|002                        |TELSTR          |20171005000000 |20171005000000   |T                   ||95531 |2             |437200      |    |2021-03-18 14:24:36.878574000|9999-12-31 23:59:59|R          |20210317                  |true|1")
    matOtWr.println("02933xxxxx          |2021-03-17 13:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00|9999-12-31 00:00:00|C                |F          |F                |WOOLWORTHS LTD                          ||||    |    |    |                   |   |                        |   |                        |                        |                      |                            |                       |                       |400                  |                           |                     |                           |SEE BUILDING PROPERTY    |ST                |                    |                  |ST                |                    |ULTIMO                |NSW                |2007                  |    |     |         |     |         |         |       |             |        |        |      |            |      |            |   |   |     |   |   |     |       |    |       |UL      |B        ||LOCKIE 04355xxxxx                       |   |00000000000000000000|002                        |TELSTR          |20190824000000 |20190824000000   |T                   ||95531 |96869         |437200      |    |2021-03-18 14:24:36.878574000|9999-12-31 23:59:59|R          |20210317                  |true|1")
    matOtWr.println("03623xxxxx          |2021-03-17 13:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00|9999-12-31 00:00:00|C                |F          |F                |KPMG AUSTRALIAN SERVICES PTY LTD        ||||                       |    |    |  |   |       |   |       |       |     |           |FLOOR1141 COLLINS ST MELBOURNE          |      |    |          |    |          |SEE BUILDING PROPERTY    | |   | | |   |SEE BUILDING PROPERTY                   |VIC                |0000                  |    |     |         |     |         |         |       |             |                       |        |      |            |      |            |        |   |     |   |   |     |                       |    |       |UL      |B        ||WAYNE SALESRNO 04330xxxxx               |   |00000000000000000000|002                        |TELSTR          |20180724000000 |20180724000000   |T                   ||95531 |3             |437200      |    |2021-03-18 14:24:36.878574000|9999-12-31 23:59:59|R          |20210317                  |false|1")
    matOtWr.println("02424xxxxx          |2021-03-17 13:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00  |9999-12-31 23:59:59|2021-03-18 00:00:00|9999-12-31 00:00:00|C                |F          |F                |STATE EMERGENCY SERVICE NSW             ||||                       |    |    |  |   |       |   |       |       |     |           |93-99 BURELLI ST     WOLLONGONG         |      |    |          |    |          |SEE BUILDING PROPERTY    | |   | | |   |SEE BUILDING PROPERTY                   |NSW                |0000                  |    |     |         |     |         |         |       |             |                       |        |      |            |      |            |        |   |     |   |   |     |                       |    |       |UL      |B        ||JENNY YOU 02986xxxxx                    |   |00000000000000000000|002                        |TELSTR          |20181025000000 |20181025000000   |T                   ||95531 |4             |437200      |    |2021-03-18 14:24:36.878574000|9999-12-31 23:59:59|R          |20210317                  |false|1")
    matOtWr.close()
    spark = SparkSession.builder.master("local[*]")
    .config("spark.hadoop.fs.defaultFS", "file:///").config("hive.metastore.warehouse.dir", "target/spark-warehouse")
    .config("spark.sql.warehouse.dir", "target/spark-warehouse").getOrCreate()
    spark.sparkContext.setLogLevel("Error")

    fileData = spark.read.option("header", "true").option("delimiter", "|").csv("src/test/resources/matcheroutput.csv")
  }

  @Test
  def transformOutFileFormatTest() {
    val output = downStreamProcessing.transformOutFileFormat(fileData, schemaText)
    output.persist()
    //output.show(false)
    Assert.assertNotNull(output)
    Assert.assertEquals(4, output.count())
  }

  @Test
  def appendHeaderTrailerTest() {
    val transformedDataset = downStreamProcessing.transformOutFileFormat(fileData, schemaText)
    val finalDataset = downStreamProcessing.appendHeaderTrailer("headerContent", "trailerContent", transformedDataset)
    finalDataset.persist()
    //finalDataset.show(false)
    Assert.assertNotNull(finalDataset)
    Assert.assertEquals(6, finalDataset.count())
  }

  @Test
  def mapFileIdToNameTest() {
    val uniqueFileIds = fileData.select("fileId","SequenceNo").distinct().collectAsList()
    val result = downStreamProcessing.mapFileIdToName(uniqueFileIds)
    Assert.assertNotNull(result)
    Assert.assertEquals(1, result.size)
    Assert.assertEquals("IPNDUPRASS1.0000001", result("95531 "))
  }

}