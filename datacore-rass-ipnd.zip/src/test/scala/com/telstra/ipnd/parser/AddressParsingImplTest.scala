package com.telstra.ipnd.parser

import scala.collection.JavaConversions.`deprecated iterableAsScalaIterable`
import scala.io.Source

import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.storage.StorageLevel
import org.junit.Assert
import org.junit.Test
import org.junit.runner.RunWith
import org.powermock.core.classloader.annotations.PowerMockIgnore

import com.google.gson.JsonParser
import com.telstra.ipnd.utils.Constants._
import org.powermock.modules.junit4.PowerMockRunner
import org.junit.Before
import java.io.PrintWriter
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.types.ArrayType
import org.junit.After

/**
 * Test class of AddressParsingImpl class
 *
 * @author d941294(Kumar,Amit)
 */
@RunWith(classOf[PowerMockRunner])
@PowerMockIgnore(Array("org.apache.*", "akka.*", "scala.*", "org.codehaus.*", "com.univocity.*", "com.google.*",
  "javax.xml.*", "com.sun.org.*", "org.apache.http.conn.ssl.*", "javax.net.ssl.*", "javax.crypto.*", "javax.security.auth.x500.X500Principal"))
class AddressParsingImplTest extends Serializable {

  //val apiUrl = "https://slot1.org009.t-dev.telstra.net/v3/address/unstrcutured"
  val apiUrl = "https://slot1.org009.t-dev.telstra.net/v3/address/unstructured/address-transform"
  val oauthUrl = "https://slot1.org009.t-dev.telstra.net/v2/oauth/token"
  //Below will be masked for checkin
  val clientId = "***"
  val clientSecret = "***"

  //plaease update the certificate before running in local to not get the exception
  val certValue = "src/test/resources/rass-ipnd_okapi_telstra_com.cer"
  val keyValue = "src/test/resources/rass-ipnd_okapi_telstra_com.key"
  val responseFormats = "structured,unstructuredAUPost,IPND"

  val opts: Map[String, String] = Map("clientId" -> clientId, "clientSecret" -> clientSecret, "apiUrl" -> apiUrl, "oauthUrl" -> oauthUrl,
    "cerPath" -> certValue, "keyPath" -> keyValue, "responseFormats" -> responseFormats)
  val addressParsing = new AddressParsingImpl(opts)
  var spark:SparkSession = _
  var addressLookupDatset: Dataset[Row] = _
  var schema:ArrayType = _
  var rassPDataset: Dataset[Row] = _
  var distinctAdrress:Dataset[Row] = _
  /*val spark = SparkSession.builder.master("local[*]")
    .config("spark.hadoop.fs.defaultFS", "file:///").config("hive.metastore.warehouse.dir", "target/spark-warehouse")
    .config("spark.sql.warehouse.dir", "target/spark-warehouse").getOrCreate()

  val addressLookupDatset = spark.read.option("header", "true").option("delimiter", "|").csv("src/test/resources/apicalldata.csv")
  val schema = addressParsing.getDecodedSchema(Source.fromFile("src/test/resources/schema.json").mkString)
  val rassPDataset = spark.read.option("header", "true").csv("src/test/resources/rasspdata.csv")
  rassPDataset.show(false)
  val distinctAdrress = rassPDataset.select(serviceBuildingProperty, serviceAddressState).distinct().coalesce(2)
  distinctAdrress.persist(StorageLevel.MEMORY_AND_DISK)*/

  //====================================================================
  //read the delimited file directly for testing
  //@Test
  def endToendTest() {
    val parser = new JsonParser
    val schemaText = Source.fromFile("src/test/resources/ingestion_schema.json").mkString

    val resultParsed = parser.parse(schemaText).getAsJsonObject.get("SourceColumns")
    val schemaArray = resultParsed.getAsJsonArray
    val res: Map[String, Tuple2[Integer, Integer]] = schemaArray.map(testcol => {
      val columnName = testcol.getAsJsonObject.get("ColumnName").getAsString
      val start = Integer.valueOf(testcol.getAsJsonObject.get("Offset").getAsJsonArray.get(0).getAsString)
      val end = Integer.valueOf(testcol.getAsJsonObject.get("Offset").getAsJsonArray.get(1).getAsString)
      (columnName, new Tuple2(start, end))
    }).toMap

    //schema
    val struct = res.map(ele => {
      StructField(ele._1, DataTypes.StringType, true)
    }).toSeq

    val schemaFullFile = StructType(struct)
    val data = spark.read.textFile("src/test/resources/Upload_daily.dat")
    val converted = data.map(row => {
      val mappedString = res.map(ele => {
        row.substring((ele._2._1) - 1, (ele._2._2))
      }).toArray
      Row.fromSeq(mappedString)
    })(RowEncoder(schemaFullFile))

    converted.show(false)
    val fullFileDistinct = converted.select(serviceBuildingProperty, serviceAddressState).distinct().coalesce(2)
    fullFileDistinct.persist()

    val lookedDataset = addressParsing.performApiCall(fullFileDistinct)
    val mappedResult = addressParsing.performMappingToColumn(lookedDataset, schema)
    val joinedData = addressParsing.performJoin(mappedResult, converted)
    val ulSchema = addressParsing.parseSelectColumns(converted.schema.fieldNames.toSeq, mappedResult.schema.fieldNames.toSeq)
    //val nonUlSchema = addressParsing.parseSelectColumns(converted.schema.fieldNames.toSeq, mappedResult.schema.fieldNames.toSeq)
    val result = addressParsing.filterAndUpdate(joinedData, ulSchema, converted.schema.fieldNames.toSeq.map(field => col(s"left.$field")))
    val updatedDatset = result._1
    val notUpdatedDatset = result._2
    updatedDatset.show(false)
    notUpdatedDatset.show(false)
  }

  //============================================
  @Before
  def init() {
    val pwRass = new PrintWriter("src/test/resources/rasspdata.csv")
    pwRass.println("publicnumber,effectivestartutcdttm,effectiveendutcdttm,effectivestartmltdttm,effectiveendmltdttm,effectivestartmltdt,effectiveendmltdt,servicestatuscode,pendingflag,cancelpendingflag,customername1,customername2,longname,customertitle,findingname1,findingname2,findingtitle,servicebuildingtype,servicebuilding1stnr,servicebuilding1stsuffix,servicebuilding2ndnr,servicebuilding2ndsuffix,servicebuildingfloortype,servicebuildingfloornr,servicebuildingfloornrsuffix,servicebuildingproperty,servicebuildinglocation,servicestreethousenr1,servicestreethousenr1suffix,servicestreethousenr2,servicestreethousenr2suffix,servicestreetname1,servicestreettype1,servicestreetsuffix1,servicestreetname2,servicestreettype2,servicestreetsuffix2,serviceaddresslocality,serviceaddressstate,serviceaddresspostcode,directorybuildingtype,directorybuilding1stnr,directorybuilding1stsuffix,directorybuilding2ndnr,directorybuilding2ndsuffix,directorybuildingfloortype,directorybuildingfloornr,directorybuildingfloornrsuffix,directorybuildingproperty,directorybuildinglocation,directorystreethousenr1,directorystreethousenr1suffix,directorystreethousenr2,directorystreethousenr2suffix,directorystreetname1,directorystreettype1,directorystreetsuffix1,directorystreetname2,directorystreettype2,directorystreetsuffix2,directoryaddresslocality,directoryaddressstate,directoryaddresspostcode,listcode,usagecode,typeofservice,customercontactname1,customercontactname2,customercontactnr,carriageserviceprovidercode,dataprovidercode,transactiondate,servicestatusdate,alternateaddressflag,priorpublicnumber,fileid,filelinenumber,inserttaskid,updatetaskid,publicationstartdttm,publicationenddttm,ssutypecode,effectivestartutcdtprtnkey")
    pwRass.println("03921xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,WERRIBEE AGED CARE TRUNK                ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,240 HOPPERS LANE     WERRIBEE           ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY    ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY                   ,VIC,0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,UL,B,NULL,SAM WEBB 04050xxxxx                     ,NULL,00000000000000000000,002,TELSTR,20171005000000,20171005000000,T,NULL,95531,2,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317")
    pwRass.println("08923xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,AUST POST KELMSCOTT POST SHOP           ,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2788 ALBANY HWY      KELMSCOTT          ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY    ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY                   ,WA ,0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE            ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,N/A,0000,LE,B,NULL,ROSLYN HENDRY 08923xxxxx                ,NULL,00000000000000000000,002,TELSTR,20190521000000,20190521000000,T,NULL,95531,20962,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317")
    pwRass.println("18005xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,GROW (NT)                               ,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6 ALBION ST          HARRIS PARK        ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY    ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY                   ,NSW,0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE            ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,N/A,0000,LE,B,NULL,SHRUTHI RIJESH 07339xxxxx               ,NULL,00000000000000000000,002,TELSTR,20060523000000,20060524000000,T,NULL,95531,22871,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317")
    pwRass.close()
    val pwApiRes = new PrintWriter("src/test/resources/apicalldata.csv")
    pwApiRes.println("servicebuildingproperty|serviceaddressstate|apiaddressresponse")
    pwApiRes.println("240 HOPPERS LANE     WERRIBEE           |VIC|{\"status\":200,\"code\":200,\"data\":{\"resultCount\":1,\"structured\":[{\"addressSummaryType\":\"PropertyAddressSummary\",\"addressId\":\"161127528\",\"addressType\":\"Property with Number\",\"confirmed\":true,\"reqaddformatout\":\"structured\",\"numSubaddresses\":0,\"planNumber\":\"PS712326\",\"parcelNumber\":\"1\",\"parcelType\":\"Lot\",\"parcelDescriptor1Prefix\":\"F\",\"condorCode\":\"WERBEE\",\"postcode\":\"3030\",\"state\":\"VIC\",\"localityName\":\"WERRIBEE\",\"propertyNumberFrom\":240,\"propertyNumberTo\":\"\",\"streetName\":\"HOPPERS\",\"streetType\":\"LANE\",\"serviceLocation\":{\"latitude\":\"-37:53:14.8\",\"longitude\":\"144:42:10.5\",\"facsRealm\":\"39\",\"exchangeServiceArea\":\"WERE\"}}],\"unstructuredAUPost\":[{\"addressSummaryType\":\"FormattedAddressSummary\",\"addressId\":\"161127528\",\"addressType\":\"Property with Number\",\"reqaddformatout\":\"unstructuredAUPost\",\"confirmed\":true,\"postcode\":\"3030\",\"state\":\"VIC\",\"localityName\":\"WERRIBEE\",\"addressline1\":\"240 HOPPERS LANE,\",\"planNumber\":\"PS712326\",\"parcelNumber\":\"1\",\"parcelType\":\"Lot\",\"parcelDescriptor1Prefix\":\"F\",\"condorCode\":\"WERBEE\",\"serviceLocation\":{\"latitude\":\"-37:53:14.8\",\"longitude\":\"144:42:10.5\"}}],\"IPND\":[{\"serviceAddress\":{\"SERVICE BUILDING TYPE\":\"\",\"SERVICE BUILDING 1ST NUMBER\":\"\",\"SERVICE BUILDING 1ST SUFFIX\":\"\",\"SERVICE BUILDING 2ND NUMBER\":\"\",\"SERVICE BUILDING 2ND SUFFIX\":\"\",\"SERVICE BUILDING FLOOR TYPE\":\"\",\"SERVICE BUILDING FLOOR NR\":\"\",\"SERVICE BUILDING FLOOR NR SUFFIX\":\"\",\"SERVICE BUILDING PROPERTY\":\"\",\"SERVICE BUILDING LOCATION\":\"\",\"SERVICE STREET HOUSE NR 1\":\"240\",\"SERVICE STREET HOUSE NR 2\":\"\",\"SERVICE STREET HOUSE NR 1 SUFFIX\":\"\",\"SERVICE STREET HOUSE NR 2 SUFFIX\":\"\",\"SERVICE ADDRESS STREET NAME 1\":\"HOPPERS\",\"SERVICE STREET TYPE 1\":\"LANE\",\"SERVICE STREET SUFFIX 1\":\"\",\"SERVICE STREET NAME 2\":\"\",\"SERVICE STREET TYPE 2\":\"LANE\",\"SERVICE STREET SUFFIX 2\":\"\",\"SERVICE ADDRESS LOCALITY\":\"WERRIBEE\",\"SERVICE ADDRESS STATE\":\"VIC\",\"SERVICE ADDRESS POSTCODE\":\"3030\"},\"directoryAddress\":{\"DIRECTORY BUILDING TYPE\":\"\",\"DIRECTORY BUILDING 1ST NUMBER\":\"\",\"DIRECTORY BUILDING 1ST SUFFIX\":\"\",\"DIRECTORY BUILDING 2ND NUMBER\":\"\",\"DIRECTORY BUILDING 2ND SUFFIX\":\"\",\"DIRECTORY BUILDING FLOOR TYPE\":\"\",\"DIRECTORY BUILDING FLOOR NR\":\"\",\"DIRECTORY BUILDING FLOOR NR SUFFIX\":\"\",\"DIRECTORY BUILDING PROPERTY\":\"\",\"DIRECTORY BUILDING LOCATION\":\"\",\"DIRECTORY STREET HOUSE NR 1\":\"240\",\"DIRECTORY STREET HOUSE NR 2\":\"\",\"DIRECTORY STREET HOUSE NR 1 SUFFIX\":\"\",\"DIRECTORY STREET HOUSE NR 2 SUFFIX\":\"\",\"DIRECTORY ADDRESS STREET NAME 1\":\"HOPPERS\",\"DIRECTORY STREET TYPE 1\":\"LANE\",\"DIRECTORY STREET SUFFIX 1\":\"\",\"DIRECTORY STREET NAME 2\":\"\",\"DIRECTORY STREET TYPE 2\":\"LANE\",\"DIRECTORY STREET SUFFIX 2\":\"\",\"DIRECTORY ADDRESS LOCALITY\":\"WERRIBEE\",\"DIRECTORY ADDRESS STATE\":\"VIC\",\"DIRECTORY ADDRESS POSTCODE\":\"3030\"}}]},\"request\":{\"data\":{\"searchOptions\":{\"responseFormats\":[\"structured\",\"unstructuredAUPost\",\"IPND\"]},\"searchData\":{\"addressLine1\":\"240 HOPPERS LANE     WERRIBEE           ,VIC\"}},\"correlationId\":\"7064c6b7-4ed2-4dd9-121b-ff5b59243c59\"},\"requestId\":\"df0211a2-0228-40c6-b9ce-1d7537d6bd9b\",\"correlationId\":\"7064c6b7-4ed2-4dd9-121b-ff5b59243c59\",\"time\":\"2021-08-20T12:57:41+10:00\"}")
    pwApiRes.println("2788 ALBANY HWY      KELMSCOTT          |WA |{\"status\":200,\"code\":200,\"data\":{\"resultCount\":1,\"structured\":[{\"addressSummaryType\":\"PropertyAddressSummary\",\"addressId\":\"420452494\",\"addressType\":\"Property with Number\",\"confirmed\":false,\"reqaddformatout\":\"structured\",\"numSubaddresses\":22,\"condorCode\":\"KLMSCT\",\"subaddresses\":{\"Level1\":[{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"KIOSK\",\"ID\":420352933,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"7\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":421339956,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"1\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":424539899,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"10\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":422539661,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"11\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":420752551,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"12\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":420352924,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"13\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":420852739,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"14\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":420953014,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"15\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":425339978,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"16\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":421140178,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"17\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":422040083,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"2\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":422940165,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"21\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":425839913,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"22\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":423540184,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"25\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":423239934,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"3\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":421439769,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"30\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":420552494,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"4\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":422640119,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"5\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":420253047,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"6\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":424439693,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"8\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"SHOP\",\"ID\":421239920,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"9\"},{\"AddressType\":\"Complex - Flat/Unit\",\"SubAddressType\":\"UNIT\",\"ID\":419782667,\"parentID\":420452494,\"Confirmed\":false,\"from\":\"23\"}]},\"postcode\":\"6111\",\"state\":\"WA\",\"localityName\":\"KELMSCOTT\",\"propertyNumberFrom\":2788,\"propertyNumberTo\":\"\",\"streetName\":\"ALBANY\",\"streetType\":\"HIGHWAY\",\"serviceLocation\":{\"latitude\":\"-32:06:53.3\",\"longitude\":\"116:00:54.3\",\"facsRealm\":\"56\",\"exchangeServiceArea\":\"KELM\"}}],\"unstructuredAUPost\":[{\"addressSummaryType\":\"FormattedAddressSummary\",\"addressId\":\"420452494\",\"addressType\":\"Property with Number\",\"reqaddformatout\":\"unstructuredAUPost\",\"confirmed\":false,\"postcode\":\"6111\",\"state\":\"WA\",\"localityName\":\"KELMSCOTT\",\"addressline1\":\"2788 ALBANY HWY,\",\"condorCode\":\"KLMSCT\",\"serviceLocation\":{\"latitude\":\"-32:06:53.3\",\"longitude\":\"116:00:54.3\"}}],\"IPND\":[{\"serviceAddress\":{\"SERVICE BUILDING TYPE\":\"\",\"SERVICE BUILDING 1ST NUMBER\":\"\",\"SERVICE BUILDING 1ST SUFFIX\":\"\",\"SERVICE BUILDING 2ND NUMBER\":\"\",\"SERVICE BUILDING 2ND SUFFIX\":\"\",\"SERVICE BUILDING FLOOR TYPE\":\"\",\"SERVICE BUILDING FLOOR NR\":\"\",\"SERVICE BUILDING FLOOR NR SUFFIX\":\"\",\"SERVICE BUILDING PROPERTY\":\"\",\"SERVICE BUILDING LOCATION\":\"\",\"SERVICE STREET HOUSE NR 1\":\"2788\",\"SERVICE STREET HOUSE NR 2\":\"\",\"SERVICE STREET HOUSE NR 1 SUFFIX\":\"\",\"SERVICE STREET HOUSE NR 2 SUFFIX\":\"\",\"SERVICE ADDRESS STREET NAME 1\":\"ALBANY\",\"SERVICE STREET TYPE 1\":\"HWY\",\"SERVICE STREET SUFFIX 1\":\"\",\"SERVICE STREET NAME 2\":\"\",\"SERVICE STREET TYPE 2\":\"HWY\",\"SERVICE STREET SUFFIX 2\":\"\",\"SERVICE ADDRESS LOCALITY\":\"KELMSCOTT\",\"SERVICE ADDRESS STATE\":\"WA\",\"SERVICE ADDRESS POSTCODE\":\"6111\"},\"directoryAddress\":{\"DIRECTORY BUILDING TYPE\":\"\",\"DIRECTORY BUILDING 1ST NUMBER\":\"\",\"DIRECTORY BUILDING 1ST SUFFIX\":\"\",\"DIRECTORY BUILDING 2ND NUMBER\":\"\",\"DIRECTORY BUILDING 2ND SUFFIX\":\"\",\"DIRECTORY BUILDING FLOOR TYPE\":\"\",\"DIRECTORY BUILDING FLOOR NR\":\"\",\"DIRECTORY BUILDING FLOOR NR SUFFIX\":\"\",\"DIRECTORY BUILDING PROPERTY\":\"\",\"DIRECTORY BUILDING LOCATION\":\"\",\"DIRECTORY STREET HOUSE NR 1\":\"2788\",\"DIRECTORY STREET HOUSE NR 2\":\"\",\"DIRECTORY STREET HOUSE NR 1 SUFFIX\":\"\",\"DIRECTORY STREET HOUSE NR 2 SUFFIX\":\"\",\"DIRECTORY ADDRESS STREET NAME 1\":\"ALBANY\",\"DIRECTORY STREET TYPE 1\":\"HWY\",\"DIRECTORY STREET SUFFIX 1\":\"\",\"DIRECTORY STREET NAME 2\":\"\",\"DIRECTORY STREET TYPE 2\":\"HWY\",\"DIRECTORY STREET SUFFIX 2\":\"\",\"DIRECTORY ADDRESS LOCALITY\":\"KELMSCOTT\",\"DIRECTORY ADDRESS STATE\":\"WA\",\"DIRECTORY ADDRESS POSTCODE\":\"6111\"}}]},\"request\":{\"data\":{\"searchOptions\":{\"responseFormats\":[\"structured\",\"unstructuredAUPost\",\"IPND\"]},\"searchData\":{\"addressLine1\":\"2788 ALBANY HWY      KELMSCOTT          ,WA \"}},\"correlationId\":\"b79a4c23-26ad-46c5-2dcb-479f1714bbf5\"},\"requestId\":\"3de2773f-bf10-47d5-bc3c-c29ab0e14ca9\",\"correlationId\":\"b79a4c23-26ad-46c5-2dcb-479f1714bbf5\",\"time\":\"2021-08-24T15:51:18+10:00\"}")
    pwApiRes.close()

    spark = SparkSession.builder.master("local[*]")
    .config("spark.hadoop.fs.defaultFS", "file:///").config("hive.metastore.warehouse.dir", "target/spark-warehouse")
    .config("spark.sql.warehouse.dir", "target/spark-warehouse").getOrCreate()
    spark.sparkContext.setLogLevel("Error")

   addressLookupDatset = spark.read.option("header", "true").option("delimiter", "|").csv("src/test/resources/apicalldata.csv")
   schema = addressParsing.getDecodedSchema(Source.fromFile("src/test/resources/schema.json").mkString)
   rassPDataset = spark.read.option("header", "true").csv("src/test/resources/rasspdata.csv")
  distinctAdrress = rassPDataset.select(serviceBuildingProperty, serviceAddressState).distinct().coalesce(2)
  distinctAdrress.persist(StorageLevel.MEMORY_AND_DISK)
  }

//  @Test
  def performApiCallTest() {
    val result = addressParsing.performApiCall(distinctAdrress)
    result.persist(StorageLevel.MEMORY_AND_DISK)
    Assert.assertNotNull(result)
    Assert.assertEquals(13, result.count())
    //result.show
  }

  @Test
  def performMappingToColumnTest() {
    //val schema = addressParsing.getDecodedSchema(Source.fromFile("src/test/resources/schema.json").mkString)
    val mappedResult = addressParsing.performMappingToColumn(addressLookupDatset, schema)
    Assert.assertNotNull(mappedResult)
    //mappedResult.show()
    Assert.assertEquals(2, mappedResult.count())
  }

  @Test
  def performJoinTest() {

    val mappedResult = addressParsing.performMappingToColumn(addressLookupDatset, schema)
    val result = addressParsing.performJoin(mappedResult, rassPDataset)
    Assert.assertNotNull(result)
    Assert.assertEquals(3, result.count())
  }

//  @Test
  def filterAndUpdateTest() {
    val mappedResult = addressParsing.performMappingToColumn(addressLookupDatset, schema)
    val joinedData = addressParsing.performJoin(mappedResult, rassPDataset)
    val ulSchema = addressParsing.parseSelectColumns(rassPDataset.schema.fieldNames.toSeq, mappedResult.schema.fieldNames.toSeq)
    //val nonUlSchema = addressParsing.parseSelectColumns(rassPDataset.schema.fieldNames.toSeq, mappedResult.schema.fieldNames.toSeq)
    val result = addressParsing.filterAndUpdate(joinedData, ulSchema, rassPDataset.schema.fieldNames.toSeq.map(field => col(s"left.$field")))
    val updatedDatset = result._1
    val notUpdatedDatset = result._2
    updatedDatset.persist()
    notUpdatedDatset.persist()
    Assert.assertNotNull(updatedDatset)
    Assert.assertNotNull(notUpdatedDatset)
    Assert.assertEquals(2, updatedDatset.count())
    Assert.assertEquals(1, notUpdatedDatset.count())
    //write the test for updated and not updated records
    val nonUL = updatedDatset.where(col("publicnumber").startsWith("08923xxxxx")).collectAsList()
    Assert.assertEquals(1, nonUL.size())
    val nonULExpected = "[08923xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,AUST POST KELMSCOTT POST SHOP           ,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,,NULL,,NULL,,,,,,,2788,,,,SEE BUILDING PROPERTY    ,HWY,,,HWY,,KELMSCOTT,WA ,6111,,NULL,,NULL,,,,,,,2788,,,,NOT AVAILABLE            ,HWY,,,HWY,,KELMSCOTT,WA,6111,LE,B,NULL,ROSLYN HENDRY 08923xxxxx                ,NULL,00000000000000000000,002,TELSTR,20190521000000,20190521000000,T,NULL,95531,20962,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317,true]"
    Assert.assertEquals(nonULExpected, nonUL.toArray().mkString(","))
    val uLData = updatedDatset.where(col("publicnumber").startsWith("03921xxxxx")).collectAsList()
    Assert.assertEquals(1, uLData.size())
    val uLDataExpected = "[03921xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,WERRIBEE AGED CARE TRUNK                ,NULL,NULL,NULL,NULL,NULL,NULL,,NULL,,NULL,,,,,,,240,,,,SEE BUILDING PROPERTY    ,LANE,,,LANE,,WERRIBEE,VIC,3030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,UL,B,NULL,SAM WEBB 04050xxxxx                     ,NULL,00000000000000000000,002,TELSTR,20171005000000,20171005000000,T,NULL,95531,2,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317,true]"
    Assert.assertEquals(uLDataExpected, uLData.toArray().mkString(","))
    val noUpdate = notUpdatedDatset.where(col(serviceBuildingProperty).equalTo("6 ALBION ST          HARRIS PARK        ")).collectAsList()
    Assert.assertEquals(1, noUpdate.size())
    val noUpdateExp = "[18005xxxxx          ,2021-03-17 13:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 23:59:59,2021-03-18 00:00:00,9999-12-31 00:00:00,C,F,F,GROW (NT)                               ,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6 ALBION ST          HARRIS PARK        ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY    ,NULL,NULL,NULL,NULL,NULL,SEE BUILDING PROPERTY                   ,NSW,0000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE            ,NULL,NULL,NULL,NULL,NULL,NOT AVAILABLE                           ,N/A,0000,LE,B,NULL,SHRUTHI RIJESH 07339xxxxx               ,NULL,00000000000000000000,002,TELSTR,20060523000000,20060524000000,T,NULL,95531,22871,437200,NULL,2021-03-18 14:24:36.878574000,9999-12-31 23:59:59,R,20210317,false]"
    Assert.assertEquals(noUpdateExp, noUpdate.toArray().mkString(","))
  }

  @After
  def cleanUp() {
    spark.stop()
  }

}