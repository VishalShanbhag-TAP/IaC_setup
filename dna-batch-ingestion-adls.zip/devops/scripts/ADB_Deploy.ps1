<#
.SYNOPSIS
Deploys all objects from Git Repo into Azure Databricks Workspace (service).
.DESCRIPTION
Deploys all objects from Git Repo into Azure Databricks Workspace (service).
.PARAMETER Region
Databricks Region.
.PARAMETER BearerToken
Bearer token to be used to auth against ADB Service.
.PARAMETER LocalPath
Folder Location in Artefact Staging Directory.
.PARAMETER FilePattern
FilePattern to search
.PARAMETER DBFSPath
DBFSPath to deploy.
.EXAMPLE
$ResourceGroupName = 'tcp0000-ae-rg-dvdpnp'
$DataFactoryName = "adf_nprd1"
$ADFRootFolder = "/agent/deploy/dna-batch-ingestion-adf/"
$Environment = "nonprod"

.\devops\scripts\ADB_Deploy.ps1 -BearerToken dapiecb0f3c2f037b2cb2bf99644363b2f24 -Region australiaeast -LocalPath '.\target\' -FilePattern 'dna_batch_ingestion_adls.jar' -DBFSPath '/FileStore/jars/'

#>
param
(
    [parameter(Mandatory = $true)] [String] $Region,
    [parameter(Mandatory = $true)] [String] $BearerToken,
    [parameter(Mandatory = $true)] [String] $LocalPath,
    [parameter(Mandatory = $true)] [String] $FilePattern,
    [parameter(Mandatory = $true)] [String] $DBFSPath    
)
$script:StartTime = Get-Date

Write-Host "======================================================================================";
Write-Host "### ADB Deployment Script                                              Version 0.1 ###";
Write-Host "======================================================================================";
Write-Host "Invoking ADB Deployment activity with following parameters:";
Write-Host "======================================================================================";
Write-Host "Region:             $Region";
Write-Host "BearerToken:        $BearerToken";
Write-Host "LocalPath:          $LocalPath";
Write-Host "FilePattern:        $FilePattern";
Write-Host "DBFSPath:           $DBFSPath";
Write-Host "======================================================================================";

Write-Host "Loading functions...";
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

Function Add-DatabricksChunk([string]$part, $handle){
    $Body = @{"data"=$part}
    $Body['handle'] = $handle
    $BodyText = $Body | ConvertTo-Json -Depth 10

    $Headers = GetHeaders $null
    Invoke-RestMethod -Uri "$DatabricksURI/api/2.0/dbfs/add-block" -Body $BodyText -Method 'POST' -Headers $Headers
    Return
}


Function Add-DatabricksDBFSFile {  
    [cmdletbinding()]
    param (
        [parameter(Mandatory = $false)][string]$BearerToken,    
        [parameter(Mandatory = $false)][string]$Region,
        [parameter(Mandatory = $true)][string]$LocalRootFolder,
        [parameter(Mandatory = $true)][string]$FilePattern,
        [parameter(Mandatory = $true)][string]$TargetLocation
    ) 

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    # Use Databricks Bearer Token Method
    $DatabricksAccessToken = "Bearer $BearerToken"
    $Headers = @{"Authorization"="$DatabricksAccessToken"}
    $DatabricksURI = "https://$Region.azuredatabricks.net"   
    $size = 1200000
    $LocalRootFolder = Resolve-Path $LocalRootFolder
    Write-Verbose $LocalRootFolder
    Push-Location
    Set-Location $LocalRootFolder

    $AllFiles = Get-ChildItem -Filter $FilePattern -Recurse -File

    Foreach ($f in $AllFiles){
        $f = Resolve-Path $f.FullName

        $BinaryContents = [System.IO.File]::ReadAllBytes($f)
        $EncodedContents = [System.Convert]::ToBase64String($BinaryContents)

        Write-Verbose "TargetLocation: $TargetLocation"
        $FileTarget = (Join-Path $TargetLocation (Resolve-Path $f -Relative))
        
        $FileTarget = $FileTarget.Replace("\","/")
        $FileTarget = $FileTarget.Replace("/./","/")

        Write-Verbose "FileTarget: $FileTarget"

        if ($EncodedContents.Length -gt $size) {
            $Body = @{'path' = $FileTarget}
            $Body['overwrite'] = "true"

            $BodyText = $Body | ConvertTo-Json -Depth 10
            $handle = Invoke-RestMethod -Uri "$DatabricksURI/api/2.0/dbfs/create" -Body $BodyText -Method 'POST' -Headers $Headers

            $i = 0
            While ($i -le ($EncodedContents.length-$size))
            {
                $part = $EncodedContents.Substring($i,$size)
                Add-DatabricksChunk -part $part -handle $handle.handle
                $i += $size
                Write-Verbose "Uploaded $i bytes"
            }
            $part = $EncodedContents.Substring($i)
            Add-DatabricksChunk -part $part -handle $handle.handle   

            $Body = @{"handle"= $handle.handle}
            $BodyText = $Body | ConvertTo-Json -Depth 10
            Invoke-RestMethod -Uri "$DatabricksURI/api/2.0/dbfs/close" -Body $BodyText -Method 'POST' -Headers $Headers
        }
        else
        {
            $Body = @{"contents"=$EncodedContents}
            $Body['path'] = $FileTarget
            $Body['overwrite'] = "true"    
            $BodyText = $Body | ConvertTo-Json -Depth 10
            Write-Verbose "Pushing file $($f.FullName) to $FileTarget"
            Invoke-RestMethod -Uri "$DatabricksURI/api/2.0/dbfs/put" -Body $BodyText -Method 'POST' -Headers $Headers
        }
    }
    Pop-Location
}

#Import-Module -Name "$PSScriptRoot\azure.databricks.cicd.tools\azure.databricks.cicd.tools.psm1"

Write-Host "Loadied functions.";

Write-Host "Deploying to Azure Databricks..."
Add-DatabricksDBFSFile -BearerToken $BearerToken -Region $Region -LocalRootFolder $LocalPath -FilePattern $FilePattern -TargetLocation $DBFSPath -Verbose

$elapsedTime = new-timespan $script:StartTime $(get-date)
Write-Host "==============================================================================";
Write-Host "### ADB Deployment successful                                              ###";
Write-Host ([string]::Format("Elapsed time: {0:d1}:{1:d2}:{2:d2}.{3:d3}", $elapsedTime.Hours, $elapsedTime.Minutes, $elapsedTime.Seconds, $elapsedTime.Milliseconds))
Write-Host "==============================================================================";