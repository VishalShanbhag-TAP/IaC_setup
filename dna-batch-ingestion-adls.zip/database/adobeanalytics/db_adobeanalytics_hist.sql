CREATE DATABASE IF NOT EXISTS ${var:ENV}_bidhr_sds_adobeanalytics_hist
;
