CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_adobeanalytics_hist.javascript_version
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/adobeanalytics/${var:ENV}_bidhr_sds_adobeanalytics_hist/javascript_version/javascript_version.parquet'
;
