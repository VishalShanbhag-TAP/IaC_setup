CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_adobeanalytics_hist.hit_data
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/adobeanalytics/${var:ENV}_bidhr_sds_adobeanalytics_hist/hit_data/hit_data.parquet'
;
