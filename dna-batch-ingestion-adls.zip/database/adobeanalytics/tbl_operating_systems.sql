CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_adobeanalytics_hist.operating_systems
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/adobeanalytics/${var:ENV}_bidhr_sds_adobeanalytics_hist/operating_systems/operating_systems.parquet'
;
