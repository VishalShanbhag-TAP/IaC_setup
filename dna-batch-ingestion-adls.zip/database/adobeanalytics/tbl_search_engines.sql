CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_adobeanalytics_hist.search_engines
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/adobeanalytics/${var:ENV}_bidhr_sds_adobeanalytics_hist/search_engines/search_engines.parquet'
;

