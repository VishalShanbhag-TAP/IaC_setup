CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_adobeanalytics_hist.event
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/adobeanalytics/${var:ENV}_bidhr_sds_adobeanalytics_hist/event/event.parquet'
;
