CREATE DATABASE IF NOT EXISTS ${var:ENV}_bidhr_sds_cij_hist
;
