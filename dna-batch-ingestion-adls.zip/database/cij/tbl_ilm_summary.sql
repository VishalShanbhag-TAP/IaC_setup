CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_cij_hist.ilm_summary
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/cij/${var:ENV}_bidhr_sds_cij_hist/ilm_summary/ilm_summary.parquet'
;
