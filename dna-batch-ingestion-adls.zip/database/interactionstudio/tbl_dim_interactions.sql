CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_interactionstudio_hist.dim_interactions
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/interactionstudio/${var:ENV}_bidhr_sds_interactionstudio_hist/dim_interactions/dim_interactions.parquet'
;