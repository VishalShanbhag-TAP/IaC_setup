CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_interactionstudio_hist.merge_activity
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/interactionstudio/${var:ENV}_bidhr_sds_interactionstudio_hist/merge_activity/merge_activity.parquet'
;