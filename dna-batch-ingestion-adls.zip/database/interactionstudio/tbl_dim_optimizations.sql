CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_interactionstudio_hist.dim_optimizations
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/interactionstudio/${var:ENV}_bidhr_sds_interactionstudio_hist/dim_optimizations/dim_optimizations.parquet'
;