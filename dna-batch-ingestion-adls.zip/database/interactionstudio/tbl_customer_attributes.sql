CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_interactionstudio_hist.customer_attributes
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/interactionstudio/${var:ENV}_bidhr_sds_interactionstudio_hist/customer_attributes/customer_attributes.parquet'
;