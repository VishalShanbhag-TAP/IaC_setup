CREATE TABLE IF NOT EXISTS ${var:ENV}_bidhr_sds_interactionstudio_hist.customer_events
  USING PARQUET
  LOCATION 'dbfs:/mnt/database/interactionstudio/${var:ENV}_bidhr_sds_interactionstudio_hist/customer_events/customer_events.parquet'
;