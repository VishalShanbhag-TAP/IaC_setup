package com.telstra.dna.ingestion.apps

import java.io.{ByteArrayInputStream, FileNotFoundException, IOException}
import java.nio.charset.Charset
import java.util.Properties

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.dna.ingestion.AbstractApp
import com.telstra.dna.ingestion.utils.{AuditUtils, IngestionUtils, PreprocessUtils}
import org.apache.spark.sql.SparkSession


object PreprocessCijSpeedRemediData extends
  AbstractApp with
  AuditUtils with
  PreprocessUtils with
  IngestionUtils {
  /**
   * Override this to add functionality to your application
   */
  override def execute(props: Properties, spark: SparkSession): Unit = {

    val preprocessFilePattern = props.getProperty("dataSet") + "_" + props.getProperty("runId") + props.getProperty("dataSetExt") + ".gpg"
    val landingFilePattern = props.getProperty("dataSet") + "_" + props.getProperty("runId") + props.getProperty("dataSetExt")

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Preprocessing Stage started for " + preprocessFilePattern)

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - preprocessPath: " + props.getProperty("preprocessPath"))
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - preprocessFilePattern: " + preprocessFilePattern)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingPath: " + props.getProperty("landingPath"))
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingFilePattern: " + landingFilePattern)

    // set app specific kv properties
    val pubKey = getAppKeyVltSecret(props.getProperty("kvScope"), props.getProperty("recipientKeys").split(",")(0)) //Public Key
    val pvtKey = getAppKeyVltSecret(props.getProperty("kvScope"), props.getProperty("recipientKeys").split(",")(1)) //Pvt Key
    val secKeyRingPassword = getAppKeyVltSecret(props.getProperty("kvScope"), props.getProperty("recipientKeys").split(",")(2)) //keyPharse

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Reading CIJ encryption secrets from keyvault as input stream..")
    val pubKeyRing = scala.io.Source.fromInputStream(new ByteArrayInputStream(new String(java.util.Base64.getDecoder.decode(pubKey)).getBytes(Charset.forName("UTF-8")))).mkString
    val secKeyRing = scala.io.Source.fromInputStream(new ByteArrayInputStream(new String(java.util.Base64.getDecoder.decode(pvtKey)).getBytes(Charset.forName("UTF-8")))).mkString

    //val keyringConfig: KeyringConfig = KeyringConfigs.withKeyRingsFromStreams(pubKeyRingInStream, secKeyRingInStream, KeyringConfigCallbacks.withPassword(secKeyRingPassword))

    val fileExistsInPreprocess = dbutils.fs.ls(props.getProperty("preprocessPath")).map(_.name).contains(preprocessFilePattern + "/")

    if (!fileExistsInPreprocess) {
      throw new FileNotFoundException("No file to preprocess with name " + preprocessFilePattern)
    } else {
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Validating if file ${preprocessFilePattern} is already registered")

      //val isRegistered = isDatasetRegistered(preprocessPath.toString, props)
      val isRegistered = false
      if (isRegistered) {
        throw new IOException(s"File ${preprocessFilePattern} is already preprocessed")
      } else {
        val srcPath = s"""${props.getProperty("preprocessPath")}/${preprocessFilePattern}/"""
        val prqFileNames = dbutils.fs.ls(srcPath).map(_.name)

        val tgtPath = s"""${props.getProperty("preprocessPath")}/${landingFilePattern}/"""

        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - ${prqFileNames.length} files to be decrypted")
        try {
          importGPGKeys(secKeyRing,pubKeyRing,s"""${props.getProperty("preprocessPath")}""",props.getProperty("appLogger"),props)
          for(i <- prqFileNames.indices){
            val file = prqFileNames(i)
            if(file.contains(".gpg")) {
              logInfo(s"""[APP_LOG] - [${props.getProperty("appLogger")}] - Decrypting file ${i}. ${srcPath}${file} and re-uploading as ${tgtPath}${file.replace(".gpg", "")}""")
              //decryptAndUpload(keyringConfig, s"""${srcPath}${file}""", s"""${tgtPath}${file.replace(".gpg", "")}""", props.getProperty("appLogger"))
              decryptAndUpload(secKeyRingPassword, s"""${srcPath}""", file,s"""${tgtPath}""", s"""${tgtPath}${file.replace(".gpg", "")}""", props.getProperty("appLogger"), props)
            }
          }
        } finally {
          logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Temp directory deleted successfully ")
        }
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Decryption done.")
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Reading data in ${tgtPath} as a dataframe.")
        val df = readAsDataFrame(tgtPath, "parquet", props: Properties)
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Generating triplet...")
        generateTriplet(df, props.getProperty("dataSet"), props.getProperty("landingPath"), props.getProperty("runId"), props.getProperty("appLogger"))
      }
    }

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Preprocessing Stage completed for " + preprocessFilePattern)
  }
}
