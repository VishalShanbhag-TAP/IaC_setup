package com.telstra.dna.ingestion.services

import java.util.Properties

import com.telstra.dna.ingestion.utils.{IngestionUtils, SparkUtils}
import org.apache.spark.internal.Logging
import org.apache.spark.sql.catalyst.parser.LegacyTypeStringParser
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SaveMode}

import scala.util.Try

/**
  * This Trait provides helper functions to work with ADLS and the trait requires SparkContextProvider to be inherited to extend this trait
  */
trait AzureDataLakeService extends
  IngestionUtils with
  Logging {

  this: SparkUtils =>

    /** Produce a StructType schema object from a encoded Schema */
    def getDecodedSchema(encodedSchema: String): StructType = {
      val json = new String(java.util.Base64.getDecoder.decode(encodedSchema))
      Try(DataType.fromJson(json)).getOrElse(LegacyTypeStringParser.parse(json)) match {
        case t: StructType => t
        case _ => throw new RuntimeException(s"Failed parsing StructType: $json")
      }
    }

    /** The function reads parquet files from the provided path
      *
      * @param path path where the data should be read from
      * @param props properties
      * @return dataframe created from the filepath read
      */
    def readAsDataFrame(path: String, format: String, props: Properties): DataFrame = {

      try {
        format.toLowerCase match {
          case "parquet" => {
            sparkSession.read.parquet(path)
          }
          case "xml" => {
            val recordSchema = getDecodedSchema(props.getProperty("schemaStr"))
            sparkSession.read.format("com.databricks.spark.xml")
              .option("rowTag", props.getProperty("rowTag"))
              .schema(recordSchema)
              .load(path)
          }
          case _ => {
            val readerOptions = stringToMap(props.getProperty("readerOptions", "").replaceAll("\"", ""), props.getProperty("appLogger"))
            logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Reader options: " + props.getProperty("readerOptions"))
            val recordSchema = getDecodedSchema(props.getProperty("schemaStr"))
            sparkSession.read.format(format).schema(recordSchema).options(readerOptions).load(path)
          }
        }
      } catch {
        case e: Throwable =>
          logError(s"Unable to prepare Dataframe from ${path}", e)
          throw e
      }
    }

    def writeAsDeltaTable(path: String, df: DataFrame, saveMode: String, replaceWhere: String, partitionColumns: String): Unit = {
      if(partitionColumns.length > 0) {
        if(saveMode == "append") {
          df.repartition(partitionColumns.split(",").map(col).toSeq : _*)
            .write.format("delta").mode("append")
            .partitionBy(partitionColumns.split(",").toSeq : _*)
            .save(path)
        } else if(replaceWhere.length > 0) {
          df.repartition(partitionColumns.split(",").map(col).toSeq : _*)
            .write.format("delta").mode("overwrite")
            .option("replaceWhere", replaceWhere)
            .partitionBy(partitionColumns.split(",").toSeq : _*).save(path)
        } else {
          df.repartition(partitionColumns.split(",").map(col).toSeq : _*)
            .write.format("delta").mode("overwrite")
            .partitionBy(partitionColumns.split(",").toSeq : _*).save(path)
        }
      } else {
        if(saveMode == "append") {
          df.write.format("delta").mode("append").save(path)
        } else if(replaceWhere.length > 0) {
          df.write.format("delta").mode("overwrite")
            .option("replaceWhere", replaceWhere).save(path)
        } else {
          df.write.format("delta").mode("overwrite").save(path)
        }
      }
    }

    def writeAsParquet(path: String, df: DataFrame, saveMode: String, partitionColumns: String): Unit = {
      if(partitionColumns.length > 0) {
        if(saveMode.toLowerCase == "append") {
          df.repartition(partitionColumns.split(",").map(col).toSeq : _*)
            .write.format("parquet").mode(SaveMode.Append)
            .partitionBy(partitionColumns.split(",").toSeq : _*)
            .save(path)
        } else {
          df.repartition(partitionColumns.split(",").map(col).toSeq : _*)
            .write.format("parquet").mode(SaveMode.Overwrite)
            .partitionBy(partitionColumns.split(",").toSeq : _*)
            .save(path)
        }
      } else {
        if(saveMode.toLowerCase == "append") {
          df.write.format("parquet").mode(SaveMode.Append).save(path)
        } else {
          df.write.format("parquet").mode(SaveMode.Overwrite).save(path)
        }
      }
    }
}


