package com.telstra.dna.ingestion.utils

import java.sql.Timestamp
import java.util.{Date, Properties}

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.{StringType, StructField, StructType, TimestampType}

trait AuditUtils {

  this: SparkUtils =>
  // TO DO ADD lowercase to left hand side
  def isDatasetRegistered(fileName: String, props: Properties): Boolean = {
    try {
      val isAuditPathAvailable = try{
        dbutils.fs.ls(props.getProperty("adlsPrefix") +props.getProperty("auditTablePath")).map(_.name)
        true
      }catch{
        case e: Throwable =>
          logError(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Unable to check existence of file - ${fileName} in audit database", e)
          false
      }
      var count:Long = 0
      if(isAuditPathAvailable){
        var auditDF = sparkSession.read.parquet(props.getProperty("adlsPrefix") +props.getProperty("auditTablePath"))
        count = auditDF
          .filter(auditDF("fileName") === fileName.toLowerCase
            && auditDF("dataSource") === props.getProperty("dataSource").replace("/","").toLowerCase)
          .count
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Count of records " + count)
      }else {
        return true
      }
      if (count > 0) false else true
    } catch {
      case e: Throwable =>
        logError(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Unable to check existence of file - ${fileName} in audit database", e)
        throw e
    }
  }

  def insertAudit(props: Properties, dataTier: String, fileName: String): Unit = {
    try {
      import java.text.SimpleDateFormat
      import java.util.TimeZone
      val ausDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      ausDateFormat.setTimeZone(TimeZone.getTimeZone("Australia/Sydney"))
      val timestmp = ausDateFormat.format(new Date())
      val auditId = java.util.UUID.randomUUID.toString
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - auditId: " + auditId)

      // Insert Audit Info
      val auditData = Seq(Row(auditId, props.getProperty("dataSource").replace("/","").toLowerCase(), dataTier, fileName.toLowerCase, Timestamp.valueOf(timestmp)))
      val auditDataSchema = List(
        StructField("auditid", StringType, true),
        StructField("datasource", StringType, true),
        StructField("datatier", StringType, true),
        StructField("filename", StringType, true),
        StructField("insertmltdttm", TimestampType, true)
      )
      val auditDataDF = sparkSession.createDataFrame(
        sparkSession.sparkContext.parallelize(auditData),
        StructType(auditDataSchema)
      )
      auditDataDF
        .write.format("parquet")
        .mode("append")
        .partitionBy("datasource")
        .save(props.getProperty("adlsPrefix") +props.getProperty("auditTablePath"))
    }
    catch {
      case e: Throwable =>
        logError(s"Unable to insert audit records for: ${fileName} in to auditTable", e)
        throw e
    }
  }

}
