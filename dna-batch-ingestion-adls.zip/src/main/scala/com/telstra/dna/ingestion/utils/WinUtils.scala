package com.telstra.dna.ingestion.utils

import java.io.File

/**
  * Singleton for loading winutils to application, for Windows local development
  */
object WinUtils {

  /**
    * Hadoop functionalities of Spark need the winutils.exe file to be present on Windows
    * http://letstalkspark.blogspot.fr/2016/02/getting-started-with-spark-on-window-64.html
    */
  def loadWinUtils(): Unit = {
    val sep = File.separator
    val current = new File(".").getAbsolutePath.replace(s"$sep.", "")
    val os = System.getProperty("os.name").toLowerCase
    if(os.indexOf("win") >= 0) {
      System.setProperty("hadoop.home.dir", s"$current${sep}src${sep}main${sep}resources$sep")
    } else if(os.indexOf("mac") >= 0) {
      System.setProperty("hadoop.home.dir", "/usr/local/Cellar/hadoop-2.7.0/lib/native")
    }
  }

}
