package com.telstra.dna.ingestion.apps

import java.util.Properties

import com.telstra.dna.ingestion.AbstractApp
import com.telstra.dna.ingestion.services.AzureDataLakeService
import com.telstra.dna.ingestion.utils.{AuditUtils, IngestionUtils}
import org.apache.spark.sql.SparkSession


object ProcessDataSets extends
  AbstractApp with
  AzureDataLakeService with
  AuditUtils with
  IngestionUtils {

  override def execute(props: Properties, spark: SparkSession): Unit = {

    val filePattern = props.getProperty("dataSet") + "_" + props.getProperty("runId")
    
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Process Stage started for " + filePattern)

    val landingPath = props.getProperty("landingPath") + "/" + filePattern + props.getProperty("dataSetExt")

    // /mnt/adobeanalytics_staging/hit_data/hit_data_yyyyMMdd.parquet/
    val stagingPath = props.getProperty("stagingPath") + "/" + filePattern

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingFilePattern: " + filePattern)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingPath: " + landingPath)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - stagingPath: " + stagingPath)

    val inputDF = readAsDataFrame(landingPath, props.getProperty("readerFormat", ""), props)

    val auditedDF = addAuditColumns(inputDF, landingPath, props.getProperty("runId"))

    writeAsParquet(stagingPath, auditedDF, "overwrite", "")

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Process Stage completed for " + filePattern)

  }
}


