package com.telstra.dna.ingestion

import java.util.{InputMismatchException, Properties}

//import com.microsoft.pnp.logging.Log4jConfiguration
//import com.microsoft.pnp.util.TryWith
import com.telstra.dna.ingestion.services._
import com.telstra.dna.ingestion.utils._
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession

/**
  * Base class for implementing Spark code. Manages the SparkSession at beginning and end of code
  */
abstract class AbstractApp extends
  SparkUtils with
  Logging with
  IngestionUtils with
  AzureKeyVaultService with
  AzureDataLakeService {
  /**
    * Main entry point for the application, it starts the SparkSession before execute()
    *
    * @param args program arguments
    */
  def main(args: Array[String]): Unit = {
    // Load Winutils for local running
    WinUtils.loadWinUtils()

    // Configure our logging
/*    TryWith(getClass.getResourceAsStream("log4j.properties")) {
      stream => {
        Log4jConfiguration.configure(stream)
      }
    }*/

    // Parse Arguments
    if (args.length != 4 ) {
      logError("""[APP_LOG] - Required Arguments (env name, datasource name, dataset name, runId) are not provided, instead: ${args.mkString(",")}""")
      throw new InputMismatchException("""Required Arguments (env name, datasource name, dataset name, runId) are not provided, instead: ${args.mkString(",")}""")
    }

    // Load local props
    var props = loadLocalAppProps()
    // Set input args to Props
    props.setProperty("env", args(0).toString.toUpperCase)
    props.setProperty("dataSource", args(1).toString)
    props.setProperty("dataSet", args(2).toString)
    props.setProperty("runId", args(3).toString)

    val appLogger = s"${props.getProperty("env")}:${props.getProperty("dataSource")}:${props.getProperty("dataSet")}:${props.getProperty("runId")}"
    props.setProperty("appLogger", appLogger)

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Loaded properties from app.properties file...")
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Base Data Path: " + props.getProperty("baseDataPath"))
    
    // Retrieving default secrets from Azure KeyVault...
    val kvScope = props.getProperty("kvScope")
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Retrieving default secrets from Azure KeyVault...")
    getDefaultSecrets(kvScope, props)

    // Start a sparkSession
    val spark = getSparkSession(props)

    // Load custom property file
    val propertyFilePath = s"properties/${props.getProperty("dataSource")}/${props.getProperty("dataSet")}.properties"
    props = loadDataSetProps(propertyFilePath, props)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - propertyFilePath: " + propertyFilePath)

    // validate and set ssu
    require(Set("RETAIL", "TRANSIENT", "ENTERPRISE", "CORPORATE").contains(props.getProperty("ssu").toUpperCase),
      "SSU can be one of: Retail, Transient, Enterprise, Corporate")

    val ssuCharacter: String = props.getProperty("ssu").toLowerCase.take(1)
    props.setProperty("ssuCharacter", ssuCharacter)

    //set the mount paths in DC area
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Verifying if mount paths exist for the datasource and creating if not present...")
    PathUtils.mountDatacorePaths(props)

    // set paths
    props.setProperty("preprocessPath", PathUtils.preprocessPath(props))
    props.setProperty("landingPath", PathUtils.landingPath(props))
    props.setProperty("stagingPath", PathUtils.stagingPath(props))
    props.setProperty("databaseTablePath", PathUtils.databaseTablePath(props))
    props.setProperty("archivePath", PathUtils.archivePath(props.getProperty("runId"), props))

    // call application code
    execute(props, spark)
  }

  /**
   * Override this to add functionality to your application
   */
  def execute(props: Properties, spark: SparkSession)
}
