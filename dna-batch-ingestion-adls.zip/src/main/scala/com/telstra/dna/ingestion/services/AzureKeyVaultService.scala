package com.telstra.dna.ingestion.services

import java.util.Properties

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils

trait AzureKeyVaultService {

  /** Function to retrive KeyVault Secrets
   *
   * @param credentialScope Scope of obtaining the Secrets
   * @return Map[String, String]
   */
  def getDefaultSecrets(credentialScope: String, props: Properties): Properties = {
    props.setProperty("appId", dbutils.secrets.get(scope = credentialScope, key = "dna-databricks-app-id")) // An ID that uniquely identifies the application
    props.setProperty("appSecret", dbutils.secrets.get(scope = credentialScope, key = "dna-databricks-app-secret")) // A string that the application uses to prove its identity.
    props.setProperty("directoryId", dbutils.secrets.get(scope = credentialScope, key = "dna-directory-id")) // An ID that uniquely identifies the Azure AD instance
    props.setProperty("dataCoreAdlsAccount", dbutils.secrets.get(scope = credentialScope, key = "dcore-adls-account"))
    props.setProperty("dataCoreAdlsContainer", dbutils.secrets.get(scope = credentialScope, key = "dcore-adls-container"))

    props
  }

  /** Function to retrive specific KeyVault Secret
   *
   * @param credentialScope Scope of obtaining the Secrets
   * @param key key id of the secret
   * @return secret value as string
   */
  def getAppKeyVltSecret(credentialScope: String, key: String): String = {
    dbutils.secrets.get(scope = credentialScope, key = key)
  }
}