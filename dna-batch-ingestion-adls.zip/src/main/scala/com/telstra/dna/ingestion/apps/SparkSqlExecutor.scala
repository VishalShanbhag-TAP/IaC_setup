package com.telstra.dna.ingestion.apps

import java.util.Properties
import java.util.regex.Pattern

import com.telstra.dna.ingestion.AbstractApp
import org.apache.spark.sql.SparkSession


object SparkSqlExecutor extends
  AbstractApp {

  override def execute(props: Properties, spark: SparkSession): Unit = {

    // Load custom property file
    val sqlFile = s"/dbfs/FileStore/app_meta/database/${props.getProperty("dataSource")}/${props.getProperty("sqlFilePrefix")}_${props.getProperty("dataSet")}.sql"

    logInfo("[APP_LOG] - Input SQL File Path:" + sqlFile)

    val sourceSql = scala.io.Source.fromFile(sqlFile).getLines()    // scala.io.Source.fromInputStream(getClass.getClassLoader.getResourceAsStream(sqlFile)).getLines() 
      .map{_.replaceAll("\\-\\-.+", "") // replace single line comments --
        .replaceAll("^\\s*$", "")}
      .filter(!_.isEmpty()).mkString("\n")

    val multiLineCommentPattern = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL)
    val commentFreeSql = multiLineCommentPattern.matcher(sourceSql).replaceAll("")

    val regexPatterns = props.getProperty("regexPatterns").split(",").map(kv => (kv.split("=")(0), kv.split("=")(1))).map(reg => (s"""\\$$\\{var:${reg._1}\\}""".r, props.getProperty(reg._2)))
    //val envRegex = ("\\$\\{var:ENV" + "\\}").r
    //val runIdRegex = ("\\$\\{var:RUN_DATE" + "\\}").r

    val transformedQuery = regexPatterns.foldLeft(commentFreeSql){(y,x) =>
      x._1.replaceAllIn(y, x._2)
    }

    spark.sqlContext.setConf("hive.exec.dynamic.partition", "true")
    spark.sqlContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")
    spark.sqlContext.setConf("spark.sql.sources.partitionOverwriteMode","dynamic")

    // Naive separation using semi-colons to identify individual SQL commands
    transformedQuery.split(";").foreach {
      query =>
        logInfo("[APP_LOG] - Running query: "+ query)
        spark.sql(query)
    }
  }
}