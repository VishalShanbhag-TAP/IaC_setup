package com.telstra.dna.ingestion.utils

import java.nio.file.Paths
import java.util.Properties

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.apache.spark.internal.Logging

object PathUtils extends Logging {

  def preprocessPath(props: Properties): String = {
    Paths.get(
      "/mnt",
      "preprocess",
      props.getProperty("ssu").toLowerCase,
      props.getProperty("dataSource").toLowerCase,
      props.getProperty("dataSet").toLowerCase
    ).toString
  }
  /**
   * landing path will be determined by condition if dataset is reserved keyword (if isDataSetReserved is non NULL and non-zero) or not  , If dataset is reserved keyword then path is changed by changedDataSet
   */
  def landingPath(props: Properties): String = {
    if (props.getProperty("isDataSetReserved")== null || props.getProperty("isDataSetReserved").toInt== 0){
      Paths.get(
        "/mnt",
        "landing",
        props.getProperty("ssu").toLowerCase,
        props.getProperty("dataSource").toLowerCase,
        props.getProperty("dataSet").toLowerCase
      ).toString
    }
    else
    {
      Paths.get(
        "/mnt",
        "landing",
        props.getProperty("ssu").toLowerCase,
        props.getProperty("dataSource").toLowerCase,
        props.getProperty("changedDataSet")
      ).toString
    }
  }
  def stagingPath(props: Properties): String = {
    Paths.get(
      "/mnt",
      "staging",
      props.getProperty("ssu").toLowerCase,
      props.getProperty("dataSource").toLowerCase,
      props.getProperty("dataSet").toLowerCase,
      s"${props.getProperty("dataSet").toLowerCase}.parquet"
    ).toString
  }

  def databaseName(props: Properties): String = {
    props.getProperty("env") +
      "_bidh" +
      props.getProperty("ssuCharacter") +
      "_sds_" +
      props.getProperty("dataSource").toLowerCase +
      "_hist"
  }

  def auditDatabaseName(props: Properties): String = {
    props.getProperty("env") +
      "_bidh" +
      props.getProperty("ssuCharacter") +
      "_sds_dna_etl_audit_hist"
  }

  def databaseTablePath(props: Properties): String = {
    Paths.get(
      "/mnt",
      "database",
      props.getProperty("ssu").toLowerCase,
      props.getProperty("dataSource").toLowerCase,
      databaseName(props: Properties),
      props.getProperty("dataSet").toLowerCase,
      s"${props.getProperty("dataSet").toLowerCase}.parquet"
    ).toString
  }

  def archivePath(runId: String, props: Properties): String = {

    val yr = runId.slice(0, 4)
    val mnth = runId.slice(4, 6)
    val dy = runId.slice(6, 8)

    Paths.get(
      "/mnt",
      "arch",
      props.getProperty("ssu").toLowerCase,
      props.getProperty("dataSource").toLowerCase,
      props.getProperty("dataSet").toLowerCase,
      yr,
      mnth,
      dy
    ).toString
  }

  def mountDir(adlsContainer: String, adlsAccount: String, adlsDir: String, mountPath: String, configs: Map[String, String]) = {

    dbutils.fs.mount(
      source = s"""abfss://${adlsContainer}@${adlsAccount}.dfs.core.windows.net/${adlsDir}""",
      mountPoint = mountPath,
      extraConfigs = configs)
  }

  def mountDatacorePaths(props: Properties): Unit = {

    val dataTiers = List("preprocess", "landing", "staging", "database", "arch")
    val config = Map(
      "fs.azure.account.auth.type" -> "OAuth",
      "fs.azure.account.oauth.provider.type" -> "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
      "fs.azure.account.oauth2.client.id" -> props.getProperty("appId"),
      "fs.azure.account.oauth2.client.secret" -> props.getProperty("appSecret"),
      "fs.azure.account.oauth2.client.endpoint" -> s"""https://login.microsoftonline.com/${props.getProperty("directoryId")}/oauth2/token"""
    )

    // loop through each tier and create mount point if not existing already
    dataTiers.foreach(tier => {
      val mountPath = s"""/mnt/${tier}/${props.getProperty("ssu").toLowerCase}/${props.getProperty("dataSource").toLowerCase}"""
      val adlsDir = s"""${props.getProperty("baseDataPath")}/${props.getProperty("env")}/SDS/${tier}/${props.getProperty("ssu").toLowerCase}/${props.getProperty("dataSource").toLowerCase}"""
    
      if (!dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(mountPath)) {
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Mounting ${adlsDir} as ${mountPath} for the first time..")
        
        mountDir(props.getProperty("dataCoreAdlsContainer"), 
                 props.getProperty("dataCoreAdlsAccount"), 
                 adlsDir,
                 mountPath,
                 config)        
      } else {
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Mount path: ${mountPath} exists already..")
      }
    }) 
  }
}
