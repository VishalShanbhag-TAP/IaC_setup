package com.telstra.dna.ingestion.apps

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{split,lit}
import org.apache.spark.sql.types.StringType
import java.io.{ByteArrayInputStream, FileNotFoundException, IOException}
import java.nio.charset.Charset
import java.util.Properties
import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.dna.ingestion.AbstractApp
import com.telstra.dna.ingestion.utils.{AuditUtils, IngestionUtils, PreprocessUtils}


object PreprocessMMFData extends
  AbstractApp with
  AuditUtils with
  PreprocessUtils with
  IngestionUtils {

  /**
   * Override this to add functionality to your application
   */
  override def execute(props: Properties, spark: SparkSession): Unit = {
    val spark = sparkSession
    import spark.implicits._
    val landingFilePathPattern    = props.getProperty("dataSet") + "_" + props.getProperty("runId") + props.getProperty("dataSetExt")
    val landingCtlFilePattern = props.getProperty("dataSet") + "_" + props.getProperty("runId") + ".ctl"
    val landingEotFilePattern = props.getProperty("dataSet") + "_" + props.getProperty("runId") + ".eot"

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Preprocessing Stage started for files exists in " + props.getProperty("preprocessPath")+"/"+props.getProperty("dataSet")+"_"+props.getProperty("runId"))
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingPath: " + props.getProperty("landingPath"))
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingFilePathPattern: " + landingFilePathPattern)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingCtlFilePattern: " + landingCtlFilePattern)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingEotFilePattern: " + landingEotFilePattern)
    // set app specific kv properties
    val pubKey = getAppKeyVltSecret(props.getProperty("kvScope"), props.getProperty("recipientKeys").split(",")(0)) //Public Key
    val pvtKey = getAppKeyVltSecret(props.getProperty("kvScope"), props.getProperty("recipientKeys").split(",")(1)) //Pvt Key
    val secKeyRingPassword = getAppKeyVltSecret(props.getProperty("kvScope"), props.getProperty("recipientKeys").split(",")(2)) //keyPharse

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Reading MMF encryption secrets from keyvault as input stream..")
    val pubKeyRing = scala.io.Source.fromInputStream(new ByteArrayInputStream(new String(java.util.Base64.getDecoder.decode(pubKey)).getBytes(Charset.forName("UTF-8")))).mkString
    val secKeyRing = scala.io.Source.fromInputStream(new ByteArrayInputStream(new String(java.util.Base64.getDecoder.decode(pvtKey)).getBytes(Charset.forName("UTF-8")))).mkString

    val PreprocessingFileCount = dbutils.fs.ls(s"""${props.getProperty("preprocessPath")}/${props.getProperty("dataSet")}_${props.getProperty("runId")}""").map(_.name).filter(_.contains(".gpg")).size
   // condition to check if files are available for decryption
    if (PreprocessingFileCount == 0 ) {
      throw new FileNotFoundException("No file to decrypt in path : " + props.getProperty("preprocessPath")+"/"+props.getProperty("dataSet")+"_"+props.getProperty("runId"))
    } else {
      val isRegistered = false
      if (isRegistered) {
        throw new IOException(s"File is already preprocessed")
      } else {
        val srcPath = s"""${props.getProperty("preprocessPath")}/${props.getProperty("dataSet")}_${props.getProperty("runId")}/"""
        val prqFileNames = dbutils.fs.ls(srcPath).map(_.name)
        var tgtPath = s"""${props.getProperty("preprocessPath")}/${landingFilePathPattern}/"""
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - ${prqFileNames.length} files to be decrypted")
        try{
        importGPGKeys(secKeyRing,pubKeyRing,s"""${props.getProperty("preprocessPath")}""",props.getProperty("appLogger"),props)
        for(i <- prqFileNames.indices){
          val file = prqFileNames(i)
          if (file.endsWith(".csv.gpg")){
            tgtPath = s"""${props.getProperty("preprocessPath")}/${landingFilePathPattern}/"""
          }
          else if ((file.endsWith(".ctl.gpg"))) {
            tgtPath = s"""${props.getProperty("preprocessPath")}/${landingCtlFilePattern}/"""
          }
          else {
            tgtPath = s"""${props.getProperty("preprocessPath")}/${landingEotFilePattern}/"""
          }

          logInfo(s"""[APP_LOG] - [${props.getProperty("appLogger")}] - Decrypting file ${i}. ${srcPath}${file} and re-uploading as ${tgtPath}${file.replace(".gpg", "")}""")

          decryptAndUpload(secKeyRingPassword, s"""${srcPath}""", file,s"""${tgtPath}""", s"""${tgtPath}${file.replace(".gpg", "")}""", props.getProperty("appLogger"), props)
          logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Decryption done for ${srcPath}${file} in ${tgtPath}.")
          logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Reading data in ${tgtPath} as a dataframe.")
          if (tgtPath.endsWith(".csv/") ){
            val fileName = props.getProperty("dataSet").toUpperCase() + "_" + props.getProperty("runId") +".dat"
            val df = readAsDataFrame(tgtPath, props.getProperty("readerFormat", ""), props: Properties)
            val piiColsList = props.getProperty("piiCols").split(",")
            val npiiDf = if(!piiColsList(0).equals("")) {
              piiColsList.foldLeft(df)((df, piiCol) => {
                df.withColumn(piiCol, lit(null).cast(StringType))
              })
            } else df
            logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Generating dataframe for ${tgtPath} ...")
            // Creation of § delimited .dat file from data frame in landing location
            createdelimitedFile(npiiDf, fileName, props.getProperty("landingPath"),"§")
            logInfo(s"[APP_LOG] - [${fileName}] - Dat file created...")

          }
          else if (tgtPath.endsWith(".eot/") ){
            val fileName = props.getProperty("dataSet").toUpperCase() + "_" + props.getProperty("runId") +".eot"
            val eotDF = Seq[String]().toDF()
            // Creation of eot file in landing location
            createFile(eotDF, fileName, props.getProperty("landingPath"))
            logInfo(s"[APP_LOG] - [${fileName}] - eot file created...")
          }
          else if (tgtPath.endsWith(".ctl/") ){
            val fileName = props.getProperty("dataSet").toUpperCase() + "_" + props.getProperty("runId") +".ctl"
            val df = sparkSession.read.format(props.getProperty("readerFormat", "")).option("header","false").option("sep","§").load(tgtPath)
            logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Generating dataframe for ${tgtPath} ...")
            // Creation of § delimited .ctl file from data frame in landing location
            createdelimitedFile(df, fileName, props.getProperty("landingPath"),"§")
            logInfo(s"[APP_LOG] - [${fileName}] - Ctl file created...")
          }
        }
//        val fileRegId = props.getProperty("runId")+s"${scala.util.Random.nextInt(999)}"
//        val regDF = Seq(fileRegId).toDF()
//        val regFileName = props.getProperty("dataSet").toUpperCase() + "_" + props.getProperty("runId") +".dat"+".reg"
//        logInfo(s"[APP_LOG] - - Creating ${regFileName} at.. "+ props.getProperty("landingPath"))
//        // registry file creation in landing location
//        createFile(regDF, regFileName, props.getProperty("landingPath"))
      }finally {
        // deletion of temp folder, decrypted csv ,ctl and eot files
        dbutils.fs.rm(s"""${props.getProperty("preprocessPath")}/temp""", true)
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Temp directory deleted successfully")
        dbutils.fs.rm(s"""${props.getProperty("preprocessPath")}/${props.getProperty("dataSet")}_${props.getProperty("runId")}.csv""",true)
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - decrypted csv files deleted successfully")
        dbutils.fs.rm(s"""${props.getProperty("preprocessPath")}/${props.getProperty("dataSet")}_${props.getProperty("runId")}.ctl""", true)
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - decrypted ctl files deleted successfully")
        dbutils.fs.rm(s"""${props.getProperty("preprocessPath")}/${props.getProperty("dataSet")}_${props.getProperty("runId")}.eot""", true)
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - decrypted eot files deleted successfully")
      }
      }
    }
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Preprocessing Stage completed for " + props.getProperty("preprocessPath")+"/"+props.getProperty("dataSet")+"_"+props.getProperty("runId"))
  }
}
