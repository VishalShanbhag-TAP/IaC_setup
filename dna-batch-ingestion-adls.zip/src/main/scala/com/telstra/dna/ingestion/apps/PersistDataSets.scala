package com.telstra.dna.ingestion.apps

import java.util.Properties

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.dna.ingestion.AbstractApp
import com.telstra.dna.ingestion.services.AzureDataLakeService
import com.telstra.dna.ingestion.utils.{AuditUtils, IngestionUtils}
import org.apache.spark.sql.SparkSession


object PersistDataSets extends
  AbstractApp with
  AzureDataLakeService with
  AuditUtils with
  IngestionUtils {

  override def execute(props: Properties, spark: SparkSession): Unit = {

    val filePattern = props.getProperty("dataSet") + "_" + props.getProperty("runId")

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Persist Stage started for " + filePattern)

    // /mnt/staging/adobeanalytics/hit_data/hit_data.parquet/hit_data_yyyyMMdd/
    val stagingPath = props.getProperty("stagingPath") + "/" + filePattern
    
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - stagingPath: " + stagingPath)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - databaseTablePath: " + props.getProperty("databaseTablePath"))

    val inputDF = readAsDataFrame(stagingPath, "parquet", props)

    val partitionColumns = props.getProperty("partitionColumns", "")

    writeAsParquet(props.getProperty("databaseTablePath"), inputDF, props.getProperty("writeMode"), partitionColumns)

    //delete the temporary directory from staging
    dbutils.fs.rm(stagingPath, true)

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Persist Stage completed for " + filePattern)

  }
}
