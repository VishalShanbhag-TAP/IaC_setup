package com.telstra.dna.ingestion.apps

import java.io.IOException
import java.util.Properties

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import com.telstra.dna.ingestion.AbstractApp
import com.telstra.dna.ingestion.utils.{AuditUtils, IngestionUtils, PreprocessUtils}
import org.apache.spark.sql.SparkSession

/**
 * A preprocessing app that extracts adobeanalytics zip files
 */
object PreprocessAdobeAnalyticsData extends
  AbstractApp with
  AuditUtils with
  PreprocessUtils with
  IngestionUtils {
  /**
   * Override this to add functionality to your application
   */
  override def execute(props: Properties, spark: SparkSession): Unit = {

    val filePattern = props.getProperty("dataSet") + "_" + props.getProperty("runId") + props.getProperty("dataSetExt")

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Preprocessing Stage started for " + filePattern)

    val preprocessPath = props.getProperty("preprocessPath") + "/" + filePattern

    val landingPath = props.getProperty("landingPath").replace(props.getProperty("dataSet"), "")

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - preprocessPath: " + preprocessPath)
    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - landingPath: " + landingPath)

    val fileExists = dbutils.fs.ls(preprocessPath).map(_.name).contains(filePattern)

    // /mnt/preprocess/adobeanalytics/telstratdtmglobalprd/telstratdtmglobalprd_yyyyMMddhh.zip/telstratdtmglobalprd_yyyyMMddhh.zip
    logInfo(s"[APP_LOG] - Validating if file ${filePattern} is already registered")
    //var isRegistered = isDatasetRegistered(fullFileName, props)
    val isRegistered = false
    if (isRegistered) {
      throw new IOException(s"File ${filePattern} is already preprocessed")
    } else {
      unZipFile(s"${preprocessPath}", filePattern, s"${landingPath}", props)

      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Preprocessing Stage completed for " + filePattern)
    }
  }
}