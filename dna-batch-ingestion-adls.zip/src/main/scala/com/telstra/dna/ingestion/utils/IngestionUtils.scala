package com.telstra.dna.ingestion.utils

import java.nio.ByteBuffer
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Properties

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

import scala.util.Try

trait IngestionUtils extends Logging {

  this: SparkUtils =>

  /**
   * Parameter conversion function used to derive the source strings into Maps
   * this is predominantly used across sourec to target column renames, source datatypes of timestamp and date fields in along the ammending the datawarehousing fileds.
   *
   * @param extParams input params of type k1=v1,k2=v2
   * @return Map of (String,String)
   * {{{param.split(",").map(x => {
   *                    val k = x.split("="); (k(0), k(1))
   *                  }).toList.toMap}}}
   */
  def stringToMap(extParams: String, logger: String): Map[String, String] = {
    logInfo("Delimiter for reading dataframe" + extParams)
    val param = extParams.replaceAll("^\"|\"$", "")
    try {
      if (param.length != 0) {
        //Negative look back to handle the separator is used as value itself
        param.split("(?<!(=)),").map(x => {
          val k = x.split("(?<!(=))=");
          (k(0), k(1))
        }).toList.toMap
      } else Map[String, String]()
    } catch {
      case e: Exception =>
        logError(s"[APP_LOG] - [${logger}] - Unable to Convert String to Map : " + extParams + " to Map", e)
        throw e
    }
  }

  def addAuditColumns(inputDF: DataFrame, fileName: String,runId:String): DataFrame = {
    try {
      inputDF.withColumn("src_file", lit(fileName))
        .withColumn("ingestion_timestamp", current_timestamp())
        .withColumn("run_date", lit(runId.substring(0,8)))
    } catch {
      case e: Throwable =>
        throw e
    }
  }

  def ssuFolderName(ssu: String) : String = ssu match {
    case "retail" => "retail"
    case "wholesale" => "wholesale"
    case "transient" => "transient"
    case "enterprise" => "reference"
  }

  def getDateOffset(runId: String, runIdFormat: String, outputDateFormat: String): String = {
    // define input format to parse runId
    val inputPattern = DateTimeFormatter.ofPattern(runIdFormat) // "yyyyMMddHH" or "yyyyMMdd"
    val odatetm = LocalDateTime.parse(runId, inputPattern)
    // define output formats to extract date and offset paths
    val outputPattern = DateTimeFormatter.ofPattern(outputDateFormat) // "yyyyMMdd-HH0000"
    // val offsetpathPattern = DateTimeFormatter.ofPattern(offsetpathFormat) // "HH" or "yyyy/MM/dd"
    odatetm.format(outputPattern)
    //(odatetm.format(outputPattern), odatetm.format(offsetpathPattern) + "/")
  }

  /**
   * Gets the content of the provided ByteBuffer as a byte array. This method will create a new byte array even if the
   * ByteBuffer can have optionally backing array.
   *
   * @param byteBuffer the byte buffer
   * @return the byte array
   */
  def byteBufferToArray(byteBuffer: ByteBuffer): Array[Byte] = {
    val length = byteBuffer.remaining
    val byteArray = new Array[Byte](length)
    byteBuffer.get(byteArray)
    byteArray
  }

  def loadLocalAppProps(): Properties = {
    val prop = new Properties()
    try {
      prop.load(getClass.getClassLoader.getResourceAsStream("properties/app.properties"))
    } catch {
      case e: Throwable => {
        logWarning("Unable to Load Internal Properties", e)
      }
    }
    prop
  }

  def loadDataSetProps(propName: String, props: Properties): Properties = {
    try {
      props.load(getClass.getClassLoader.getResourceAsStream(propName))
    } catch {
      case e: Throwable => {
        logWarning("Unable to Load Dataset Properties", e)
      }
    }
    props
  }

  def generateTriplet(df: DataFrame, dataSet: String,
                      tripletPath: String, runId: String, logger: String): Unit = {

    val spark = sparkSession
    import spark.implicits._

    val fileName = dataSet + "_" + runId
    val datFileName = fileName + ".dat"
    val ctlFileName = fileName + ".ctl"
    val eotFileName = fileName + ".eot"

    // Create Dat file
    logInfo(s"[APP_LOG] - [${logger}] - Creating ${datFileName} at ${tripletPath}...")
    createFile(df, datFileName, tripletPath)
    logInfo(s"[APP_LOG] - [${logger}] - Dat file created...")

    // Create Ctl file
    val extractTime = "00:00:00"
    val checksum = "0"
    val recCount = df.count.toString

    logInfo(s"[APP_LOG] - [${logger}] - Creating ${ctlFileName} at ${tripletPath}...")
    val ctlDF = Seq((recCount, runId, extractTime, datFileName, "BIDH", checksum)).toDF
    createFile(ctlDF, ctlFileName, tripletPath)
    logInfo(s"[APP_LOG] - [${logger}] - Ctl file created...")

    // Create Eot file
    logInfo(s"[APP_LOG] - [${logger}] - Creating ${eotFileName} at ${tripletPath}...")
    val eotDF = Seq[String]().toDF()
    createFile(eotDF, eotFileName, tripletPath)
    logInfo(s"[APP_LOG] - [${logger}] - Eot file created...")

    // Create FileRegistration file
//    val fileRegId = s"$runId${scala.util.Random.nextInt(999)}"
//    val regDF = Seq(fileRegId).toDF()
//    val regFileName = s"$datFileName.reg"
//    logInfo(s"[APP_LOG] - [${logger}] - Creating ${regFileName} at ${tripletPath}...")
//    createFile(regDF, regFileName, tripletPath)
    logInfo(s"[APP_LOG] - [${logger}] - Eot file created...")

//    logInfo(s"[APP_LOG] - [${logger}] - Triplet ${fileName}[.dat/.ctl/.eot] with ${recCount} records generated at ${tripletPath} with fileRegId - ${fileRegId}")
    logInfo(s"[APP_LOG] - [${logger}] - Triplet ${fileName}[.dat/.ctl/.eot] with ${recCount} records generated at ${tripletPath}")
  }

  def copyMerge(
                 srcFS: FileSystem, srcDir: Path,
                 dstFS: FileSystem, dstFile: Path,
                 deleteSource: Boolean, conf: Configuration
               ): Boolean = {

    if (dstFS.exists(dstFile))
      logInfo(s"[APP_LOG] - ${dstFile} exists already, will be overwritten...")

    srcFS.delete(dstFile, true)
      //throw new IOException(s"Target $dstFile already exists")

    // Source path is expected to be a directory:
    if (srcFS.getFileStatus(srcDir).isDirectory()) {

      val outputFile = dstFS.create(dstFile)
      Try {
        srcFS
          .listStatus(srcDir)
          .sortBy(_.getPath.getName)
          .collect {
            case status if status.isFile() =>
              val inputFile = srcFS.open(status.getPath())
              Try(IOUtils.copyBytes(inputFile, outputFile, conf, false))
              inputFile.close()
          }
      }
      outputFile.close()

      if (deleteSource) srcFS.delete(srcDir, true) else true
    }
    else false
  }


  def merge(srcPath: String, dstPath: String): Unit =  {
    val hadoopConfig = new Configuration()
    val hdfs = FileSystem.get(hadoopConfig)

    // the "true" setting deletes the source files once they are merged into the new output
    copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), true, hadoopConfig)
  }


  def createFile(df: DataFrame, fileName: String, tripletPath: String): Unit = {

    val tempPath = tripletPath + "/temp_" + fileName
    val mergedFileName = tripletPath + "/" + fileName
    sparkSession.sql("SET spark.sql.sources.commitProtocolClass=org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol")

    df.write
      .mode("overwrite")
      .option("header", "false")
      .option("emptyValue", "")
      .option("sep","|")
      .option("timestampFormat","yyyy-MM-dd HH:mm:ss")
      .csv(tempPath)

    merge(tempPath, mergedFileName)
  }
  def createdelimitedFile(df: DataFrame, fileName: String, tripletPath: String, delimiter:String): Unit = {

    val tempPath = tripletPath + "/temp_" + fileName
    val mergedFileName = tripletPath + "/" + fileName
    sparkSession.sql("SET spark.sql.sources.commitProtocolClass=org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol")

    df.write
      .mode("overwrite")
      .option("header", "false")
      .option("emptyValue", "")
      .option("sep",delimiter)
      .option("timestampFormat","yyyy-MM-dd HH:mm:ss")
      .csv(tempPath)

    merge(tempPath, mergedFileName)
  }
}



