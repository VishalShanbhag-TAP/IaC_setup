package com.telstra.dna.ingestion.utils

import java.io.{FileNotFoundException, IOException}
import java.util.Properties

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.{ArrayType, StructType}
import org.apache.spark.sql.functions.{to_json,col,expr}

import scala.sys.process._

trait PreprocessUtils extends Logging {

  this: SparkUtils =>

  def unZipFile(srcDir: String, file: String, tgtDir: String, props: Properties): Unit = {

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Temporarily unzipping ${srcDir}/${file} to ${srcDir}/temp...")

    try {
      val result = s"""unzip -oj /dbfs${srcDir}/${file} -d /dbfs${srcDir}/temp""".!
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Unzip operation finished with return code: " + result)

      Thread.sleep(10000) // 10Sec thread sleep
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Waiting for 10 seconds to allow IO to finish...")
      
      val exfileCount = dbutils.fs.ls(s"${srcDir}/temp").map(_.name).size
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Number of files extracted: " + exfileCount)

      dbutils.fs.ls(s"${srcDir}/temp")
        .map(f => (f.name, f.path))
        .foreach(np => {
          val srcPath = np._2
          val tgtPath = s"""${tgtDir}/${np._1.replace(".tsv", "")}/${np._1.replace(".tsv", "")}_${props.getProperty("runId")}.tsv"""
          logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Moving ${srcPath} to ${tgtPath}...")
          dbutils.fs.mv(srcPath, tgtPath)
        })
    } catch {
      case e: Exception => e.getMessage
        throw new FileNotFoundException(file)
    } finally {
        dbutils.fs.rm(s"""${srcDir}/temp""", true)
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Temp directory deleted successfully")
    }
  }

  def genericUnZipFile(srcDir: String, file: String, tgtDir: String, props: Properties): Unit = {

    logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Temporarily unzipping ${srcDir}/${file} to ${srcDir}/temp...")

    try {
      val result = s"""unzip -oj /dbfs${srcDir}/${file} -d /dbfs${srcDir}/temp""".!
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Unzip operation finished with return code: " + result)

      Thread.sleep(10000) // 10Sec thread sleep
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Waiting for 10 seconds to allow IO to finish...")

      val exfileCount = dbutils.fs.ls(s"${srcDir}/temp").map(_.name).size
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Number of files extracted: " + exfileCount)

      dbutils.fs.ls(s"${srcDir}/temp")
        .map(f => (f.name, f.path))
        .foreach(np => {

          val srcPath = np._2
          val srcFile = np._1.replace("-", "_")
          val srcDirs = srcFile.split('.')(0)
          val srcExt = props.getProperty("dataSetExt")

          logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Preprocessing File ${np._2}")

          //logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Source File Name ${np._1} ")

          logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Source Extension ${srcExt} ")
          if(np._1.contains(srcExt)){
            val tgtPath = s"""${tgtDir}/${srcDirs}/${srcFile.replace(srcExt, "")}_${props.getProperty("runId")}${props.getProperty("dataSetExt")}"""
            logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Moving ${srcPath} to ${tgtPath}...")
            dbutils.fs.mv(srcPath, tgtPath)
          }
        })
    } catch {
      case e: Exception => e.getMessage
        throw new FileNotFoundException(file)
    } finally {
      dbutils.fs.rm(s"""${srcDir}/temp""", true)
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Temp directory deleted successfully")
    }
  }


  def importGPGKeys(secKey: String,pubKey: String, preDir: String, logger: String,props: Properties):Unit={
    try{
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Temporarily creating the temp dir to import keys to ${preDir}/temp...")
      if(null!=secKey && null!=pubKey){
        dbutils.fs.put(preDir+"/temp/pvtKeys.asc",secKey,true)
        dbutils.fs.put(preDir+"/temp/pubKeys.asc",pubKey,true)
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Importing GPG keys from ${preDir}/temp...")
        val importSecKeyCode = s"""gpg --import /dbfs${preDir}/temp/pvtKeys.asc""".!
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Importing recipient secret Key has been  finished with return code(0 Indicates Success, 1 Indicates Failure): " + importSecKeyCode)
        val importPubKeyCode = s"""gpg --import /dbfs${preDir}/temp/pubKeys.asc""".!
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Importing recipient pub Key has been  return code(0 Indicates Success, 1 Indicates Failure): " + importPubKeyCode)
      }else{
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Please check either recipient pub key or secret is not valid / imported properly " )
      }

      //check sign key require then import sender public key
      if(null!= props.getProperty("isSignRequired") && (props.getProperty("isSignRequired").equals("yes") && null!=props.getProperty("senderKeys"))){
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - This dateset requires to import and trust sender keys: " )
        val signedKeys= props.getProperty("senderKeys").split(",")
        for(i <- signedKeys.indices){
          val senderSignKey = dbutils.secrets.get(scope = props.getProperty("kvScope"), key = signedKeys(i))
          dbutils.fs.put(preDir+"/temp/senderSignKey_%s.asc".format(i),new String(java.util.Base64.getDecoder.decode(senderSignKey)),true)
          val importsenderSignCode = s"""gpg --import /dbfs${preDir}/temp/senderSignKey_%s.asc""".format(i).!
          logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Importing sender pub Key has been finished with return code(0 Indicates Success, 1 Indicates Failure): " + importsenderSignCode)
        }
      }else{
        logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Either sender key or isSignRequired flag not set in property file: " )
      }
      //List Keys
      //val listkeys = """gpg --list-keys""".!
      //trust the keys always from both sender and recipient
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Command has been  intiated to trust both sender and recipient keys" )
      val trustCode = """gpg --list-keys --fingerprint --with-colons | sed -E -n -e 's/^fpr:::::::::([0-9A-F]+):$/\1:6:/p' | gpg --import-ownertrust""".!
      logInfo(s"[APP_LOG] - [${props.getProperty("appLogger")}] - Status of trust key command(0 Indicates Success, 1 Indicates Failure) : "+ trustCode)
    }catch {
      case e: Exception => e.getMessage
        throw new IOException("Unable to create the temp directory/import keys for GPG Encryptin/Decryption")
    }
  }

  def decryptAndUpload(keyPharse: String,srcDir: String, file:String,tgtPath: String, tgtAbsPath: String, logger: String, props: Properties): Unit = {
    try {
      logInfo(s"[APP_LOG] - [${logger}] - Performing decryption on ${srcDir} for ${file}... and destination path is /dbfs${tgtAbsPath}")
      dbutils.fs.mkdirs(tgtPath)
      var decryptStatus =  s"""gpg --batch --no-use-agent --passphrase ${keyPharse} --output /dbfs${tgtAbsPath} --decrypt /dbfs${srcDir}${file}""".!
      logInfo(s"[APP_LOG] - [${logger}] - Decryption done and its return status is "+ decryptStatus)
    }catch {
      case e: Exception => e.getMessage
        throw new FileNotFoundException(file)
    }
  }

  def flattenDataframe(df: DataFrame, fieldsToIgnore: Seq[String], fieldsToCast: Seq[String]): DataFrame = {
    val fields = df.schema.fields
    val fieldNames = fields.map(x => x.name)
    for(i <- fields.indices){
      val field = fields(i)
      val fieldtype = field.dataType
      val fieldName = field.name
      fieldtype match {
        case arrayType: ArrayType =>
          val fieldNamesExcludingArray = fieldNames.filter(_!=fieldName)
          val fieldNamesPostIgnore = fieldNamesExcludingArray.filter(f => !fieldsToIgnore.contains(f))
          val fieldNamesAndExplode = fieldNamesPostIgnore ++ Array(s"posexplode_outer($fieldName) as (${fieldName}_idx, $fieldName)")
          val explodedDf = df.selectExpr(fieldNamesAndExplode:_*)
          return flattenDataframe(explodedDf, fieldsToIgnore, fieldsToCast)
        case structType: StructType =>
          val regex  = "[^A-Za-z0-9]".r
          val childFieldnames = structType.fieldNames.map(childname => fieldName +"."+ childname)
          val newfieldNames = fieldNames.filter(_!= fieldName) ++ childFieldnames
          val fieldNamesPostIgnore = newfieldNames.filter(f => !fieldsToIgnore.contains(f))
          val asIsCols = fieldNamesPostIgnore.filter(f => !fieldsToCast.contains(f)).map(x => col(x).as(regex.replaceAllIn(x, "_").toLowerCase))
          val castedCols = fieldNamesPostIgnore.filter(f => fieldsToCast.contains(f)).map(x => to_json(col(x)).as(regex.replaceAllIn(x, "_").replaceAll("__", "_").toLowerCase))
          val explodedf = df.select({asIsCols ++ castedCols} :_ *)
          return flattenDataframe(explodedf, fieldsToIgnore, fieldsToCast)
        case _ =>
      }
    }
    df
  }

  def hashIdGenerator(df: DataFrame, columnToHashed: Seq[String]): DataFrame = {

    val columnStr = StringBuilder.newBuilder

    for(col <- columnToHashed){
      columnStr.append(s"COALESCE(CAST(%s AS STRING),'') ,'|',".format(col))
    }

    val hashColsString = s"cast(hash(concat_ws('|', %s)) as string)".format(columnStr.dropRight(1))

    val hashedDf = df.withColumn("hash_id",expr(s"${hashColsString}"))

    hashedDf
  }
}
