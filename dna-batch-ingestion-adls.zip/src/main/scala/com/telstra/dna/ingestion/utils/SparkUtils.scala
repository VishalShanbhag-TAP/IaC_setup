package com.telstra.dna.ingestion.utils

import java.util.Properties

import org.apache.spark.SparkConf
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession

/**
  * Trait that provides the management of a SparkSession
  */
trait SparkUtils extends Logging {

  @transient private var _sparkSession: SparkSession = _
  
  /**
   * Returns a single accessible SparkSession
   * @param props
   * @tparam T this is for serializerClass, which is of type Class[T]
   * @return Spark session
   */
  def getSparkSession[T](props: Properties): SparkSession = {

    val mode = props.getProperty("mode")
    val appName = props.getProperty("appName")

    val conf = new SparkConf()
    conf.setMaster(mode).setAppName(appName)
    // conf.set("fs.azure.account.auth.type."+props.getProperty("dataCoreAdlsAccount")+".dfs.core.windows.net", "OAuth")
    // conf.set("fs.azure.account.oauth.provider.type."+props.getProperty("dataCoreAdlsAccount")+".dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    // conf.set("fs.azure.account.oauth2.client.id."+props.getProperty("dataCoreAdlsAccount")+".dfs.core.windows.net", props.getProperty("appId"))
    // conf.set("fs.azure.account.oauth2.client.secret."+props.getProperty("dataCoreAdlsAccount")+".dfs.core.windows.net", props.getProperty("appSecret"))
    // conf.set("fs.azure.account.oauth2.client.endpoint."+props.getProperty("dataCoreAdlsAccount")+".dfs.core.windows.net", s"https://login.microsoftonline.com/${props.getProperty("directoryId")}/oauth2/token") //its a tatent id

    _sparkSession = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()

    //logInfo(s"[APP_LOG] - Created new Spark session")

    sparkSession
  }

  def sparkSession: SparkSession = _sparkSession
}
