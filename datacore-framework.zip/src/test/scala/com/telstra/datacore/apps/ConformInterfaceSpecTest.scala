package com.telstra.datacore.apps

import com.telstra.datacore.conforminterface.{DelimitedFile, DelimitedFileProcess, FileExtractorProcess, FixedDelimitedFileProcess, FixedWidthFile, ValidateRecordset}
import com.telstra.datacore.metadata.{ArgumentConfiguration, SourceColumn, SourceColumnFormat}
import org.apache.spark.sql.SparkSession
import org.scalatest.funsuite.AnyFunSuite

import java.util.Properties
import scala.io.Source
import org.apache.spark.SparkContext
import org.apache.log4j.Logger
import org.apache.log4j.Level


class ConformInterfaceSpecTest extends AnyFunSuite{

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  val spark: SparkSession = SparkSession.builder().appName("test").master("local").getOrCreate()
  spark.sparkContext.setLogLevel("OFF")
  val sparkContext: SparkContext = spark.sparkContext
  val props = new Properties()
  props.setProperty("jobName", "test")
  props.setProperty("jobId", "1234")
  props.setProperty("taskId", "1234")
  props.setProperty("oDate", "20210808")
  props.setProperty("envName", "ENV01")

  val absolutePath = TestFileGeneration.absolutePath
  TestFileGeneration.generateTempJson(absolutePath,"test.json")
  TestFileGeneration.randomDelimitedFile(3,3,3,3,3,6,"20210808","2021-08-08 12:23:42","|",4,absolutePath,"delimitedfile.dat")

    test("test of Conform Interface class"){

      props.setProperty("argJsonPath", absolutePath+"test.json")
      try
      {
        ConformInterface.execute(props,spark)
      }
      catch {
        case e:Exception=>("Null data")

      }
    }

    test("test of Conform Interface class incorrect json path"){
      props.setProperty("argJsonPath", "src/test/resources/edq_rass_data.schema.jso")
      try
      {
        ConformInterface.execute(props,spark)
      }
      catch {
        case e:Exception=>("'src/test/resources/edq_rass_data.schema.jso' does not exist")
      }
    }


  test("extenstion seperator test with ."){
    TestFileGeneration.generateTempJson(absolutePath,"test.json")
    FileExtractorProcess.addExtensionSeperator(".ctl")
    val jsonPath = absolutePath+"test.json"
    val argumentJsonString = Source.fromFile(jsonPath).mkString
    val argJson = ArgumentConfiguration.parse(argumentJsonString)
    try {
      DelimitedFileProcess.apply(spark, argumentsConfig = argJson, "E01", "20210908", "1234", "1234", props)
    }
    catch {
      case e:NullPointerException=>"Failed due to invalid parameters"
    }
    try {
      FixedDelimitedFileProcess.apply(spark, argumentsConfig = argJson, "E01", "20210908", "1234", "1234", props)
    }
    catch {
      case e:NullPointerException=>"Failed due to invalid parameters"
    }
  }




  //  Valid test case
  val sourcedefcolumns = List(
    SourceColumn("RECORD_TYPE","VARCHAR",3,nullable = false,Some(List(1,3))),
    SourceColumn("EVENT_TYPE_ID","INTEGER",3,nullable = false,Some(List(4,6))),
    SourceColumn("RECORD","CHAR",3,nullable = false,Some(List(4,6))),
    SourceColumn("BIGINT_ID","BIGINT",3,nullable = false,Some(List(4,6))),
    SourceColumn("SMALLINT_ID","SMALLINT",3,nullable = false,Some(List(4,6))),
    SourceColumn("TEMP","DECIMAL",6,nullable = false,Some(List(10,15)),Some(SourceColumnFormat(None,None,Some("5")))),
    SourceColumn("DATE_INFO","DATE",8,nullable = false,Some(List(16,23)),Some(SourceColumnFormat(Some("yyyyMMdd"),Some("8"),None))),
    SourceColumn("DATE_INFO","TIMESTAMP",19,nullable = false,Some(List(24,33)),Some(SourceColumnFormat(Some("yyyy-MM-dd HH:mm:ss"),Some("6"),None)))
  )

  val filePath = "src/test/resources/delimitedfile.dat"
  //  Valid data load
  test("load records and validate with test case header 0 trailer 0 Success run"){

    val loadedRecords = DelimitedFile.loadRecords(sparkContext,filePath,"\n","ISO-8859-1",0,0)
    val splitRecords = DelimitedFile.splitRecords(loadedRecords,Some("|"),"ISO-8859-1")
    ValidateRecordset.convertRDD(splitRecords,sourcedefcolumns)
    ValidateRecordset.apply(splitRecords,sourcedefcolumns,props = props,"1234","1234")
  }

  val sourcedefcolumnstimeerr = List(
    SourceColumn("RECORD_TYPE","VARCHAR",3,nullable = false,Some(List(1,3))),
    SourceColumn("EVENT_TYPE_ID","INTEGER",3,nullable = false,Some(List(4,6))),
    SourceColumn("RECORD","CHAR",3,nullable = false,Some(List(4,6))),
    SourceColumn("BIGINT_ID","BIGINT",3,nullable = false,Some(List(4,6))),
    SourceColumn("SMALLINT_ID","SMALLINT",3,nullable = false,Some(List(4,6))),
    SourceColumn("TEMP","DECIMAL",6,nullable = false,Some(List(10,15)),Some(SourceColumnFormat(None,None,Some("5")))),
    SourceColumn("DATE_INFO","DATE",8,nullable = false,Some(List(16,23)),Some(SourceColumnFormat(Some("yyyyMMdd"),Some("8"),None))),
    SourceColumn("DATE_INFO","TIMESTAMP",19,nullable = false,Some(List(16,34)),Some(SourceColumnFormat(Some("yyyyy-MM-dd HH:mm:ss"),Some("6"),None)))
  )

  //  Invalid timestamp pattern length data load
  test("load records and validate with timestamp format length error"){
    val loadedRecords = DelimitedFile.loadRecords(sparkContext,filePath,"\n","ISO-8859-1",0,0)
    val splitRecords = DelimitedFile.splitRecords(loadedRecords,Some("|"),"ISO-8859-1")
    ValidateRecordset.convertRDD(splitRecords,sourcedefcolumnstimeerr)
    try
    {
      ValidateRecordset.apply(splitRecords,sourcedefcolumnstimeerr,props = props,"1234","1234")
    }
    catch {
      case e:IllegalArgumentException=>"Pattern Length does not match field length"
    }

  }

  //  Error columns definition
  val sourceerrdefcolumns = List(
    SourceColumn("RECORD_TYPE","VARCHAR",2,nullable = false,Some(List(1,3))),
    SourceColumn("EVENT_TYPE_ID","INTEGER",3,nullable = false,Some(List(4,6))),
    SourceColumn("RECORD","CHAR",3,nullable = false,Some(List(4,6))),
    SourceColumn("BIGINT_ID","BIGINT",3,nullable = false,Some(List(4,6))),
    SourceColumn("SMALLINT_ID","SMALLINT",3,nullable = false,Some(List(4,6)))
  )

  test("load records test case header 0 trailer 0 failure for column length"){
    val loadedRecords = DelimitedFile.loadRecords(sparkContext,filePath,"\n","ISO-8859-1",1,0)
    val splitRecords = DelimitedFile.splitRecords(loadedRecords,Some("|"),"ISO-8859-1")
    ValidateRecordset.convertRDD(splitRecords,sourcedefcolumns)

    try {
      ValidateRecordset.apply(splitRecords, sourceerrdefcolumns, props = props, "1234", "1234")
    }
    catch {
      case e:IllegalArgumentException=> "Column length mismatch"
    }
  }

  test("load records test case header 1 trailer 1"){
    val loadedRecords = DelimitedFile.loadRecords(sparkContext,filePath,"\n","ISO-8859-1",1,1)
  }

  val loadRecord = DelimitedFile.loadRecords(sparkContext,filePath,"\n","ISO-8859-1",1,0)
  test("split records test case"){
    val splitRecords = DelimitedFile.splitRecords(loadRecord,Some("|"),"ISO-8859-1")

  }

  val sourcedeffixeddelimitedcolumns = List(
    SourceColumn("RECORD_TYPE","VARCHAR",3,nullable = false,Some(List(1,3))),
    SourceColumn("EVENT_TYPE_ID","INTEGER",3,nullable = false,Some(List(4,6))),
    SourceColumn("RECORD","CHAR",3,nullable = false,Some(List(4,6))),
    SourceColumn("BIGINT_ID","BIGINT",3,nullable = false,Some(List(4,6))),
    SourceColumn("SMALLINT_ID","SMALLINT",3,nullable = false,Some(List(4,6)))
  )


  //  Fixed width file success records
  val offsetList = Seq((1,5),(6,6),(7,7),(8,8))


  TestFileGeneration.randomFixedDelimitedFileGeneration(5,1,1,2,4,absolutePath,"testing.dat",header = false,trailer = false)
  val fixedFilePath = "src/test/resources/testing.dat"

  val argJsonPath = "src/test/resources/test.json"
  val argumentJsonString: String = Source.fromFile(argJsonPath).mkString
  val argumentConfiguration = ArgumentConfiguration.parse(argumentJsonString)
  test("test Fixed delimited files with success run"){
    val loadedRecords = FixedWidthFile.loadRecords(sparkContext,fixedFilePath,9,0,0)
    FixedWidthFile.splitRecords(loadedRecords,offsetList,"ASCII")

    val Fixedfile = FixedDelimitedFileProcess.loadRecords(spark,fixedFilePath,argumentConfiguration)
    FixedDelimitedFileProcess.splitRecords(spark,Fixedfile,argumentConfiguration)

  }


  test("test Fixed delimited files with header 1 trailer 0"){
    try
    {
      val loadedRecords = FixedWidthFile.loadRecords(sparkContext,fixedFilePath,23,1,0)
    }
    catch {
      case e:Exception=> "Partial record length found at the end of split"
    }
  }


  TestFileGeneration.randomFixedDelimitedFileGeneration(5,1,0,0,4,absolutePath,"test.dat",header = false,trailer = false)
  //  val fixedFilePath10 = "src/test/resources/test.dat"
  val fixedFilePath10 = absolutePath+"test.dat"
  test("test Fixed delimited files with header 0 footer"){
    val invalidoffsetList = Seq((1,5),(6,6),(7,7),(8,8))
    val loadedRecords = FixedWidthFile.loadRecords(sparkContext,fixedFilePath10,23,0,0)
    val splitRecords = FixedWidthFile.splitRecords(loadedRecords,invalidoffsetList,"ASCII")

    try
    {
      FixedDelimitedFileProcess.loadRecords(spark,fixedFilePath10,argumentConfiguration)
    }
    catch {
      case e:IllegalArgumentException=> "Record length is shorter than length specified in the schema"
    }
    TestFileGeneration.deleteRecursively(absolutePath)
  }

}

