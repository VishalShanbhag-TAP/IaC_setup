package com.telstra.datacore.apps

import java.io.{BufferedWriter, File, FileWriter, PrintWriter}
import scala.util.Random


object TestFileGeneration {

  def writeFile(filePath:String,fileName:String,data:String): Unit ={
    val dir = new File(filePath)
    if(!dir.exists()) dir.mkdir()
    val pw = new PrintWriter(new File(filePath+fileName))
    pw.write(data)
    pw.close()
  }

  def randomDelimitedFile(RECORD_TYPE:Int,EVENT_TYPE_ID:Int,RECORD:Int,BIGINT_ID:Int,SMALLINT_ID:Int,
                          DECIMAL:Int,DATE:String,TIMESTAMP:String,Delimiter:String,generateLines:Int,
                          filePath:String,filename:String): Unit =
  {

    var finalFile = ""
    for(i <- 1 to generateLines)
    {
      val recordType = Random.alphanumeric.filter(_.isLetter).take(RECORD_TYPE).mkString.toUpperCase()
      val eventType = Random.alphanumeric.filter(_.isDigit).take(EVENT_TYPE_ID).mkString
      val record = Random.alphanumeric.filter(_.isLetter).take(RECORD).mkString.toUpperCase()
      val bigInt = Random.alphanumeric.filter(_.isDigit).take(BIGINT_ID).mkString
      val smallInt = Random.alphanumeric.filter(_.isDigit).take(SMALLINT_ID).mkString
      val decimal = Random.alphanumeric.filter(_.isDigit).take(DECIMAL).mkString

      if(i==1) {
        finalFile = recordType+Delimiter+eventType+Delimiter+record+Delimiter+bigInt+Delimiter+
          smallInt+Delimiter+decimal+Delimiter+DATE+Delimiter+TIMESTAMP
      }
      else {
        finalFile = finalFile+"\n"+recordType+Delimiter+eventType+Delimiter+record+Delimiter+bigInt+Delimiter+
          smallInt+Delimiter+decimal+Delimiter+DATE+Delimiter+TIMESTAMP
      }

    }

    writeFile(filePath,filename,finalFile)
  }


  def randomFixedDelimitedFileGeneration(PUBLICNUMBER:Int,SERVICESTATUSCODE:Int,PENDINGFLAG:Int,CANCELPENDINGFLAG:Int,generateLines:Int,
                                         filePath:String,filename:String,header:Boolean,trailer:Boolean): Unit =
  {

    val headerLine = "HDRIPNDUPRASS1000000520200217014124"
    val trailerLine = "TRL0000005202002170141240000010"
    var finalFile = ""

    if(header) finalFile = finalFile+headerLine
    for(i <- 1 to generateLines)
    {
      val publicNo = Random.alphanumeric.filter(_.isDigit).take(PUBLICNUMBER).mkString.toUpperCase()
      val statusCode = Random.alphanumeric.filter(_.isLetter).take(SERVICESTATUSCODE).mkString.toUpperCase()
      val pendingFlag = Random.alphanumeric.filter(_.isLetter).take(PENDINGFLAG).mkString.toUpperCase()
      val cancelPendingFlag = Random.alphanumeric.filter(_.isLetter).take(CANCELPENDINGFLAG).mkString.toUpperCase()


      if(i==1 & !header) {
        finalFile = publicNo+statusCode+pendingFlag+cancelPendingFlag
      }
      else {
        finalFile = finalFile+"\n"+publicNo+statusCode+pendingFlag+cancelPendingFlag
      }

    }

    if(trailer) finalFile = finalFile+"\n"+trailerLine
    writeFile(filePath,filename,finalFile)
  }

  val data = "{\n  \"Scope\": {\n    \"SourceSystem\": \"RAAS\",\n    \"TableName\": \"test_data\",\n    \"SSU\": \"retail\",\n    \"SourceSystemId\": 0\n  },\n  \"File\": {\n    \"FilePatternName\": \"upload*\",\n    \"FileExtensions\": [\"dat\",\"eot\"],\n    \"FileSourceLocation\": \"/ipnd/src/land\",\n    \"CompressionType\": \"NULL\",\n    \"CharacterSet\": \"ASCII\",\n    \"HeaderLines\": 1,\n    \"TrailerLines\": 1,\n    \"FileStructureType\": \"FIXED-DELIMITED\",\n    \"FileStructure\": {\n      \"FieldDelimiter\": \"\",\n      \"RecordLength\": 9,\n      \"RecordDelimiter\": \"\\n\"\n    },\n\t\"OutputFormat\": \"parquet\",\n    \"SequenceEnforced\": true\n  },\n  \"SourceColumns\": [\n    {\n      \"ColumnName\": \"PUBLICNUMBER\",\n      \"DataType\": \"VARCHAR\",\n      \"MaxLength\": 5,\n      \"Nullable\": false,\n      \"Offset\": [\n        1,\n        5\n      ]\n    },\n    {\n      \"ColumnName\": \"SERVICESTATUSCODE\",\n      \"DataType\": \"VARCHAR\",\n      \"MaxLength\": 1,\n      \"Nullable\": false,\n      \"Offset\": [\n        6,\n        6\n      ]\n    },\n    {\n      \"ColumnName\": \"PENDINGFLAG\",\n      \"DataType\": \"VARCHAR\",\n      \"MaxLength\": 1,\n      \"Nullable\": false,\n      \"Offset\": [\n        7,\n        7\n      ]\n    },\n    {\n      \"ColumnName\": \"CANCELPENDINGFLAG\",\n      \"DataType\": \"VARCHAR\",\n      \"MaxLength\": 1,\n      \"Nullable\": false,\n      \"Offset\": [\n        8,\n        8\n      ]\n    }\n  ],\n  \"LightKeys\": {\n    \"GeneratedLightKeys\": [],\n    \"AliasedLightKeys\": []\n  },\n  \"IntegrationKeys\": [],\n  \"CDC\": {\n    \"ChangeType\": \"Insertonly\",\n    \"col_ChangeKeys\": [\n      \"PUBLICNUMBER\"\n    ],\n    \"sql_EffectiveDttm\": \"\",\n    \"sql_EffectiveDttmFirst\": \"\"\n  }\n}"


  def generateTempJson(filePath:String,fileName:String): Unit ={
    val dir = new File(filePath)
    if(!dir.exists()) dir.mkdir()
    val fileExists = new File("filePath+fileName").exists()
    if(!fileExists){
      val file = new File(filePath+fileName)
      val bw = new BufferedWriter(new FileWriter(file))
      bw.write(data)
      bw.close()
    }
  }

  def deleteRecursively(file: String): Unit = {
    val filenames = new File(file)
    filenames.listFiles().foreach(r=>r.delete())

  }
  val absolutePath = new File("src/test/resources").getCanonicalPath+"/"

}
