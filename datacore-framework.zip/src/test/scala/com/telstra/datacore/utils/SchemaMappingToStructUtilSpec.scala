package com.telstra.datacore.utils

import com.telstra.datacore.metadata.{SourceColumn, SourceColumnFormat}
import org.scalatest.funsuite.AnyFunSuite

class SchemaMappingToStructUtilSpec extends AnyFunSuite{

  val sourceColumnFormatspec = SourceColumnFormat(Some("test"),None,None)
  val sourceColumnFormatDecimal = SourceColumnFormat(Some("test"),None,Some("5"))
  val sourceColumnFormatTimeStamp = SourceColumnFormat(Some("test"),Some("25"),Some("5"))
  val sourceColumnDateFormat = SourceColumnFormat(Some("yyyyMMdd"),Some("5"),None)

  test("SchemaMapping test case"){
    SchemaMappingToStructUtil.getDecimalType(20,Some(sourceColumnFormatspec))
    SchemaMappingToStructUtil.getDecimalType(20,Some(sourceColumnFormatDecimal))
    SchemaMappingToStructUtil.getDecimalType(20,Some(sourceColumnFormatTimeStamp))
  }

  val dataType = List("VARCHAR","CHAR","INTEGER","BIGINT","SMALLINT")
  test("DataType Validate cases"){
    for(i<- dataType)
      {
        val sourceColumnspec = SourceColumn("test",i,5,false,Some(List(1,2,3)),Some(sourceColumnFormatspec))
        i match {
          case "VARCHAR"=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
          case "CHAR"=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
          case "INTEGER"=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
          case "BIGINT"=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
          case "TIMESTAMP"=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
          case "SMALLINT"=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
          case "DATE"=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
          case dataType=>SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspec))
      }
    }
  }

  test("Decimal DataType Validate"){
    val sourceColumnspecdec = SourceColumn("test","DECIMAL",5,false,Some(List(1,2,3)),Some(sourceColumnFormatDecimal))
    SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnspecdec))
  }

  test("TimeStamp validation"){
    val sourceColumnFormatTime = SourceColumn("test","TIMESTAMP",5,false,Some(List(1,2,3)),Some(sourceColumnFormatTimeStamp))
    SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnFormatTime))
  }

  test("Date Format validation"){
    val sourceColumnFormatTime = SourceColumn("test","dataType",5,false,Some(List(1,2,3)),Some(sourceColumnFormatspec))
    try
      {
        SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnFormatTime))
      }
      catch {
        case e:IllegalArgumentException=>("Data Type not defined")
      }

  }

  test("DataType"){

    val sourceColumnFormatTime =  SourceColumn("DATE_INFO","DATE",8,false,Some(List(16,23)),Some(SourceColumnFormat(Some("yyyyMMdd"),Some("5"),None)))
    SchemaMappingToStructUtil.createSchemaFromSourceColumns(Seq(sourceColumnFormatTime))
  }

}
