package com.telstra.datacore.utils

import org.scalatest.funsuite.AnyFunSuite

class ConfigurationPathUtilSpec extends AnyFunSuite{

  test("should match the staging path")
  {
    val actual = ConfigurationPathUtil.stagingTablePath("E01","retail","RAAS","test")
//    val expected = "data"+"/"+"E01"+"/"+"SDS"+"/"+"inbound"+"/"+"staging"+"/"+"retail"+"/"+"raas"+"/"+"test"
//    assert(actual==expected)
  }

  test("should match the landing path")
  {
    val actual = ConfigurationPathUtil.landingFilePath("E01","retail","RAAS","test")
//    val expected = "data"+"/"+"E01"+"/"+"SDS"+"/"+"inbound"+"/"+"landing"+"/"+"retail"+"/"+"raas"+"/"+"test"
//    assert(actual==expected)
  }

  test("should match Odate format"){
    ConfigurationPathUtil.datePath("20210808")
  }

  test("should match archival path"){
    val actual = ConfigurationPathUtil.archivePath("E01","retail","RAAS","test","20210808")
//    val expected = "data"+"/"+"E01"+"/"+"SDS"+"/"+"inbound"+"/"+"arch"+"/"+"retail"+"/"+"raas"+"/"+"test"+"/"+"2021"+"/"+"8"+"/"+"8"
//    assert(actual==expected)
  }

  test("scope folder name should match"){
    val retail = ConfigurationPathUtil.ssuFolderName("retail")
    ConfigurationPathUtil.ssuFolderName("wholesale")
    ConfigurationPathUtil.ssuFolderName("transient")
    ConfigurationPathUtil.ssuFolderName("enterprise")
    assert("retail"==retail)
  }

}
