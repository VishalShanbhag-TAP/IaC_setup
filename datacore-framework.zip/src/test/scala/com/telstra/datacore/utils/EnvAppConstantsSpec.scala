package com.telstra.datacore.utils

import org.scalatest.funsuite.AnyFunSuite

class EnvAppConstantsSpec extends AnyFunSuite{

  val metadbInfo = EnvAppConstants.MetadataDBProperties("test","test","key","pass")
  test("Metadata Properties test"){
    EnvAppConstants.MetadataDBProperties("test","test","key","pass")
  }


  val KVScopeSPKeyinfo = EnvAppConstants.KVScopeSPKey("ipnd-databricks-scope","databricks-mount-sp-client-id","databricks-mount-sp-client-secret","databricks-mount-sp-tenant-id")
  test("KVScope Scope Properties test"){
    EnvAppConstants.KVScopeSPKey("ipnd-databricks-scope","databricks-mount-sp-client-id","databricks-mount-sp-client-secret","databricks-mount-sp-tenant-id")
  }

  var envList = List("E01","PRD")
  test("get metadata properties"){
    EnvAppConstants.getMetadataDBProperties()
  }

  test("get Service Principle properties"){
    EnvAppConstants.getServicePrincipalProperties()
  }



}
