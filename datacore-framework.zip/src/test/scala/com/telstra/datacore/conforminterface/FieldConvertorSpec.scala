package com.telstra.datacore.conforminterface

import com.telstra.datacore.metadata.{SourceColumn, SourceColumnFormat}
import org.scalatest.funsuite.AnyFunSuite

class FieldConvertorSpec extends AnyFunSuite{


  test("Convert String Field cases"){
    FieldConverter.convertStringField(true,20)
  }


  //    SourceColumn("DATE_INFO","DATE",6,false,Some(List(16,21))),
  val sourcedefcolumns = List(
    SourceColumn("RECORD_TYPE","VARCHAR",3,false,Some(List(1,3))),
    SourceColumn("EVENT_TYPE_ID","CHAR",3,false,Some(List(4,6))),
    SourceColumn("ID","INTEGER",2,false,Some(List(6,7))),
    SourceColumn("ID_NUM","BIGINT",2,false,Some(List(8,9))),
    SourceColumn("TEMP","DECIMAL",6,false,Some(List(10,15)),Some(SourceColumnFormat(None,None,Some("5")))),
    SourceColumn("DATE_INFO","DATE",6,false,Some(List(16,21)),Some(SourceColumnFormat(Some("20210108"),Some("5"),None))),
    SourceColumn("DATE_INFO","TIMESTAMP",6,false,Some(List(16,21)),Some(SourceColumnFormat(Some("20210108"),Some("5"),None))),
    SourceColumn("NUM_ID","SMALLINT",2,false,Some(List(22,23)))
  )

  val unknownDatatype = List(SourceColumn("test","DATATYPE",2,false,Some(List(1,2))))

    test("Row Convertor test case"){
      RowConverter.fromMetadata(sourcedefcolumns)

      try {
        RowConverter.fromMetadata(unknownDatatype)
      }
      catch {
        case e:Exception=> "Unhandled DataType"
      }
    }


}
