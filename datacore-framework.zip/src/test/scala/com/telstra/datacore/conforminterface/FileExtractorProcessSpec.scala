package com.telstra.datacore.conforminterface

import org.scalatest.funsuite.AnyFunSuite

class FileExtractorProcessSpec extends AnyFunSuite{

  test("extenstion seperator test without .") {
    FileExtractorProcess.addExtensionSeperator("ctl")
    FileExtractorProcess.addExtensionSeperator("")
  }

  val listOfFiles = List(".ctl",".eot",".dat")
  val emptyListOfFiles = List()
  val allset = List("ctl","eot","CTL","EOT","DAT")
  val nonEmpty = List("ste")
  test("extension Map test"){
    FileExtractorProcess.extensionMap(listOfFiles)
    FileExtractorProcess.extensionMap(emptyListOfFiles)
    FileExtractorProcess.extensionMap(allset)
    FileExtractorProcess.extensionMap(nonEmpty)
  }

}
