package com.telstra.datacore.conforminterface

import com.telstra.datacore.metadata.{ControlFileField}
import org.scalatest.funsuite.AnyFunSuite
import java.text.SimpleDateFormat

class ControlFileSpec extends AnyFunSuite{

  val date= new SimpleDateFormat("yyyyMMdd")
  val now = date.parse("20170928")
  val controlFile = ControlFile(10,now,"test",1234,"IPND","test")
  test("Control File test"){
    ControlFile(10,now,"test",1234,"IPND","test")
  }

  val delimitedString = "3|20210825024252|180019|cmp_5490_cmpmedldr_20210726_180019_lxapp4628|3|CMP|4"
  val controlfilefieldextractdateinfo =List(
    ControlFileField("RECORD_COUNT",None),
    ControlFileField("EXTRACT_DATE",Some("yyyyMMddHHmmss")),
    ControlFileField("EXTRACT_TIME",Some("HHmmss")),
    ControlFileField("FILE_NAME",None),
    ControlFileField("BATCH_ID",None),
    ControlFileField("SOURCE_SYSTEM",None),
    ControlFileField("MD5",None))

  test("Delimited String test case"){
    ControlFile.fromDelimitedString(delimitedString,"|",controlfilefieldextractdateinfo,"RASS")
  }


  test("Delimited String error test case"){
    val delimitedStringerr = "3|20210726|180019|cmp_5490_cmpmedldr_20210726_180019_lxapp4628|3|CMP|4|4"
    try {
      ControlFile.fromDelimitedString(delimitedStringerr,"|",controlfilefieldextractdateinfo,"RASS")
    }
    catch {
      case e:IllegalArgumentException=>"Control file size and number of fields specified did not match"
    }
  }

  test("Record count must me Integer test case"){
    val delimitedStringRecCounterr = "ab|20210726|180019|cmp_5490_cmpmedldr_20210726_180019_lxapp4628|3|CMP|4"
    try{
      ControlFile.fromDelimitedString(delimitedStringRecCounterr,"|",controlfilefieldextractdateinfo,"RASS")
    }
    catch {
      case e:IllegalArgumentException=>"Control file size and number of fields specified did not match"
    }
  }

  test("BatchId must me Integer test case"){
    val delimitedStringBatchIderr = "3|20210726|180019|cmp_5490_cmpmedldr_20210726_180019_lxapp4628|ab|CMP|4"
    try{
      ControlFile.fromDelimitedString(delimitedStringBatchIderr,"|",controlfilefieldextractdateinfo,"RASS")
    }
    catch {
      case e:IllegalArgumentException=>"Control file size and number of fields specified did not match"
    }
  }


  test("DateTime test case"){
    try
      {
        ControlFile.convertToDate("123123","342344")
      }
    catch {
      case e:IllegalArgumentException=>"Format supplied for DATE/TIME was incorrect"
    }
  }



}
