package com.telstra.datacore.metadata

import com.telstra.datacore.apps.TestFileGeneration
import org.scalatest.funsuite.AnyFunSuite
import scala.io.Source

class ArgumentConfigurationSpec extends AnyFunSuite{

  val absolutePath = TestFileGeneration.absolutePath
  val jsonFilePath = absolutePath+"test.json"
  TestFileGeneration.generateTempJson(absolutePath,"test.json")
  val jsons = Source.fromFile(jsonFilePath).mkString
//  test("Argument json Success Run"){
//      ArgumentConfiguration.parse(jsons)
//  }

  test("Argument json erro"){
    try{
      ArgumentConfiguration.parse("abds")
    }
    catch {
      case e:Exception=>"Failed"
    }
  }

}
