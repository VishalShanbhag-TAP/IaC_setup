package com.telstra.datacore.metadata

import org.scalatest.BeforeAndAfterAll
import org.scalatest.funsuite.AnyFunSuite
import java.time

class ArgumentsConfigurationSpec extends AnyFunSuite with  BeforeAndAfterAll{

  val FileStruct: FileStructure = FileStructure(Some("Pipe"),905,"\n")
  val sourceColumnFormatspec: SourceColumnFormat = SourceColumnFormat(Some("test"),None,None)
  val sourceColumnspec: SourceColumn = SourceColumn("test","VARCHAR",5,nullable = false,Some(List(1,2,3)),Some(sourceColumnFormatspec))
  val FileInfonfixed: File = File("cmp_*_cmpmedmer_*",List("dat","ctl"),"gz","ISO",1,1,"FIXED",FileStruct,"csv",SequenceEnforced = true,Some("Daily"))
  val controlfilefiledList = List(ControlFileField("RECORD_COUNT",None),ControlFileField("EXTRACT_DATE",Some(time.LocalDateTime.now().getDayOfMonth.toString)))

  test("Scope case class"){
    Scope("IPND","ABC","RETAIL",1234)
  }

  test("Scope class failure case"){
    try{
      Scope("IPND","ABC","ABCD",1234)
    }
    catch {
      case e:IllegalArgumentException=>"SSU can be one of: Retail, Wholesale, Transient, Enterprise, Corporate"
    }
  }

  test("FileStructure case class"){
    FileStructure(Some("Pipe"),905,"\n")
  }

  test("Testing File case class"){
    File("cmp_*_cmpmedmer_*",List("dat","ctl"),"gz","ISO",1,1,"Delimited",FileStruct,"csv",SequenceEnforced = true,Some("Daily"))
  }

   test("file info failure case header"){
    try {
      File("cmp_*_cmpmedmer_*",List("dat","ctl"),"gz","ISO",-1,-1,"Delimited",FileStruct,"csv",SequenceEnforced = true,Some("Daily"))
    }
    catch {
      case e:IllegalArgumentException=>"HeaderLines should be greater than zero"
    }
  }

  test("file info failure case trailer"){
    try {
      File("cmp_*_cmpmedmer_*",List("dat","ctl"),"gz","ISO",1,-1,"Delimited",FileStruct,"csv",SequenceEnforced = true,Some("Daily"))
    }
    catch {
      case e:IllegalArgumentException=>"TrailerLines should be greater than zero"
    }
  }


  test("Control File case class for record count"){
    ControlFileField("RECORD_COUNT",None)
  }


  test("Control File case class for EXTRACT_DATE") {
    try{
      ControlFileField("EXTRACT_DATE", None)
    }
    catch {
      case e:IllegalArgumentException=>"DATE, DATETIME or TIME then format cannot be empty"
    }
  }

  test("Control File case class for EXTRACT_TIME") {
    try{
      ControlFileField("EXTRACT_TIME", None)
    }
    catch {
      case e:IllegalArgumentException=>"DATE, DATETIME or TIME then format cannot be empty"
    }
  }

  test("Control File case class for EXTRACT_DATETIME") {
    try{
      ControlFileField("EXTRACT_DATETIME", None)
    }
    catch {
      case e:IllegalArgumentException=>"DATE, DATETIME or TIME then format cannot be empty"
    }
  }

  test("Control file format positive case"){
    ControlFileFormat("Pipe",controlfilefiledList)
    }

  test("Control file format DATE case"){

    try{
       ControlFileFormat("Pipe",List(ControlFileField("RECORD_COUNT",None)))
    }
    catch {
       case e:IllegalArgumentException=>"Must contain either a DATE or DATETIME"
    }
  }

  test("Control file format RecordCount case"){
    try{
      ControlFileFormat("Pipe",List(ControlFileField("EXTRACT_DATE",Some(time.LocalDateTime.now().getDayOfMonth.toString))))
    }
    catch {
      case e:IllegalArgumentException=>"Must contain either a DATE or DATETIME"
    }
  }


  test("Souce Columns format case class test"){
      SourceColumnFormat(Some("test"),None,None)
  }


  test("Source column test case"){
    SourceColumn("test","yymmdd",5,nullable = false,Some(List(1,2,3)),Some(sourceColumnFormatspec))
  }

  test("Source column containing white space"){
    try
      {
        SourceColumn("test ","yymmdd",5,nullable = false,Some(List(1,2,3)),Some(sourceColumnFormatspec))
      }
    catch {
      case e:IllegalArgumentException=>"ColumnName cant have white spaces"
    }
  }

  test("SourceColumn: When source column datatype is TimeStamp,Date or Date Time, Format cannot be empty"){
    try
    {
      SourceColumn("test","DATE",5,nullable = false,Some(List(1,2,3)),Some( SourceColumnFormat(None,None,None)))
    }
    catch {
      case e:IllegalArgumentException=>"ColumnName cant have white spaces"
    }
  }

  test("SourceColumn: When source column TimeStamp Format,timezone cannot be empty"){
    try
    {
      SourceColumn("test","TIMESTAMP",5,nullable = false,Some(List(1,2,3)),Some( SourceColumnFormat(None,None,None)))
    }
    catch {
      case e:IllegalArgumentException=>"ColumnName cant have white spaces"
    }
  }


  test("SourceColumn: When source column datatype is Decimal,SourceColumnFormat decimal place cannot be empty"){
    try
    {
      SourceColumn("test","DECIMAL",5,nullable = false,Some(List(1,2,3)),Some( SourceColumnFormat(None,None,None)))
    }
    catch {
      case e:IllegalArgumentException=>"ColumnName cant have white spaces"
    }
  }

  val ScopeClass: Scope = Scope("IPND","ABC","RETAIL",1234)
  val FileInfo: File = File("cmp_*_cmpmedmer_*",List("dat","ctl"),"gz","ISO",1,1,"Delimited",FileStruct,"csv",SequenceEnforced = true,Some("Daily"))
  val controlFileFormatInfo: ControlFileFormat = ControlFileFormat("Pipe",controlfilefiledList)
  val argumentConfigurationspec: ArgumentsConfiguration = ArgumentsConfiguration(ScopeClass,FileInfo,Some(controlFileFormatInfo),Some(List(sourceColumnspec)))

  test("Argument configuration test class"){
    ArgumentsConfiguration(ScopeClass,FileInfo,Some(controlFileFormatInfo),Some(List(sourceColumnspec)))
  }


  test("Argument configuration no ctl") {
    try{
      ArgumentsConfiguration(ScopeClass, FileInfonfixed, None, Some(List(sourceColumnspec)))
    }
    catch {
      case e:IllegalArgumentException=>"FileExtensions contains ctl and a control file exists then Schema.ControlFile must be specified"
    }
  }


  test("Argument configuration for FIXED") {
    val sourceColumnspecOffsetNone = SourceColumn("test","VARCHAR",5,nullable = false,None,Some(sourceColumnFormatspec))
    try{
       ArgumentsConfiguration(ScopeClass, FileInfonfixed, Some(controlFileFormatInfo), Some(List(sourceColumnspecOffsetNone)))
    }
    catch {
      case e:IllegalArgumentException=>"FileExtensions contains ctl and a control file exists then Schema.ControlFile must be specified"
    }
  }


  test("Argument configuration for FIXED-DELIMITED") {
    val FileInfonfixeddelimited = File("cmp_*_cmpmedmer_*",List("dat","ctl"),"gz","ISO",1,1,"DELIMITED-FIXED",FileStruct,"csv",SequenceEnforced = true,Some("Daily"))
    val sourceColumnspecOffsetNone = SourceColumn("test","VARCHAR",5,nullable = false,None,Some(sourceColumnFormatspec))
    try{
      ArgumentsConfiguration(ScopeClass, FileInfonfixeddelimited, Some(controlFileFormatInfo), Some(List(sourceColumnspecOffsetNone)))
    }
    catch {
      case e:IllegalArgumentException=>"FileExtensions contains ctl and a control file exists then Schema.ControlFile must be specified"
    }
  }
}
