package com.telstra.datacore.services

import com.telstra.datacore.conforminterface.FileRegistrationId
import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.SparkSession
import org.scalatest.funsuite.AnyFunSuite


class PostgresDBServiceSpec extends AnyFunSuite {

  val spark = SparkSession.builder().appName("test").master("local").getOrCreate()
  val sparkContext = spark.sparkContext
  val config = new Configuration(sparkContext.hadoopConfiguration)
  val columns = Seq("id","file_name","record_count","sequence","status")
  val invalidcolumns = Seq("id","file_nam","record_count","sequence","status")
  val data = Seq(
    (1, "TEST_20121212_10",5,10,"copied"),
    (2, "TEST_20121212_11",8,11,"copied"),
    (3, "TEST_20121212_12",4,12,"copied")
  )
  var df = spark.createDataFrame(data).toDF(columns:_*)
  var invalidColumnDf = spark.createDataFrame(data).toDF(invalidcolumns:_*)

  test("Test File registration ID test"){
    FileRegistrationId.getFileRegID(df,"TEST_20121212_12")
  }

  test("Test Fileregistration for Invalid Pattern name"){
    try
    {
      FileRegistrationId.getFileRegID(df,"TEST_20121212")
    }
    catch {
      case e:Exception=>("FilePattern name not present")
    }
  }

  test("Test Fileregistration for Invalid column name"){
    try {
      FileRegistrationId.getFileRegID(invalidColumnDf,"TEST_20121212_12")
    }
    catch {
      case e:Exception=>("FilePattern name not present")
    }
  }

}
