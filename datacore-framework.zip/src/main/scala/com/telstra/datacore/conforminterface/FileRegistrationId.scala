package com.telstra.datacore.conforminterface

import org.apache.spark.internal.Logging
import org.apache.spark.sql.{AnalysisException, DataFrame}
import org.apache.spark.sql.functions.col

object FileRegistrationId extends Logging{

  // Get file regristrtion id from Postresql
  def getFileRegID(df:DataFrame,filePattern:String): (Int, Int) = {
    try {
      val fileRegisterFilter = df.select("id", "sequence").filter(col("file_name") === filePattern)
      val fileRegId = fileRegisterFilter.take(1)(0).getAs[Int]("id")
      val sequence = fileRegisterFilter.take(1)(0).getAs[Int]("sequence")
      logInfo("[APP_LOG] fileRegistration : " + fileRegId)
      logInfo("[APP_LOG] sequence : " + sequence)
      (fileRegId, sequence)
    }
    catch {
            case  e:AnalysisException =>
              throw new Exception("Spark Invaild Info : "+e.getMessage)
            case  e:Exception =>
              throw new Exception("Invalid Pattern : "+e.getMessage)
          }
  }

}
