package com.telstra.datacore.conforminterface

import com.telstra.datacore.Logging
import com.telstra.datacore.metadata.SourceColumn
import org.apache.spark.rdd.RDD
import java.util.Properties

object ValidateRecordset extends Logging {

    val errorLimit = 100

    def convertRDD(records: RDD[(Long, Seq[String])],
                   sourceColumns: Seq[SourceColumn]): Either[RDD[String],RDD[(Long,Seq[Any])]] = {

      val validators = RowConverter.fromMetadata(sourceColumns)
      val convertedRecords = records.map {
        RowConverter.convert(validators, _)
      }

      val errors = convertedRecords.filter(_.isLeft).flatMap(_.left.get)

      if(errors.count < 1){
        Right(convertedRecords.filter(_.isRight).map(_.right.get))
      } else {
        Left(errors)
      }
    }

    @throws(classOf[IllegalArgumentException])
    def apply(records: RDD[(Long, Seq[String])],
              sourceColumns: Seq[SourceColumn],props:Properties,jobId:String,taskId:String): RDD[(Long, Seq[Any])] = {

      val result = convertRDD(records,sourceColumns)

      if(result.isLeft){
        val errorMessages = result.left.get.take(errorLimit)
        val errorCount = result.left.get.count
        val unshownErrors = errorCount - errorLimit

          logger.error("Field Validation Failed:")
        errorMessages.map(x => f"- $x").foreach(logger.error(_))
        if(unshownErrors > 0){
          logger.error(f"$unshownErrors additional errors")
        }
        throw new IllegalArgumentException(s"Field Validation Failed: ${errorMessages.head}")
      }
      result.right.get
    }
}