package com.telstra.datacore.conforminterface

import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.io.{BytesWritable, LongWritable}
import org.apache.hadoop.mapreduce.lib.input.FixedLengthInputFormat
import org.apache.spark.internal.Logging
import java.nio.ByteBuffer
import java.nio.charset.{Charset, CodingErrorAction}


object FixedWidthFile extends Serializable with Logging{
  def loadRecords(sparkContext: SparkContext,
                  filePath: String,
                  recordLength: Int,
                  headerCount: Int,
                  footerCount: Int): RDD[(Array[Byte], Long)] = {
    val fixedWidthInputConfiguration = new Configuration(sparkContext.hadoopConfiguration)
    fixedWidthInputConfiguration.setInt(FixedLengthInputFormat.FIXED_RECORD_LENGTH, recordLength)

    val records = sparkContext.newAPIHadoopFile(filePath,
      classOf[FixedLengthInputFormat],
      classOf[LongWritable],
      classOf[BytesWritable],
      fixedWidthInputConfiguration)
      .map { case (_, bytesWritable) => bytesWritable.getBytes.map(identity) }
      .zipWithIndex

    (headerCount, footerCount) match {
      case (0, 0) => records
      case _ => {
        val firstIndex = headerCount
        val lastIndex = records.count - footerCount - 1

        records.filter { case (record, index) => index >= firstIndex && index <= lastIndex }
      }
    }

  }

  def splitRecords(records: RDD[(Array[Byte], Long)],
                   offsets: Seq[(Int, Int)],
                   characterSet: String): RDD[(Long, Seq[String])] = {
    records.map { case (bytes, index) =>
      // Offsets are defined as 1-based and inclusive
      // .slice is 0-based and exclusive of end
      val fields = offsets.map { case (start, end) => bytes.slice(start-1, end) }
      val decoder = Charset.forName(characterSet).newDecoder
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)

      try {
        (index, fields.map(field => decoder.decode(ByteBuffer.wrap(field)).toString))
      } catch {
        case mie: java.nio.charset.MalformedInputException => {
          logInfo(s"Failed character decoding from $characterSet on line $index")
          throw new IllegalArgumentException(s"Failed character decoding from $characterSet on line $index")
        }
      }
    }
  }
}