package com.telstra.datacore.conforminterface

import com.telstra.datacore.metadata.SourceColumn

object RowConverter {

    def fromMetadata(columnDefs:Seq[SourceColumn]):Seq[String => Either[String,Any]] = {
      columnDefs map {
        case SourceColumn(_,"VARCHAR",maxLength,nullable,_,_) => FieldConverter.convertStringField(nullable, maxLength)
        case SourceColumn(_,"CHAR",maxLength,nullable,_,_) => FieldConverter.convertStringField(nullable, maxLength)
        case SourceColumn(_,"INTEGER",_,nullable,_,_) => FieldConverter.convertIntegerField(nullable)
        case SourceColumn(_,"BIGINT",_,nullable,_,_) => FieldConverter.convertBigIntegerField(nullable)
        case SourceColumn(_,"DECIMAL",_,nullable,_,_) => FieldConverter.convertNumericField(nullable)
        case SourceColumn(_,"TIMESTAMP",_,nullable,_,format) => FieldConverter.convertTimestampField(nullable, format.get.mask.get)
        case SourceColumn(_,"DATE",_,nullable,_,format) => FieldConverter.convertDateField(nullable, format.get.mask.get)
        case SourceColumn(_,"SMALLINT",_,nullable,_,_) => FieldConverter.convertSmallIntegerField(nullable)
        case SourceColumn(_,dataType,_,_,_,_) => throw new Exception("Unhandled Data Type Encountered in Field Validation: "+ dataType)
      }
    }

    def convert(validators:Seq[String => Either[String,Any]],row:(Long,Seq[String])):Either[Seq[String],(Long,Seq[Any])] = {

      val validatorCount = validators.size
      val rowNum = row._1 + 1
      val rowData = row._2

      val results = validators.zip(rowData).map {
        case (v,dat) => v(dat)
      }

      if (rowData.size != validatorCount) {
        val fieldCount = rowData.size
        Left(Seq(s"Row:$rowNum - Field count $fieldCount, expected $validatorCount"))

      } else if (results.forall(_.isRight)) {
        Right( (row._1,results.map(_.right.get)) )

      } else {
        val errSeq = results.zipWithIndex.flatMap {
          case(Left(errm),col:Int) => Seq(s"Row:$rowNum, Col:${col+1} - $errm")
          case _ => Seq()
        }
        Left(errSeq)
      }
    }
}