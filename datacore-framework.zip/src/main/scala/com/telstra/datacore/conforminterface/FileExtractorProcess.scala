package com.telstra.datacore.conforminterface

object FileExtractorProcess {

  def addExtensionSeperator(ext:String): String = {
    if(ext.isEmpty) ext
    else if (ext.startsWith(".")) ext
    else "." + ext
  }

  def extensionMap(fileExtensions: Seq[String]): List[Option[String]] = {

    if(fileExtensions.isEmpty) return List(Some(""), None, None)

    val dataExtension = fileExtensions.diff(Seq("ctl","eot","CTL","EOT")).headOption.map(addExtensionSeperator)
    val ctlExtension = fileExtensions.intersect(Seq("ctl","CTL")).headOption.map(addExtensionSeperator)
    val eotExtension = fileExtensions.intersect(Seq("eot","EOT")).headOption.map(addExtensionSeperator)
    require(dataExtension.nonEmpty,"No data extension found in schema")
    List(dataExtension,ctlExtension,eotExtension)
  }

}
