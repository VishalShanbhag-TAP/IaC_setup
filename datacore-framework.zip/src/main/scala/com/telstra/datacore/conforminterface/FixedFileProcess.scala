package com.telstra.datacore.conforminterface

import com.telstra.datacore.apps.FileProcess
import com.telstra.datacore.metadata.ArgumentsConfiguration
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object FixedFileProcess extends FileProcess {
  def loadRecords(ss: SparkSession, filePath: String, argumentsConfig:ArgumentsConfiguration): RDD[(Array[Byte], Long)] = {
    FixedWidthFile.loadRecords(ss.sparkContext,
      filePath,
      argumentsConfig.file.fileStructure.recordLength,
      argumentsConfig.file.headerLines,
      argumentsConfig.file.trailerLines)
  }

  def splitRecords(ss: SparkSession, records: RDD[(Array[Byte], Long)],argumentsConfig:ArgumentsConfiguration): RDD[(Long, Seq[String])] = {
    val offsets = argumentsConfig.sourceColumns match {
      case Some(sc) =>
        val offsetVal = sc.map(cols => (cols.offset.get(0), cols.offset.get(1)))
        offsetVal
      case None => throw new Exception("SourceColumns Not Provided")
    }

    FixedWidthFile.splitRecords(records,
      offsets,
      argumentsConfig.file.characterSet)
  }
}