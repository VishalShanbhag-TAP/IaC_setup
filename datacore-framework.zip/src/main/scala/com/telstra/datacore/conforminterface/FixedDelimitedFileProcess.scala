package com.telstra.datacore.conforminterface

import com.telstra.datacore.apps.FileProcess
import com.telstra.datacore.metadata.ArgumentsConfiguration
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object FixedDelimitedFileProcess extends FileProcess {
  override def loadRecords(ss: SparkSession, filePath: String, argumentsConfig:ArgumentsConfiguration): RDD[(Array[Byte], Long)] = {

    val rdd = DelimitedFile.loadRecords(ss.sparkContext,
      filePath,
      argumentsConfig.file.fileStructure.recordDelimiter,
      argumentsConfig.file.characterSet,
      argumentsConfig.file.headerLines,
      argumentsConfig.file.trailerLines)

    val recordLength = argumentsConfig.file.fileStructure.recordLength
    logInfo("record length "+recordLength)
    val badRecordsRDD: RDD[(Array[Byte], Long)] = rdd.filter(r => r._1.map(_.toChar).mkString.length!= recordLength)

    if (!badRecordsRDD.isEmpty) {
      throw new IllegalArgumentException("Record length is shorter than length specified in the schema")
    }

    rdd
  }

  override def splitRecords(ss: SparkSession, records: RDD[(Array[Byte], Long)],argumentsConfig:ArgumentsConfiguration): RDD[(Long, Seq[String])] = {
    val offsets = argumentsConfig.sourceColumns match {
      case Some(sc) => {
        val offsetVal = sc.map(cols => (cols.offset.get(0), cols.offset.get(1)))
        offsetVal
      }
      case None => throw new Exception("SourceColumns Not Provided")
    }

    FixedWidthFile.splitRecords(records,
      offsets,
      argumentsConfig.file.characterSet)
  }
}