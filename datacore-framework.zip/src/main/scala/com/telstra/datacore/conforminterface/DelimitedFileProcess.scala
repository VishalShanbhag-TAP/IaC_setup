package com.telstra.datacore.conforminterface

import com.telstra.datacore.apps.FileProcess
import com.telstra.datacore.metadata.ArgumentsConfiguration
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object DelimitedFileProcess extends FileProcess {

   override protected def loadRecords(ss: SparkSession, filePath: String, argumentsConfig: ArgumentsConfiguration): RDD[(Array[Byte], Long)] = {
      DelimitedFile.loadRecords(ss.sparkContext,
         filePath,
         argumentsConfig.file.fileStructure.recordDelimiter,
         argumentsConfig.file.characterSet,
         argumentsConfig.file.headerLines,
         argumentsConfig.file.trailerLines)
   }

   override protected def splitRecords(ss: SparkSession, records: RDD[(Array[Byte], Long)], argumentsConfig: ArgumentsConfiguration): RDD[(Long, Seq[String])] = {
      DelimitedFile.splitRecords(records,
         argumentsConfig.file.fileStructure.fieldDelimiter,
         argumentsConfig.file.characterSet)
   }
}