package com.telstra.datacore.conforminterface

import com.telstra.datacore.metadata.ControlFileField

import java.text.SimpleDateFormat
import java.util.regex.Pattern
import org.apache.spark.internal.Logging

  case class ControlFile(
                          expectedRecordCount: Int,
                          extractDateTime: java.util.Date,
                          extractFileName: String,
                          batchId: Int,
                          sourceSystem: String,
                          md5: String
                        )

  object ControlFile extends Logging {

    def fromDelimitedString(delimitedString: String, fieldDelimiter: String, controlFileFields: List[ControlFileField], source: String): ControlFile = {
      logInfo("[APP_LOG] Field Delimiter "+ fieldDelimiter)
      val quotedFieldDelimiter = Pattern.quote(fieldDelimiter)
      val controlFileContent = delimitedString.split(quotedFieldDelimiter, -1).toList

      logInfo(s"[APP_LOG] - Control File Content: " + controlFileContent)

      require(controlFileContent.size == controlFileFields.size,
        s"Control file size (${controlFileContent.size}) and number of fields specified (${controlFileFields.size}) did not match"
      )

      val controlFileMap = controlFileFields.zip(controlFileContent).map {
        case (field, content) => field.columnName -> (field.format, content)
      }.toMap

      logInfo(s"[APP_LOG] - Control File Map: " + controlFileMap)

      val expectedRecordCount = try {
        fieldExtractor(controlFileMap, "RECORD_COUNT").get.trim.toInt
      } catch {
        case exn: NumberFormatException => throw new IllegalArgumentException("Value supplied for Record Count in control file must be a number")
      }

      logInfo(s"[APP_LOG] - Expected Record Count: " + expectedRecordCount)

      val extractDateTime = dateFieldExtractor(controlFileMap)
      val extractFileName = fieldExtractor(controlFileMap, "FILE_NAME").getOrElse("EXTRACT.DAT")

      logInfo(s"[APP_LOG] - Expected File Name: " + extractFileName)

      val batchId = try {
        fieldExtractor(controlFileMap, "BATCH_ID").getOrElse("-1").toInt
      } catch {
        case exn: NumberFormatException => throw new IllegalArgumentException("Value supplied for Batch ID in control file must be a number")
      }

      logInfo(s"[APP_LOG] - Batch Id: " + batchId)

      val sourceSystem = fieldExtractor(controlFileMap, "SOURCE_SYSTEM").getOrElse(source)
      val md5 = fieldExtractor(controlFileMap, "MD5").getOrElse("0")

      logInfo(s"[APP_LOG] - Source System Id: " + sourceSystem)
      logInfo(s"[APP_LOG] - MD5: " + md5)

      ControlFile(expectedRecordCount, extractDateTime, extractFileName, batchId, sourceSystem, md5)
    }

    def fieldExtractor(controlFileMap: Map[String, (Option[String], String)], fieldName: String): Option[String] = {
      controlFileMap.get(fieldName).flatMap {
        case (_, content: String) => Some(content)
      }
    }

    def dateFieldExtractor(controlFileMap: Map[String, (Option[String], String)]): java.util.Date = {
      val extractDate = controlFileMap.get("EXTRACT_DATE")
      val extractDateTime = controlFileMap.get("EXTRACT_DATETIME")
      val extractTime = controlFileMap.getOrElse("EXTRACT_TIME", (Some("HH:mm:ss"), "00:00:00"))

      logInfo(s"[APP_LOG] - Extract Date: " + extractDate)
      logInfo(s"[APP_LOG] - Extract Date Time: " + extractDateTime)
      logInfo(s"[APP_LOG] - Extract Time: " + extractTime)

      if (extractDateTime.nonEmpty) {
        extractDateTime.get match {
          case (Some(format), dateTime) => convertToDate(dateTime, format)
          case _ => throw new IllegalArgumentException("if ControlFile.Fields is DATETIME then format cannot be empty")
        }
      } else if (extractDate.nonEmpty) {
        extractDate.get match {
          case (Some(format), date) =>
            val (timeFormat, time) = extractTime match {
              case (Some(timeStampFormat), timeStamp) => (timeStampFormat, timeStamp)
              case _ => throw new IllegalArgumentException("if ControlFile.Fields is TIME then format cannot be empty")
            }
            val dateTime = List(date, time).mkString
            val dateTimeFormat = List(format, timeFormat).mkString

            logInfo(s"[APP_LOG] - Date Time: " + dateTime)
            logInfo(s"[APP_LOG] - Date Time Format: " + dateTimeFormat)

            convertToDate(dateTime, dateTimeFormat)
          case _ => throw new IllegalArgumentException("if ControlFile.Fields is DATE then format cannot be empty")
        }
      } else {
        throw new IllegalArgumentException("ControlFile.Fields must contain either a DATE or DATETIME")
      }
    }

    def convertToDate(value: String, format: String): java.util.Date = {
      val formatter = new SimpleDateFormat(format)
      formatter.setLenient(false)

      logInfo(s"[APP_LOG] - Value: " + value)
      logInfo(s"[APP_LOG] - Format: " + format)

      try {
        formatter.parse(value)
      } catch {
        case exn: java.text.ParseException =>
          throw new IllegalArgumentException("Format supplied for DATE/TIME was incorrect")
      }
    }
}