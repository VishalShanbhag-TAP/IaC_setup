package com.telstra.datacore.conforminterface

import java.sql.Timestamp
import java.time.{LocalDate, LocalDateTime}
import java.time.format.DateTimeFormatterBuilder
import java.time.temporal.ChronoField
import scala.util.{Either, Failure, Left, Right, Success}


object FieldConverter extends Serializable {

  val emptyValueError = "Null or Empty Value in Non-Nullable Field"

  def convertStringField(isNullable: Boolean, maxLength: Integer): String => Either[String,String] = {
    (field: String) => {
      if (isNullable && field.trim.length == 0) Right(null)
      else if (!isNullable && field.trim.length == 0) Left(emptyValueError)
      else if (field.length > maxLength) Left("Column Length Exceeds Maximum")
      else Right(field)
    }
  }

  def convertIntegerField(isNullable: Boolean): String => Either[String,Integer] = {
    (field: String) => {
      if (isNullable && field.trim.length == 0) Right(null)
      else if (!isNullable && field.trim.length == 0) Left(emptyValueError)
      else scala.util.Try(field.trim.toInt) match {
        case Success(v) => Right(v)
        case Failure(_) => Left("Not a valid Integer")
      }
    }
  }

  //impala cannot read Parquet Short
  def convertSmallIntegerField(isNullable: Boolean): String => Either[String,Integer] = {
    (field: String) => {
      if (isNullable && field.trim.length == 0) Right(null)
      else if (!isNullable && field.trim.length == 0) Left(emptyValueError)
      else scala.util.Try(field.trim.toShort.toInt) match {
        case Success(v) => Right(v)
        case Failure(_) => Left("Not a valid SmallInt")
      }
    }
  }

  def convertBigIntegerField(isNullable: Boolean): String => Either[String,java.lang.Long] = {
    (field: String) => {
      if (isNullable && field.trim.length == 0) Right(null)
      else if (!isNullable && field.trim.length == 0) Left(emptyValueError)
      else scala.util.Try(field.trim.toLong) match {
        case Success(v) => Right(v)
        case Failure(_) => Left("Not a valid BigInt")
      }
    }
  }

  def convertNumericField(isNullable: Boolean): String => Either[String,BigDecimal] = {
    (field: String) => {
      if (isNullable && field.trim.length == 0) Right(null)
      else if (!isNullable && field.trim.length == 0) Left(emptyValueError)
      else scala.util.Try(new java.math.BigDecimal(field.trim)) match {
        case Success(v) => Right(v)
        case Failure(_) => Left("Not a valid Numeric")
      }
    }
  }

  def convertTimestampField(isNullable: Boolean, format: String): String => Either[String,String] = {
    (field: String) => {
      if (isNullable && field.trim.length == 0) Right(null)
      else if (!isNullable && field.trim.length == 0) Left(emptyValueError)
      else if (field.length != format.length) Left("Pattern Length does not match field length")
      else {
        val formatter = caseInsensitiveFormatter(format)
        val datePattern = "yyyy-MM-dd HH:mm:ss"
        val formatter1 = new DateTimeFormatterBuilder().appendPattern(datePattern).optionalStart // optional decimal point followed by 1 to 6 digits
          .appendPattern(".").appendFraction(ChronoField.MICRO_OF_SECOND, 1, 6, false).optionalEnd.toFormatter

        scala.util.Try( LocalDateTime.parse(field,formatter) ) match {
          case Success(v) => scala.util.Try(formatter1.format(v)) match {
            case Success(value) => Right(value)
            case Failure(_) => Left("Not a valid Timestamp Value")
          }
          case Failure(_) => Left("Input datetime does not match the given format")
        }
      }
    }
  }

  def convertDateField(isNullable: Boolean, format: String): String => Either[String,java.sql.Timestamp] = {
    (field: String) => {

      if (isNullable && field.trim.length == 0) Right(null)
      else if (!isNullable && field.trim.length == 0) Left("Null or Empty Value in Non-Nullable Field")
      else if (field.length != format.length) Left("Pattern Length does not match field length")
      else {
        //val formatter = DateTimeFormatter.ofPattern(format) //.withResolverStyle(ResolverStyle.STRICT)
        val formatter = caseInsensitiveFormatter(format)
        scala.util.Try( Timestamp.valueOf( LocalDate.parse(field,formatter).atStartOfDay() ) ) match {
          case Success(v) => Right(v)
          case Failure(_) => Left("Not a valid Date")
        }
      }
    }
  }

  private

  def caseInsensitiveFormatter(format: String) = {
    new DateTimeFormatterBuilder()
      .parseCaseInsensitive()
      .appendPattern(format)
      .toFormatter()
  }
}