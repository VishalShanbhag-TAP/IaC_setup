package com.telstra.datacore.conforminterface

import com.telstra.datacore.lib.ByteDelimitedTextInputFormat
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.io.{LongWritable, Text}
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD

import java.nio.ByteBuffer
import java.nio.charset.{Charset, CodingErrorAction}
import java.util.regex.Pattern
import org.apache.spark.internal.Logging

object DelimitedFile extends Serializable with Logging {

  def loadRecords(sparkContext: SparkContext,
                  filePath: String,
                  recordDelimiter: String,
                  characterSet: String,
                  headerCount: Int,
                  footerCount: Int): RDD[(Array[Byte], Long)] = {


    logInfo(s"[APP_LOG] - Data File Path: " + filePath)
    logInfo(s"[APP_LOG] - Record Delimiter: " + recordDelimiter)

    val textInputConfiguration = new Configuration(sparkContext.hadoopConfiguration)

      textInputConfiguration.set("bytedelimitedtextinputformat.record.delimiter", recordDelimiter)
      textInputConfiguration.set("bytedelimitedtextinputformat.record.delimiter.charset", characterSet)

    val records = sparkContext.newAPIHadoopFile(filePath,
      classOf[ByteDelimitedTextInputFormat],
      classOf[LongWritable],
      classOf[Text],
      textInputConfiguration)
      .map { case (_, text) => text.getBytes}
      .zipWithIndex

    logInfo("[APP-LOG] - record count "+records.count())
    (headerCount, footerCount) match {
      case (0, 0) => records
      case _ => {
        val firstIndex = headerCount
        val lastIndex = records.count - footerCount - 1

        records.filter { case (record, index) => index >= firstIndex && index <= lastIndex }
      }
    }
  }

  def splitRecords(records: RDD[(Array[Byte], Long)],
                   fieldDelimiter: Option[String],
                   characterSet: String): RDD[(Long, Seq[String])] = {
    records.map { case (bytes, index) =>

      val charset = Charset.forName(characterSet)
      val decoder = charset.newDecoder
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)
      val fieldDelimiterString:String = fieldDelimiter.get

      try {
        val decodedRecord = decoder.decode(ByteBuffer.wrap(bytes)).toString
        (index, decodedRecord.split(Pattern.quote(fieldDelimiterString),-1): Seq[String])
      } catch {
        case mie: java.nio.charset.MalformedInputException => {
          throw new IllegalArgumentException(s"Failed character decoding from $characterSet on line $index")
        }
      }

    }
  }
}