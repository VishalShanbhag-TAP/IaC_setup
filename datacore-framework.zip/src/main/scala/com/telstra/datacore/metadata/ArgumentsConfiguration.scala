package com.telstra.datacore.metadata

object setBoolean{
  val setBoolean = true

}
case class Scope(sourceSystem: String, tableName: String, ssu: String, sourceSystemId: Int) {
  require(Set("RETAIL", "WHOLESALE", "TRANSIENT", "ENTERPRISE", "CORPORATE").contains(ssu.toUpperCase),
    "SSU can be one of: Retail, Wholesale, Transient, Enterprise, Corporate")
  val ssuCharacter: String = ssu.toUpperCase.take(1)
}

case class FileStructure(fieldDelimiter: Option[String], recordLength: Int, recordDelimiter: String)

case class File(filePatternName: String, fileExtensions: List[String], compressionType: String, characterSet: String, headerLines: Int, trailerLines: Int, fileStructureType: String, fileStructure: FileStructure, outputFormat:String, SequenceEnforced: Boolean, multiDaily:Option[String]) {
  require (headerLines>=0, "File.HeaderLines should be greater than zero")
  require (trailerLines>=0, "File.TrailerLines should be greater than zero")
}

case class ControlFileField(columnName: String, format: Option[String] = None) {
  require ({if (columnName == "EXTRACT_DATE" || columnName == "EXTRACT_TIME" || columnName == "EXTRACT_DATETIME") format.nonEmpty
  else setBoolean.setBoolean}, "if ControlFile.Fields is DATE, DATETIME or TIME then format cannot be empty")
}

case class ControlFileFormat(delimiter: String, controlFileFields: List[ControlFileField]) {
  require (controlFileFields.exists{_.columnName == "RECORD_COUNT"}, "ControlFile.Fields must contain record count")
  require (controlFileFields.exists{_.columnName == "EXTRACT_DATE"} || controlFileFields.exists{_.columnName == "EXTRACT_DATETIME"},
    "ControlFile.Fields must contain either a DATE or DATETIME")
}

case class SourceColumnFormat(mask: Option[String] = None, timeZone: Option[String] = None, decimalPlace: Option[String] = None)

case class SourceColumn(columnName: String, dataType: String, maxLength: Int, nullable:Boolean, offset: Option[List[Int]] = None, format: Option[SourceColumnFormat] = None) {
  require (columnName.indexOf(' ') == -1, "SourceColumns.ColumnName cant have white spaces")
  require ({ if (Set("timestamp", "date", "decimal").contains(dataType.toLowerCase)) format.nonEmpty
  else setBoolean.setBoolean}, "if SourceColumns.dataType is TIMESTAMP, DATE or DECIMAL then SourceColumns.Format must exist")
  require ({if ("date".contains(dataType.toLowerCase)) format.get.mask.nonEmpty
  else setBoolean.setBoolean}, "if SourceColumns.dataType is DATE, then SourceColumns.Format.Mask cant be empty")
  require ({if ("timestamp".contains(dataType.toLowerCase)) format.get.mask.nonEmpty && format.get.timeZone.nonEmpty
  else setBoolean.setBoolean}, "if SourceColumns.dataType is TIMESTAMP, then the SourceColumns.Format.Mask and SourceColumns.Format.TimeZone cant be empty")
  require ({if ("decimal".contains(dataType.toLowerCase)) format.get.decimalPlace.nonEmpty
  else setBoolean.setBoolean}, "if SourceColumns.dataType is DECIMAL, then the SourceColumns.Format.DecimalPlace cant be empty")
}

case class ArgumentsConfiguration(scope: Scope, file: File, controlFileFormat: Option[ControlFileFormat] = None, sourceColumns: Option[List[SourceColumn]]) {
  require ({if (file.fileExtensions.contains("ctl")) controlFileFormat.nonEmpty
  else setBoolean.setBoolean}, "if Schema.File.FileExtensions contains ctl and a control file exists then Schema.ControlFile must be specified")
  require ({if (file.fileStructureType == "FIXED" || file.fileStructureType == "DELIMITED-FIXED") sourceColumns.get.exists(_.offset.nonEmpty)
  else setBoolean.setBoolean}, "if Schema.File.FileStructureType is FIXED or DELIMITED FIXED then Schema.SourceColumns.offset must be specified")
}