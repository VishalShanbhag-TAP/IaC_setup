package com.telstra.datacore.metadata

import org.apache.log4j.LogManager
import play.api.libs.functional.syntax._
import play.api.libs.json._
import javax.management.InvalidAttributeValueException

object ArgumentConfiguration {

  val logger = LogManager.getLogger(getClass.getName)

  implicit val scopeReads : Reads[Scope] =(
    (JsPath \ "SourceSystem").read[String] and
      (JsPath \ "TableName").read[String] and
      (JsPath \ "SSU").read[String] and
      (JsPath \ "SourceSystemId").read[Int]
    )(Scope)

  implicit val fileStructureReads : Reads[FileStructure] = (
    (JsPath \ "FieldDelimiter").readNullable[String] and
      (JsPath \ "RecordLength").read[Int] and
      (JsPath \  "RecordDelimiter").read[String]
  )(FileStructure)

  implicit val fileReads:Reads[File]  = (
    (JsPath \ "FilePatternName").read[String] and
      (JsPath \ "FileExtensions").read[List[String]] and
      (JsPath \ "CompressionType").read[String] and
      (JsPath \ "CharacterSet").read[String] and
      (JsPath \ "HeaderLines").read[Int] and
      (JsPath \ "TrailerLines").read[Int] and
      (JsPath \ "FileStructureType").read[String] and
      (JsPath \ "FileStructure").read[FileStructure] and
      (JsPath \ "OutputFormat").read[String] and
      (JsPath \ "SequenceEnforced").read[Boolean] and
      (JsPath \ "MultiDaily").readNullable[String]
    ) (File)

  implicit val controlFileFieldReads: Reads[ControlFileField] = (
    (JsPath \ "ColumnName").read[String] and
      (JsPath \ "Format").readNullable[String]
  )(ControlFileField)

  implicit val controlFileFormatReads: Reads[ControlFileFormat] = (
    (JsPath \ "Delimiter").read[String] and
      (JsPath \ "Fields").read[List[ControlFileField]]
  )(ControlFileFormat)

  implicit val sourceColumnFormatReads : Reads[SourceColumnFormat] = (
    (JsPath \ "Mask").readNullable[String] and
      (JsPath \ "TimeZone").readNullable[String] and
      (JsPath \ "DecimalPlace").readNullable[String]
    ) (SourceColumnFormat)

  implicit val sourceColumnReads:Reads[SourceColumn] = (
    (JsPath \ "ColumnName").read[String] and
      (JsPath \ "DataType").read[String] and
      (JsPath \ "MaxLength").read[Int] and
      (JsPath \ "Nullable").read[Boolean] and
      (JsPath \ "Offset").readNullable[List[Int]] and
      (JsPath \ "Format").readNullable[SourceColumnFormat]
  )(SourceColumn)
   implicit val argumentsConfigurationReads:Reads[ArgumentsConfiguration] = (
     (JsPath \ "Scope").read[Scope] and
       (JsPath \"File").read[File] and
       (JsPath \ "ControlFile").readNullable[ControlFileFormat] and
       (JsPath \ "SourceColumns").readNullable[List[SourceColumn]]
   )(ArgumentsConfiguration)


  def parse(json: String) = {
    Json.parse(json).validate[ArgumentsConfiguration] match {
      case JsSuccess(value, path) => value
      case JsError(errors) => {
        logger.error(s"JSON Parsing Error:$errors")
        throw new InvalidAttributeValueException()
      }
    }
  }
}