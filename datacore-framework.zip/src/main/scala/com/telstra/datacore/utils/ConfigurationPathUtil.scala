package com.telstra.datacore.utils

import java.nio.file.Paths

object ConfigurationPathUtil {

  def ssuFolderName(ssu: String): String = ssu match {
    case "retail" => "retail"
    case "wholesale" => "wholesale"
    case "transient" => "transient"
    case "enterprise" => "reference"
  }

  def stagingTablePath(environmentName: String, ssu: String, sourceSystem: String, tableName: String): String = {
    Paths.get(
      "app_root",
      "bidh",
      "data",
      environmentName,
      "SDS",
      "staging",
      ssuFolderName(ssu).toLowerCase,
      sourceSystem.toLowerCase,
      tableName.toLowerCase
    ).toString
  }

  def landingFilePath(environmentName: String, ssu: String, sourceSystem: String, tableName: String): String = {
    Paths.get(
      "app_root",
      "bidh",
      "data",
      environmentName,
      "SDS",
      "landing",
      ssuFolderName(ssu).toLowerCase,
      sourceSystem.toLowerCase,
      tableName.toLowerCase
    ).toString
  }

  def datePath(oDate:String): (String, String, String) = {
    val dateFormat = "yyyyMMdd"
    val dtf = java.time.format.DateTimeFormatter.ofPattern(dateFormat)
    val dateString = oDate

    val dateInput = java.time.LocalDate.parse(dateString, dtf)
    val year = dateInput.getYear.toString
    var month = dateInput.getMonthValue.toString
    var day = dateInput.getDayOfMonth.toString
    if(month.length ==1) month = 0+month else year
    if(day.length ==1) day = 0+day else year
    (year,month,day)
  }

  def archivePath(environmentName: String, ssu: String, sourceSystem: String, tableName: String,oDate:String): String = {
    Paths.get(
      "app_root",
      "bidh",
      "data",
      environmentName,
      "SDS",
      "arch",
      ssuFolderName(ssu).toLowerCase,
      sourceSystem.toLowerCase,
      tableName.toLowerCase,
      datePath(oDate)._1,
      datePath(oDate)._2,
      datePath(oDate)._3
    ).toString
  }

}