package com.telstra.datacore.utils

import com.telstra.datacore.Logging

object EnvAppConstants extends Logging{

  case class MetadataDBProperties(dbName:String,userName:String, kvScopeName:String, dbPassKey:String)
  case class KVScopeSPKey(scopeName:String, clientIdKey:String, clientSecretKey:String,tenantId:String)

  val keyScope = "datacore-akv-scope"

  def getMetadataDBProperties(): MetadataDBProperties = {

    val dbName = "datacore-adb-postgres-hostname"
    val userName = "datacore-adb-postgres-user"
    val kvScopeName = keyScope
    val dbPassKey = "datacore-adb-postgres-accesstoken"
    MetadataDBProperties(dbName,userName,kvScopeName,dbPassKey)
  }

  def getServicePrincipalProperties():KVScopeSPKey = {

    val scopeName = keyScope
    val clientIdKey = "databricks-mount-sp-client-id"
    val clientSecretKey = "databricks-mount-sp-client-secret"
    val tenantIdKey = "databricks-mount-sp-tenant-id"

    KVScopeSPKey(scopeName = scopeName, clientIdKey = clientIdKey, clientSecretKey = clientSecretKey, tenantId = tenantIdKey)
  }
}