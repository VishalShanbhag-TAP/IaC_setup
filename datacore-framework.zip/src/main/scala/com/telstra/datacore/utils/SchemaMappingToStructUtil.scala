package com.telstra.datacore.utils

import com.telstra.datacore.metadata.{SourceColumn, SourceColumnFormat}
import org.apache.spark.sql.types._

object SchemaMappingToStructUtil {



  def getDecimalType(maxLength: Int, format: Option[SourceColumnFormat]): DecimalType = {
    (maxLength, format) match {
      case (i, Some(SourceColumnFormat(_, _, Some(decimalPlace)))) => DecimalType(i, decimalPlace.toInt)
      case (i, Some(SourceColumnFormat(_, _, None))) => DecimalType(i, 0)
      case (i, _) => DecimalType(i, 0)
    }
  }

  /** Map the given datatypes to the spark datatypes and create the Struct type,
   *  that can be used to apply the schema to the incoming files
   *  call this method with columns/source columns definition to get the spark struct type schema definition back*/

  def createSchemaFromSourceColumns(columnDefinitions: Seq[SourceColumn]) = {
    val convertedStructFiled = columnDefinitions.map(_ match {
      case SourceColumn(name, "VARCHAR", maxLength, nullable, _, _) => StructField(name = name, dataType = StringType, nullable = nullable)
      case SourceColumn(name, "CHAR", maxLength, nullable, _, _) => StructField(name = name, dataType = StringType, nullable = nullable)
      case SourceColumn(name, "INTEGER", maxLength, nullable, _, _) => StructField(name = name, dataType = IntegerType, nullable = nullable)
      case SourceColumn(name, "BIGINT", maxLength, nullable, _, _) => StructField(name = name, dataType = LongType, nullable = nullable)
      case SourceColumn(name, "DECIMAL", maxLength, nullable, _, format) => StructField(name = name, dataType = getDecimalType(maxLength, format), nullable = nullable)
      case SourceColumn(name, "TIMESTAMP", maxLength, nullable, _, _) => StructField(name = name, dataType = TimestampType, nullable = nullable)
      case SourceColumn(name, "DATE", maxLength, nullable, _, _) => StructField(name = name, dataType = DateType, nullable = nullable)
      case SourceColumn(name, "SMALLINT", maxLength, nullable, _, _) => StructField(name = name, dataType = IntegerType, nullable = nullable)
      case SourceColumn(name, dataType, maxLength, nullable, _, _) => throw new IllegalArgumentException(s"DataType not defined for schema Conversio $dataType")
    })
    StructType(convertedStructFiled)
  }

}