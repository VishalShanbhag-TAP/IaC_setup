package com.telstra.datacore.services

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils

object AzureKeyVaultService {

  /* Function to retrive specific KeyVault Secret @param credentialScope Scope of obtaining the Secrets
    @param key key id of the secret
     @return secret value as string
   */
  def getAppKeyVltSecret(credentialScope: String, key: String): String = {
    dbutils.secrets.get(scope = credentialScope, key = key)
  }
}