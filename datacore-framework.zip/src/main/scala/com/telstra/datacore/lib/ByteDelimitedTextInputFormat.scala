package com.telstra.datacore.lib

import org.apache.hadoop.io.{LongWritable, Text}
import org.apache.hadoop.mapreduce.{InputSplit, RecordReader, TaskAttemptContext}
import org.apache.hadoop.mapreduce.lib.input.{LineRecordReader, TextInputFormat}

import java.nio.charset.Charset

class ByteDelimitedTextInputFormat extends TextInputFormat {
  override def createRecordReader(split: InputSplit, context: TaskAttemptContext): RecordReader[LongWritable, Text] = {
    val delimiter = context.getConfiguration.get("bytedelimitedtextinputformat.record.delimiter")
    val delimiterCharset = context.getConfiguration.get("bytedelimitedtextinputformat.record.delimiter.charset");
    val recordDelimiterBytes = new LineRecordReader(delimiter.getBytes(Charset.forName(delimiterCharset)));
    recordDelimiterBytes
  }
}