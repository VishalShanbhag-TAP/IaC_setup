package com.telstra.datacore

import org.apache.log4j.LogManager
/** Base logging class and to be used in application for application logging  */

trait Logging {
  protected val logger = LogManager.getLogger(getClass.getName)

}