package com.telstra.datacore.apps

import org.apache.spark.SparkConf
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession

import java.util.Properties

/**
 * Trait that provides the management of a SparkSession
 */
trait SparkUtils extends Logging {

  @transient private var _sparkSession: SparkSession = _

  /**
   * Returns a single accessible SparkSession
   *
   * @param props
   * @tparam T this is for serializerClass, which is of type Class[T]
   * @return Spark session
   */
  def getSparkSession[T](props: Properties): SparkSession = {

    val jobName = props.getProperty("jobName")

    val conf = new SparkConf()
    conf.setAppName(jobName)
    _sparkSession = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()

    sparkSession
  }

  def sparkSession: SparkSession = _sparkSession
}
