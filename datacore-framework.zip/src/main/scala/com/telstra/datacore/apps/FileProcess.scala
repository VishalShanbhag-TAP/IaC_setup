package com.telstra.datacore.apps

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils
import ConformInterface.sparkSession
import com.telstra.datacore.conforminterface.{ControlFile, FileExtractorProcess, FileRegistrationId, ValidateRecordset}
import com.telstra.datacore.metadata.ArgumentsConfiguration
import com.telstra.datacore.services.AzureKeyVaultService
import com.telstra.datacore.utils.{ConfigurationPathUtil, SchemaMappingToStructUtil}
import org.apache.spark.internal.Logging
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{DataTypes, StructField, IntegerType}
import org.apache.spark.sql.{AnalysisException, DataFrame, Row, SparkSession}
import play.api.libs.json.{JsValue, Json}

import java.sql.SQLException
import java.util.Properties
import javax.xml.bind.DatatypeConverter

trait FileProcess extends Logging {

  def apply(spark: SparkSession, argumentsConfig: ArgumentsConfiguration, environment: String, oDate: String, jobId: String, taskId: String, props: Properties): Unit = {

    //Get the schema for the file from the Schema.json file.
    val fileSchema = SchemaMappingToStructUtil.createSchemaFromSourceColumns(argumentsConfig.sourceColumns.get)
    //Add the line number column for each file
    val appendLineNumberToSchema = fileSchema.add(StructField("FILELINENUMBER", DataTypes.LongType, nullable = false))
    val appendFileId = appendLineNumberToSchema.add(StructField("fileRegId", DataTypes.LongType, nullable = false))

    // Create empty dataframe with the file structure with line number column
    var combinedDf: DataFrame = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], appendFileId)
    if (argumentsConfig.file.SequenceEnforced) {
      combinedDf = combinedDf.withColumn("sequence", lit(null).cast(IntegerType))
    }

    //Get the landing path for the given Interface/Files
    val landingPath: String = ConfigurationPathUtil.landingFilePath(
      environment,
      argumentsConfig.scope.ssu,
      argumentsConfig.scope.sourceSystem,
      argumentsConfig.scope.tableName
    )

    //Get the staging path to write the converted Dataframes from the given file/schema
    val stagingPath: String = ConfigurationPathUtil.stagingTablePath(
      environment,
      argumentsConfig.scope.ssu,
      argumentsConfig.scope.sourceSystem,
      argumentsConfig.scope.tableName
    )

    val archivePath: String = ConfigurationPathUtil.archivePath(
      environment,
      argumentsConfig.scope.ssu,
      argumentsConfig.scope.sourceSystem,
      argumentsConfig.scope.tableName,
      oDate
    )

    val fileExtensions: Seq[String] = argumentsConfig.file.fileExtensions
    val extensionList = FileExtractorProcess.extensionMap(fileExtensions)

    val dataFileExtension: String = extensionList(0).get
    val ctlListExtension: Option[String] = extensionList(1)
    logInfo("[APP_LOG] - ctlListExtension : " + ctlListExtension)

    // File registration table
    val fileRegTable = "file_registrations"
    // File name column

    val kvScopeName = props.getProperty("kvScopeName")
    val decodedJsonValue = AzureKeyVaultService.getAppKeyVltSecret(kvScopeName,"datacore-storage-accounts")

    def getContainerName(decodedJson:String) = {
      val base64Decoded = DatatypeConverter.parseBase64Binary(decodedJson)
      val jsonStr = new String(base64Decoded)

      val json: JsValue = Json.parse(jsonStr)
      var url = (json \ "dataStorageAccount" \ "url").get.toString()
      var container = (json \ "dataStorageAccount" \ "container").get.toString()
      url = url.substring(9, url.length - 1)
      container = container.substring(1, container.length - 1)
      (url,container)
    }

    val storageAccountUrl = getContainerName(decodedJsonValue)._1
    val storageContainerName = getContainerName(decodedJsonValue)._2
    val adlsUrl = s"abfss://$storageContainerName@$storageAccountUrl"
    logInfo("[APP_LOG] - adls url : "+adlsUrl)
    //Get the file name from landing path
    val landingFilePath = s"$adlsUrl/$landingPath"
    val stagingFilePath = s"$adlsUrl/$stagingPath"
    val archivalFilePath = s"$adlsUrl/$archivePath/"
    logInfo(s"[APP_LOG] - landingFilePath : " + landingFilePath)
    logInfo(s"[APP_LOG] - stagingFilePath : " + stagingFilePath)
    logInfo(s"[APP_LOG] - archivalFilePath : " + archivalFilePath)

    // Connecting to Database
    val conn = PostgresDBService.establishConnection(props)._1
    val fileRegistration = PostgresDBService.establishConnection(props)._2
    val batchStatement = conn.createStatement()
    logInfo(s"[APP_LOG] - landingFilePath : " + landingFilePath)

    // Updated recordcount and validation status
    def updateValidationStatus(filePattern: String, recordcount: Long, fileRegId: Int, status: String): Unit = {
      val recupdate = s"UPDATE $fileRegTable SET record_count = $recordcount, status = '$status' where file_name = '$filePattern'"
      logInfo("[APP_LOG] - " + recupdate)
      batchStatement.addBatch(recupdate)
    }

    // Execute the bactch statement and close connection
    def executeSqlQuery(): Unit = {
      try {
        batchStatement.executeBatch()
        conn.close()
      }
      catch {
        case e: SQLException =>
          throw new Exception("Invaild credentials : " + e.getMessage)
        case e: AnalysisException =>
          throw new Exception("Spark Invaild Info : " + e.getMessage)
        case e: Exception =>
          throw new Exception("Invalid Pattern : " + e.getMessage)
      }
    }

    def dataArchive(landingPath: String, archivalPath: String): Unit = {
      try {
        // Check if directory exists or not by listing
        dbutils.fs.ls(archivalPath)
        logInfo("[APP_LOG] - Path exists, Archive data")

        // Archival of data
        dbutils.fs.mv(landingPath, archivalPath, true)
        logInfo("[APP_LOG] - Data archived")
      }
      catch {
        case e: Exception =>
          logInfo("[APP_LOG] - Path not exists,create Directory")

          // Create directory if not exists
          dbutils.fs.mkdirs(archivalPath)
          // Archival of data
          dbutils.fs.mv(landingPath, archivalPath, true)
          logInfo("[APP_LOG] - Data archived")
      }
    }

    val listOfLandingFiles = dbutils.fs.ls(landingFilePath).map(_.name)

    if(listOfLandingFiles.length !=0)
      {
        listOfLandingFiles.map(file => {
          //Check if the ".dat" exist in the landing path
          if (file.contains(dataFileExtension)) {

            val dataFilePath = s"""$landingFilePath/$file"""
            val loadedRecords = loadRecords(spark, dataFilePath, argumentsConfig)
            val loadedRecordCount = loadedRecords.count()
            val filePattern = file.substring(0, file.lastIndexOf("."))

            var fileRegId = 0
            var sequence = 0
            fileRegId = FileRegistrationId.getFileRegID(fileRegistration, filePattern)._1
            sequence = FileRegistrationId.getFileRegID(fileRegistration, filePattern)._2
            logInfo("[APP_LOG] - fileRegId - " + fileRegId)
            logInfo("[APP_LOG] - Source System " + argumentsConfig.scope.sourceSystem)

            val controlFileName = file.replace(dataFileExtension, ".ctl")

            def recordCountValidation(fileName: String) = {
              val ctlFilePath = s"""$landingFilePath/$fileName"""
              logInfo("[APP_LOG] - ctlFilePath : " + ctlFilePath)
              val ctlFilesName = dbutils.fs.ls(ctlFilePath).map(_.name)
              logInfo("[APP_LOG] - ctlFilesName : " + ctlFilesName)

              //Check ".ctl" file exist for the given data file
              ctlFilesName.foreach(ctlfile => {
                val controlFileDetails = ControlFile.fromDelimitedString(spark.sparkContext.textFile(ctlFilePath).take(1)(0)
                  , argumentsConfig.controlFileFormat.get.delimiter
                  , argumentsConfig.controlFileFormat.get.controlFileFields
                  , argumentsConfig.scope.sourceSystem)

                val expectedRecordCount = controlFileDetails.expectedRecordCount

                if (expectedRecordCount == loadedRecordCount) {
                  logInfo(s"[APP_LOG] - Expected Record Count : " + expectedRecordCount)
                  logInfo("[APP_LOG] - Record count validation successful")
                } else {
                  updateValidationStatus(filePattern, loadedRecordCount, fileRegId, "validation_failed")
                  executeSqlQuery()
                  throw new Exception("Record validation failed with control file record count")
                }
              })
            }

            // If control file extension exists validate control count against data count

            if (ctlListExtension != None) {
              logInfo("[APP_LOG] - ctlFiles")
              val ctlFileExtension: String = ctlListExtension.get
              val fileName = file.replace(dataFileExtension, ctlFileExtension)
              recordCountValidation(fileName)
            }

            else if (ctlListExtension == None & listOfLandingFiles.contains(controlFileName)) {
              recordCountValidation(controlFileName)
            }
            else {
              throw new Exception("Control file validation conditions not matching")
            }

            //Split the incoming records to Separate columns.
            val splitLoadedRecords = splitRecords(spark, loadedRecords, argumentsConfig)

            //Validate the incoming columns against respective datatypes
            val validatedFields = ValidateRecordset(splitLoadedRecords, argumentsConfig.sourceColumns.get, props, jobId, taskId)
            updateValidationStatus(filePattern, loadedRecordCount, fileRegId, "validation_success")
            //Converting  (a:string,b:String) => Row(a:String,b:String) because only rows can be converted to Dataframe
            val convertToRowType = validatedFields.map(r => r._2 :+ (r._1 + 1)).map(Row.fromSeq)

            val convertedDfTemp = spark.createDataFrame(convertToRowType, appendLineNumberToSchema)
            var convertedDf = sparkSession.emptyDataFrame
            if (argumentsConfig.file.SequenceEnforced) {
              convertedDf = convertedDfTemp.withColumn("FILEID", lit(fileRegId)).withColumn("SEQUENCE", lit(sequence))
            }
            else {
              convertedDf = convertedDfTemp.withColumn("FILEID", lit(fileRegId))
            }

            // Append the data frame for each iteration
            combinedDf = convertedDf.union(combinedDf)

          }
        })

        logInfo("[APP_LOG] - Total records processed : " + combinedDf.count())
        // Update the Postgres db with record count and validation success status
        executeSqlQuery()
        // Persist the data to parquet file
        val finalloc = s"""$stagingFilePath"""
        combinedDf.coalesce(1).write.mode("overwrite").format("parquet").save(finalloc)

        logInfo("[APP_LOG] - Archival Process Started")
        // Archive data
        listOfLandingFiles.map(file => {
          dataArchive(landingFilePath + "/" + file, archivalFilePath)
          logInfo("[APP_LOG] - File moved : " + file)
        })
      }
    else throw new Exception("[APP_LOG] - No Files to process in landing folder")
  }

  protected def loadRecords(sc: SparkSession
                            , filePath: String
                            , argumentsConfig: ArgumentsConfiguration): RDD[(Array[Byte], Long)]

  protected def splitRecords(sc: SparkSession
                             , records: RDD[(Array[Byte], Long)]
                             , argumentsConfig: ArgumentsConfiguration): RDD[(Long, Seq[String])]
}
