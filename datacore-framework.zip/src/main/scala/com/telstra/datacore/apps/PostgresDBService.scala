package com.telstra.datacore.apps

import com.telstra.datacore.apps.ConformInterface.sparkSession
import com.telstra.datacore.services.AzureKeyVaultService
import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame

import java.sql.{Connection, DriverManager}
import java.util.Properties
import java.util.concurrent.Executors
import com.microsoft.aad.adal4j.{AuthenticationContext, ClientCredential}

object PostgresDBService extends Logging {

  def establishConnection(props: Properties): (Connection, DataFrame) = {
    try
      {
        val kvScopeName = props.getProperty("kvScopeName")
        val dbName = AzureKeyVaultService.getAppKeyVltSecret(kvScopeName, props.getProperty("dbName"))
        val userName = AzureKeyVaultService.getAppKeyVltSecret(kvScopeName,props.getProperty("userName"))
        val ClientId =  AzureKeyVaultService.getAppKeyVltSecret(kvScopeName, "datacore-adb-sp-client-id")
        val ClientSecret =  AzureKeyVaultService.getAppKeyVltSecret(kvScopeName, "datacore-adb-sp-client-secret")
        val TenantId = AzureKeyVaultService.getAppKeyVltSecret(kvScopeName, "datacore-azure-tenant-id")

        //  Get access token
        val authority = "https://login.windows.net/" + TenantId
        val resourceAppIdURI = "https://ossrdbms-aad.database.windows.net"

        val service = Executors.newFixedThreadPool(1)
        val context = new AuthenticationContext(authority, true, service);
        val ClientCred = new ClientCredential(ClientId, ClientSecret)
        val authResult = context.acquireToken(resourceAppIdURI, ClientCred, null)
        val accessToken = authResult.get().getAccessToken

        val connectionString = s"jdbc:postgresql://$dbName.postgres.database.azure.com:5432/datacore_application_meta?user=$userName@$dbName&password=$accessToken&sslmode=require"
        val jdbcServer = s"jdbc:postgresql://$dbName.postgres.database.azure.com:5432/datacore_application_meta"
        logInfo("[APP_LOG] db name : " + dbName)

        val conn = DriverManager.getConnection(connectionString)
        logInfo("[APP_LOG] DB Connection established")

        // Fetch table info into Dataframe
        var fileRegistration = sparkSession.read
          .format("jdbc")
          .option("url", jdbcServer)
          .option("dbtable", "file_registrations")
          .option("user", userName + "@" + dbName)
          .option("password", accessToken)
          .option("sslmode","require")
          .load()
        (conn, fileRegistration)
      }
    catch {
      case e: Exception => throw new Exception("connection error")
    }
  }


}
