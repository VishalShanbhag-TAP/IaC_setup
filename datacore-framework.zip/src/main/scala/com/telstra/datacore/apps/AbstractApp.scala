package com.telstra.datacore.apps

import com.telstra.datacore.Logging
import com.telstra.datacore.utils._
import org.apache.spark.sql.SparkSession
import java.util.{InputMismatchException, Properties}
/**
 * Base class for implementing Spark code. Manages the SparkSession at beginning and end of code
 */
abstract class AbstractApp extends
  SparkUtils with
  Logging{
  def main(args: Array[String]): Unit = {
    if (args.length != 7) {
      logError("""[APP_LOG] - Required Arguments (JobJson, SchemaJSon, JobName, ODate, EnvName, JobId, TaskId) are not provided, instead: ${args.mkString(",")}""")
      throw new InputMismatchException("""Required Arguments (job json, schema json, job name, date, env name, Job Id, Task Id) are not provided, instead: ${args.mkString(",")}""")
    }
    
    val props = new Properties()
    props.setProperty("jobJsonPath", args(0))
    props.setProperty("argJsonPath", args(1))
    props.setProperty("jobName", args(2))
    props.setProperty("oDate", args(3))
    props.setProperty("envName", args(4))
    props.setProperty("jobId", args(5))
    props.setProperty("taskId", args(6))

    logInfo(s"[APP_LOG] - Json Path: " + props.getProperty("argJsonPath"))
    logInfo(s"[APP_LOG] - Job Name: " + props.getProperty("jobName"))
    logInfo(s"[APP_LOG] - Job Id: " + props.getProperty("jobId"))
    logInfo(s"[APP_LOG] - Task Id: " + props.getProperty("taskId"))
    logInfo(s"[APP_LOG] - oDate Id: " + props.getProperty("oDate"))
    logInfo(s"[APP_LOG] - Env Name: " + props.getProperty("envName"))

    val spark = getSparkSession(props)
    val dbConnectionParams = EnvAppConstants.getMetadataDBProperties()

    props.setProperty("dbName",dbConnectionParams.dbName)
    props.setProperty("userName",dbConnectionParams.userName)
    props.setProperty("dbPassKey",dbConnectionParams.dbPassKey)
    props.setProperty("kvScopeName",dbConnectionParams.kvScopeName)

    // call application code
    execute(props, spark)
  }
  /**
   * Override this to add functionality to your application
   */
  def execute(props: Properties, spark: SparkSession)
}