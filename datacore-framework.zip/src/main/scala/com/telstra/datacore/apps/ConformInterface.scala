package com.telstra.datacore.apps

import com.telstra.datacore.conforminterface
import com.telstra.datacore.conforminterface.{DelimitedFileProcess, FixedDelimitedFileProcess, FixedFileProcess}
import com.telstra.datacore.metadata.{ArgumentConfiguration, ArgumentsConfiguration}
import com.telstra.datacore.utils.SchemaMappingToStructUtil
import org.apache.spark.sql.SparkSession

import java.util.Properties
import com.databricks.dbutils_v1.DBUtilsHolder.dbutils

object ConformInterface extends
  AbstractApp {

  /**
   * Override this to add functionality to your application
   */
  override def execute(props: Properties, spark: SparkSession): Unit = {
    val spark = sparkSession

    def fileExists(jsonPath:String): ArgumentsConfiguration ={
      try {
        val argumentJsonString = dbutils.fs.head(jsonPath).mkString
        val argumentsJson = ArgumentConfiguration.parse(argumentJsonString)
        argumentsJson
      }
      catch {
        case e: Exception => throw new Exception("Invalid Path or Json does not exists")
      }
    }

    val argumentsJson = fileExists(props.getProperty("argJsonPath"))

    val fileStructure = argumentsJson.file.fileStructureType
    SchemaMappingToStructUtil.createSchemaFromSourceColumns(argumentsJson.sourceColumns.
      getOrElse(throw new Exception("Cannot run ConfirmInterface without ColumnDefinition")))

    logInfo(s"[APP_LOG] - FileStructure: " + fileStructure)

    fileStructure match {
      case "DELIMITED" => DelimitedFileProcess(spark, argumentsConfig = argumentsJson, environment = props.getProperty("envName"), oDate = props.getProperty("oDate"), jobId = props.getProperty("jobId"), taskId = props.getProperty("taskId"), props = props)
      case "FIXED-DELIMITED" => FixedDelimitedFileProcess(spark, argumentsConfig = argumentsJson, environment = props.getProperty("envName"), oDate = props.getProperty("oDate"), jobId = props.getProperty("jobId"), taskId = props.getProperty("taskId"), props = props)
//      case "FIXED" => FixedFileProcess(spark, argumentsConfig = argumentsJson, environment = props.getProperty("envName"), oDate = props.getProperty("oDate"), jobId = props.getProperty("jobId"), taskId = props.getProperty("taskId"), props = props)
//      case "PARQUET" => ParquetFileProcess(spark, argumentsConfig = argumentsJson, environment = props.getProperty("envName"), oDate = props.getProperty("oDate"), jobId = props.getProperty("jobId"), taskId = props.getProperty("taskId"), props = props)

    }
  }
}
