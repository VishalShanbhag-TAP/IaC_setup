# Author: Vishal S Shanbhag
# Date: 12/07/2020
# Version: 1.0.0
# Description: The script writen to backup and restore code stored in Azure Repo. The script will backup and restore to/from BitBukcet
# To backup the code below are the mandatory(M) and oprional(O) parameters
 #
#   a) organisaton (M)
#   b) AzuureDevOpsusername (M)
#   c) AzureDevOpsAccessToken (M)
#   d) BitBucketAccessToken (M)
#   e) agentworkingdir (M)
#   f) type (M)
#   g) project (M/O) (Note:To clone individual repository the parameter "project" must be passed along with "repository")
#   h) repository (O)
#   i) BitBucketusername (M)
# To restore the code below are the mandatory(M) and oprional(O) parameters
#   a) organisaton (M)
#   b) username (M)
#   c) AzureDevOpsAccessToken (M)
#   d) BitBucketAccessToken (M)
#   e) agentworkingdir (M)
#   f) type (M)
#   g) project (M) (Note:This parameter is mandatory when restoring the code from bitbucket)
#   h) repository (O)
#   i) BitBucketusername (M)
#########################################################################################################################################
param
(
    [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $organization,
    [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $AzuureDevOpsusername,
    [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $BitBucketusername,
    [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $AzureDevOpsAccessToken,
    [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $BitBucketAccessToken,
    [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $agentworkingdir,
    [parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [String] $type,
    [parameter(Mandatory = $false)] [String] $project,
    [parameter(Mandatory = $false)] [String] $repository
)
try {

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $authorization = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes(":$AzureDevOpsAccessToken"))
    $adoheaders = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $adoheaders.Add("Accept-Charset", 'UTF-8')
    $adoheaders.Add('Content-Type','Application/Json')
    $adoheaders.Add('Authorization',"Basic $authorization")

    $Header = @{"Authorization" = 'Basic '+[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($BitBucketusername+':'+$BitBucketAccessToken))}

    function Get-Repository {
        param(
            [string] $project,
            [string] $projectkey
        )
        try{
            if($type -eq 'backup'){
                $apiUrl = "https://dev.azure.com/$organization/$project/_apis/git/repositories?api-version=5.1"
                $listofrepo = Invoke-WebRequest -Uri $apiUrl -Method Get -Headers $adoheaders|ConvertFrom-Json|Select-Object -expand value|Select-Object name, id
            }
            elseif ($type -eq 'restore') {
                $apiUrl = "https://git.tools.telstra.com/rest/api/1.0/projects/$projectkey/repos"
                $listofrepo = Invoke-WebRequest -Method GET -Header $Header -ContentType "application/json" -uri $apiUrl|ConvertFrom-Json|Select-Object -expand values|Select-Object name
            }
            return $listofrepo
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            Write-Host "Get Repository: $ErrorMessage"
        }
        finally{
            $apiUrl=$null
            $listofrepo=$null
            $project=$null
            $projectkey=$null
        }
    }
    function Backup-Restore{
        param (
            [string] $adoproject,
            [string] $bitbucketproject,
            [string] $repositoryname,
            [string] $repositoryid,
            [string] $projectkey
        )
        try{

            if($type -eq "backup"){
                $lastCommitCount=Get-LastCommit -project $adoproject -repositoryId $repositoryid
                if($lastCommitCount -gt 0){
                    Clone-Repository -repository $repositoryname -project $adoproject
                    $key=Get-BitBucketProject -project $bitbucketproject
                    if([ValidateNotNullOrEmpty()]$key){
                        push-repository  -repository $repositoryname -projectKey $key
                    }
                }
            }
            elseif($type -eq "restore"){
                Clone-Repository -repository $repositoryname -projectkey $projectkey
                push-repository  -repository $repositoryname -project $adoproject
            }
        }
        catch{
            $ErrorMessage = $_.Exception.Message
            Write-Host "Backup Restore: $ErrorMessage"
        }
        finally{
            $repositoryid=$null
            $adoproject=$null
            $bitbucketproject=$null
            $lastCommitCount=$null
            $key=$null
            $repositoryname=$null
            $projectkey=$null
        }
    }
    function Clone-Repository {
        param (
            [string] $repository,
            [string] $projectkey,
            [string] $project
        )
        try{
            if($type -eq "backup"){
                $login = $AzuureDevOpsusername+":"+$AzureDevOpsAccessToken
                git clone --mirror https://$login@dev.azure.com/$organization/$project/_git/$repository
            }
            elseif($type -eq 'restore') {
                $login = $BitBucketusername+":"+$BitBucketAccessToken
                git clone --mirror https://$login@git.tools.telstra.com/scm/$projectkey/$repository.git
            }
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            Write-Host "Clone Repository: $ErrorMessage"
        }
        finally{
            $login=$null
            $repository=$null
            $project=$null
            $projectkey=$null
        }
    }
    function Get-LastCommit {
        param(
            [string] $project,
            [string] $repositoryId
        )
        try{
            $dte= (Get-Date).AddDays(-1).ToString('MM/dd/yyyy HH:mm:ss')
            $apiUrl = "https://dev.azure.com/$organization/$project/_apis/git/repositories/$repositoryId/commits?fromDate=$dte&api-version=5.1"
            $commitCount = Invoke-WebRequest -Uri $apiUrl -Method Get -Headers $adoheaders|ConvertFrom-Json|Select-Object -expand count
            return $commitCount
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            Write-Host "Get LastCommit: $ErrorMessage"
        }
        finally{
            $repositoryId=$null
            $dte=$null
            $apiUrl=$null
            $commitCount=$null
            $project=$null
        }
    }
    function push-repository {
        param (
            [string] $repository,
            [string] $projectKey,
            [string] $project
        )
        try{
            Set-Location -Path $repository".git" -PassThru
            if($type -eq "backup"){
                $login = $BitBucketusername+":"+$BitBucketAccessToken
                git remote add new-origin https://$login@git.tools.telstra.com/scm/$projectKey/$repository.git
                git push new-origin --mirror
                if( -not $?){
                    create-repository -repository $repository -projectKey $projectKey
                }
            }
            elseif ($type -eq "restore"){
                $login = $AzuureDevOpsusername+":"+$AzureDevOpsAccessToken
                create-repository -adoproject $project -repository $repository
                git remote add new-origin https://$login@dev.azure.com/$organization/$project/_git/$repository
                git push new-origin --mirror
                if( -not $?){
                    create-repository -adoproject $project -repository $repository
                }
            }
        }
        catch{
            $ErrorMessage = $_.Exception.Message
            Write-Host "Push Repository: $ErrorMessage"
        }
        finally{
            $login=$null
            $repository=$null
            $projectKey=$null
            $project=$null
        }
    }
    function create-repository {
        param (
            [string] $adoproject,
            [string] $repository,
            [string] $projectKey
        )
        try{
            if($type -eq "backup"){
                $postParams=@"
                {
                    "name": "$repository",
                    "scmId": "git",
                    "forkable": true
                }
"@
                $apiUrl = "https://git.tools.telstra.com/rest/api/1.0/projects/$projectKey/repos"
                $statusCode = Invoke-WebRequest -Method POST -Header $Header -ContentType "application/json" -uri $apiUrl -Body $postParams|ConvertFrom-Json
                if($statusCode.state -eq "AVAILABLE"){
                    $login = $BitBucketusername+":"+$BitBucketAccessToken
                    git remote add new-origin https://$login@git.tools.telstra.com/scm/$projectKey/$repository.git
                    git push new-origin --mirror
                }
            }
            elseif ($type -eq "restore"){
                $project=$adoproject.replace("%20"," ")
                $lisOfProject=Get-Project
                $projectCount=$lisOfProject.count
                for ($k = 0; $k -lt $projectCount; $k++){
                    $name=$lisOfProject.value[$k].name
                    if($name -eq $project){
                        $projectId=$lisOfProject.value[$k].id
                        break
                    }
                }
                $postParams=@"
                {
                    "name": "$repository",
                    "project": {
                        "id": "$projectId"
                    }
                }
"@
                $apiUrl = "https://dev.azure.com/$organization/$adoproject/_apis/git/repositories?api-version=5.1"
                $repoCreation=Invoke-WebRequest -Uri $apiUrl -Method POST -Headers $adoheaders -Body $postParams|ConvertFrom-Json
                $repoId=$repoCreation.id
                if([ValidateNotNullOrEmpty()]$repoId){
                    push-repository -repository $repository -project $adoproject
                }
            }
        }
        catch{
            $ErrorMessage = $_.Exception.Message
            Write-Host "Create Repository: $ErrorMessage"
        }
        finally{
            $repository=$null
            $apiUrl=$null
            $postParams=$null
            $adoproject=$null
            $projectKey=$null
            $statusCode=$null
            $project=$null
            $lisOfProject=$null
            $projectCount=$null
            $name=$null
            $projectId=$null
            $repoCreation=$null
            $repoId=$null
        }
    }
    function Get-Project{
        try{
            $apiUrl = "https://dev.azure.com/$organization/_apis/projects?api-version=5.1"
            $projectDetails=Invoke-WebRequest -Uri $apiUrl -Method Get -Headers $adoheaders|ConvertFrom-Json|Select-Object count, value
            return $projectDetails
        }
        catch{
            $ErrorMessage = $_.Exception.Message
            Write-Host "Get Project: $ErrorMessage"
        }
        finally{
            $apiUrl=$null
            $projectDetails=$null
        }
    }
    function Get-BitBucketProject{
        param (
            [string] $project
        )
        try{
            $isProjectExist="false"
            $url = "https://git.tools.telstra.com/rest/api/1.0/projects?name=$project"
            $response=Invoke-WebRequest -Method GET -Header $Header -ContentType "application/json" -uri $url|ConvertFrom-Json|Select-Object values
            $projectCount=$response.values.count
            if($projectCount -eq "1"){
                $name=$response.values.name
                $projectKey=$response.values.key
            }
            else{
                for ($m = 0; $m -lt $projectCount; $m++){
                    $name=$response.values.name[$m]
                    if($name -eq $project){
                        $projectKey=$response.values.key[$m]
                        $isProjectExist="true"
                        break
                    }
                }
                #The BitBukcet doesn't support creation of project using personal access token.It works only when you use Account-01 user name
                #and passowrd. The Account-01 user namd and password is not advisable to use in code. Find the below link for more details
                #Make sure that you have already project created in BitBucket to backup code stored in Azure Repository
                #https://community.atlassian.com/t5/Bitbucket-questions/Bitbucket-Server-project-creation-via-REST-API/qaq-p/1148703
                if($isProjectExist -eq "false"){
                    $projectKey=Create-BitBucketProject -project $project
                }
            }
            return $projectKey
        }
        catch{
            $ErrorMessage = $_.Exception.Message
            Write-Host "Get BitBucketProject: $ErrorMessage"
        }
        finally{
            $url=$null
            $project=$null
            $isProjectExist=$null
            $projectCount=$null
            $name=$null
            $projectKey=$null
            $response=$null
        }
    }
    #The BitBukcet doesn't support creation of project using personal access token.It works only when you use Account-01 user name
    #and passowrd. The Account-01 user namd and password is not advisable to use in code. Find the below link for more details
    #https://community.atlassian.com/t5/Bitbucket-questions/Bitbucket-Server-project-creation-via-REST-API/qaq-p/1148703
    function Create-BitBucketProject{
        param (
            [string] $project
        )
        try{

            $projectKey=Generate-ProjectKey
            $postParams=@"
            {
                "key": "$projectKey",
                "name": "$project",
                "description": "The $project created to backup Azure Repo Code"
            }
"@
            $url = "https://git.tools.telstra.com/rest/api/1.0/projects"
            $response=Invoke-WebRequest -Method POST -Header $Header -ContentType "application/json" -uri $url -Body $postParams|ConvertFrom-Json
            $projectId= $response.id
            if([ValidateNotNullOrEmpty()]$projectId){
                return $projectKey
            }
        }
        catch{
            $ErrorMessage = $_.Exception.Message
            Write-Host "Create BitBucketProject: $ErrorMessage"
        }
        finally{
            $url=$null
            $project=$null
            $response=$null
            $projectKey=$null
            $postParams=$null
            $projectId=$null
        }
    }
    function Generate-ProjectKey{
        try{
            $dte=[Math]::Round((Get-Date).ToFileTime()/10000)
            $key="ADO"+""+$dte
            return $key
        }
        catch{
            $ErrorMessage = $_.Exception.Message
            Write-Host "Generate ProjectKey: $ErrorMessage"
        }
        finally{
            $dte=$null
            $key=$null
        }
    }

    if($type -eq "backup"){
        if([ValidateNotNullOrEmpty()]$project -AND [ValidateNotNullOrEmpty()]$repository){
            $name=$project.replace(" ","%20")
            $ListOfRepositories = Get-Repository -project $name
            $countOfRepositories = $ListOfRepositories.count
            for ($q = 0; $q -lt $countOfRepositories; $q++){
                $backupreponame = $ListOfRepositories.name[$q]
                if($repository -eq $backupreponame){
                    $repoId = $ListOfRepositories.id[$q]
                    break
                }
            }
            if([ValidateNotNullOrEmpty()]$repoId){
                Backup-Restore -adoproject $name -bitbucketproject $project -repositoryname $backupreponame -repositoryid $repoId
            }
        }
        elseif([ValidateNotNullOrEmpty()]$project){
            $name=$project.replace(" ","%20")
            $ListOfRepositories = Get-Repository -project $name
            $countOfRepositories = $ListOfRepositories.count
            for ($p = 0; $p -lt $countOfRepositories; $p++){
                $repoId = $ListOfRepositories.id[$p]
                $backupreponame = $ListOfRepositories.name[$p]
                Backup-Restore -adoproject $name -bitbucketproject $project -repositoryname $backupreponame -repositoryid $repoId
            }
        }
        else {
            $ListOfProjects = Get-Project
            $projectCount = $ListOfProjects.count
            for ($l = 0; $l -lt $projectCount; $l++){
                $project=$ListOfProjects.value[$l].name
                $name=$project.replace(" ","%20")
                $ListOfRepositories = Get-Repository -project $name
                $countOfRepositories = $ListOfRepositories.count
                for ($n = 0; $n -lt $countOfRepositories; $n++){
                    if($countOfRepositories -eq 1){
                     $repoId = $ListOfRepositories.id
                     $backupreponame = $ListOfRepositories.name
                    }
                    else{
                     $repoId = $ListOfRepositories.id[$n]
                     $backupreponame = $ListOfRepositories.name[$n]
                    }
                    Backup-Restore -adoproject $name -bitbucketproject $project -repositoryname $backupreponame -repositoryid $repoId
                }
            }
        }
    }
    elseif ($type -eq 'restore') {
        if([ValidateNotNullOrEmpty()]$project -AND [ValidateNotNullOrEmpty()]$repository){
            $name=$project.replace(" ","%20")
            $key = Get-BitBucketProject -project $project
            Backup-Restore -adoproject $name -projectkey $key -repositoryname $repository
        }
        elseif([ValidateNotNullOrEmpty()]$project){
            $name=$project.replace(" ","%20")
            $key = Get-BitBucketProject -project $project
            $ListOfRepositories = Get-Repository -projectkey $key
            $countOfRepositories = $ListOfRepositories.count
            for ($r = 0; $r -lt $countOfRepositories; $r++){
                $backupreponame = $ListOfRepositories.name[$r]
                Backup-Restore -adoproject $name -projectkey $key -repositoryname $backupreponame
            }
        }
        else{
            Write-Error "Mandatory Parameter project is missing in the request" -ErrorAction Stop
        }
    }
}
catch {
    $ErrorMessage = $_.Exception.Message
    Write-Error "Outer Catch: $ErrorMessage" -ErrorAction Stop
}
finally{
    $authorization=$null
    $adoheaders=$null
    $Header=$null
}
