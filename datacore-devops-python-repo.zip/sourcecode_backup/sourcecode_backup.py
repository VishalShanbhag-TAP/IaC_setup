import subprocess
import requests
import logging
import sys

def main() -> None:
    try:
        key_vault = "tcp0015ndatacoredevops"
        agent_directory = sys.argv[1]

        headers = {'Metadata': 'true'}
        response = requests.get("http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net", headers=headers)
        token = response.json()
        access_token = token["access_token"]
        kv_token = {'Authorization': 'Bearer ' + access_token, }

        ado_user_id = f'https://{key_vault}.vault.azure.net/secrets/AzureDevOpsusername?api-version=2016-10-01'
        user_id = requests.get(ado_user_id, headers=kv_token)
        ado_user_id_response = user_id.json()
        ado_user_name = ado_user_id_response["value"]

        ado_access_token = f'https://{key_vault}.vault.azure.net/secrets/azuredevopsaccesstoken?api-version=2016-10-01'
        access_token = requests.get(ado_access_token, headers=kv_token)
        ado_token_response = access_token.json()
        ado_token = ado_token_response["value"]

        bitbucket_user_id = f'https://{key_vault}.vault.azure.net/secrets/BitBucketusername?api-version=2016-10-01'
        bb_user_id = requests.get(bitbucket_user_id, headers=kv_token)
        bitbucket_user_response = bb_user_id.json()
        bitbucket_user_name = bitbucket_user_response["value"]

        bitbucket_access_token = f'https://{key_vault}.vault.azure.net/secrets/bitbukcetaccesstoken/?api-version=2016-10-01'
        bb_access_token = requests.get(bitbucket_access_token, headers=kv_token)
        bitbucket_token_response = bb_access_token.json()
        bitbucket_token = bitbucket_token_response["value"]

        try:
            subprocess.check_call(["/usr/bin/pwsh", "/opt/app/deployment/package/script/code_backup/sourcecode_backup.ps1", "DataCore-Telstra", f"{ado_user_name}", f"{bitbucket_user_name}", f"{ado_token}", f
"{bitbucket_token}", f"{agent_directory}", "backup"])
        except subprocess.CalledProcessError:
            raise RuntimeError("The JetPack Scan Failed!") from None


    except Exception as error:
        logging.error(error, exc_info=True)
        sys.exit(1)

if __name__ == '__main__':
    try:
        main()
    except:
        sys.exit(1)