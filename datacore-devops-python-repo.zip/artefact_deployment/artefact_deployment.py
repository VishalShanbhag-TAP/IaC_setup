from ast import Pass
import os
import sys
import git
import json
import logging
import psycopg2
from psycopg2.extras import execute_batch
import requests
from datetime import datetime
from azure.storage.filedatalake import DataLakeServiceClient
from azure.identity import ManagedIdentityCredential
from databricks_api import DatabricksAPI
from azure.identity import ClientSecretCredential
import base64
from functools import reduce
import secrets
import subprocess
import struct
import pyodbc

def deploy_main():
    try:
        build_agent_artifact_directory = sys.argv[1]
        build_source_branch_name = sys.argv[2]
        environment_name = sys.argv[3]
        storage_account_name = sys.argv[4]
        metadata_postgres_host_name = sys.argv[5]
        metastore_postgres_host_name = sys.argv[6]
        databricks_endpoint = sys.argv[7]
        datacore_azure_tenant_id = sys.argv[8]
        datacore_devops_adb_client_id = sys.argv[9]
        datacore_devops_adb_client_secret = sys.argv[10]
        datacore_adb_sp_client_id = sys.argv[11]
        datacore_adb_sp_client_secret = sys.argv[12]
        datacore_metastore_sp_client_id = sys.argv[13]
        datacore_metastore_sp_client_secret = sys.argv[14]

        container_name = "datacore"
        container_directory = "metadata"
        environment_type = environment_id = Change_SqlFile = None
        update_string = ()

        sql_cmd = """SELECT ID, TYPE FROM environments WHERE NAME = %s"""
        values = (str(environment_name),)
        record_set = query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                           metadata_postgres_host_name, sql_cmd, values)

        # Generate random alphanumeric value to create random folder for each job instance in databricks
        rand_token = secrets.token_hex(3)

        for row in record_set:
            environment_id = row[0]
            environment_type = row[1]

        print("environment type : "+str(environment_type))
        print("environment id : "+str(environment_id))
        if environment_type is None:
            msg = f"Environment Type has not been registered for environment"
            logging.error(msg)

        if environment_id is None:
            msg = f"Environment Id has not been registered for environment"
            logging.error(msg)

        branch_name = build_source_branch_name.split("/")[-1]

        change_SqlFile = changed_file(build_agent_artifact_directory, storage_account_name, container_name,
                                      container_directory, environment_name, environment_type, environment_id,
                                      metadata_postgres_host_name, databricks_endpoint, datacore_azure_tenant_id,
                                      datacore_devops_adb_client_id, datacore_devops_adb_client_secret,                               datacore_adb_sp_client_id, datacore_adb_sp_client_secret,
                                      metastore_postgres_host_name, datacore_metastore_sp_client_id,
                                      datacore_metastore_sp_client_secret, rand_token, branch_name, update_string)

        if change_SqlFile is not None:
            create_job_cluster(environment_name, databricks_endpoint, datacore_azure_tenant_id,
                               datacore_adb_sp_client_id, datacore_adb_sp_client_secret, metastore_postgres_host_name,
                               datacore_metastore_sp_client_id, datacore_metastore_sp_client_secret, rand_token,
                               build_source_branch_name)

    except Exception as error:
        logging.error(error, exc_info=True)

def changed_file(build_agent_artifact_directory, storage_account_name, container_name, container_directory,
                 environment_name, environment_type, environment_id, metadata_postgres_host_name,
                 databricks_endpoint, datacore_azure_tenant_id,datacore_devops_adb_client_id,
                 datacore_devops_adb_client_secret, datacore_adb_sp_client_id, datacore_adb_sp_client_secret,
                 metastore_postgres_host_name, datacore_metastore_sp_client_id , datacore_metastore_sp_client_secret,
                 rand_token, branch_name, update_string):
    try:
        adls_path = change_SqlFile = adb_token = tag_commit = None
        changed_files_list = diff_all_files= list_update =to_be_deployed = executed_files = []
        git_repo = git.Repo(build_agent_artifact_directory)

        resource_uri = "https://database.windows.net/"

        build_tags = [t for t in git_repo.tags if t.name.startswith(branch_name+"_"+t.name.split('_')[-1])]
        head_commit = git_repo.remotes.origin.refs[branch_name].object
        parent_branch_commit = git_repo.remotes.origin.refs["development"].object

        #Get the latest tag commit id which is not equal to head commit
        for build_tag in reversed(build_tags):
            if build_tag.commit != head_commit:
                tag_commit = build_tag.commit
                break

        #If build tags exists then check the commit difference between latest build tag and lastet or head commit
        if tag_commit:
            changed_files_list = [commit.b_path for commit in tag_commit.diff(head_commit)
                                  if commit.change_type in ('A', 'M', 'R') and
                                    (commit.b_path.endswith(".bidh.sql") or commit.b_path.endswith(".json"))]
        #Diff between head commit and the parent branch
        diff_all_files = [commit.b_path for commit in parent_branch_commit.diff(head_commit)
                          if commit.change_type in ('A', 'M', 'R') and
                            (commit.b_path.endswith(".bidh.sql") or commit.b_path.endswith(".json"))]

        # Get the latest run Id from deployments table
        get_max_id = 'select max(run_id) from deployments where branch_name = %s and environment_name = %s'
        values = (str(branch_name), str(environment_name), )
        get_run_id = query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                           metadata_postgres_host_name, get_max_id, values)
        # If run id is not present set it to 0 else get the latest run id
        previous_run_id = get_run_id[0][0] if get_run_id[0][0] != None else 0
        current_run_id = previous_run_id+1
        print("run_id :"+str(current_run_id))

        # Get the list of undeployed files from postgres
        sqlquery = f"SELECT file_name from deployments where branch_name = %s and \
               environment_name = %s and status = 'undeployed' and run_id = {previous_run_id}"
        records = query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                           metadata_postgres_host_name, sqlquery, values)

        # Undeployed files list from database
        un_deployed_filelist = [i[0] for i in records]
        print("changed_files_list : "+str(changed_files_list))

        # If there are changes made after the first run
        if len(changed_files_list) != 0:
            common_files_list = [value for value in diff_all_files if value in un_deployed_filelist]
            to_be_deployed = common_files_list + changed_files_list
        else:
            print("First time job deployment from branch :"+branch_name)
            to_be_deployed = diff_all_files

        to_be_deployed = list(set(to_be_deployed))
        to_be_deployed.sort()
        print("Files to be deployed : "+str(to_be_deployed))
        insertion_list = [(current_run_id, branch_name, environment_name, i, 'undeployed') for i in to_be_deployed ]

        # Insert records to database
        insert_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, insertion_list)

        for files in to_be_deployed:
            split_path = files.rsplit('/', 1)
            file_path = split_path[0]
            file_upload = split_path[1]
            file_path_on_local = os.path.join(build_agent_artifact_directory, files)
            dict_values = {}

            if file_path_on_local.endswith('.json'):
                try:
                    sourcesystem, schemaname, direction, ssu, clusterSize = parse_json(file_path_on_local)
                    local_path = os.path.join(build_agent_artifact_directory, file_path)
                    if file_path_on_local.endswith('.job.json'):
                        adls_path = os.path.join(container_directory, environment_type, environment_name, str(file_path))
                    elif file_path_on_local.endswith('.schema.json'):
                        adls_path = os.path.join(container_directory, environment_type, environment_name, str(file_path),
                                                schemaname)

                    upload_files(file_upload, local_path, storage_account_name, container_name, adls_path,
                                datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret)

                    dict_values = {'file_name':str(files)}
                    list_update = list(update_string)
                    executed_files.append(files)
                    list_update.append(dict_values)
                    update_string= tuple(list_update)

                except Exception as error:
                    unexecuted_files = [value for value in to_be_deployed if value not in executed_files]
                    print("Files not executed : "+str(unexecuted_files))
                    print("Failed to execute file : "+str(unexecuted_files[0]))
                    update_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                            metadata_postgres_host_name, update_string, branch_name, environment_name, current_run_id)
                    logging.error(error, exc_info=True)
                    sys.exit("unable to upload json file")

                update_job_registration(file_path_on_local, sourcesystem, schemaname, direction, ssu, clusterSize,
                                        environment_id, metadata_postgres_host_name,
                                        datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                        datacore_devops_adb_client_secret)

            for files in to_be_deployed:
                split_path = files.rsplit('/', 1)
                file_path = split_path[0]
                file_upload = split_path[1]
                file_path_on_local = os.path.join(build_agent_artifact_directory, files)
                dict_values = {}
                if file_path_on_local.endswith('.bidh.sql'):
                    resource = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"
                    change_SqlFile = "true"
                    if adb_token is None:
                        adb_token = aad_token(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                        datacore_devops_adb_client_secret, resource)

                    try:
                        db = DatabricksAPI(host=databricks_endpoint, token=adb_token)
                        db.dbfs.put(path=f"/FileStore/database/{environment_name}/{rand_token}/{file_upload}", contents=None,
                                overwrite="true", headers=None, src_path=file_path_on_local)

                        executed_files.append(files)
                        dict_values = {'file_name':str(files)}
                        list_update = list(update_string)
                        list_update.append(dict_values)
                        update_string= tuple(list_update)
                    except Exception as error:
                        # Update database with status for the successfully deployed files
                        unexecuted_files = [value for value in to_be_deployed if value not in executed_files]
                        print("Files not executed : "+str(unexecuted_files))
                        print("Failed to execute file : "+str(unexecuted_files[0]))
                        update_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                                metadata_postgres_host_name, update_string, branch_name, environment_name, current_run_id)
                        logging.error(error, exc_info=True)
                        raise SystemExit("Unable to write files to databricks")

            if change_SqlFile is not None:
                # Create job cluster in databricks to execute sql scripts in hive metastore
                print("Files deployed successfully")
                print("Creating job cluster to execute hive scripts")
                create_job_cluster(environment_name, databricks_endpoint, datacore_azure_tenant_id,
                               datacore_adb_sp_client_id, datacore_adb_sp_client_secret, metastore_postgres_host_name,
                               datacore_metastore_sp_client_id, datacore_metastore_sp_client_secret, rand_token,
                               branch_name)

        # Update data base with status if all the files are deployed successfully
        update_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                        metadata_postgres_host_name, update_string, branch_name, environment_name, current_run_id)

        # Delete all the rows for that environment and branch
        delete_rows(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, environment_name, branch_name)

        print("All Files executed successfully")

    except Exception as error:
        logging.error(error, exc_info=True)
        sys.exit("Failed to deploy files")

def parse_json(file_path_on_local):
    sourcesystem = tablename = direction = ssu = clusterSize = None
    with open(file_path_on_local, "rb") as json_data:
        json_obj = json.load(json_data)
        if file_path_on_local.endswith('.job.json'):
            sourcesystem = json_obj['sourceSystem'].lower()
            tablename = json_obj['tableName'].lower()
            direction = json_obj['direction'].lower()
            ssu = json_obj['ssu'].lower()
            clusterSize = json_obj['jobSize']
        elif file_path_on_local.endswith('.schema.json'):
            scope_details = json_obj['Scope']
            sourcesystem = scope_details['SourceSystem'].lower()
            tablename = scope_details['TableName'].lower()
            direction = scope_details['Direction'].lower()
    return sourcesystem, tablename, direction, ssu, clusterSize

def upload_files(file_upload, local_path, storage_account_name, container_name, adls_path, datacore_azure_tenant_id,
                 datacore_devops_adb_client_id, datacore_devops_adb_client_secret):
    credential = ClientSecretCredential(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                        datacore_devops_adb_client_secret)
    service_client = DataLakeServiceClient(
        account_url="{}://{}.dfs.core.windows.net".format("https", storage_account_name),
        credential=credential)
    file_system_client = service_client.get_file_system_client(file_system=container_name)
    directory_client = file_system_client.get_directory_client(adls_path)

    for r, d, f in os.walk(str(local_path)):
        if f:
            for file in f:
                if file == file_upload:
                    file_path_on_local = os.path.join(r, file)
                    file_client = directory_client.get_file_client(file)
                    local_file = open(file_path_on_local, 'r')
                    file_contents = local_file.read()
                    file_client.upload_data(file_contents,
                                            overwrite=True)

def update_job_registration(file, sourcesystem, schemaname, direction, ssu, clusterSize, environment_id,
                            metadata_postgres_host_name,
                            datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret):
    try:
        file_name = os.path.basename(file)
        index_of_dot = file_name.index('.')
        job_name = file_name[:index_of_dot]

        sql_query_cmd = """SELECT * FROM JOB_REGISTRATIONS WHERE JOB_NAME = %s AND ENVIRONMENT_ID = %s"""
        values = (job_name, environment_id,)
        record_set = query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                           metadata_postgres_host_name, sql_query_cmd, values)

        if record_set:
            date_time = datetime.now()
            sql_update_cmd = """UPDATE JOB_REGISTRATIONS SET MODIFIED_DATE_TIME = %s, SOURCE_SYSTEM = %s, \
                                DB_CLUSTER_SIZE= %s, TABLE_NAME = %s, SSU = %s WHERE JOB_NAME = %s"""
            values = (date_time, str(sourcesystem), str(clusterSize), str(schemaname), str(ssu), str(job_name),)
            upsert(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                   metadata_postgres_host_name, sql_update_cmd, values)
        else:
            sql_insert_cmd = """INSERT INTO JOB_REGISTRATIONS (JOB_NAME, ENVIRONMENT_ID, SOURCE_SYSTEM, TABLE_NAME, DB_CLUSTER_SIZE, SSU, DIRECTION) values(%s,%s,%s,%s,%s,%s,%s);"""
            values = (
                str(job_name), str(environment_id), str(sourcesystem), str(schemaname), str(clusterSize), str(ssu),
                str(direction),)
            upsert(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                   metadata_postgres_host_name, sql_insert_cmd, values)
    except Exception as error:
        logging.error(error, exc_info=True)


def initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                             metadata_postgres_host_name):
    try:
        resource = "https://ossrdbms-aad.database.windows.net"
        aadtoken = aad_token(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                             resource)
        connection = psycopg2.connect(
            host=f"{metadata_postgres_host_name}.postgres.database.azure.com",
            port=5432,
            dbname="datacore_application_meta",
            user=f"azdevops_datacoremeta_devops_writer@{metadata_postgres_host_name}",
            password=aadtoken,
            sslmode='require'
        )
        return connection
    except Exception as error:
        logging.error(error, exc_info=True)
        sys.exit("Connection error: Unable to connect to postgres")

# Query to get results from database
def query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, sql_query, values):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                              datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cursor = connection.cursor()
        cursor.execute(sql_query, values)
        records = cursor.fetchall()
        return records
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Invalid parameters provided in the query")

# Insert new rows to database
def insert_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, data):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                              datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cur = connection.cursor()
        insert_query = 'insert into deployments (run_id, branch_name, environment_name, file_name, status) values %s'
        psycopg2.extras.execute_values (
            cur, insert_query, data
        )
        connection.commit()
        cur.close()
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("unable to insert data job got failed")

# Update the status as deployed for the database
def update_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, data, branch_name, environment_name, max_id):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                              datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cur = connection.cursor()
        cur.execute(f"PREPARE updateStmt AS UPDATE deployments SET status = 'deployed' WHERE \
                   branch_name = '{branch_name}' and environment_name = '{environment_name}' and \
                   file_name = $1 and run_id = {max_id}")
        execute_batch(cur, "EXECUTE updateStmt (%(file_name)s)", data)
        cur.execute("DEALLOCATE updateStmt")
        connection.commit()
        cur.close()
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Issue with updating data in batch")

def delete_rows(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, environment_name, branch_name):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                            datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cur = connection.cursor()
        values = (str(environment_name), str(branch_name),)
        delete_query = "delete from deployments where environment_name =  %s and branch_name = %s"
        cur.execute(delete_query,values)
        connection.commit()
        cur.close()
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Issue while deleting rows from database")

def upsert(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
           metadata_postgres_host_name, sql_query, values):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                              datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cursor = connection.cursor()
        cursor.execute(sql_query, values)
        connection.commit()
    except Exception as error:
        logging.error(error, exc_info=True)

def aad_token(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret, resource):
    try:
        # Setup the endpoint
        endpoint = f'https://login.microsoftonline.com/{datacore_azure_tenant_id}/oauth2/token'
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        payload = f"grant_type=client_credentials&client_id={datacore_devops_adb_client_id}&client_secret={datacore_devops_adb_client_secret}&resource={resource}"
        r = requests.post(endpoint, headers=headers, data=payload)
        response = r.json()
        aad_token = response["access_token"]
        return aad_token
    except Exception as error:
        logging.error(error, exc_info=True)
        sys.exit("Unable to get the access token")


# Create job cluster
def create_job_cluster(environment, databricks_endpoint, datacore_azure_tenant_id, datacore_adb_sp_client_id,
                       datacore_adb_sp_client_secret, metastore_postgres_host_name, datacore_metastore_sp_client_id,
                       datacore_metastore_sp_client_secret, rand_token, branch_name):
    try:
        client_id = "{{secrets/datacore-akv-scope/datacore-adb-sp-client-id}}"
        client_secret = "{{secrets/datacore-akv-scope/datacore-adb-sp-client-secret}}"
        endpoint = "https://login.microsoftonline.com/" + datacore_azure_tenant_id + "/oauth2/token"

        # Generate access token for cluster creation
        cluster_access_token = aad_token(datacore_azure_tenant_id, datacore_adb_sp_client_id,
                                         datacore_adb_sp_client_secret, "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d")
        write_external_metastore_config(databricks_endpoint, cluster_access_token, datacore_azure_tenant_id, client_id,
                                        client_secret, metastore_postgres_host_name, datacore_metastore_sp_client_id,
                                        datacore_metastore_sp_client_secret)

        init_script = "dbfs:/databricks/scripts/external-metastore.sh"

        spark_config = {
            "spark.hadoop.fs.azure.account.auth.type": "OAuth",
            "spark.hadoop.fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
            "spark.hadoop.fs.azure.account.oauth2.client.id": client_id,
            "spark.hadoop.fs.azure.account.oauth2.client.secret": client_secret,
            "spark.hadoop.fs.azure.account.oauth2.client.endpoint": endpoint
        }

        cluster_name = branch_name+ "_" + environment
        cluster_config = {
            "cluster_name": cluster_name,
            "spark_version": "9.1.x-scala2.12",
            "node_type_id": "Standard_DS3_v2",
            "spark_conf": spark_config,
            "num_workers": 2,
            "autotermination_minutes": 10,
            "init_scripts": [{
                "dbfs": {
                    "destination": init_script
                }
            }]
        }

        response = requests.post(
            f'{databricks_endpoint}/api/2.0/clusters/create',
            json=cluster_config,
            headers={'Authorization': f'Bearer {cluster_access_token}'}
        )

        if response.status_code == 200:
            cluster_id = response.json()['cluster_id']
            print('cluster_id : '+cluster_id)
            trigger_job(cluster_id, databricks_endpoint, cluster_access_token, environment, rand_token, cluster_name)
    except Exception as error:
        logging.error(error, exc_info=True)


# Trigger job
def trigger_job(cluster_id, databricks_endpoint, aadtoken, environment, rand_token, cluster_name):
    job_id = create_adb_job(databricks_endpoint, aadtoken, cluster_id, environment, cluster_name)

    if job_id != -1:
        job_details = {
            "job_id": job_id,
            "python_params": [
                environment,
                rand_token
            ]
        }
        try:
            response = requests.post(
                f'{databricks_endpoint}/api/2.0/jobs/run-now',
                json=job_details,
                headers={'Authorization': f'Bearer {aadtoken}'}
            )
            if response.status_code == 200:
                return response.json()

        except Exception as error:
            logging.error(error, exc_info=True)
    else:
        logging.error("Unable to create the ADB job")


def create_adb_job(databricks_endpoint, aadtoken, cluster_id, environment, cluster_name):
    # Form the job json
    job_name = cluster_name
    db_job_data = {
        "name": job_name,
        "existing_cluster_id": cluster_id,
        "timeout_seconds": 3600,
        "spark_python_task": {
            "python_file": f"dbfs:/FileStore/patterns/{environment}/ddlexecution_main.py"
        }
    }

    # Create the Databricks job
    db_job_response = requests.post(
        f'{databricks_endpoint}/api/2.0/jobs/create',
        json=db_job_data,
        headers={'Authorization': f'Bearer {aadtoken}'}
    )

    print(db_job_response.content)
    if db_job_response.status_code == 200:
        return db_job_response.json()['job_id']
    else:
        return -1


def write_external_metastore_config(databricks_endpoint, adb_access_token, datacore_azure_tenant_id, client_id,
                                    client_secret, metastore_postgres_host_name, datacore_metastore_sp_client_id,
                                    datacore_metastore_sp_client_secret):
    try:
        # Hive metastore details
        metastore_pg_user = f"azdatabricks_metastore_writer@{metastore_postgres_host_name}"
        metastore_access_token = aad_token(datacore_azure_tenant_id, datacore_metastore_sp_client_id,
                                           datacore_metastore_sp_client_secret,
                                           "https://ossrdbms-aad.database.windows.net")
        metastore_connection_url = f"jdbc:postgresql://{metastore_postgres_host_name}.postgres.database.azure.com:5432/dc_metastore?user={metastore_pg_user}&password={metastore_access_token}&sslmode=require"

        init_script_template = """#!/bin/sh
            source /etc/environment
            cat << 'EOF' > /databricks/driver/conf/00-custom-spark.conf
            [driver] {
                "spark.hadoop.javax.jdo.option.ConnectionURL" = "<connection_url>"
                "spark.hadoop.javax.jdo.option.ConnectionUserName" = "<pg_user>"
                "spark.hadoop.javax.jdo.option.ConnectionPassword" = "<pg_pwd>"
                "spark.hadoop.javax.jdo.option.ConnectionDriverName" = "org.postgresql.Driver"
                "spark.sql.hive.metastore.version" = "0.13.0"
                "spark.hadoop.datanucleus.autoCreateSchema" = "true"
                "spark.hadoop.datanucleus.autoCreateTables" = "true"
                "spark.hadoop.datanucleus.fixedDatastore" = "false"
            }
        """

        replacements = (
            ("<client_id>", client_id),
            ("<client_secret>", client_secret),
            ("<connection_url>", metastore_connection_url),
            ("<pg_user>", metastore_pg_user),
            ("<pg_pwd>", metastore_access_token)
        )
        init_script_string = reduce(lambda a, kv: a.replace(*kv), replacements, init_script_template)

        init_script_string_bytes = init_script_string.encode("ascii")
        init_script_metastore_config = base64.b64encode(init_script_string_bytes).decode("ascii")

        adb = DatabricksAPI(host=databricks_endpoint, token=adb_access_token)
        adb.dbfs.put(path="/databricks/scripts/external-metastore.sh", contents=init_script_metastore_config,
                     overwrite="true", headers=None, src_path=None)
        return True
    except Exception as error:
        logging.error(error, exc_info=True)
        return False

if __name__ == '__main__':
    try:
        deploy_main()
    except:
        sys.exit(1)
