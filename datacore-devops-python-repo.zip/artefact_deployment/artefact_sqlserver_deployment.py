import os
import sys
import git
import json
import logging
import psycopg2
from psycopg2.extras import execute_batch
import requests
from datetime import datetime
from azure.storage.filedatalake import DataLakeServiceClient
from azure.identity import ManagedIdentityCredential
from databricks_api import DatabricksAPI
from azure.identity import ClientSecretCredential
import base64
from functools import reduce
import secrets
import struct
import pyodbc

def deploy_main():
    try:
        build_agent_artifact_directory = sys.argv[1]
        build_source_branch_name = sys.argv[2]
        environment_name = sys.argv[3]
        metadata_postgres_host_name = sys.argv[4]
        datacore_azure_tenant_id = sys.argv[5]
        datacore_devops_adb_client_id = sys.argv[6]
        datacore_devops_adb_client_secret = sys.argv[7]
        datacore_adb_sp_client_id = sys.argv[8]
        datacore_adb_sp_client_secret = sys.argv[9]
        sqlserver_host_name = sys.argv[10]
        sqlserver_database = sys.argv[11]

        environment_type = environment_id = None
        update_string = ()

        sql_cmd = """SELECT ID, TYPE FROM environments WHERE NAME = %s"""
        values = (str(environment_name), )
        record_set = query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret, 
                           metadata_postgres_host_name, sql_cmd, values)

        for row in record_set:
            environment_id = row[0]
            environment_type = row[1]

        print("environment type : "+str(environment_type))
        print("environment id : "+str(environment_id))

        if environment_type is None:
            msg = f"Environment Type has not been registered for environment"
            logging.error(msg)

        if environment_id is None:
            msg = f"Environment Id has not been registered for environment"
            logging.error(msg)

        branch_name = build_source_branch_name.split("/")[-1]

        if branch_name.startswith('feature_'):
            env_id = [id for id in sqlserver_database.split(',') if id[-2:] == environment_name[-2:]]
            sqlserver_database = env_id[0] if env_id else sys.exit("Database does not exists")
        else:
            sqlserver_database

        changed_file(build_agent_artifact_directory, environment_name, metadata_postgres_host_name,
                        datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                        branch_name, sqlserver_host_name, sqlserver_database, datacore_adb_sp_client_id,
                        datacore_adb_sp_client_secret, update_string)

    except Exception as error:
        logging.error(error, exc_info = True)


def changed_file(build_agent_artifact_directory, environment_name, metadata_postgres_host_name, datacore_azure_tenant_id,
                 datacore_devops_adb_client_id, datacore_devops_adb_client_secret, branch_name, sqlserver_host_name,
                 sqlserver_database, datacore_adb_sp_client_id, datacore_adb_sp_client_secret, update_string):
    try:
        #Define all the variables to None or empty list
        token = change_SqlFile = sqlserver_connection = tag_commit = None
        changed_files_list = diff_all_files = list_update = to_be_deployed = executed_files = []
        git_repo = git.Repo(build_agent_artifact_directory)

        resource_uri = "https://database.windows.net/"

        #Get the build tags for that branch
        build_tags = [tag for tag in git_repo.tags if tag.name.startswith(branch_name+"_"+tag.name.split('_')[-1])]
        head_commit = git_repo.remotes.origin.refs[branch_name].object
        parent_branch_commit = git_repo.remotes.origin.refs["development"].object

        #Get the latest tag commit id which is not equal to head commit
        for build_tag in reversed(build_tags):
            if build_tag.commit != head_commit:
                tag_commit = build_tag.commit
                break

        #If build tags exists then check the commit difference between latest build tag and lastet or head commit
        if tag_commit:
            changed_files_list = [commit.b_path for commit in tag_commit.diff(head_commit)
                                  if commit.change_type in ('A', 'M', 'R') and
                                    commit.b_path.endswith(".bidw.sql")]
        #Diff between head commit and the parent branch
        diff_all_files = [commit.b_path for commit in parent_branch_commit.diff(head_commit)
                          if commit.change_type in ('A', 'M', 'R')
                            and  commit.b_path.endswith(".bidw.sql")]

        # Get the latest run Id from deployments table
        get_max_id = 'select max(run_id) from deployments where branch_name = %s and environment_name = %s'
        values = (str(branch_name), str(environment_name), )
        get_run_id = query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                           metadata_postgres_host_name, get_max_id, values)
        # If run id is not present set it to 0 else get the latest run id
        previous_run_id = get_run_id[0][0] if get_run_id[0][0] != None else 0
        current_run_id = previous_run_id+1
        print("run_id :"+str(current_run_id))

        # Get the list of undeployed files from postgres
        sqlquery = f"SELECT file_name from deployments where branch_name = %s and \
               environment_name = %s and status = 'undeployed' and run_id = {previous_run_id}"
        records = query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                           metadata_postgres_host_name, sqlquery, values)

        un_deployed_filelist = [i[0] for i in records]
        print("changed_files_list : "+str(changed_files_list))

        if len(changed_files_list) != 0:
            common_files_list = [value for value in diff_all_files if value in un_deployed_filelist]
            to_be_deployed = common_files_list + changed_files_list

        else:
            print("First time job deployment from branch :"+branch_name)
            to_be_deployed = diff_all_files

        to_be_deployed = list(set(to_be_deployed))
        to_be_deployed.sort()
        print("Files to be deployed : "+str(to_be_deployed))
        insertion_list = [(current_run_id, branch_name, environment_name, i, 'undeployed') for i in to_be_deployed ]

        # Insert records to database
        insert_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, insertion_list)

        # Get the token generated if it is none
        if token is None:
            token = aad_token(datacore_azure_tenant_id, datacore_adb_sp_client_id,
                              datacore_adb_sp_client_secret, resource_uri)
        # Establish connection with sql server
        if sqlserver_connection is None:
            sqlserver_connection = intiate_sqlserver_client(token, sqlserver_host_name, sqlserver_database)

        # Files to be executed in sql server
        for files in to_be_deployed:
            file_path_on_local = os.path.join(build_agent_artifact_directory, files)
            # Get the list files to be executed in a dictionary
            dict_values = {'file_name':str(files)}
            list_update = list(update_string)
            execution_status = execute_sql_script(sqlserver_connection, file_path_on_local, environment_name)

            if execution_status == 'SUCCESS':
                executed_files.append(files)
                list_update.append(dict_values)
                update_string = tuple(list_update)
            else :
                # Update database with status for the successfully deployed files
                unexecuted_files = [value for value in to_be_deployed if value not in executed_files]
                print("Files not executed : "+str(unexecuted_files))
                print("Failed to execute file : "+str(unexecuted_files[0]))
                update_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                            metadata_postgres_host_name, update_string, branch_name, environment_name, current_run_id)
                sys.exit("Failed to execute sql file")

        # Update data base with status
        update_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                        metadata_postgres_host_name, update_string, branch_name, environment_name, current_run_id)

        delete_rows(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                        metadata_postgres_host_name, environment_name, branch_name)
        
        print("All Files executed successfully")

        # Close the connection once execution is over
        if sqlserver_connection is not None:
            sqlserver_connection.close()

        return change_SqlFile

    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit(1)

# Establish connection to sql server using access token
def intiate_sqlserver_client(access_token, sqlserver_host_name, sqlserver_database):
    try:
        token = bytes(access_token, "UTF-8")
        exptoken = b'';
        for i in token:
            exptoken += bytes({i})
            exptoken += bytes(1)
        tokenstruct = struct.pack("=i", len(exptoken)) + exptoken
        connection = pyodbc.connect(driver = '{ODBC Driver 17 for SQL Server}',
                host = sqlserver_host_name, database = sqlserver_database, encrypt = 'yes', attrs_before = {1256:tokenstruct})
        connection.autocommit = True
        return connection
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Failed to connect to sql server database")

# Read file and execute sql server scripts
def execute_sql_script(sqlserver_connection, file_path, environment_name):
    try:
        cursor = sqlserver_connection.cursor()
        open_file = open(file_path, 'r')
        read_file = open_file.read().format(env = environment_name, ENV = environment_name)
        cursor.execute(read_file)
        cursor.commit()
        return 'SUCCESS'
    except Exception as error:
        logging.error(error, exc_info = True)
        return 'FAILURE'

def initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                             metadata_postgres_host_name):
    try:
        resource = "https://ossrdbms-aad.database.windows.net"
        access_token = aad_token(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
                             resource)
        connection = psycopg2.connect(
            host = f"{metadata_postgres_host_name}.postgres.database.azure.com",
            port = 5432,
            dbname = "datacore_application_meta",
            user = f"azdevops_datacoremeta_devops_writer@{metadata_postgres_host_name}",
            password = access_token,
            sslmode = 'require'
        )
        return connection
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Failed to connect to postgres Database")

# Query to get results from database
def query(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, sql_query, values):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                              datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cursor = connection.cursor()
        cursor.execute(sql_query, values)
        records = cursor.fetchall()
        return records
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Invalid parameters provided in the query")

# Insert new rows to database
def insert_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, data):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                              datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cur = connection.cursor()
        insert_query = 'insert into deployments (run_id, branch_name, environment_name, file_name, status) values %s'
        psycopg2.extras.execute_values (
            cur, insert_query, data
        )
        connection.commit()
        cur.close()
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("unable to insert data job got failed")

# Update the status as deployed for the database
def update_batch(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, data, branch_name, environment_name, max_id):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                                              datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cur = connection.cursor()
        cur.execute(f"PREPARE updateStmt AS UPDATE deployments SET status = 'deployed' WHERE \
                   branch_name = '{branch_name}' and environment_name = '{environment_name}' and \
                   file_name = $1 and run_id = {max_id}")
        execute_batch(cur, "EXECUTE updateStmt (%(file_name)s)", data)
        cur.execute("DEALLOCATE updateStmt")
        connection.commit()
        cur.close()
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Issue with updating data in batch")

def delete_rows(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret,
          metadata_postgres_host_name, environment_name, branch_name):
    try:
        connection = initiate_database_client(datacore_azure_tenant_id, datacore_devops_adb_client_id,
                            datacore_devops_adb_client_secret, metadata_postgres_host_name)
        cur = connection.cursor()
        values = (str(environment_name), str(branch_name),)
        delete_query = "delete from deployments where environment_name =  %s and branch_name = %s"
        cur.execute(delete_query,values)
        connection.commit()
        cur.close()
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Issue while deleting rows from database")

def aad_token(datacore_azure_tenant_id, datacore_devops_adb_client_id, datacore_devops_adb_client_secret, resource):
    try:
        # Setup the endpoint
        endpoint = f'https://login.microsoftonline.com/{datacore_azure_tenant_id}/oauth2/token'
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        payload = f"grant_type = client_credentials&client_id = {datacore_devops_adb_client_id}&client_secret = {datacore_devops_adb_client_secret}&resource = {resource}"
        r = requests.post(endpoint, headers = headers, data = payload)
        response = r.json()
        aad_token = response["access_token"]
        return aad_token
    except Exception as error:
        logging.error(error, exc_info = True)
        sys.exit("Unable to generate access token")

if __name__ == '__main__':
    try:
        deploy_main()
    except:
        sys.exit(1)
