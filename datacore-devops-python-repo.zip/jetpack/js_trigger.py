import subprocess
import requests
import logging
import sys

def main() -> None:
    try:
        key_vault = sys.argv[1]

        headers = {'Metadata': 'true'}
        response = requests.get("http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net", headers=headers)
        token = response.json()
        access_token = token["access_token"]
        kv_token = {'Authorization': 'Bearer ' + access_token, }

        client_id_url = f'https://{key_vault}.vault.azure.net/secrets/okapi-client-id?api-version=2016-10-01'
        client_id = requests.get(client_id_url, headers=kv_token)
        client_id_response = client_id.json()
        okapi_client_id = client_id_response["value"]

        client_secret_url = f'https://{key_vault}.vault.azure.net/secrets/okapi-client-secret?api-version=2016-10-01'
        client_secret = requests.get(client_secret_url, headers=kv_token)
        client_secret_response = client_secret.json()
        okapi_client_secret = client_secret_response["value"]

        try:
            subprocess.check_call(["/opt/jetpack/src/script/js_trigger.sh", f"{okapi_client_id}", f"{okapi_client_secret}"])
        except subprocess.CalledProcessError:
            raise RuntimeError("The JetPack Initialize Failed!") from None

    except Exception as error:
        logging.error(error, exc_info=True)
        sys.exit(1)

if __name__ == '__main__':
    try:
        main()
    except:
        sys.exit(1)