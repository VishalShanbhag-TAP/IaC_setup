-- DQ 10051 --
-- bundle_id, po_id ,subscriber_id, bpo_id in OCS Offer table should match with combination of  bundle_id, po_id,msisdn,bpo_id  in DXP Bar Bundle and DXP Bar Core table --
CREATE
OR REPLACE TEMP view ocs_offer USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_offer/'
);
create
or replace temp view bar using org.apache.spark.sql.parquet options (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_bar/'
);
create
or replace temp view ocs_offer_der as (
  select
    bundle_id,
    po_id,
    subscriber_id,
    bpo_id,
    concat(
      coalesce(bundle_id, 'NULL'),
      '-',
      coalesce(po_id, 'NULL'),
      '-',
      coalesce(subscriber_id, 'NULL'),
      '-',
      coalesce(bpo_id, 'NULL')
    ) as bundle_id_po_id_subs_id_bpo_id
  from
    ocs_offer
);
create
or replace temp view bar_der as (
  select
    bb_bundle_id,
    bb_po_id,
    msisdn,
    bpo_id,
    concat(
      coalesce(bb_bundle_id, 'NULL'),
      '-',
      coalesce(bb_po_id, 'NULL'),
      '-',
      coalesce(msisdn, 'NULL'),
      '-',
      coalesce(bpo_id, 'NULL')
    ) as bundle_id_po_id_msisdn_bpo_id
  from
    bar
);

create
or replace temp view temp_final as (
  select
    10051 as issue_id,
    "Misaligned combination of bundle_id, po_id ,subscriber_id, bpo_id" as issue,
    o.bundle_id_po_id_subs_id_bpo_id as issue_key_1,
    "Bundle_Id, Po_Id ,Subscriber_Id, Bpo_Id" as issue_key_1_ref,
    b.bundle_id_po_id_msisdn_bpo_id as issue_key_2,
    "Bundle_Id, Po_Id ,Msisdn, Bpo_Id" as issue_key_2_ref,
    current_date() as created_dt
  from
    ocs_offer_der o full
    outer join bar_der b on o.bundle_id = b.bb_bundle_id
    and o.bpo_id = b.bpo_id
    and o.po_id = b.bb_po_id
    and o.subscriber_id = b.msisdn
    where o.bundle_id_po_id_subs_id_bpo_id != b.bundle_id_po_id_msisdn_bpo_id
);
insert
  OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10051/' using PARQUET
SELECT
  *
FROM
  temp_final;