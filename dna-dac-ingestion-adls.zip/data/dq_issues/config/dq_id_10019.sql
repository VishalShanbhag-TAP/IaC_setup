CREATE OR REPLACE TEMP view sfdc_users_crl USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/crl/output/sfdc/users" );

create or replace temp view temp_final as (select 10019 as issue_id, "Duplicate username user object in SFDC User" as issue, id as issue_key_1, "IdentityProfileId" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from sfdc_users_crl where sfdc_username_dupes > 1);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10019/' using PARQUET SELECT * FROM temp_final;