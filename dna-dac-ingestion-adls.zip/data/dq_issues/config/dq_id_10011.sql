CREATE OR REPLACE TEMP view caiman_crl USING org.apache.spark.sql.parquet OPTIONS (path "mnt/dac2/data/crl/output/caiman" ); 

create or replace temp view temp_final as (select 10011 as issue_id, "Raaguid with blank record in CAIMAN" as issue, raaguid as issue_key_1, "Raaguid" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from caiman_crl where allsiebelcontactids_isNull = true and b2cprofileid_isNull = true and raaguid is not null);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10011/' using PARQUET SELECT * FROM temp_final;