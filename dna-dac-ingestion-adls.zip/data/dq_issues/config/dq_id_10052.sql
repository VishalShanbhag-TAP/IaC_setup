--DQ 10052 --
-- For same subscriber_id in OCS Offer table and DXP Bar Core table,check of data alignment of  bpo_id--
CREATE OR REPLACE TEMP view ocs_offer_crl
USING org.apache.spark.sql.parquet
OPTIONS (path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_offer/' ); 

CREATE OR REPLACE TEMP view dxp_bar_core_crl
USING org.apache.spark.sql.parquet
OPTIONS (path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_bar_core/'); 

create or replace temp view temp_final as 
(select 10052 as issue_id,
       "Misaligned bpo_id in OCS offer and DXP bar code object" as issue,
       o.subscriber_id,
       o.bpo_id as issue_key_1,
       "Bpo_Id in OCS" as issue_key_1_ref,
       bc.bpo_id as issue_key_2,
       "Bpo_Id in DXP" as issue_key_1_ref2,
       current_date() as created_dt
       from ocs_offer_crl o left outer join dxp_bar_core_crl bc on  o.subscriber_id = bc.msisdn where o.bpo_id != bc.bpo_id); 
       

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10052/' using PARQUET SELECT * FROM temp_final;