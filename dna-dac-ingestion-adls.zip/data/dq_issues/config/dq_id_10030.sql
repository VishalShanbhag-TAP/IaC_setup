/*
To get the list of data_transaction_supplementarydata_key_payerentityid where either
of  data_transaction_lineitems_userdefined_key_agreementid,
data_transaction_lineitems_userdefined_key_agreementsource,
data_transaction_lineitems_userdefined_key_agreementtype cloumn value is null and data_transaction_supplementarydata_key_payerentityid is not null
*/


CREATE or replace temp view dna_payments_events_crl
USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/crl/output/dna/payments_events");

create or replace temp view temp_final
 as 
 (select 10030 as issue_id, "Data_transaction_supplementarydata_key_payerentityid is not null but any of the agreement column is null" as issue, data_transaction_supplementarydata_key_payerentityid as issue_key_1, "Payerentityid" as issue_key_1_ref, data_transaction_lineitems_userdefined_key_agreementid as issue_key_2, "Agreementid" as issue_key_2_ref, current_date() as created_dt
 from dna_payments_events_crl
 where !data_transaction_supplementarydata_key_payerentityid_isNull and (data_transaction_lineitems_userdefined_key_agreementid_isNull 
 or data_transaction_lineitems_userdefined_key_agreementsource_isNull
 or data_transaction_lineitems_userdefined_key_agreementtype_isNull) order by data_transaction_supplementarydata_key_payerentityid);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10030/' using PARQUET SELECT * FROM temp_final;