
--To get the list of correlationid's in payments_events where both joinkeys are not null and could not join with either account or contact

CREATE or replace temp view PAYMENTS_ACCOUNT_CONTACT 
USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/integrated_datasets/PAYMENTS_ACCOUNT_CONTACT");

create or replace temp view temp_final
 as 
 (select 10025 as issue_id, "Both joinkeys are not null and payments could not join with either account or contact" as issue, PAYMENTS_correlationid as issue_key_1, "Correlationid" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt
 from PAYMENTS_ACCOUNT_CONTACT
 where 
	(payments_data_transaction_supplementarydata_key_payerentityid is not null or  payments_data_transaction_supplementarydata_key_customeraccountid is not null)
	and payments_data_transaction_supplementarydata_key_payerentityid != CONTACT_identityprofileid__c
	and payments_data_transaction_supplementarydata_key_customeraccountid != ACCOUNT_accountuuid__c
	and payments_data_transaction_supplementarydata_key_customeraccountid !=  ACCOUNT_customerid__c);
		

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10025/' using PARQUET SELECT * FROM temp_final;