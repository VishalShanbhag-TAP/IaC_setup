create or replace temp view caiman_sfdc USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/integrated_datasets/caiman_sfdc" );

create or replace temp view caiman_sfdc_al_rc as 
(
select *
from
  (
    select
      CAIMAN_b2cprofileid,
      CAIMAN_allsiebelcontactids
    from
      caiman_sfdc
    where
      CAIMAN_b2cprofileid is not null
      or CAIMAN_allsiebelcontactids is not null
  ) a
  full outer join 
  (
    select
      SFDCCONTACT_identityprofileid__c,
      SFDCCONTACT_Rcrmcontactid__c
    from
      caiman_sfdc
    where
      SFDCCONTACT_identityprofileid__c is not null
      or SFDCCONTACT_Rcrmcontactid__c is not null
  ) b 
  on a.CAIMAN_allsiebelcontactids = b.SFDCCONTACT_Rcrmcontactid__c
);

create or replace temp view temp_final as (select 10022 as issue_id, "CAIMAN b2cprofileid and SFDC identityprofileid misalign on matching Rcrmcontactid" as issue, SFDCCONTACT_identityprofileid__c as issue_key_1, "IdentityProfileId" as issue_key_1_ref, CAIMAN_b2cprofileid as issue_key_2, "B2cprofileid" as issue_key_2_ref, current_date() as created_dt from caiman_sfdc_al_rc where caiman_b2cprofileid!= SFDCCONTACT_identityprofileid__c);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10022/' using PARQUET SELECT * FROM temp_final;