create or replace temp view caiman_sfdc USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/integrated_datasets/caiman_sfdc" );

create or replace temp view temp_final as (select 10020 as issue_id, "CAIMAN b2cprofileid is not present in SFDC identityprofileid__c" as issue, CAIMAN_b2cprofileid as issue_key_1, "B2cprofileid" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from caiman_sfdc where CAIMAN_b2cprofileid is not null and SFDCCONTACT_identityprofileid__c is null);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10020/' using PARQUET SELECT * FROM temp_final;