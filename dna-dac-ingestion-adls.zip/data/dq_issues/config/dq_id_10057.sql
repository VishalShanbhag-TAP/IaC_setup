-- For same account_uuid in OCS Account table and  in DXP UDR table, check data alignment between subscriber_id and service_id
-- DQ 10057 --
create
or replace temp view DXP_UDR_CRL USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_udr/'
);
create
or replace temp view OCS_ACCOUNT_CRL USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_account/'
);
create
or replace temp view temp_final as (
  select
    10057 as issue_id,
    "Misaligned subscriber_id OCS" as issue,
    a.subscriber_id as issue_key_1,
    "subscriber_id" as issue_key_1_ref,
    u.service_id as issue_key_2,
    "service_id " as issue_key_2_ref,
    current_date() as created_dt
  from
    (
      select
        distinct account_uuid,
        subscriber_id
      from
        OCS_ACCOUNT_CRL
    ) a
    inner join (
      select
        distinct customer_id,
        service_id
      from
        DXP_UDR_CRL
    ) u on a.account_uuid = u.customer_id
  where
    a.subscriber_id != u.service_id
);
insert
  OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10057/' using PARQUET
SELECT
  *
FROM
  temp_final;