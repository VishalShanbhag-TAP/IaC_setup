-- For same account_uuid in OCS Account table and  in DXP UDR table, check data alignment between contract_id and service_instance_id
-- DQ 10056 --

create or replace temp view DXP_UDR_CRL 
USING org.apache.spark.sql.parquet
OPTIONS (path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_udr/');

create or replace temp view OCS_ACCOUNT_CRL 
USING org.apache.spark.sql.parquet
OPTIONS (path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_account/');

create or replace temp view temp_final as
(select 10056 as issue_id,
"Misaligned contract_id in OCS" as issue,
a.contract_id as issue_key_1,
"contract_id" as issue_key_1_ref,
u.service_instance_id as issue_key_2, 
"service_instance_id" as issue_key_2_ref,
current_date() as created_dt
from (select distinct account_uuid , contract_id from OCS_ACCOUNT_CRL) a inner join (select distinct customer_id,service_instance_id from DXP_UDR_CRL) u on a.account_uuid = u.customer_id where a.contract_id != u.service_instance_id
);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10056/' using PARQUET SELECT * FROM temp_final;