
/*SFDC-EOMSYS Misalignment - Serial Number-data_msisdn*/
create or replace temp view sfdc_eomsys_integrated 
using parquet options (path '/mnt/dac2/data/integrated_datasets/eomsys_sfdcasset/');

create or replace temp view stg_mgt as 
select 10402 as issue_id,
"asset" as entity_name,
"msisdn" as eomsys_field_name,
eomsys_data_msisdn as eomsys_field_value,
"serialnumber" as sfdc_field_name,
asset_serialnumber as sfdc_field_value,
"productid" as key_field_name,
eomsys_data_productid as key_field_value,
current_date() as created_dt
from
(select distinct eomsys_data_msisdn,
                 eomsys_data_productid,
                 eomsys_data_productcode,
                 asset_serialnumber
                 from 
sfdc_eomsys_integrated where
asset_vlocity_cmt__assetreferenceid__c is not null 
and eomsys_data_productid is not null and (asset_serialnumber like '614%' or asset_serialnumber like '04%')
and eomsys_data_productcode in ('M0000005','M0000004') and eomsys_data_systemid='B2C-Vlocity'
and eomsys_data_productid = asset_vlocity_cmt__assetreferenceid__c and eomsys_data_msisdn != asset_serialnumber
and eomsys_eventkey='EOMSYS.Order.ManageOrder.Success.v2.event');


insert OVERWRITE DIRECTORY '/mnt/dac2/data/tmp/dq_issues/10402/' using PARQUET SELECT * FROM stg_mgt;

create or replace temp view stg_fact as (select eomsys_field_value as issue_key_1, sfdc_field_value as issue_key_2, current_date() as created_dt from stg_mgt);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/fact_issue_current/issue_id=10402/' using PARQUET SELECT * FROM stg_fact;