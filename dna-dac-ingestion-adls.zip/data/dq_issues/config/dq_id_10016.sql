CREATE OR REPLACE TEMP view sfdc_contact_crl USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/crl/output/sfdc/contact" );

create or replace temp view temp_final as (select 10016 as issue_id, "Not valid user object in SFDC Contact" as issue, contactuuid__c as issue_key_1, "Contactuuid" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from sfdc_contact_crl where isValidUserObject = false);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10016/' using PARQUET SELECT * FROM temp_final;