-- For same subscriber_id in OCS Offer table and DXP LDR table, check for data alignment between bundle_id--
-- DQ 10058--
create
or replace temp view DXP_LDR_CRL USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_ldr/'
);
CREATE
OR REPLACE TEMP view ocs_offer_crl USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_offer/'
);
create
or replace temp view temp_final as (
  select
    10058 as issue_id,
    "Misaligned bundle_id in OCS" as issue,
    o.bundle_id as issue_key_1,
    "bundle_id in OCS" as issue_key_1_ref,
    l.bundle_id as issue_key_2,
    "bundle_id in DXP LDR" as issue_key_2_ref,
    current_date() as created_dt
  from
    (
      select
        distinct bundle_id,
        subscriber_id
      from
        ocs_offer_crl
    ) o
    inner join (
      select
        distinct msisdn,
        bundle_id
      from
        DXP_LDR_CRL
    ) l on o.subscriber_id = l.msisdn
  where
    o.bundle_id != l.bundle_id
);
insert
  OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10058/' using PARQUET
SELECT
  *
FROM
  temp_final;