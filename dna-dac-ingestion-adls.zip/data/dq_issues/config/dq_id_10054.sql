-- DQ 10054 --
--subscriber_id, bpo_id in OCS Offer table should match with msisdn,bpo_id respectively in DXP Bar Core table--
CREATE
OR REPLACE TEMP view ocs_offer_crl USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_offer/'
);
CREATE
OR REPLACE TEMP view DXP_BAR_CORE_CRL using org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_bar_core/'
);
create
or replace temp view temp_final as (
  select
    10054 as issue_id,
    "Misaligned subscriber_id, bpo_id in OCS and DXP" as issue,
    o.subscriber_id as issue_key_1,
    "subscriber_id" as issue_key_1_ref,
    o.bpo_id as issue_key_2,
    "Bpo_id" as issue_key_2_ref,
    current_date() as created_dt
  from
    ocs_offer_crl o
    left outer join DXP_BAR_CORE_CRL bc on o.subscriber_id = bc.msisdn
    and o.bpo_id = bc.bpo_id
  where
    bc.msisdn is null
);
insert
  OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10054/' using PARQUET
SELECT
  *
FROM
  temp_final;