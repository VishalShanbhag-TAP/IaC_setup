CREATE OR REPLACE TEMP view caiman_sfdc USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/integrated_datasets/caiman_sfdc" );

create or replace temp view temp_final as (select 10004 as issue_id, "AllSibelContactId missing RcrmContactId in CAIMAN-SFDC" as issue, caiman_allsiebelcontactids as issue_key_1, "Allsiebelcontactids" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from caiman_sfdc where SFDCCONTACT_rcrmcontactid__c is null and caiman_allsiebelcontactids is not null);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10004/' using PARQUET SELECT * FROM temp_final;