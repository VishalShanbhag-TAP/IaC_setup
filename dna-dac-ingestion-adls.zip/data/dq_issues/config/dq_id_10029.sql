-- To get list of data_transaction_supplementarydata_key_payerentityid where data_transaction_paymentprovider_paymentmethod* is null
CREATE or replace temp view dna_payments_events_crl
USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/crl/output/dna/payments_events");

create or replace temp view temp_final
 as 
 (select 10029 as issue_id, "Data_transaction_supplementarydata_key_payerentityid is Not null but any data_transaction_paymentprovider_paymentmethod is null in Payments_Events" as issue, data_transaction_supplementarydata_key_payerentityid as issue_key_1, "Payerentityid" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt
 from dna_payments_events_crl
 where !data_transaction_supplementarydata_key_payerentityid_isNull
 and (data_transaction_paymentprovider_paymentmethod_bsb_isNull
 or 
 data_transaction_paymentprovider_paymentmethod_cardtype_isNull
 or 
  data_transaction_paymentprovider_paymentmethod_last4_isNull
 or 
  data_transaction_paymentprovider_paymentmethod_type_isNull
 or 
  data_transaction_paymentprovider_paymentmethod_uniqueidentifier_isNull) order by data_transaction_supplementarydata_key_payerentityid);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10029/' using PARQUET SELECT * FROM temp_final;