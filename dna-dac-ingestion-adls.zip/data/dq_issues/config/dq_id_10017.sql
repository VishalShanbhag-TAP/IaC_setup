CREATE OR REPLACE TEMP view sfdc_users_crl USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/crl/output/sfdc/users" );

create or replace temp view temp_final as (select 10017 as issue_id, "Contactless user object in SFDC User" as issue, id as issue_key_1, "ID" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from sfdc_users_crl where isContaclessUser = true);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10017/' using PARQUET SELECT * FROM temp_final;