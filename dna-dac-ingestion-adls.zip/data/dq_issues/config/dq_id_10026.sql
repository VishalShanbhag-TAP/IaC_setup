
--To get the list of correlationids where join is successful with both account and contact but contact doesn't match account via ACR

CREATE or replace temp view PAYMENTS_ACCOUNT_CONTACT 
USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/integrated_datasets/PAYMENTS_ACCOUNT_CONTACT");

create or replace temp view temp_final
 as 
 (select 10026 as issue_id, "Join is successful with both account and contact but contact doesn't match account" as issue, PAYMENTS_correlationid as issue_key_1, "Correlationid" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt
 from PAYMENTS_ACCOUNT_CONTACT
 where 
	(payments_data_transaction_supplementarydata_key_customeraccountid = ACCOUNT_accountuuid__c	or 	payments_data_transaction_supplementarydata_key_customeraccountid =  ACCOUNT_customerid__c)
	and payments_data_transaction_supplementarydata_key_payerentityid = CONTACT_identityprofileid__c
	and (ACCOUNT_id != ACR_accountid or CONTACT_ID != ACR_contactid));
		

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10026/' using PARQUET SELECT * FROM temp_final;