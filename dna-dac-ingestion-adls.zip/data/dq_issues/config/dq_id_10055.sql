-- DQ 10055--
-- For same account_uuid in OCS Subscriber table and DXP LDR table, check data alignment between subscriber_id and msisdn
create
or replace temp view DXP_LDR_CRL USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_ldr/'
);
create
or replace temp view DXP_SUBSCRIBER_CRL USING org.apache.spark.sql.parquet OPTIONS (
  path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_subscriber/'
);
create
or replace temp view temp_final as (
  select
    10055 as issue_id,
    "Misaligned subscriber_id" as issue,
    s.subscriber_id as issue_key_1,
    "subscriber_id" as issue_key_1_ref,
    l.msisdn as issue_key_2,
    "msisdn in DXP" as issue_key_2_ref,
    current_date() as created_dt
  from
    (
      select
        distinct account_uuid,
        subscriber_id
      from
        DXP_SUBSCRIBER_CRL
    ) s
    inner join (
      select
        distinct acct_uuid,
        msisdn
      from
        DXP_LDR_CRL
    ) l on s.account_uuid = l.acct_uuid
  where
    l.msisdn != s.subscriber_id
);
insert
  OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10055/' using PARQUET
SELECT
  *
FROM
  temp_final;