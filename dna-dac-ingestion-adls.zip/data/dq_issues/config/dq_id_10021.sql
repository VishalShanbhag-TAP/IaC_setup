create or replace temp view caiman_sfdc USING org.apache.spark.sql.parquet OPTIONS (path "/mnt/dac2/data/integrated_datasets/caiman_sfdc" );

create or replace temp view temp_final as (select 10021 as issue_id, "SFDC identityprofileid__c is not present in CAIMAN b2cprofileid" as issue, SFDCCONTACT_identityprofileid__c as issue_key_1, "IdentityProfileId" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from caiman_sfdc where CAIMAN_b2cprofileid is null and SFDCCONTACT_identityprofileid__c is not null);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10021/' using PARQUET SELECT * FROM temp_final;