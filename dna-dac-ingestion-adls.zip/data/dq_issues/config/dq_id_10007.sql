CREATE OR REPLACE TEMP view caiman_crl USING org.apache.spark.sql.parquet OPTIONS (path "mnt/dac2/data/crl/output/caiman" );

create or replace temp view temp_final as (select 10007 as issue_id, "Duplicate allsiebelcontactids in CAIMAN" as issue, allsiebelcontactids as issue_key_1, "Allsiebelcontactids" as issue_key_1_ref, cast(null as string) as issue_key_2, cast(null as string) as issue_key_2_ref, current_date() as created_dt from caiman_crl where allsiebelcontactids_IsDuplicate_cipusername_isSame = true);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10007/' using PARQUET SELECT * FROM temp_final;