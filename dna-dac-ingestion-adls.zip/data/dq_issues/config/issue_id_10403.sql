/*PRESENT IN EOMSYS BUT MISSING IN SFDC SFDC- Missing- Service Number-serialnumber*/
create or replace temp view sfdc_eomsys_integrated 
using parquet options (path '/mnt/dac2/data/integrated_datasets/eomsys_sfdcasset/');

create or replace temp view stg_mgt as 
select 10403 as issue_id,
 "eomsys" as entity_name,
 "data_msisdn" as eomsys_field_name,
 eomsys_data_msisdn as eomsys_field_value, 
"proudctid" as key_field_name,
eomsys_data_productid as key_field_value,
 current_date() as created_dt 
 from 
 (select distinct eomsys_data_msisdn,
 eomsys_data_productid from sfdc_eomsys_integrated 
 where eomsys_data_productid is not null 
 and asset_vlocity_cmt__assetreferenceid__c is not null and
 eomsys_data_msisdn is not null and asset_serialnumber is null 
 and eomsys_eventkey='EOMSYS.Order.ManageOrder.Success.v2.event' and
 (asset_serialnumber like '614%' or asset_serialnumber like '04%')
and eomsys_data_productcode in ('M0000005','M0000004') and eomsys_data_systemid='B2C-Vlocity');


insert OVERWRITE DIRECTORY '/mnt/dac2/data/tmp/dq_issues/10403/' using PARQUET SELECT * FROM stg_mgt;

create or replace temp view stg_fact as (select eomsys_field_value as issue_key_1, cast(null as string) as issue_key_2, created_dt from stg_mgt);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/fact_issue_current/issue_id=10403/' using PARQUET SELECT * FROM stg_fact;