-- DQ 11053 --

--For same bundle_id in OCS Offer table and DXP Bar Bundle table,check for data alignment of  po_id--


CREATE or Replace temp view dxp_bar_bundle 
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_bar_bundle/prepaid_med_bar_bundle.parquet");
  
CREATE OR REPLACE TEMP view ocs_offer_crl 
USING org.apache.spark.sql.parquet
OPTIONS (path '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_offer/' ); 

create or replace temp view temp_final as
(select 10053 as issue_id,
"Misaligned po_id in OCS and DXP " as issue,
tmp.bundle_id,
tmp.OCS_Offer_PO_ID as issue_key_1,
"Po_Id in OCS" as issue_key_1_ref,
tmp.DXP_BB_PO_ID as issue_key_2, 
"Po_Id in DXP" as issue_key_2_ref,
current_date() as created_dt
from
( select OCS_Offer.bundle_id as bundle_id,
OCS_Offer.po_id as OCS_Offer_PO_ID,
DXP_BB.po_id as DXP_BB_PO_ID
from
(select distinct bundle_id,po_id from ocs_offer_crl) OCS_Offer
inner join
(select distinct bundle_id,po_id from dxp_bar_bundle) DXP_BB
on OCS_Offer.bundle_id = DXP_BB.bundle_id) as tmp  where tmp.OCS_Offer_PO_ID != tmp.DXP_BB_PO_ID);
insert OVERWRITE DIRECTORY '/mnt/dac2/data/dq_issues/tmp/10053/' using PARQUET SELECT * FROM temp_final;