/*SFDC- Product - Missing Mandatory Attributes-Product Id*/
create or replace temp view sfdc_eomsys_integrated 
using parquet options (path '/mnt/dac2/data/integrated_datasets/eomsys_sfdcasset/');

create or replace temp view stg_mgt as 
select distinct 10401 as issue_id,"Product" as entity_name,"productid" as eomsys_field_name,
eomsys_data_productid as eomsys_field_value,
current_date() as created_dt from sfdc_eomsys_integrated
where eomsys_data_productid is not null and asset_vlocity_cmt__assetreferenceid__c is null and eomsys_eventkey='EOMSYS.Order.ManageOrder.Success.v2.event';

insert OVERWRITE DIRECTORY '/mnt/dac2/data/tmp/dq_issues/10401/' using PARQUET SELECT * FROM stg_mgt;

create or replace temp view stg_fact as 
(select eomsys_field_value as issue_key_1, cast(null as string) as issue_key_2, current_date() as created_dt from stg_mgt);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/fact_issue_current/issue_id=10401/' 
using PARQUET SELECT * FROM stg_fact;