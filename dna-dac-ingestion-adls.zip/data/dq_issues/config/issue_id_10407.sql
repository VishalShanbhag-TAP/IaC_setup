/*PRESENT IN SFDC BUT MISSING IN EOMSYS EOMSYS- Missing- SIM Number-data_simserialnumber*/
create or replace temp view sfdc_eomsys_integrated 
using parquet options (path '/mnt/dac2/data/integrated_datasets/eomsys_sfdcasset/');

create or replace temp view stg_mgt as 
select 10407 as issue_id,
 "sfdc" as entity_name,
 "serialnumber" as sfdc_field_name,
 asset_serialnumber as sfdc_field_value, 
"proudctid" as key_field_name,
eomsys_data_productid as key_field_value,
 current_date() as created_dt 
 from 
 (select distinct asset_serialnumber,
 eomsys_data_productid from sfdc_eomsys_integrated 
 where eomsys_data_productid is not null 
 and asset_vlocity_cmt__assetreferenceid__c is not null and  eomsys_data_simserialnumber is null
 and asset_serialnumber is not null
 and (asset_name in ('iPhone XR','U3 3G','SIM'))
 and eomsys_data_productcode in ('M0000005','M0000004') and eomsys_data_systemid='B2C-Vlocity'
 and eomsys_eventkey='EOMSYS.Order.ManageOrder.Success.v2.event');


insert OVERWRITE DIRECTORY '/mnt/dac2/data/tmp/dq_issues/10407/' using PARQUET SELECT * FROM stg_mgt;

create or replace temp view stg_fact as (select sfdc_field_value as issue_key_1, cast(null as string) as issue_key_2, created_dt from stg_mgt);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/fact_issue_current/issue_id=10407/' using PARQUET SELECT * FROM stg_fact;