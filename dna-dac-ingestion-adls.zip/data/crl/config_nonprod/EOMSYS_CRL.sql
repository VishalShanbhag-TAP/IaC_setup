/* LOADING EOMSYS DATA */
CREATE temp view eomsys_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/dna/E11_bidhR_sds_dna_hist/eomsysevents_manageorder_v2"
);

create or replace temp view eomsys_crl_int as (
select
  
  eventkey,
  data_productid,
  data_msisdn,
  data_simserialnumber,
  data_systemid,
  data_productcode
  from
  eomsys_crl_input
);

create or replace temp view eomsys_crl_out as (
select 
  eventkey,
  data_productid,
  data_msisdn,
  data_simserialnumber,
  data_productcode,
  eventkey is null as eventkey_isNull,
  data_productid is null as data_productid_isNull,
  data_msisdn is null as data_msisdn_isNull,
  data_simserialnumber is null as data_simserialnumber_isNull
   from eomsys_crl_int
);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/eomsys/' using PARQUET SELECT * FROM eomsys_crl_out;