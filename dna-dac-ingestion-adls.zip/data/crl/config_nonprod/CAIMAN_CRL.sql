CREATE temp view caiman_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/caiman/E11_bidhr_SDS_caiman_hist/user/user.parquet"
);

create temp view caiman_crl_int as (
select
  raaguid,
  cipuid,
  allsiebelcontactids,
  ecsid,
  ecsidstatus,
  cipemailverified,
  defaultsiebelcac,
  b2cprofileid,
  tuid,
  cipusername,
  (count(1) over (partition by raaguid)) > 1 raaguid_IsDuplicate,
  (count(1) over (partition by cipusername)) > 1 cipusername_IsDuplicate,
  (count(1) over (partition by b2cprofileid)) > 1 b2cprofileid_IsDuplicate,
  (count(1) over (partition by allsiebelcontactids)) > 1 allsiebelcontactids_IsDuplicate
  from
  caiman_crl_input
);

create temp view caiman_crl_output as 
(select
  raaguid,
  cipuid,
  allsiebelcontactids,
  ecsid,
  ecsidstatus,
  cipemailverified,
  defaultsiebelcac,
  b2cprofileid,
  tuid,
  cipusername,
  raaguid_IsDuplicate,
  allsiebelcontactids_IsDuplicate,
  b2cprofileid_IsDuplicate,
  cipusername_IsDuplicate,
  raaguid is null as raaguid_isNull,
  allsiebelcontactids is null as allsiebelcontactids_isNull,
  b2cprofileid is null as b2cprofileid_isNull,
  cipusername is null as cipusername_isNull,
  raaguid not RLIKE '^G[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]$' as raaguid_isMalformed,
  upper(cipusername) not RLIKE '^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$' as cipusername_isMalformed,
  b2cprofileid not rlike '^aa89a87-e9aa-aea0-68ac-' as b2cprofileid_isMalformed,
  allsiebelcontactids not rlike '^1-' as allsiebelcontactids_isMalformed,
  (count(1) over (partition by raaguid,cipusername)) > 1 as raaguid_IsDuplicate_cipusername_isSame,
  (count(1) over (partition by b2cprofileid,cipusername)) > 1 as b2cprofileid_IsDuplicate_cipusername_isSame,
  (count(1) over (partition by allsiebelcontactids,cipusername)) > 1 as allsiebelcontactids_IsDuplicate_cipusername_isSame,
  ((count(1) over (partition by raaguid,allsiebelcontactids)) = 1 and raaguid_IsDuplicate) raaguid_isDuplicate_allsiebelcontactids_isDifferent,
  ((count(1) over (partition by raaguid,allsiebelcontactids)) = 1 and allsiebelcontactids_IsDuplicate) allsiebelcontactids_isDuplicate_raaguid_isDifferent,
  ((count(1) over (partition by raaguid,b2cprofileid)) = 1 and raaguid_IsDuplicate) raaguid_isDuplicate_b2cprofileid_isDifferent,
  ((count(1) over (partition by raaguid,b2cprofileid)) = 1 and b2cprofileid_IsDuplicate) b2cprofileid_isDuplicate_raaguid_isDifferent
from
  caiman_crl_int
);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/caiman' using PARQUET SELECT * FROM caiman_crl_output