-- SPCMP DXP_OCS_PREPAID--

-- OCS OFFER --
CREATE or replace temp view ocs_prepaid_offer_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_offer/prepaid_med_offer.parquet");
  

--OCS OFFER CRL OUTPUT--
create or replace  temp view ocs_prepaid_offer_crl_output
as
(
select subscriber_id,
offer_id,
offer_type,
bundle_id,
po_id,bpo_id,
subscriber_id is null as subscriber_id_IsNull,
offer_type is null as offer_type_isNull,
case when unlimited_indicator= "True" then "Yes"
    when unlimited_indicator= "False" then "Yes"
    else "No"
    end as unlimited_indicator_AsExpected
from ocs_prepaid_offer_crl_input);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_offer/' using PARQUET SELECT * FROM ocs_prepaid_offer_crl_output;


-- OCS ACCOUNT --
CREATE temp view ocs_prepaid_account_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_account/prepaid_med_account.parquet");
  
  
-- OCS ACCOUNT CRL OUTPUT--
create or replace temp view ocs_prepaid_account_crl_output
as
(select subscriber_id,
bundle_id,
account_uuid,
contract_id,
subscriber_id is null as subscriber_id_isNull,
dedicated_account_id is null as dedicated_account_id_isNull,
dedicated_account_unit_type is null as dedicated_account_unit_type_isNull,
bundle_id is null as bundle_id_isNull,
bundle_name is null as bundle_name_isNull,
balance_amount is null as balance_amount_isNull,
balance_unit is null as balance_unit_isNull,
cac_id is null as cac_id_isNull,
account_uuid is null as account_uuid_isNull,
contract_id is null as contract_id_isNull,
if(account_in_euro_flag = 0 or account_in_euro_flag = 1, True,False) as account_in_euro_flag_as_expected,
if(balance_unit = "SECONDS" or balance_unit = "BYTES" or balance_unit="COUNT" or balance_unit="CURRENCY",True,False) as balance_unit_asExpected
from ocs_prepaid_account_crl_input);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_account/' using PARQUET SELECT * FROM ocs_prepaid_account_crl_output;


-- OCS SUBSCRIBER --
CREATE or Replace temp view ocs_prepaid_subscriber_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_subscriber/prepaid_med_subscriber.parquet");
  
  
-- OCS SUBSCRIBER CRL OUTPUT--
create or replace temp view ocs_prepaid_subscriber_crl_output as
(select subscriber_id,
       account_uuid,
       contract_id,
       imsi,
       subscriber_id is null as subscriber_id_IsNUll,
       account_id is null as account_id_IsNull ,
       language is null as language_isNull ,
       service_class_id is null as service_class_id_isNull ,
       account_balance is null as account_balance_IsNull,
       account_activated_flag is null as account_activated_flag_IsNull,
       service_fee_expiry_date is null as service_fee_expiry_date_isNull,
       supervision_period_expiry_date is null as supervision_period_expiry_date_IsNull,
       account_disconnection_date is null as account_disconnection_date_IsNull,
      -- credit_clearance_date is null as credit_clearance_date_IsNull,
       cac_id is null as cac_id_isNull,
       account_uuid is null as account_uuid_isNull,
       contract_id is null as contract_id_isNull,
       imsi is null as imsi_isNull,
       spid is null as spid_isNull,
       payment_type is null as payment_type_isNull,
       commercial_offer is null as commercial_offer_IsNull ,
       service_status is null as service_status_isNull,
       brand_name is null as brand_name_isNull,
       if(first_ivr_call_done_flag = 0,"NO","Yes") as first_ivr_call_done,
       if(spid = 0002,"Yes","No") as SPID_Is_0002,
       if(payment_type = 1,"Prepiad","Not Prepaid") as Payment_type_check,
       if(Service_Status = "Active" or Service_Status = "Inactive" or Service_Status = "Grace","Yes","No") as Service_Status_as_expected,
       if(Brand_name = "Telstra" or brand_name= "Boost","Yes","No") as Brand_name_as_expected
       from 
       ocs_prepaid_subscriber_crl_input);
 
 insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_subscriber/' using PARQUET SELECT * FROM ocs_prepaid_subscriber_crl_output;
       


-- OCS MAPPING--
CREATE or Replace temp view ocs_prepaid_mapping_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_snapshot_mapping/prepaid_snapshot_mapping.parquet");
  
  
 -- OCS MAPPING CRL OUTPUT--
create or replace temp view ocs_prepaid_mapping_crl_output 
as
(select old_subscriber_id,new_subscriber_id, old_subscriber_id is null as old_subscriber_id_isNUll , new_subscriber_id is null as new_subscriber_id_isNull from ocs_prepaid_mapping_crl_input);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/ocs_mapping/' using PARQUET SELECT * FROM ocs_prepaid_mapping_crl_output;



--prepaid_med_udr
-- DXP UDR ---

CREATE or Replace temp view dxp_prepaid_udr_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_udr/prepaid_med_udr.parquet");
  
  
  -- DXP UDR CRL OUTPUT --

create or replace temp view  dxp_prepaid_udr_crl_output
as
(select customer_id,
       service_id,
       bundle_id,
       service_instance_id,
       record_type is null as record_type_isNull,
       event_time is null as event_time_isNull,
       service_type is null as service_type_isNull,
       service_id is null as service_id_isNull,
       usage_cat is null as usage_cat_isNull,
       usage_desc is null as usage_desc_isNull,
       usage_origin is null as usage_origin_isNull,
       event_start_time is null as event_start_time_isNull,
       event_end_time is null as event_end_time_isNull,
       gst_class is null as gst_class_isNull,
       usage_quantity is null as usage_quantity_isNull,
       quantity_unit is null as quantity_unit_isNull,
       country is null as country_isNull,
       carrier is null as carrier_isNull,
       calling_party_number is null as calling_party_number_isNull,
       crm_system is null as crm_system_isNull,
       customer_segment is null as customer_segment_isNull,
       service_instance_id is null as service_instance_id_isNull,
       country_carrier_code is null as country_carrier_code_isNull,
       rated_quantity is null as rated_quantity_isNull,
       payment_type is null as payment_type_isNull,
       commercial_offer is null as commercial_offer_isNull,
       brand is null as brand_isNull,
       state is null as state_isNull,
       event_outcome is null as event_outcome_isNull,
       if(record_type = "UDR",True,False) as record_type_isUDR,
       if(service_type  = 1,True,False) as service_type_isExpected,
       if(quantity_unit = "KILOBYTES" or quantity_unit = "SECONDS" or quantity_unit = "COUNT", TRUE,FALSE) as quantity_unit_asExpected,
       if(crm_system = "DXP",True,False) as crm_system_asExpected,
       if(customer_segment = "B2C",True,False) as customer_segment_asExpected
       from dxp_prepaid_udr_crl_input);
       
insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_udr/' using PARQUET SELECT * FROM dxp_prepaid_udr_crl_output;

-- DXP LDR--
-- prepaid_med_ldr

CREATE or Replace temp view dxp_prepaid_ldr_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_ldr/prepaid_med_ldr.parquet");
  
  -- DXP LDR CRL OUTPUT--
create or replace temp view dxp_prepaid_ldr_crl_output as
(select acct_uuid,
       contract_id,
       msisdn,
       imsi,
       bundle_id,
       record_type is null as record_type_isNull,
       event_type_id is null as event_type_id_isNull,
       event_instance_id is null as event_instance_id_isNull,
       event_date_time is null as event_date_time_isNull,
       cac_id is null as cac_id_isNull,
       acct_uuid is null as acct_uuid_isNull,
       contract_id is null as contract_id_isNull,
       payment_type is null as payment_type_isNull,
       service_type is null as service_type_isNull,
       commercial_offer is null as commercial_offer_isNull,
       brand is null as brand_isNull,
       gst_flag is null as gst_flag_isNull,
       if(record_type = "LDR",True,False) as record_type_asExpected,
       if(service_type = 1, True,False) as service_type_asExpected,
       if(payment_type = 1,True,False) as payment_type_asExpected
       from 
       dxp_prepaid_ldr_crl_input);
insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_ldr/' using PARQUET SELECT * FROM dxp_prepaid_ldr_crl_output;

-- DXP BAR BUNDLE--
-- prepaid_med_bar_bundle--

CREATE or Replace temp view dxp_prepaid_bar_bundle_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_bar_bundle/prepaid_med_bar_bundle.parquet");
  
  
  
-- DXP BAR BUNDLE CRL OUTPUT--
create or replace temp view dxp_prepaid_bar_bundle_crl_output
as
(select 
event_instance_id,
event_type_id,
record_type is null as record_type_isNull,
event_type_id is null as event_type_id_isNull,
event_instance_id is null as event_instance_id_isNull,
bundle_seq_nbr is null as bundle_seq_nbr_isNull,
if(record_type = "BAR",True,False) as record_type_asExpected,
if(bundle_type = "MESSAGING" or bundle_type="DATA" or bundle_type = "VOICE" or bundle_type = "NETWORK",TRUE,False) as bundle_type_asExpected
from
dxp_prepaid_bar_bundle_crl_input);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_bar_bundle/' using PARQUET SELECT * FROM dxp_prepaid_bar_bundle_crl_output;


-- DXP BAR CORE --
-- prepaid_med_bar_core

CREATE or Replace temp view dxp_prepaid_bar_core_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_bar_core/prepaid_med_bar_core.parquet");
  
  
  -- DXP BAR CORE CRL OUTPUT --

create or replace temp view dxp_prepaid_bar_core_crl_output as
(select event_instance_id,
       record_type,
       event_type_id,
       bpo_id,
       msisdn,
       event_date_time is null as event_date_time_IsNull,
       cac_id is null as cac_id_isNull,
       account_uuid is null as account_uuid_isNull,
       contract_id is null as contract_id_isNull,
       service_type is null as service_type_isNull,
       payment_type is null as payment_type_isNull,
       service_class_id is null as service_class_id_isNull,
       commercial_offer is null as commercial_offer,
       brand is null as brand_isNull,
       state is null as state_isNull,
       number_of_bundles is null as number_of_bundles_IsNull,
       if(record_type = "BAR","Yes","No") as record_type_isBAR
       from dxp_prepaid_bar_core_crl_input);
       
       
insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_bar_core/' using PARQUET SELECT * FROM dxp_prepaid_bar_core_crl_output;



-- DXP BAR BUNDLE --
-- prepaid_med_bar_bundle--

CREATE or Replace temp view dxp_prepaid_bar_bundle_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/spcmp/E11_bidhr_SDS_spcmp_hist/prepaid_med_bar_bundle/prepaid_med_bar_bundle.parquet");
  
  
  
  -- JOINING BAR CORE AND BAR BUNDLE --

create or replace temp view bar
as
(select
bb.event_instance_id as bb_event_instance_id,
bb.effectivestartutcdttm as bb_effectivestartutcdttm,
bb.effectiveendutcdttm as bb_effectiveendutcdttm,
bb.effectivestartmltdttm as bb_effectivestartmltdttm,
bb.effectiveendmltdttm as bb_effectiveendmltdttm,
bb.effectivestartmltdt as bb_effectivestartmltdt,
bb.effectiveendmltdt as bb_effectiveendmltdt,
bb.ikeventinstance as bb_ikeventinstance,
bb.record_type as bb_record_type,
bb.event_type_id as bb_event_type_id,
bb.bundle_seq_nbr as bb_bundle_seq_nbr,
bb.bundle_instance_id as bb_bundle_instance_id,
bb.bundle_id as bb_bundle_id,
bb.bundle_name as bb_bundle_name,
bb.po_id as bb_po_id,
bb.po_name as bb_po_name,
bb.origin_bundle_id as bb_origin_bundle_id,
bb.origin_bundle_name as bb_origin_bundle_name,
bb.origin_bundle_catg as bb_origin_bundle_catg,
bb.origin_bundle_subcatg as bb_origin_bundle_subcatg,
bb.bundle_type as bb_bundle_type,
bb.unlimited_ind as bb_unlimited_ind,
bb.rollover_ind as bb_rollover_ind,
bb.rollover_type as bb_rollover_type,
bb.bundle_quantity as bb_bundle_quantity,
bb.bundle_val_before as bb_bundle_val_before,
bb.bundle_val_after as bb_bundle_val_after,
bb.bundle_unit as bb_bundle_unit,
bb.bundle_expiry as bb_bundle_expiry,
bb.bundle_expiryutcdttm as bb_bundle_expiryutcdttm,
bb.bundle_expirymltdttm as bb_bundle_expirymltdttm,
bb.bundle_expiry_src as bb_bundle_expiry_src,
bb.fileid as bb_fileid,
bb.filelinenumber as bb_filelinenumber,
bb.inserttaskid as bb_inserttaskid,
bb.updatetaskid as bb_updatetaskid,
bb.publicationstartdttm as bb_publicationstartdttm,
bb.publicationenddttm as bb_publicationenddttm,
bb.ssutypecode as bb_ssutypecode,
bb.effectivestartutcdtprtnkey as bb_effectivestartutcdtprtnkey,
bc.*
from dxp_prepaid_bar_bundle_crl_input bb
full outer join dxp_prepaid_bar_core_crl_input bc
on bb.event_instance_id=bc.event_instance_id and bb.record_type=bc.record_type
and bb.event_type_id=bc.event_type_id);

insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/spcmp_dxp_ocs_prepaid/dxp_bar/' using PARQUET SELECT * FROM bar;