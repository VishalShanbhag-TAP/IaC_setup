-- CUSTOMR

CREATE OR REPLACE temp view ocs_customer_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/ocs/E11_bidhr_SDS_ocs_hist/customer/customer.parquet");


CREATE OR REPLACE temp view ocs_customer_crl_output
as
(select *,
       case when record_type = 'CUS' then True
       else False
       end as record_type_cus,
       record_type is null as record_type_isNull,
       cid is null as cid_isNull,
       creation_time is null as creation_time_isNull,
       status is null as status_isNull,
       crm_system is null as crm_system_isNull,
       segment is null as segment_isNull,
       case when status='Active' then True
       when status='Pending_Deletion' then True
       else False
       end as Status_As_Expected,
       case when crm_system = "B2C_Vlocity" then True
       else False
       end as Crm_System_As_Expected,
       case when segment="B2C" then True
       when segment = "B2B" then True
       else False
       end as segement_As_expected
       from ocs_customer_crl_input);

-- CHARGEPOINT

CREATE OR REPLACE temp view ocs_chargepoint_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/ocs/E11_bidhr_SDS_ocs_hist/chargepoint/chargepoint.parquet");



create or replace temp view ocs_chargepoint_crl_output
as
(select *,
if(record_type = "CPT",True,False) as Record_type_isCPT,
record_type is null as record_type_isNull,
charge_point_id is null as charge_point_id_isNull,
creation_time is null as creation_time_isNull,
status is null as status_isNull,
customer_id is null as customer_id_isNull,
cycle_day is null as cycle_day_isNull,
crm_system is null as crm_system_isNUll,
customer_segment is null as customer_segment_isNull,
case when status='Active' then True
     when status='Pending_Deletion' then True
       else False
       end as Status_As_Expected,
if(crm_system="B2C_Vlocity", True, False) as crm_system_As_Expected,
case when customer_segment="B2C" then True
       when customer_segment = "B2B" then True
       else False
       end as customer_segement_As_expected
from ocs_chargepoint_crl_input);

-- CHARGEPOINT_PRODUCT

CREATE OR REPLACE temp view ocs_chargepoint_product_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/ocs/E11_bidhr_SDS_ocs_hist/chargepoint_product/chargepoint_product.parquet");



create or replace temp view ocs_chargepoint_product_crl_output
as (select * ,
if(record_type = "CPR",True,False) as Record_type_isCPR,
record_type is null as record_type_isNull,
charge_point_id is null as charge_point_id_isNull,
ocs_product_id is null as ocs_product_id_isNull,
start_time is null as start_time_isNull,
status is null as status_isNull,
case when status='Active' then True
     when status='Cancellation' then True
     when status='Inactive' then True
     else False
     end as Status_As_Expected,
case when charge rlike '^[0-9%]+\.[0-9]{1,2}$' then True
     else False
     end as Charge_As_Expected
from ocs_chargepoint_product_crl_input
);

-- PRODUCT

CREATE OR REPLACE temp view ocs_product_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/ocs/E11_bidhr_SDS_ocs_hist/product/product.parquet");




create or replace temp view ocs_product_crl_output
as (select * ,
if(record_type = "PRD",True,False) as Record_type_isPRD,
record_type is null as record_type_isNull,
service_id is null as service_id_isNull,
ocs_product_id is null as ocs_product_id_isNull,
product_start_time is null as product_start_time_isNull,
status is null as status_isNull,
case when service_id rlike '^61[0-9]{8,9}$' then True
     else False
     end as Service_id_As_Expected,
case when status='Active' then True
     when status='Cancellation' then True
     when status='Inactive' then True
     else False
     end as Status_As_Expected,
case when charge rlike '^[0-9%]+\.[0-9]{1,2}$' then True
     else False
     end as Charge_As_Expected
from ocs_product_crl_input
);

-- SERVICE

CREATE OR REPLACE temp view ocs_service_crl_input
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/E11/SDS/database/retail/ocs/E11_bidhr_SDS_ocs_hist/service/service.parquet");


create or replace temp view ocs_service_crl_output
as (select * ,
record_type is null as record_type_isNull,
service_id is null as service_id_isNull,
creation_time is null as Creation_time_isNull,
payment_type is null as Payment_type_isNull,
status is null as sSatus_isNull,
customer_id is null as Customer_id_isNull,
charge_point_id is null as Charge_point_id_isNull,
crm_system is null as Crm_system_isNull,
customer_segment is null as Customer_segment_isNull,
cycle_day is null as Cycle_day_isNull,
service_type is null as Service_type_isNull,
if(record_type = "SRV",True,False) as Record_type_isSRV,
case when service_id rlike '^61[0-9]{8,9}$' then True
     else False
     end as Service_id_As_Expected,
if(customer_segment != 'B2C' and service_instance_id is null , True,False) as Service_instance_id_IsAvailableOnlyForB2C,
if(payment_type = 0 ,True,False)as Payment_type_IsZero,
if(crm_system = 'B2C_Vlocity' ,True,False)as Crm_system_IsB2C_Vlocity,
case when customer_segment='B2C' then True
     when customer_segment='B2B' then True
     else False
     end as Customer_segment_As_Expected,
case when service_type='Mobile' then True
     when service_type='Fixed' then True
     when service_type='IPService' then True
     when service_type='IoT' then True
     else False
     end as Service_type_As_Expected,
case when device_id rlike '^50[0-9]{13}$' then True
     else False
     end as Device_id_As_Expected, 
case when shaping_indicator=0 then True
     when shaping_indicator=1 then True
     else False
     end as Shaping_indicator_As_Expected,
case when shaping_status='ShapingEnablement' then True
     when shaping_status='SafetyNet' then True
     when shaping_status='FullBW' then True
     else False
     end as Shaping_status_As_Expected
from ocs_service_crl_input
);


INSERT OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/ocs_postpaid/customer' using PARQUET SELECT * FROM ocs_customer_crl_output;
INSERT OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/ocs_postpaid/chargepoint' using PARQUET SELECT * FROM ocs_chargepoint_crl_output;
INSERT OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/ocs_postpaid/chargepointproduct' using PARQUET SELECT * FROM ocs_chargepoint_product_crl_output;
INSERT OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/ocs_postpaid/product' using PARQUET SELECT * FROM ocs_product_crl_output;
INSERT OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/ocs_postpaid/service' using PARQUET SELECT * FROM ocs_service_crl_output;