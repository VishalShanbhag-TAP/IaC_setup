-- CONTACT
CREATE temp view sfdc_contact
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/PRD/SDS/database/retail/sfdc/PRD_bidhr_SDS_sfdc_hist/contact/contact.parquet"
);

-- USERS
CREATE temp view sfdc_users
USING org.apache.spark.sql.parquet
OPTIONS (
  path "/mnt/datacore/app_root/bidh/data/PRD/SDS/database/retail/sfdc/PRD_bidhr_SDS_sfdc_hist/users/users.parquet/"
);
--ASSET


CREATE OR REPLACE temp view asset
USING org.apache.spark.sql.parquet
OPTIONS (
  path "/mnt/datacore/app_root/bidh/data/PRD/SDS/database/retail/sfdc/PRD_bidhr_SDS_sfdc_hist/asset/asset.parquet/effectiveendutcdtprtnkey=99991231"
);
--ASSET CRL

create or replace temp view sfdc_asset_crl
as
(
select *,
serialnumber is null as serialnumber_isNull, --eomsys use case
vlocity_cmt__assetreferenceid__c is null as vlocity_cmt__assetreferenceid__c_isNull
from asset
);

-- CRL's for contact

create or replace temp view sfdc_contact_crl as (	
	select
		c.identityprofileid__c,
		--c.email,
		c.contactuuid__c,
		c.tcmuuid__c,
		c.rcrmcontactid__c,
		c.vlocity_cmt__status__c,
		count(1) over (partition by rcrmcontactid__c) sfdc_rcrmid_dupes,
		count(1) over (partition by identityprofileid__c) sfdc_profileId_dupes,
		if(u.contactID is not null, true, false) as isValidUserObject 
	from
		sfdc_contact c
	left outer join 
		sfdc_users u
	on
		c.id = u.contactID 
	where 
		c.identityprofileid__c is not null
);


-- CRL's for Users 

create or replace temp view sfdc_users_crl as (	
	select 
	  u.id, 
	  u.contactID, 
	  count(1) over (partition by u.username) sfdc_username_dupes, 
	  if(u.contactID is null, true, false) as isContaclessUser,
	  if(u.username is null, true, false) as isUserNameNull
	 from sfdc_users u 
);


insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/sfdc/contact' using PARQUET SELECT * FROM sfdc_contact_crl;
insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/sfdc/users' using PARQUET SELECT * FROM sfdc_users_crl;
insert OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/sfdc/asset' using PARQUET SELECT * FROM sfdc_asset_crl;