-- PAYMENTS EVENTS 

CREATE or replace temp view payments_events
USING org.apache.spark.sql.parquet
OPTIONS (
  path "mnt/datacore/app_root/bidh/data/PRD/SDS/database/retail/dna/PRD_bidhr_SDS_dna_hist/payments_events/payments_events.parquet"
);

-- PAYMENT EVENTS CRL 

CREATE OR REPLACE temp view payments_events_crl as (
	select *,
	--Column for sfdc payment
	data_transaction_supplementarydata_key_customeraccountid is null as data_transaction_supplementarydata_key_customeraccountid_isNull,
	data_transaction_paymentprovider_paymentmethod_bsb is null as data_transaction_paymentprovider_paymentmethod_bsb_isNull,
	data_transaction_paymentprovider_paymentmethod_cardtype is null as data_transaction_paymentprovider_paymentmethod_cardtype_isNull,
	data_transaction_paymentprovider_paymentmethod_last4 is null as data_transaction_paymentprovider_paymentmethod_last4_isNull,
	data_transaction_paymentprovider_paymentmethod_type is null as data_transaction_paymentprovider_paymentmethod_type_isNull,
	data_transaction_supplementarydata_key_payerentityid is null as data_transaction_supplementarydata_key_payerentityid_isNull,
    (data_transaction_supplementarydata_key_payerentitytype is not null and data_transaction_supplementarydata_key_payerentitytype != 'IDENTITY_PROFILE_ID') as data_transaction_supplementarydata_key_payerentitytype_isMalformed,
	--Coulmn for caiman payment
    data_transaction_lineitems_userdefined_key_agreementid is null as data_transaction_lineitems_userdefined_key_agreementid_isNull,
    data_transaction_lineitems_userdefined_key_agreementsource is null as data_transaction_lineitems_userdefined_key_agreementsource_isNull,
    data_transaction_lineitems_userdefined_key_agreementtype is null as data_transaction_lineitems_userdefined_key_agreementtype_isNull,
    data_transaction_paymentprovider_paymentmethod_uniqueidentifier is null as data_transaction_paymentprovider_paymentmethod_uniqueidentifier_isNull,
	(count(1) over (partition by data_transaction_supplementarydata_key_payerentityid)) > 1 as data_transaction_supplementarydata_key_payerentityid_isDuplicate,
	(count(1) over (partition by data_transaction_supplementarydata_key_customeraccountid)) > 1 as data_transaction_supplementarydata_key_customeraccountid_isDuplicate
    from
	payments_events);

INSERT OVERWRITE DIRECTORY '/mnt/dac2/data/crl/output/payments_events' using PARQUET SELECT * FROM payments_events_crl;