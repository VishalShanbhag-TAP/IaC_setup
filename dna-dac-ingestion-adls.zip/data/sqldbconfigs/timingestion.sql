/****** Object:  Table [IngestionAudit].[configs]    Script Date: 2/11/2021 3:35:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [IngestionAudit].[configs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[job_name] [varchar](100) NOT NULL,
	[created_date] [datetime] NULL,
	[jsonconfig] [varchar](8000) NULL,
	[filepattern] [varchar](200) NULL,
	[sourcesystem] [varchar](200) NULL,
	[tablename] [varchar](200) NULL,
	[ingestiontype] [varchar](200) NULL,
	[replicatetosqldw] [varchar](100) NULL,
	[last_touched_timestamp] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[job_name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
-----------------
/****** Object:  Table [IngestionAudit].[fileregistration]    Script Date: 2/11/2021 3:36:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [IngestionAudit].[fileregistration](
	[file_id] [int] NOT NULL,
	[file_name] [varchar](100) NOT NULL,
	[rundatetimestamp] [datetime] NULL,
	[file_status] [varchar](100) NULL,
	[pipeline_runid] [varchar](200) NULL,
PRIMARY KEY CLUSTERED 
(
	[file_name] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
------------------------
/****** Object:  StoredProcedure [IngestionAudit].[File_Status]    Script Date: 2/11/2021 3:37:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [IngestionAudit].[File_Status]( @file_name [VARCHAR](100),@file_name_pattern [VARCHAR](100),@file_status [VARCHAR](100),@pipeline_runid [VARCHAR](500),@file_id INT OUTPUT,@job_name varchar(200) OUTPUT)
AS
BEGIN
    BEGIN TRY
	SET NOCOUNT ON;  
	DECLARE @fileid INT ;  
	DECLARE @jobname varchar(200);
    SET @fileid = NEXT VALUE FOR [IngestionAudit].CountBy1;  
	print @fileid
    insert into IngestionAudit.fileregistration(file_id,file_name,file_status,pipeline_runid,rundatetimestamp)  values(@fileid,@file_name,@file_status,@pipeline_runid,CURRENT_TIMESTAMP);
	print @fileid;
	SET @job_name = ( select job_name from IngestionAudit.configs where filepattern=@file_name_pattern)
	if(@job_name IS NULL )
	select @fileid as file_id, 'NOT FOUND PATTERN' as job_name
	else
	select @fileid as file_id, @job_name as job_name	
END TRY
BEGIN CATCH
select -1 as file_id, 'File Already Registered' as job_name
END CATCH;
End;
GO
------------------
/****** Object:  Table [dbo].[audit_tbl]    Script Date: 2/11/2021 3:38:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[audit_tbl](
	[audit_id] [int] NOT NULL,
	[workflow_id] [int] NOT NULL,
	[stage_id] [int] NULL,
	[job_name] [varchar](100) NULL,
	[run_id] [varchar](100) NULL,
	[start_time] [datetime] NULL,
	[end_time] [datetime] NULL,
	[status] [varchar](100) NULL,
	[created_date] [datetime] NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[audit_tbl] ADD  DEFAULT (getdate()) FOR [created_date]
GO
----------
id	job_name	created_date	jsonconfig	filepattern	sourcesystem	tablename	ingestiontype	replicatetosqldw	last_touched_timestamp
7	Contact_Merge_Extraction_spcmp	2021-07-06 04:56:13.490	{   "JobName": "Contact_Merge_Extraction",   "Stages": [ {    "StageId": 101,    "IsEnabled": "yes",    "StageType": "ExecuteSQLCustomized",    "StageName": "ORC generation of Extract",    "Attributes": "sqlFilePath=/dbfs/mnt/dac2/config/extracts/ContactMerge.sql"   },   {    "StageId": 102,    "IsEnabled": "yes",    "StageType": "Zipping",    "StageName": "GZIP generation of Extract",    "Attributes": "inputPath=/mnt/dac2/outbound/spcmp/contactmerge/orc_temp/,outputPath=/mnt/dac2/outbound/spcmp/contactmerge/"   },   {    "StageId": 103,    "IsEnabled": "yes",    "StageType": "Encryption",    "StageName": "Encryption of Extract",    "Attributes": "filePath=/mnt/dac2/outbound/spcmp/contactmerge/,pub-key=Excalibur-public-key,tempPath=/mnt/dac2/outbound/spcmp/,recipient=TeamExcalibur@team.telstra.com"   },   {    "StageId": 104,    "IsEnabled": "yes",    "StageType": "Archive",    "StageName": "Archive of jobs",    "Attributes": "inputPath=/mnt/dac2/outbound/spcmp/contactmerge/,outputPath=/mnt/dac2/outbound/spcmp/contactmerge/archive/"   }   ]  }	NULL	NULL	NULL	NULL	NULL	2021-11-01 21:55:22.000
8	prepaid_med_subscriber_active_extraction	2021-07-13 01:56:39.520	{   "JobName": "prepaid_med_subscriber_active_extraction",   "Stages": [ {    "StageId": 101,    "IsEnabled": "yes",    "StageType": "ExecuteSQLCustomized",    "StageName": "ORC generation of prepaid_med_subscriber_active Extract",    "Attributes": "sqlFilePath=/dbfs/mnt/dac2/config/extracts/prepaid_med_subscriber_active.sql"   },   {    "StageId": 102,    "IsEnabled": "yes",    "StageType": "Zipping",    "StageName": "GZIP generation of Extract",    "Attributes": "inputPath=/mnt/dac2/outbound/spcmp/prepaid_med_subscriber_active/orc_temp/,outputPath=/mnt/dac2/outbound/spcmp/prepaid_med_subscriber_active/"   },   {    "StageId": 103,    "IsEnabled": "yes",    "StageType": "Encryption",    "StageName": "Encryption of Extract",    "Attributes": "filePath=/mnt/dac2/outbound/spcmp/prepaid_med_subscriber_active/,pub-key=dac1-public-key,tempPath=/mnt/dac2/outbound/spcmp/,recipient=CSBDataAnalyticsReporting-Jagger@team.telstra.com"   },   {    "StageId": 104,    "IsEnabled": "yes",    "StageType": "Archive",    "StageName": "Archive of jobs",    "Attributes": "inputPath=/mnt/dac2/outbound/spcmp/prepaid_med_subscriber_active/,outputPath=/mnt/dac2/outbound/spcmp/prepaid_med_subscriber_active/archive/"   }   ]  }	NULL	NULL	NULL	NULL	NULL	2021-07-15 23:09:52.000
3	Tim_Extract_Ingestion_pkg_event_outcome_summ	2021-05-12 02:00:16.903	  {   "JobName": "Tim_Extract_Ingestion_pkg_event_outcome_summ",   "Stages": [{    "StageId": 101,    "IsEnabled": "yes",    "StageType": "Archive",    "StageName": "Archive of jobs",    "Attributes": "inputPath=/mnt/dac2/landing/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_event_outcome_summ/,extensions=eot|ctl"   }, {    "StageId": 102,    "IsEnabled": "yes",    "StageType": "Decryption",    "StageName": "decryption of jobs",    "Attributes": "pvt-key=dac1-pvt-key,tempPath=/mnt/dac2/tmp,pvt-key-passphrase=dac1-passphrase-secret,inputPath=/mnt/dac2/archive/tim_extracts/pkg_event_outcome_summ/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_event_outcome_summ/"   }, {    "StageId": 103,    "IsEnabled": "yes",    "StageType": "Unzipping",    "StageName": "unizzping  of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/pkg_event_outcome_summ/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_event_outcome_summ_zip/"   }, {    "StageId": 104,    "IsEnabled": "yes",    "StageType": "ValidateToParquet",    "StageName": "parquet  conversion of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/pkg_event_outcome_summ_zip/,outputPath=/mnt/dac2/data/dac1/tim_extracts/pkg_event_outcome_summ/,saveMode=Overwrite,inputformat=orc,manualSchema=event_dt:date|days_diff:int|weeks_diff:int|event_type:string|comms_type:string|outcome:string|package_type:string|qty:int,partitionColumns=empty"   }]  }	DACN_DACN_TIM_pkg_event_outcome_summNNNNNNNNNNNNNN.zip.gpg	NULL	NULL	NULL	NULL	NULL
6	Tim_Extract_Ingestion_pkg_event_summ	2021-05-16 23:30:23.747	{   "JobName": "Tim_Extract_Ingestion_pkg_event_summ",   "Stages": [{    "StageId": 101,    "IsEnabled": "yes",    "StageType": "Archive",    "StageName": "Archive of jobs",    "Attributes": "inputPath=/mnt/dac2/landing/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_event_summ/,extensions=eot|ctl"   }, {    "StageId": 102,    "IsEnabled": "yes",    "StageType": "Decryption",    "StageName": "decryption of jobs",    "Attributes": "pvt-key=dac1-pvt-key,tempPath=/mnt/dac2/archive/tim_extracts/pkg_event_summ/,pvt-key-passphrase=dac1-passphrase-secret,inputPath=/mnt/dac2/archive/tim_extracts/pkg_event_summ/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_event_summ/"   }, {    "StageId": 103,    "IsEnabled": "yes",    "StageType": "Unzipping",    "StageName": "unizzping  of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/pkg_event_summ/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_event_summ_zip/"   }, {    "StageId": 104,    "IsEnabled": "yes",    "StageType": "ValidateToParquet",    "StageName": "parquet  conversion of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/pkg_event_summ_zip/,outputPath=/mnt/dac2/data/dac1/tim_extracts/pkg_event_summ/,saveMode=Overwrite,inputformat=orc,manualSchema=event_dt:date|days_diff:int|weeks_diff:int|record_type:string|event_type:string|comms_type:string|comms_subtype:string|package_type:string|qty:int,partitionColumns=empty"   }]  }	DACN_DACN_TIM_pkg_event_summNNNNNNNNNNNNNN.zip.gpg	NULL	NULL	NULL	NULL	NULL
1	Tim_Extract_Ingestion_pkg_summ	2021-05-12 02:00:16.880	{   "JobName": "Tim_Extract_Ingestion_pkg_summ",   "Stages": [{    "StageId": 101,    "IsEnabled": "yes",    "StageType": "Archive",    "StageName": "Archive of jobs",    "Attributes": "inputPath=/mnt/dac2/landing/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_summ/,extensions=eot|ctl"   }, {    "StageId": 102,    "IsEnabled": "yes",    "StageType": "Decryption",    "StageName": "decryption of jobs",    "Attributes": "pvt-key=dac1-pvt-key,tempPath=/mnt/dac2/archive/tim_extracts/pkg_summ,pvt-key-passphrase=dac1-passphrase-secret,inputPath=/mnt/dac2/archive/tim_extracts/pkg_summ/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_summ/"   }, {    "StageId": 103,    "IsEnabled": "yes",    "StageType": "Unzipping",    "StageName": "unizzping  of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/pkg_summ/,outputPath=/mnt/dac2/archive/tim_extracts/pkg_summ_zip/"   }, {    "StageId": 104,    "IsEnabled": "yes",    "StageType": "ValidateToParquet",    "StageName": "parquet  conversion of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/pkg_summ_zip/,outputPath=/mnt/dac2/data/dac1/tim_extracts/pkg_summ/,saveMode=Overwrite,inputformat=orc,manualSchema=package_type:string|migration_status:string|comms_status:string|eligibility_status:string|is_end_state:boolean|days_duration:int|cnt_awaiting_reschedule:int|cnt_failed:int|cnt_temp_ineligible:int|qty:string|log_dt:string,partitionColumns=empty"   }]  }	DACN_DACN_TIM_pkg_summNNNNNNNNNNNNNN.zip.gpg	NULL	NULL	NULL	NULL	NULL
4	Tim_Extract_Ingestion_srv_elig_summ	2021-05-12 02:00:16.913	  {   "JobName": "Tim_Extract_Ingestion_srv_elig_summ",   "Stages": [{    "StageId": 101,    "IsEnabled": "yes",    "StageType": "Archive",    "StageName": "Archive of jobs",    "Attributes": "inputPath=/mnt/dac2/landing/,outputPath=/mnt/dac2/archive/tim_extracts/srv_elig_summ/,extensions=eot|ctl"   }, {    "StageId": 102,    "IsEnabled": "yes",    "StageType": "Decryption",    "StageName": "decryption of jobs",    "Attributes": "pvt-key=dac1-pvt-key,tempPath=/mnt/dac2/tmp,pvt-key-passphrase=dac1-passphrase-secret,inputPath=/mnt/dac2/archive/tim_extracts/srv_elig_summ/,outputPath=/mnt/dac2/archive/tim_extracts/srv_elig_summ/"   }, {    "StageId": 103,    "IsEnabled": "yes",    "StageType": "Unzipping",    "StageName": "unizzping  of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/srv_elig_summ/,outputPath=/mnt/dac2/archive/tim_extracts/srv_elig_summ_zip/"   }, {    "StageId": 104,    "IsEnabled": "yes",    "StageType": "ValidateToParquet",    "StageName": "parquet  conversion of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/srv_elig_summ_zip/,outputPath=/mnt/dac2/data/dac1/tim_extracts/srv_elig_summ/,saveMode=Overwrite,inputformat=orc,manualSchema=scenario:string|elig:string|cnt_all_blockers:int|is_elig_prod:boolean|is_elig_process:boolean|is_elig_dq:boolean|is_elig_prime:boolean|is_elig_package:boolean|is_in_contract:boolean|is_tdi:boolean|is_direct_debit:boolean|is_dvl:boolean|response_id_str:string|issue_desc_str:string|prod_id:string|srv_type:string|srv_subtype:string|bus_unit:string|cnt:long|priority_cohort:string|primed_status:string|readiness:string|log_dt:string,partitionColumns=empty"   }]  }	DACN_DACN_TIM_srv_elig_summNNNNNNNNNNNNNN.zip.gpg	NULL	NULL	NULL	NULL	NULL
5	Tim_Extract_Ingestion_srv_summ	2021-05-12 02:00:16.920	  {   "JobName": "Tim_Extract_Ingestion_srv_summ",   "Stages": [{    "StageId": 101,    "IsEnabled": "yes",    "StageType": "Archive",    "StageName": "Archive of jobs",    "Attributes": "inputPath=/mnt/dac2/landing/,outputPath=/mnt/dac2/archive/tim_extracts/srv_summ/,extensions=eot|ctl"   }, {    "StageId": 102,    "IsEnabled": "yes",    "StageType": "Decryption",    "StageName": "decryption of jobs",    "Attributes": "pvt-key=dac1-pvt-key,tempPath=/mnt/dac2/tmp,pvt-key-passphrase=dac1-passphrase-secret,inputPath=/mnt/dac2/archive/tim_extracts/srv_summ/,outputPath=/mnt/dac2/archive/tim_extracts/srv_summ/"   }, {    "StageId": 103,    "IsEnabled": "yes",    "StageType": "Unzipping",    "StageName": "unizzping  of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/srv_summ/,outputPath=/mnt/dac2/archive/tim_extracts/srv_summ_zip/"   }, {    "StageId": 104,    "IsEnabled": "yes",    "StageType": "ValidateToParquet",    "StageName": "parquet  conversion of jobs",    "Attributes": "inputPath=/mnt/dac2/archive/tim_extracts/srv_summ_zip/,outputPath=/mnt/dac2/data/dac1/tim_extracts/srv_summ/,saveMode=Overwrite,inputformat=orc,manualSchema=srv_type:string|srv_subtype:string|migration_type:string|is_migrated:string|elig_tim:string|elig_cim:string|migration_status:string|is_legacy_complete:string|main_plan:string|cohort_id:string|qty:int|log_dt:string,partitionColumns=empty"   }]  }	DACN_DACN_TIM_srv_summNNNNNNNNNNNNNN.zip.gpg	NULL	NULL	NULL	NULL	NULL