# pre-requisite: ensure other recipients public keys in your local

list_of_recipients=""
for recipient in recipients/*.key
do
  recipient_name=${recipient:11}  #removes 'recipients/ at the start of recipient name
  list_of_recipients="$list_of_recipients --recipient ${recipient_name%.*}" #removes '.key' at the end of recipient name
done

echo "list of recipients in folder:"
echo $list_of_recipients | sed 's/--recipient/\n/g'

for file in ./config/development/job_runner.json.gpg ./config/production/job_runner.json.gpg;
do
  # [ -e $file ] && rm $file # remove if it exists
  gpg --batch --yes --output ${file%.*} --decrypt $file
done
