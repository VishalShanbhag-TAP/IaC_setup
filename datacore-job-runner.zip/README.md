# DATACORE JOB-RUNNER 

The function keys for run_job need to be set before the script can be run. 
```bash
export RUN_JOB_KEY = secret_value # function app key
export JOB_RUN_STATUS_KEY = secret_value # function app key
```

Help Message:

```bash
python .\job_runner.py --help
```

Example:
```bash
$ python ./job_runner.py --app_name tcp-azu0014-ae-afa-datacore-ipnd-nprod01 --job_name QBIS000001D --o_date 
20210313 --environment E01
```
