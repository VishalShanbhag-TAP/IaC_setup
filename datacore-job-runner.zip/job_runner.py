import json
import click
import asyncio
import aiohttp
import gnupg
from pathlib import Path

END_STATES = (
    'completed',
    'failed',
    'aborted'
)


async def run_job(application_name, job_name, o_date, environment, retry):
    if not JOB_RUN_KEY:
        raise click.ClickException(click.style("Environment variable JOB_RUN_KEY is not set", fg='red'))

    async with aiohttp.ClientSession() as session:
        url = f"https://{application_name}.azurewebsites.net/api/job_run?code={JOB_RUN_KEY}"
        data = {
            "environment": environment[3:],
            "jobName": job_name,
            "oDate": o_date,
            "retry": retry
        }
        async with session.post(url, data=json.dumps(data)) as response:
            if 'location' in response.headers:
                return response.headers['location']
            else:
                msg = click.style(await response.text(), fg='red')
                raise click.ClickException(msg)

    return None


async def job_run_status(job_status_url, sleep=10):
    if not JOB_RUN_STATUS_KEY:
        raise click.ClickException(click.style("Environment variable JOB_RUN_STATUS_KEY is not set", fg='red'))

    if job_status_url:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{job_status_url}?code={JOB_RUN_STATUS_KEY}") as response:
                job_status = await response.json()
                status = job_status['jobRun']['status']
                if status not in END_STATES:
                    await asyncio.sleep(sleep)
                    return await job_run_status(job_status_url)
                else:
                    return status


@click.command()
@click.option('--job_name', required=True)
@click.option('--o_date', required=True)
@click.option('--environment', required=True)
@click.option('--retry', default=False, type=bool)
@click.option('--polling_interval', default=10)
def run(job_name, o_date, environment, retry, polling_interval):
    loop = asyncio.get_event_loop()
    location_url = loop.run_until_complete(run_job(APP_NAME, job_name, o_date, environment, retry))
    retry_text = ''
    if not location_url:
        click.ClickException(click.style("Job Status Endpoint is missing", fg='red'))

    if retry:
        retry_text = 'RETRY ATTEMPT for'
    job_status = loop.run_until_complete(job_run_status(location_url, polling_interval))
    is_job_completed = job_status == 'completed'

    colour = 'green' if is_job_completed else 'red'
    msg = click.style(
        f"[{job_status.upper()}] {retry_text} JOB_NAME '{job_name}' "
        f"for O_DATE '{o_date}' and ENVIRONMENT '{environment}'",
        fg=colour)

    if is_job_completed:
        click.echo(msg)
    else:
        raise click.ClickException(msg)


def __get_config():
    gpg = gnupg.GPG(gnupghome=f"{Path.home()}/.gnupg/")
    with open('./job_runner.json.gpg', 'rb') as f:
        status = gpg.decrypt_file(f)

    if not status.ok:
        raise Exception(status.stderr)
    return json.loads(status.data)


if __name__ == '__main__':
    config = __get_config()
    JOB_RUN_KEY = config["JOB_RUN_KEY"]
    JOB_RUN_STATUS_KEY = config["JOB_RUN_STATUS_KEY"]
    APP_NAME = config["APP_NAME"]
    run()
