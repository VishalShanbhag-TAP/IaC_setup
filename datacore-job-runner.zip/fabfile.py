from fabric import task

CONFIG = {
    'lxapp6002.dc.corp.telstra.com': {
        'env': 'development',
        'script_dir': '/opt/app/controlm/biddev/script'
    },
    'lxapp6005.dc.corp.telstra.com': {
        'env': 'production',
        'script_dir': '/opt/app/controlm/bidprd/script'
    }
}


@task
def deploy(c):
    env = CONFIG[c.host]['env']
    script_dir = CONFIG[c.host]['script_dir']
    print(f"Deploying code to {c.host} ({env}) ...")
    code_dir = "/opt/app/datacore-job-runner/"
    c.put('./requirements.txt', code_dir)
    c.put('./job_runner.py', code_dir)
    print(f"Copying job_runner.sh to {script_dir}")
    c.put('./job_runner.sh', script_dir)
    c.put(f"./config/{env}/job_runner.json.gpg", code_dir)
    print("Deployment complete!")

