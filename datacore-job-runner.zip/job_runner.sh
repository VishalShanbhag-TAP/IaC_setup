cd /opt/app/datacore-job-runner || exit
if [ "$4" ]; then
  python3 ./job_runner.py --job_name "$1" --o_date "$2" --environment "$3" --retry "$4"
else
  python3 ./job_runner.py --job_name "$1" --o_date "$2" --environment "$3"
fi