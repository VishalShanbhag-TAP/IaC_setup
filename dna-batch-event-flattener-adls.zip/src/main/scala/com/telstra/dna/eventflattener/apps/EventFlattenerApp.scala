package com.telstra.dna.eventflattener.apps

import java.nio.file.Paths
import com.telstra.dna.eventflattener.config._
import com.telstra.dna.eventflattener.utils._
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.catalyst.parser.LegacyTypeStringParser

import java.time.LocalDate
import scala.util.Try

object EventFlattenerApp extends Common{

  val spark: SparkSession = getSparkSession()
  val fs: FileSystem = getFs(spark)

  val mnt = mountAdls()
  import spark.implicits._

  // register standardizeTimeStampUdf
  val standardizeTimeStamp: ((String, String, String, String) => String) = standardizeTimestamp
  val standardizeTimeStampUdf = udf(standardizeTimeStamp)

  // scope options
  val sourceSystem = flattenConfig.scope.sourceSystem.toLowerCase
  val ssu = flattenConfig.scope.ssu.toLowerCase
  val histDbName = s"${env.toUpperCase}_bidh${flattenConfig.scope.ssuCharacter}_sds_${sourceSystem}_hist"

  // source options
  val srcName = flattenConfig.source.name.toLowerCase
  val preSchemaFilter = flattenConfig.source.preSchemaFilter
  val postSchemaFilter = flattenConfig.source.postSchemaFilter.getOrElse("")
  val postFlattenFilter = flattenConfig.source.postFlattenFilter.getOrElse("")
  val inputFields = flattenConfig.source.fields
  val fieldToFlatten = flattenConfig.source.flatten.field
  val flattenSchema: StructType = {
    val json = new String(java.util.Base64.getDecoder.decode(flattenConfig.source.flatten.schema))
    Try(DataType.fromJson(json)).getOrElse(LegacyTypeStringParser.parse(json)) match {
      case t: StructType => t
      case _ => throw new RuntimeException(s"Failed parsing StructType: $json")
    }
  }

  // Transform options
  val tgtName = flattenConfig.target.name
  val errorTableName = "flt_errors_adls"
  val tgtPartitionCols = flattenConfig.target.partitionBy

  // compute path expressions
  val tgtPathPrefix= Paths.get(
    mountPath,
    "/app_root/bidh/data",
    env.toUpperCase,
    "SDS",
    //if (flattenConfig.target.tgtType.toLowerCase == "table") "database" else "landing",
    "database",
    ssuFolderName(ssu),
    flattenConfig.scope.sourceSystem
  ).toString

  val tgtTablePath =  Paths.get(tgtPathPrefix, histDbName, tgtName, s"${tgtName}.parquet").toString
  val errorPath =  Paths.get(tgtPathPrefix, histDbName, errorTableName, s"${errorTableName}.parquet").toString

  // parse flattening input expressions
  val fieldsToSelect = flattenConfig.target.transform.fieldsToSelect
  val fieldsToDrop = flattenConfig.target.transform.fieldsToDrop.getOrElse(Array.empty[String])
  val fieldsAsString = flattenConfig.target.transform.fieldsAsString.getOrElse(Array.empty[String])
  val fieldsAsIs = flattenConfig.target.transform.fieldsAsIs.getOrElse(Array.empty[String]) // could be struct or arrays in val_ notation
  val fieldsToStandardize = flattenConfig.target.transform.fieldsToStandardize.getOrElse(Array.empty[Standardize])
  val fieldsToPivot = flattenConfig.target.transform.fieldsToPivot.getOrElse(Array.empty[Pivot])
  val fieldsToRename = flattenConfig.target.transform.fieldsToRename.getOrElse(Array.empty[Rename])
  val fieldAsEffectiveDttm = flattenConfig.target.transform.fieldAsEffectiveDttm
  val mandatoryFields = flattenConfig.target.transform.mandatoryFields.getOrElse(Array.empty[String])

  val selectList = {fieldsToSelect ++ fieldsAsString ++ inputFields }.distinct.map(_.replace(".", "_")).toSeq
  val prefixesToRemove = flattenConfig.target.transform.prefixesToRemove

  // refresh input dataset
  refreshTableMetadata(s"${histDbName}.${srcName}", spark)
  logInfo(s"[APP_LOG] - Running flattening in batches of size ${batchSize} dates between ${windowStart} and ${windowEnd}")

  // compute date filter expresion
  val odateListofLists = getDateList(windowStart, windowEnd).dropRight(1).grouped(batchSize.toInt).toList
  odateListofLists.foreach( odateList => {
    logInfo(s"[APP_LOG] - Running for the window between ${odateList.min} and ${odateList.max}")
    val oDateExpr = s"ingestiondate IN (${odateList.mkString("'", "', '", "'")})"

    //  val oDateExpr = s"ingestiondate >= '${windowStart}' AND ingestiondate < '${windowEnd}'"
    //  logInfo(s"Running for the window between ${windowStart} and ${windowEnd}")

    // compute filter expresion
    val filterExpr = if(preSchemaFilter.isEmpty) {
      oDateExpr
    } else {
      val filterByTuple = preSchemaFilter.map(fil => {
        val colName = fil.field.toLowerCase
        val values = fil.value.map(_.toLowerCase).mkString("'", "', '", "'")
        (fil.filterGroup, s"LOWER(${colName}) IN (${values})")
      })
      val filterBy = filterByTuple.groupBy(_._1).map(_._2.map(_._2).mkString("(", " AND ", ")")).mkString("(", " OR ", ")")

      List(oDateExpr, filterBy).mkString(" AND ")
    }

    logInfo(s"[APP_LOG] - Applying following column filter expression on input data: '${filterExpr}'")

    // read data from input
    val eventDf = spark
      .read
      .table(s"${histDbName}.${srcName}")
      .filter(filterExpr)
      .select(inputFields.map(col) :_*)

    // deduplicate events in the input
    // TO DO: parameterize ingestiontimestamp col. coz few usecases may not have it
    val windowSpec = Window.partitionBy(col(fieldToFlatten)).orderBy($"ingestiontimestamp".asc)
    val dedupedDf = eventDf.withColumn("row_id", row_number().over(windowSpec))
      .filter('row_id === 1)
      .drop('row_id)
      .withColumn("val", from_json(col(fieldToFlatten), flattenSchema).as("val"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //logInfo(s"[APP_LOG] - Record count after applying preSchemaFilter and deduping: ${dedupedDf.count}")

    val postFilterDf = if(postSchemaFilter.length > 0) {
      dedupedDf.filter(postSchemaFilter)
    } else dedupedDf

    //logInfo(s"[APP_LOG] - Record count after applying postSchemaFilter: ${postFilterDf.count}")

    // Flatten the dataframe
    val flattenedDf = flattenDataframe(postFilterDf, fieldsToDrop, fieldsAsString, fieldsAsIs)

    // cast all column names to lowerCase
    val lowerCaseDf = flattenedDf.select(flattenedDf.columns.map(x => col(x).alias(x.toLowerCase)) :_*)

    // apply post flatten filters
    val postFlattenFilterDf = if(postFlattenFilter.length > 0) {
      lowerCaseDf.filter(postFlattenFilter)
    } else lowerCaseDf

    // Pivoting
    val pivotedDf = if(fieldsToPivot.nonEmpty) {
      pivotDataframe(postFlattenFilterDf, fieldsToPivot.toList)
    } else postFlattenFilterDf

    // ensure select list fields are present in flattened and pivoted dataframe
    require(selectList.map(_.toLowerCase).forall(pivotedDf.columns.map(_.toLowerCase).contains),
      s"""Not all columns specified in Fields section are present after pivoting.
    Columns in config json:- \n==============================\n${selectList.mkString(",")}
    Columns in Dataframe after pivoting:- \n==============================\n${pivotedDf.columns.mkString(",")}""")

    val selectDf = pivotedDf.select(selectList.map(col):_*)
      .distinct
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    // Filter records with NULL in mandatoryFields will be recognised as malformed
    val validDf = selectDf.filter(mandatoryFields.map(_.toLowerCase).distinct.map(f => s"${f} IS NOT NULL").mkString(" AND "))

    // standardize timestamp fields as per conf
    val targetTimestampFormat = "yyyy-MM-dd HH:mm:ss"
    val standardizedDf = if(fieldsToStandardize.nonEmpty) {
      fieldsToStandardize.foldLeft(validDf)((df, s) => {
        if(s.sourceFormat== "epoch_timestamp") {
          df.withColumn(s"${s.field}utcdttm",
            when(col(s.field).isNull || trim(col(s.field)) === "", lit(null))
              .otherwise(when(length(col(s.field)) === 10, date_format(from_utc_timestamp(col(s.field).cast(TimestampType),  "UTC"), targetTimestampFormat))
                        .otherwise(date_format(from_utc_timestamp((col(s.field)/1000).cast(TimestampType), "UTC"), targetTimestampFormat))
                        ))
            .withColumn(s"${s.field}mltdttm",
            when(col(s.field).isNull || trim(col(s.field)) === "", lit(null))
              .otherwise(when(length(col(s.field)) === 10, date_format(from_utc_timestamp(col(s.field).cast(TimestampType),  "Australia/Melbourne"), targetTimestampFormat))
                        .otherwise(date_format(from_utc_timestamp((col(s.field)/1000).cast(TimestampType), "Australia/Melbourne"), targetTimestampFormat))
                        ))
        } else{
          df.withColumn(s"${s.field}utcdttm",
            when(col(s.field).isNull || trim(col(s.field)) === "", lit(null))
              .otherwise(standardizeTimeStampUdf(col(s.field), lit(s.sourceFormat), lit(targetTimestampFormat), lit("UTC"))))
            .withColumn(s"${s.field}mltdttm",
              when(col(s.field).isNull || trim(col(s.field)) === "", lit(null))
                .otherwise(standardizeTimeStampUdf(col(s.field), lit(s.sourceFormat), lit(targetTimestampFormat), lit("Australia/Melbourne"))))
      }})
    } else validDf

    val cleanDf = standardizedDf.filter(fieldsToStandardize.map(s => s"(${s.field} IS NULL OR (${s.field}utcdttm != 'UNPARSABLE' AND ${s.field}mltdttm != 'UNPARSABLE'))").mkString(" AND "))

    val selectDfCount = selectDf.count
    val validDfCount = validDf.count
    val cleanDfCount = cleanDf.count

    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Record count post flattening and pivoting: ${selectDfCount}")
    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - ${odateList.min} to ${odateList.max} - Record count post cleanup of malformed events: ${validDfCount}")
    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - ${odateList.min} to ${odateList.max} - Record count post cleanup of events with standardization issues: ${cleanDfCount}")

    if(selectDfCount != validDfCount){
      logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - ${odateList.min} to ${odateList.max} - ${selectDfCount - validDfCount} records couldn't be parsed. Treating them as errors")
      val malformedErrorDf = selectDf.filter(mandatoryFields.map(_.toLowerCase).distinct.map(f => s"${f} IS NULL").mkString(" OR "))
        .select(lit(null).cast(IntegerType).alias("jobinstanceid"),
          lit(tgtName).alias("tablename"),
          $"ingestiondate",
          lit(s"Event couldn't be parsed").alias("error_reason"),
          $"rawevent".alias("malformedevent"),
          current_timestamp().alias("createdtimestamp"))

      logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Writing malformedErrorDf to dbfs..")
      writeToDbricks(malformedErrorDf, histDbName, errorTableName, errorPath, List("ingestiondate","tablename"), "create", fs, spark)
    }

    if(validDfCount != cleanDfCount){
      logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - ${validDfCount - cleanDfCount} records have timestamp standardization issues. Treating them as errors")

      val stdErrorFilter =  fieldsToStandardize.map(s => s"""(${s.field}utcdttm = 'UNPARSABLE'
                            OR ${s.field}mltdttm = 'UNPARSABLE'
                            OR (${s.field} IS NOT NULL AND ${s.field}utcdttm IS NULL)
                            OR (${s.field} IS NOT NULL AND ${s.field}mltdttm IS NULL))""").mkString(" OR ")

      val stdErrorDf = standardizedDf.filter(stdErrorFilter)
        .select(lit(null).cast(IntegerType).alias("jobinstanceid"),
          lit(tgtName).alias("tablename"),
          $"ingestiondate",
          lit("Field couldn't be standardized").alias("error_reason"),
          $"rawevent".alias("malformedevent"),
          current_timestamp().alias("createdtimestamp"))

      logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Writing stdErrorDf to dbfs..")
      writeToDbricks(stdErrorDf, histDbName, errorTableName, errorPath, List("ingestiondate","tablename"), "create", fs, spark)
    }

    //  val errorDf = stdErrorDf.union(malformedErrorDf).persist
    //  val errorDfCount = errorDf.count

    // validate if any records are dropped
    //  if(selectDfCount != cleanDfCount) {
    //    logWarning(s"[APP_LOG] - Total Error Records - ${errorDfCount}. Unparsable Error Records - ${selectDfCount - validDfCount}. Standardization Error Records - ${validDfCount - cleanDfCount}.")
    //  }

    //Add prtnkey col to get partiton col in sqldw table when using polybase
    val partitionedDf = tgtPartitionCols.foldLeft(cleanDf)((df, c) => {
        df.withColumn(s"${c.toLowerCase}prtnkey",$"${c}" )
      })
    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Added prtnkey columns.")

    // for each timestamp column in standardize section
    val timestampColDf = if(fieldsToStandardize.nonEmpty) {
      fieldsToStandardize.foldLeft(partitionedDf)((df, s) => {
        df.withColumn(s"${s.field}mltdttm", col(s"${s.field}mltdttm").cast(TimestampType))
          .withColumn(s"${s.field}utcdttm", col(s"${s.field}utcdttm").cast(TimestampType))
          .withColumn(s"${s.field}", from_utc_timestamp(col(s"${s.field}utcdttm"), s"${s.sourceTimezone}"))
      })
    } else partitionedDf

    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Casted mltdttm cols to timestamp type")

    // add hashCol and effectiveDttm cols
    val auditColDf = timestampColDf.selectExpr(
                      "*"
                    , "0 AS fileid"
                    , "0 AS filelinenumber"
                    , "0 AS inserttaskid"
                    , "0 AS updatetaskid"
                    , "from_utc_timestamp(date_trunc('second', now()), 'Australia/Melbourne') AS publicationstartdttm"
                    , "to_timestamp('9999-12-31 23:59:59','yyyy-MM-dd HH:mm:ss') AS publicationenddttm"
                    , s"'${flattenConfig.scope.ssuCharacter.toUpperCase}' AS ssutypecode"
                    , s"to_timestamp(${fieldAsEffectiveDttm}mltdttm, 'yyyy-MM-dd HH:mm:ss') as effectivestartmltdttm"
                    , "to_timestamp('9999-12-31 23:59:59', 'yyyy-MM-dd HH:mm:ss') as effectiveendmltdttm"
                    , s"to_timestamp(${fieldAsEffectiveDttm}utcdttm, 'yyyy-MM-dd HH:mm:ss') as effectivestartutcdttm"
                    , "to_timestamp('9999-12-31 23:59:59', 'yyyy-MM-dd HH:mm:ss') as effectiveendutcdttm"
                    , s"date_trunc('day', to_timestamp(${fieldAsEffectiveDttm}mltdttm, 'yyyy-MM-dd HH:mm:ss')) as effectivestartmltdt"
                    , "date_trunc('day', to_timestamp('9999-12-31 23:59:59', 'yyyy-MM-dd HH:mm:ss')) as effectiveendmltdt"
                  )

    val orderSelectList =  List(/* Primary Key - must be first columns defined */
      // Business Start & End UTC Dttm*/
        "EffectiveStartUTCDttm"
      , "EffectiveEndUTCDttm"
      // Business Start & End MLTD Dttm*/
      , "EffectiveStartMLTDttm"
      , "EffectiveEndMLTDttm"
      // Business Start & End Dt*/
      , "EffectiveStartMLTDt"
      , "EffectiveEndMLTDt") ++
      // Select list
    selectList ++
      // UTC and MLT Timestamps
    {if(fieldsToStandardize.nonEmpty) fieldsToStandardize.flatMap(s => List(s"${s.field}UTCDttm", s"${s.field}MLTDttm")) else List()} ++
      //Audit Columns
    List(
        "FileId"
      , "FileLineNumber"
      , "InsertTaskId"
      , "UpdateTaskId"
      , "PublicationStartDttm"
      , "PublicationEndDttm"
      // SSU Columns
      , "SSUTypeCode")  ++
    // PartitionCols
    tgtPartitionCols.map(p => s"${p}prtnkey")

    val orderedDf = auditColDf.selectExpr(orderSelectList:_*)

    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Added dummy Audit cols for consistency")

    /*"""CAST(HASH(CONCAT_WS('|'
        , COALESCE(CAST(eventname  AS STRING),'')
        , COALESCE(CAST(ingestiondate  AS STRING),'')
        , CAST(ROW_NUMBER() OVER (PARTITION by eventname, ingestiondate ORDER BY NULL) AS STRING)
        )) AS STRING) as hashId"""*/

    // Rename fields as per conf
    // TO DO: Verify if columns in conf are present in dataframe
    val renamedDf = if(fieldsToRename.nonEmpty) {
      fieldsToRename.foldLeft(orderedDf)((df, s) => {
        df.withColumnRenamed(s.from, s.to)
      })
    } else orderedDf

    // remove column prefixes and drop rawevent
    val finalDf = removeColumnPrefix(renamedDf, prefixesToRemove.map(c => c +"_")).drop("rawevent")

    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Removed column prefixes and dropped rawevent column")

    odateList.foreach( odate => {
      logInfo(s"[APP_LOG] - Clearing target partition for $odate")
      cleanupAdls(s"${tgtTablePath}/ingestiondateprtnkey=${odate}/", fs)
    })

    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Writing finalDf to dbfs..")
    writeToDbricks(finalDf, histDbName, tgtName, tgtTablePath, tgtPartitionCols.map(_.toLowerCase + "prtnkey"), "drop_and_create", fs, spark)

    logInfo(s"[APP_LOG] - Batch Window - ${odateList.min} to ${odateList.max} - Flattening completed")

    // unpersist previously cached dataframe
    dedupedDf.unpersist(true)
    selectDf.unpersist(true)
  })
  logInfo(s"[APP_LOG] - Flattening completed for all dates between ${windowStart} and ${windowEnd}.")
}