package com.telstra.dna.eventflattener.config

import spray.json._

object FlattenConfigurationParser {

  object FlattenJsonProtocol extends DefaultJsonProtocol {
    implicit val scope = jsonFormat(Scope, "SourceSystem", "SSU")
    implicit val preSchemafilter = jsonFormat(PreSchemaFilter, "Field", "Value", "Group")
    implicit val flatten = jsonFormat(Flatten, "Field", "Schema")
    implicit val source = jsonFormat(Source, "Name", "Fields", "PreSchemaFilter", "PostSchemaFilter", "PostFlattenFilter", "Flatten")
    implicit val standardize = jsonFormat(Standardize, "Field", "SourceFormat", "SourceTimeZone")
    implicit val pivot = jsonFormat(Pivot, "KeyField", "ValueField", "Values")
    implicit val rename = jsonFormat(Rename, "From", "To")
    //implicit val collectArrays = jsonFormat(CollectArrays, "ArrayField", "ValueFields")
    implicit val transform = jsonFormat(Transform, "FieldsToSelect", "FieldsToDrop", "FieldsAsString", "FieldsAsIs", // "FieldsToCollect",
                                                  "FieldsToStandardize", "FieldsToPivot", "FieldsToRename", "MandatoryFields",
                                                  "FieldAsEffectiveDttm", "PrefixesToRemove")
    implicit val target = jsonFormat(Target, "Name", "PartitionBy", "Transform")
    implicit val main = jsonFormat(FlattenConfiguration, "Scope", "Source", "Target")
  }

  import FlattenJsonProtocol._
  @throws(classOf[JsonParser.ParsingException])
  @throws(classOf[DeserializationException])
  @throws(classOf[IllegalArgumentException])
  def parse(json: String): FlattenConfiguration = {
    json.parseJson.convertTo[FlattenConfiguration]
  }
}