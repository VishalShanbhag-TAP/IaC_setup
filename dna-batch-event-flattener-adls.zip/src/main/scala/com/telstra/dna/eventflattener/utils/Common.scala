package com.telstra.dna.eventflattener.utils

import java.io.IOException
import java.time.{LocalDate, LocalDateTime, OffsetDateTime, ZoneId, ZonedDateTime}
import java.time.format.DateTimeFormatter
import com.telstra.dna.eventflattener.config._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.permission.{FsAction, FsPermission}
import org.apache.hadoop.fs.{FileStatus, FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import org.apache.spark.sql.catalyst.parser.LegacyTypeStringParser
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.util.Try

trait Common extends SparkUtils {

  def flattenDataframe(df: DataFrame, fieldsToDrop: Seq[String]=List(), fieldsToCast: Seq[String]=List(), fieldsAsIs: Seq[String]=List()): DataFrame = {
    val fields = df.schema.fields
    val fieldNames = fields.map(x => x.name)

    for(i <- fields.indices){
      val field = fields(i)
      val fieldtype = field.dataType
      val fieldName = field.name
      fieldtype match {
        case arrayType: ArrayType if(fieldsAsIs.contains(fieldName)) =>  Array(col(fieldName))
        case arrayType: ArrayType if(!fieldsAsIs.contains(fieldName))=>
          val fieldNamesExcludingArray = fieldNames.filter(_!=fieldName)
          val fieldNamesPostDrop = fieldNamesExcludingArray.filter(f => !fieldsToDrop.contains(f))
          val fieldNamesAndExplode = fieldNamesPostDrop ++ Array(s"posexplode_outer($fieldName) as (${fieldName}_idx, $fieldName)")
          val explodedDf = df.selectExpr(fieldNamesAndExplode:_*)
          return flattenDataframe(explodedDf, fieldsToDrop, fieldsToCast, fieldsAsIs)
        case structType: StructType if(fieldsAsIs.contains(fieldName)) => struct(col(fieldName))
        case structType: StructType if(!fieldsAsIs.contains(fieldName)) =>
          logInfo(s"[APP_LOG] - Expanding field: " + fieldName + ": \n==========================")
          val regex = "[^A-Za-z0-9]".r
          val childFieldnames = structType.fieldNames.map(childname => fieldName +"."+ childname)
          logInfo(s"[APP_LOG] - Child fields of " + fieldName + ": \n==========================\n" + childFieldnames.mkString(", ") + "\n")
          val newfieldNames = fieldNames.filter(_!= fieldName) ++ childFieldnames
          val fieldNamesPostDrop = newfieldNames.filter(f => !fieldsToDrop.contains(f))
          logInfo(s"[APP_LOG] - fieldNamesPostDrop for " + fieldName + ": \n==========================\n" + fieldNamesPostDrop.mkString(", ") + "\n")
          //val asIsCols = fieldNamesPostDrop.filter(f => !fieldsToCast.contains(f)).map(x => col(x).as(regex.replaceAllIn(x, "").replaceAll("_", "").toLowerCase))
          val asIsCols = fieldNamesPostDrop.filter(f => !fieldsToCast.contains(f)).map(x => col(x).as(regex.replaceAllIn(x, "_")))
          logInfo(s"[APP_LOG] - asIsCols for " + fieldName + ": \n==========================\n" + asIsCols.mkString(", ") + "\n")
          //val castedCols = fieldNamesPostDrop.filter(f => fieldsToCast.contains(f)).map(x => to_json(col(x)).as(regex.replaceAllIn(x, "").replaceAll("", "").toLowerCase))
          val castedCols = fieldNamesPostDrop.filter(f => fieldsToCast.contains(f)).map(x => to_json(col(x)).as(regex.replaceAllIn(x, "_").replaceAll("__", "_")))
          logInfo(s"[APP_LOG] - castedCols for " + fieldName + ": \n==========================\n" + castedCols.mkString(", ") + "\n")
          val explodedf = df.select({asIsCols ++ castedCols} :_ *)
          return flattenDataframe(explodedf, fieldsToDrop, fieldsToCast, fieldsAsIs)
        case _ =>
      }
    }
    df
  }

  def pivotDataframe(inputDf: DataFrame, pivotList: List[Pivot]): DataFrame = {

    pivotList match {
      case Nil => inputDf
      case p::tail => {
        val df = inputDf.drop(pivotList.map(f => s"${f.keyField.toLowerCase.split("_").dropRight(1).mkString("_")}_idx"):_*)
        val gKeys = df.columns.filter(x => !List(p.keyField.toLowerCase, p.valueField.toLowerCase).contains(x))
        val pivDf = df.select({List(lower(col(p.keyField.toLowerCase)).alias(p.keyField.toLowerCase), col(p.valueField.toLowerCase)) ++ gKeys.map(col)} :_*)
          .groupBy(gKeys.map(col):_*)
          .pivot(p.keyField.toLowerCase, p.values)
          .agg(first(p.valueField.toLowerCase))

        val dropColDf = pivDf.select(pivDf.columns.map(x => col(x).cast(StringType).alias(x.toLowerCase)) :_*)
          .drop(p.keyField.toLowerCase, p.valueField.toLowerCase)

        val pivColsToRename = p.values.map(v => (v.toLowerCase, s"${p.keyField.toLowerCase}_${v}"))
        val pivRenamedDf = pivColsToRename.foldLeft(dropColDf)((df, f) => {
          df.withColumnRenamed(f._1, f._2)
        })
        /*val pivColsToRename = dropColDf.columns.filter(x => !gKeys.contains(x)).map(v => (v, s"${p.keyField.toLowerCase}_${v}"))
        val pivRenamedDf = pivColsToRename.foldLeft(dropColDf)((df, f) => {
          df.withColumnRenamed(f._1, f._2)
        })*/

        pivotDataframe(pivRenamedDf, tail)
      }
    }
  }

  final def removeColumnPrefix(df: DataFrame, prefix: List[String]): DataFrame = {
    prefix match {
      case Nil => df
      case head::tail => {
        logInfo(s"[APP_LOG] - Removing prefix: $head" )
        removeColumnPrefix(df.select(df.columns.map(x => col(x).alias(x.replace(head, ""))) :_*), tail)
      }
    }
  }

  def standardizeTimestamp(inputStr: String, inputFormat: String, outputFormat: String = "yyyy-MM-dd HH:mm:ss", outputTimezone: String = "Australia/Sydney"): String = {
    val formats = List(inputFormat) ++ List("yyyy-MM-dd HH:mm:ss.SSSZ", "yyyy-MM-dd HH:mm:ss.SSSSSS", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm:ss.SSSzzzz", "yyyy-MM-dd'T'HH:mm:sszzzz",
      "yyyy-MM-dd'T'HH:mm:ss z", "yyyy-MM-dd'T'HH:mm:ssz", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HHmmss.SSSz",
      "yyyy-MM-dd'T'HH:mm:ss.SSSZ","yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX","yyyyMMdd'T'HHmmssXXX",
      "yyyyMMdd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss.SSSSSSXXX", "yyyyMMdd'T'HHmmssZ", "yyyy-MM-dd'T'H:mm:ssXXX",
      "yyyy-MM-dd","yyyy-MM-dd'T'HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS","yyyy-MM-dd'T'HH:mm:ss.SS","dd/MM/yyyy' 'HH:mm:ss","dd/MM/yyyy")

    val dateTimeFormats = formats.map(p => (p, DateTimeFormatter.ofPattern(p)))
    val outputDateTimeFormat = DateTimeFormatter.ofPattern(outputFormat)

    val trimmedDate = inputStr.trim
    val eventDateTime = dateTimeFormats.toStream.map { case (pattern, fmt) =>
      Try(OffsetDateTime.parse(trimmedDate, fmt).atZoneSameInstant(ZoneId.of(outputTimezone)))
        .orElse(Try(LocalDateTime.parse(trimmedDate, fmt).atZone(ZoneId.of(outputTimezone)))
                .orElse(Try(LocalDate.parse(trimmedDate, fmt).atTime(0, 0, 0))))
    }.filter(_.isSuccess).lastOption.map( t => outputDateTimeFormat.format(t.get))
    eventDateTime match {
      case Some(dateTime) => dateTime
      case None => "UNPARSABLE"
    }
  }

  def ssuFolderName(ssu: String) : String = ssu match {
    case "retail" => "retail"
    case "wholesale" => "wholesale"
    case "transient" => "transient"
    case "enterprise" => "reference"
  }

  def getColumnDefinitions(schema: StructType) = {
    schema.fields.map { x => x.name.toLowerCase -> (x.dataType match {
      case StringType => "string"
      case IntegerType => "int"
      case LongType => "bigint"
      case DoubleType => "double"
      case DateType => "date"
      case FloatType => "float"
      case TimestampType => "timestamp"
      case BooleanType => "boolean"
      case ArrayType(DoubleType, true) => "array<double>"
      case ArrayType(LongType, true) => "array<long>"
      case ArrayType(FloatType, true) => "array<float>"
      case ArrayType(IntegerType, true) => "array<int>"
      case ArrayType(StringType, true) => "array<string>"
      case x: DecimalType => s"decimal(${x.precision},${x.scale})"
    }) }
  }

  private def createOrReplaceDbricksTable(df: DataFrame, databaseName: String, tableName: String, path: String,
                                         partitionCols:List[String], ddlMode: String, spark: SparkSession): Unit = {
    //println(df.schema)
    val fields = getColumnDefinitions(df.schema)
    //val cols = fields.filterNot(f=> f._1.endsWith("prtnkey") || f._1=="tablename")

    val dropDdl = s"DROP TABLE IF EXISTS ${databaseName}.${tableName}\n"
    val createDdl = s"CREATE TABLE IF NOT EXISTS ${databaseName}.${tableName} (\n\t" +
      fields.map(f => { "`" + f._1 + "` " + f._2 }).mkString(", \n\t") +
      s"\n)\nUSING org.apache.spark.sql.parquet \n" +
      s"PARTITIONED BY (\n\t" +
      partitionCols.map(f => s"`${f}`").mkString(", \n\t") +
      s"\n)\nLOCATION '${path}'"

    ddlMode.toLowerCase match {
      case "create" => spark.sql(createDdl)
      case "drop_and_create" => {
        logInfo(s"[APP_LOG] - Dropping Table..")
        spark.sql(dropDdl)
        //println(dropDdl)
        logInfo(s"[APP_LOG] - Creating Table..")
        //println(createDdl)
        spark.sql(createDdl)
      }
      case _ => {
        require(Set("CREATE", "DROP_AND_CREATE").contains(ddlMode.toUpperCase),
          "DDL Mode can be either create or drop_and_create")
      }
    }
  }

  def writeToDbricks(df: DataFrame, databaseName: String, tableName: String, path: String,
                    partitionCols: List[String], ddlMode: String = "drop_and_create", fs: FileSystem, spark: SparkSession): Unit = {
    
    val columnsInOrder = df.columns
    val booleanCols = df.schema.fields.filter(c => c.dataType.equals(BooleanType)).map(c => c.name.toLowerCase)
    val doubleCols = df.schema.fields.filter(c => c.dataType.equals(DoubleType)).map(c => c.name.toLowerCase)
    //val timestampCols = df.schema.fields.filter(c => c.dataType.equals(TimestampType)).map(c => c.name.toLowerCase)
    val otherCols = df.schema.fields.filter(c => !(c.dataType.equals(BooleanType)
                                            //    || c.dataType.equals(TimestampType)
                                                  || c.dataType.equals(DoubleType)))
                                    .map(c => col(c.name.toLowerCase))
    val castedDf = df.select({otherCols ++ booleanCols.map(c => col(c).cast(IntegerType)) ++
                              //timestampCols.map(c => col(c).cast(StringType)) ++
                              doubleCols.map(c => col(c).cast(DecimalType(20, 5)))} :_*)

    val orderedDf = castedDf.select(columnsInOrder.map(col) :_*)

    val oldTimestampMode = orderedDf.sqlContext.getConf("spark.sql.parquet.int96AsTimestamp")
    orderedDf.sqlContext.setConf("spark.sql.parquet.int96AsTimestamp","true")

    //orderedDf.repartition(partitionCols.map(col):_*)
    orderedDf.repartition(partitionCols.map(col):_*)
      .write
      .partitionBy(partitionCols:_*)
      .mode("append")
      .format("parquet")
      .save(path)

    orderedDf.sqlContext.setConf("spark.sql.parquet.int96AsTimestamp", oldTimestampMode)

    // createOrReplaceDbricksTable(df, databaseName, tableName, path, partitionCols, ddlMode, spark)
    createOrReplaceDbricksTable(orderedDf, databaseName, tableName, path, partitionCols, ddlMode, spark)

    logInfo(s"[APP_LOG] - Setting permissions on ${path}")
    setPermissions(path, fs)

    //refreshImpala(s"${histDbName}.${errorTargetName}", impalaHost)
    logInfo(s"[APP_LOG] - Refreshing metadata for ${databaseName}.${tableName}")
    refreshTableMetadata(s"${databaseName}.${tableName}", spark)
  }

  def cleanupAdls(path: String, fs: FileSystem):Unit= {

    val filePath = fs.makeQualified(new Path(path)).toString
    fs.delete(new Path(filePath), true)

  }

  import java.time.format.DateTimeFormatter
  import java.time.LocalDate
  import java.util
  import scala.collection.JavaConversions._
  def getDateList(strStartDate: String, strEndDate: String) = {
    // List to be populated with the desired strings
    val result = new util.ArrayList[String]
    // Formatter for the desired pattern
    val formatter = DateTimeFormatter.ofPattern("yyyyMMdd")
    // Parse strings to LocalDate instances
    val startDate = LocalDate.parse(strStartDate, formatter)
    val endDate = LocalDate.parse(strEndDate, formatter)
    // Loop starting with start date until end date with a step of one day
    var date = startDate
    while ( {
      !date.isAfter(endDate)
    }) {
      result.add(date.format(formatter))
      date = date.plusDays(1)
    }
    // Return the populated list
    result.toList
  }

  def setPermissions(path: String, fs: FileSystem):Unit = {
    val filePath = fs.makeQualified(new Path(path)).toString

    if (fs.isFile(new Path(filePath))) { //filePath refers to a file
      //revert to FsAction.ALL  FsAction.READ_EXECUTE  , FsAction.READ_EXECUTE after testing
      fs.setPermission(new Path(filePath),new FsPermission(FsAction.ALL, FsAction.ALL , FsAction.ALL))
    } else { //else filePath refers to a directory
      fs.setPermission(new Path(filePath),new FsPermission(FsAction.ALL, FsAction.ALL , FsAction.ALL))
      val fileStatuses = fs.listStatus(new Path(filePath))
      fileStatuses.foreach((f: FileStatus) => {
        setPermissions(f.getPath.toString, fs)
      })
    }
  }

  def refreshTableMetadata(tableName: String, spark: SparkSession): Unit = {
    spark.sql(s"MSCK REPAIR TABLE ${tableName}")
    spark.sql(s"REFRESH TABLE ${tableName}")
  }

  def generateTriplet(fs: FileSystem, df: DataFrame, tripletFileName: String,
                      tripletPath: String, oDate: String, dataFileDelimiter: String, spark: SparkSession): Unit = {

    import spark.implicits._
    val fileName = tripletFileName + "_" + oDate + "_" + scala.util.Random.nextInt(999)
    val datFileName = fileName + ".dat"
    val ctlFileName = fileName + ".ctl"
    val eotFileName = fileName + ".eot"
    val defaultDelimiter = "|"

    // Create Dat file
    createFile(df, datFileName, tripletPath,fs,dataFileDelimiter)

    // Create Ctl file
    val extractTime = "00:00:00"
    val checksum = "0"
    val recCount = df.count.toString

    val ctlDF = Seq((recCount, oDate, extractTime, datFileName, "BIDH", checksum)).toDF
    createFile(ctlDF, ctlFileName, tripletPath,fs,defaultDelimiter)

    // Create Eot file
    val eotDF = Seq[String]().toDF()
    createFile(eotDF, eotFileName, tripletPath,fs,defaultDelimiter)

    // Create FileRegistration file
    val fileRegId = s"$oDate${scala.util.Random.nextInt(999)}"
    val regDF = Seq(fileRegId).toDF()
    val regFileName = s"$datFileName.reg"
    createFile(regDF, regFileName, tripletPath,fs,defaultDelimiter)

    logInfo(s"[APP_LOG] - Triplet ${fileName}[.dat/.ctl/.eot] with ${recCount} records generated at ${tripletPath} with fileRegId - ${fileRegId}")
  }

  def copyMerge(
                 srcFS: FileSystem, srcDir: Path,
                 dstFS: FileSystem, dstFile: Path,
                 deleteSource: Boolean, conf: Configuration
               ): Boolean = {

    if (dstFS.exists(dstFile))
      throw new IOException(s"Target $dstFile already exists")

    // Source path is expected to be a directory:
    if (srcFS.getFileStatus(srcDir).isDirectory()) {

      val outputFile = dstFS.create(dstFile)
      Try {
        srcFS
          .listStatus(srcDir)
          .sortBy(_.getPath.getName)
          .collect {
            case status if status.isFile() =>
              val inputFile = srcFS.open(status.getPath())
              Try(IOUtils.copyBytes(inputFile, outputFile, conf, false))
              inputFile.close()
          }
      }
      outputFile.close()

      if (deleteSource) srcFS.delete(srcDir, true) else true
    }
    else false
  }

  def merge(srcPath: String, dstPath: String, fs: FileSystem): Unit =  {
    val hadoopConfig = new Configuration()
    //    val hdfs = FileSystem.get(hadoopConfig)

    val hdfs = fs
    // the "true" setting deletes the source files once they are merged into the new output
    copyMerge(hdfs, new Path(srcPath), hdfs, new Path(dstPath), true, hadoopConfig)
  }

  def createFile(df: DataFrame, fileName: String, tripletPath: String,fs : FileSystem, delimiter: String): Unit = {

    logInfo(s"[APP_LOG] - Delimiter ${delimiter} is used for file ${fileName}")
    val tempPath = tripletPath + "/temp_" + fileName
    val mergedFileName = tripletPath + "/" + fileName
    df.repartition(1)
      .write
      .option("sep",delimiter.trim)
      .option("timestampFormat","yyyy-MM-dd HH:mm:ss")
      .option("nullValue", null)
      .csv(tempPath)

    merge(tempPath, mergedFileName,fs)
  }

}

