package com.telstra.dna.eventflattener.services

import com.databricks.dbutils_v1.DBUtilsHolder.dbutils

case class AKVSecrets(appId: String, 
                      appSecret: String, 
                      directoryId: String, 
                      adlsAccount: String, 
                      adlsContainer: String)

trait AzureKeyVaultService {

  def getAkvSecrets: AKVSecrets = {
    val akvKeyList = List("dna-databricks-app-id", "dna-databricks-app-secret", "dna-directory-id",
    "dcore-adls-account", "dcore-adls-container")

    akvKeyList.map(k => dbutils.secrets.get(scope = "dna-akv-scope", key = k)) match {

      case List(a, b, c, d, e) => AKVSecrets(a, b, c, d, e)
      case _  => throw new IllegalArgumentException(s"Unknown key vaults key specified")

    }
  }
}