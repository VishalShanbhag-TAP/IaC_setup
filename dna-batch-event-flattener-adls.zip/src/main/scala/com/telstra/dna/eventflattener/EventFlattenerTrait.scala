package com.telstra.dna.eventflattener

import com.telstra.dna.eventflattener.config.{FlattenConfiguration, FlattenConfigurationParser}

import scala.io.Source
import com.telstra.dna.eventflattener.services.{AKVSecrets, AzureKeyVaultService}
import org.apache.spark.internal.Logging

import org.apache.spark.sql.types._

trait EventFlattenerTrait extends Logging with AzureKeyVaultService with App {

  lazy val env = args(0).toLowerCase
  
  lazy val dataSource = args(1).toLowerCase

  lazy val dataSet = args(2).toLowerCase

  lazy val windowStart = args(3)

  lazy val windowEnd = args(4)

  lazy val batchSize = args(5)

  lazy val flattenConfig: FlattenConfiguration =
    FlattenConfigurationParser.parse(Source.fromFile(s"/dbfs/app_meta/${env.toUpperCase}/config/${dataSource}/${dataSet}.flatten.config.json").mkString)

  lazy val akvSecrets: AKVSecrets = getAkvSecrets
  lazy val mountPath = s"/mnt/bidh"
  lazy val adlsDir = s"""abfss://${akvSecrets.adlsContainer}@${akvSecrets.adlsAccount}.dfs.core.windows.net"""

}
