package com.telstra.dna.eventflattener.config

case class Scope(
                  sourceSystem: String,
                  ssu: String
                ){
  require(Set("RETAIL", "WHOLESALE", "TRANSIENT", "ENTERPRISE", "CORPORATE").contains(ssu.toUpperCase),
    "SSU can be one of: Retail, Wholesale, Transient, Enterprise, Corporate")

  val ssuCharacter: String = ssu.toLowerCase.take(1)
  
}

case class PreSchemaFilter(
                            field: String,
                            value: List[String],
                            filterGroup: String
                          )

case class Flatten(
                    field: String,
                    schema: String
                  )                 

case class Source(
                   name: String,
                   fields: List[String],
                   preSchemaFilter: List[PreSchemaFilter],
                   postSchemaFilter: Option[String],
                   postFlattenFilter: Option[String],
                   flatten: Flatten
                 )

case class Standardize(
                        field: String,
                        sourceFormat: String,
                        sourceTimezone: String
                      )

case class Pivot(
                  keyField: String,
                  valueField: String,
                  values: List[String]
                )

case class Rename(
                   from: String,
                   to: String
                 )

case class Transform(
                      fieldsToSelect: Array[String],
                      fieldsToDrop: Option[Array[String]],
                      fieldsAsString: Option[Array[String]],
                      fieldsAsIs: Option[Array[String]],
                      fieldsToStandardize: Option[Array[Standardize]],
                      fieldsToPivot: Option[Array[Pivot]],
                      fieldsToRename: Option[Array[Rename]],
                      mandatoryFields: Option[Array[String]],
                      fieldAsEffectiveDttm: String,
                      prefixesToRemove: List[String]
                    )

case class Target(
                   name: String,
                   partitionBy: List[String],
                   transform: Transform
                 )

case class FlattenConfiguration(
                                       scope: Scope,
                                       source: Source,
                                       target: Target
                                     )

