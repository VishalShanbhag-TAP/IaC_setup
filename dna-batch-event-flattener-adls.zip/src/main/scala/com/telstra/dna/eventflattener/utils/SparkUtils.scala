package com.telstra.dna.eventflattener.utils

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import java.net.URI

import com.telstra.dna.eventflattener.EventFlattenerTrait
import org.apache.spark.internal.Logging
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf
import com.databricks.dbutils_v1.DBUtilsHolder.dbutils

/**
 * Trait that provides the management of a SparkSession
 */

trait SparkUtils extends Logging with EventFlattenerTrait {

  @transient private var _sparkSession: SparkSession = _
  @transient private var _fileSystem: FileSystem = _

  /**
   * Returns a single accessible SparkSession
   * @return Spark session
   */
  def getSparkSession(): SparkSession = {

    val conf = new SparkConf()
    conf.setMaster("local").setAppName(flattenConfig.source.name)
    conf.set("fs.azure.account.auth.type."+akvSecrets.adlsAccount+".dfs.core.windows.net", "OAuth")
    conf.set("fs.azure.account.oauth.provider.type."+akvSecrets.adlsAccount+".dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    conf.set("fs.azure.account.oauth2.client.id."+akvSecrets.adlsAccount+".dfs.core.windows.net",akvSecrets.appId)
    conf.set("fs.azure.account.oauth2.client.secret."+akvSecrets.adlsAccount+".dfs.core.windows.net", akvSecrets.appSecret)
    conf.set("fs.azure.account.oauth2.client.endpoint."+akvSecrets.adlsAccount+".dfs.core.windows.net", s"https://login.microsoftonline.com/${akvSecrets.directoryId}/oauth2/token")
    conf.set("hive.exec.dynamic.partition", "true")
    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    conf.set("hive.exec.max.dynamic.partitions", "5000")
    conf.set("spark.sql.shuffle.partitions", "200")
//    conf.set("spark.sql.session.timeZone", "Australia/Melbourne")

    _sparkSession = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()

    logInfo(s"Created new Spark session")

    sparkSession
  }

  def getFs(spark: SparkSession): FileSystem = {

    val conf = new Configuration(spark.sparkContext.hadoopConfiguration)
    _fileSystem = FileSystem.get(new URI(mountPath), conf)
 
    logInfo(s"FS object created")

    fileSystem
  }

  def mountAdls(): String = {

    val config = Map(
      "fs.azure.account.auth.type" -> "OAuth",
      "fs.azure.account.oauth.provider.type" -> "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
      "fs.azure.account.oauth2.client.id" -> akvSecrets.appId,
      "fs.azure.account.oauth2.client.secret" -> akvSecrets.appSecret,
      "fs.azure.account.oauth2.client.endpoint" -> s"""https://login.microsoftonline.com/${akvSecrets.directoryId}/oauth2/token"""
    )

    if (!dbutils.fs.mounts.map(mnt => mnt.mountPoint).contains(mountPath)) {
      
      logInfo(s"[APP_LOG] - Mounting ${adlsDir} as ${mountPath} for the first time..")
        
      dbutils.fs.mount(
        source = adlsDir,
        mountPoint = mountPath,
        extraConfigs = config)
    } else {
      logInfo(s"[APP_LOG] - Mount path: ${mountPath} exists already..")
    } 
    mountPath
  }

  def sparkSession: SparkSession = _sparkSession
  def fileSystem: FileSystem = _fileSystem
}
