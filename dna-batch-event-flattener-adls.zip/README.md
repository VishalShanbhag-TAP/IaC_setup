# Generic Event Flattening Framework

This is a spark based configuration driven framework that flattens json events and pivots key-value pairs in events as columns and rows. It uses attached sample config json to query raw_events_compacted table and does filtering of events, flattening of events by applying schema, pivoting of key-value pairs, deduping, standardizing timestamps, selecting required fields and finally writing to a partitioned external table on HDFS.

### Step 1: Filtering RawEventsCompacted to pick right set of records:

Using Filters section in config json, we specify filters to apply on raw_events_compacted table. We also filter data for the given date for which the job is running, generally passed via control-m to jof then to application. Because Control-M jobs for tomorrow are ordered today and as all our jobs run in the early hours, when we pick events, we pick for the previous oDATE instead of oDATE.

Ex: Job running on Nov 1st at 2 AM will have ODATE as 20191101 and we query data for 20191031 from raw layer.

For receipts, eventKey is not mandatory. So we specify below in config

**"Filters": [**
    **{**
     **"Field": "eventpublisher",**
     **"Value": [**
      **"Receipts"**
     **],**
     **"Group": "A"**
    **},**
    **{**
     **"Field": "eventname",**
     **"Value": [**
      **"Receipt_Generated_success"**
     **],**
     **"Group": "A"**
    **}**
   **]**

For payments, it would be something like below -

**"Filters": [**
    **{**
     **"Field": "eventpublisher",**
     **"Value": [**
      **"paymentengine"**
     **],**
     **"Group": "A"**
    **},**
    **{**
     **"Field": "eventkey",**
     **"Value": [**
      **"payments.lifecyclemanagement.create.success.v1.event"**
     **],**
     **"Group": "A"**
    **},**
    **{**
     **"Field": "eventname",**
     **"Value": [**
      **"payment agreement registered"**
     **],**
     **"Group": "A"**
    **},**
    **{**
     **"Field": "eventpublisher",**
     **"Value": [**
      **"paymentengine"**
     **],**
     **"Group": "B"**
    **},**
    **{**
     **"Field": "eventkey",**
     **"Value": [**
      **"payments.lifecyclemanagement.modify.success.v1.event"**
     **],**
     **"Group": "B"**
    **},**
    **{**
     **"Field": "eventname",**
     **"Value": [**
      **"payment agreement status updated"**
     **],**
     **"Group": "B"**
    **}**
   **]**

**Few points to note reg filters:**

1. Filters is a json array abject, so you can specify any     number of filters. 
2. Each filter struct has 3 things - *Field*, *Value*,     and *Group*. Field is the column name you would like to filter on     and value is an array of values to used in IN clause. Filters are arranged     in groups. Filters of same group are ANDed and filters from different     groups are ORed.
        Ex; the above filter array would generate - 
        **(**
        **LOWER(eventpublisher) IN ('paymentengine') AND LOWER(eventkey) IN     ('payments.lifecyclemanagement.create.success.v1.event') AND     LOWER(eventname) IN (payment agreement registered)**
        **) OR** 
        **(****
        \**LOWER(eventpublisher) IN ('paymentengine') AND LOWER(eventkey) IN     ('payments.lifecyclemanagement.modify.success.v1.event') AND     LOWER(eventname) IN (payment agreement status updated)\****
        **)**

### Step 2: Removal of duplicates - exact payloads

All of DNA eventing systems use "**atleast once**" semantics. So they are instances when a same payload can ingested into the raw layer multiple times on a same day at multiple times or even on multiple days

To overcome this, the flattening app deduplicates by grouping on rawevent and picking the earliest record.

```
 // deduplicate events introduced by sparkstreaming/flume
  val windowSpec = Window.partitionBy($"rawevent").orderBy($"ingestiontimestamp".asc)
  val dedupedDf = eventDf.withColumn("row_id" , row_number().over(windowSpec))
    .filter('row_id === 1)
    .drop('row_id)
    .select($"ingestiondate", $"ingestiontimestamp", $"rawevent")
```

 

The SQL equivalent of this would be

```
SELECT ingestiondate, ingestiontimestamp, rawevent 
  FROM (
        SELECT ingestiondate, ingestiontimestamp, rawevent, ROW_NUMBER() OVER (PARTITION BY rawevent ORDER BY ingestiontimestamp ASC) row_id,
        FROM eventDF
       )
 WHERE row_id = 1
```

 

This means, if we have same payload ingested at different times of a day then spark would have generated different ingestion timestamps depending on time of the day when the record is ingested. We pick the record which is ingested in the first instance. Picking first or last record from this set should not matter from business perspective as the payload is same in both cases and we are using spark generated ingestiontimestamp and not any business column. We pick the earliest because it would tell us in auditing when the record was ingested the first time.

### Step 3: Recursive Flattening Of Events

After de-duping, we the apply the schema from input json config to rawevent field and input that to flattening function. Flattening logic is as below -

Whenever the spark parser encounters

- **Simple** attribute then it     is selected
- a complex attribute like a **Struct** then     all attributes under it are expanded using dot (.) notation recursively,     i.e., if a child attribute of the struct attribute is again a struct,then     it is again expanded. This happens until all levels are expanded and only     Simple attributes are present in the dataframe
- a complex attribute like an **Array** attribute,     then it explodes the column. In spark, exploding an array column causes     new rows to be created. If the array attribute is an array of structs,     then explode cause multiple rows with the struct attribute added. Then     using above step, this struct attribute is expanded recursively.

### Step 4: Standardizing Columns (to StringType and to Lowercase)

After flattening, we standardize columns. As we are unsure of the data types because of less visibility on source event schemas, we cast all columns to string type. Also, column names in Hive/Impala are insensitive, but they are sensitive in Parquet. To overcome issues at later point and ensure consistency, names of all columns are converted to lowercase. Please see, it is not the data that is being case converted but only the field names.

### Step 5: Pivoting Key-Value Array Of Structs

In certain events, we might encounter Key-Value pair based array of structs. Recursive Explosion and Expansion of these objects causes multiple records from above . However, for Payment Model and other usecases, business is interested in supplementary data fields. So, we pivot these arrays. i.e, we make the value of key attribute as column names and value attribute as values for these key columns.

Post flattening, the output would be something like this if we have both supplementarydata and userdefined arrays

 

| **correlationId** | **data_transaction_supplementaryData_key** | **data_transaction_supplementaryData_value** | **data_transaction_lineItems_userDefined_key** | **data_transaction_lineItems_userDefined_value** |
| ----------------- | ------------------------------------------ | -------------------------------------------- | ---------------------------------------------- | ------------------------------------------------ |
| 62792273BC2F5B62  | customerId                                 | eda12252-9e1c-21f4-2095-da4cf8948047         | agreementId                                    | 12345                                            |
| 62792273BC2F5B62  | customerId                                 | eda12252-9e1c-21f4-2095-da4cf8948047         | agreementType                                  | Perm                                             |
| 62792273BC2F5B62  | paymentProfile                             | ASYNC                                        | agreementId                                    | 12345                                            |
| 62792273BC2F5B62  | paymentProfile                             | ASYNC                                        | agreementType                                  | Perm                                             |

 

After pivoting, pivot the Key and value columns and dropping the original key and value columns post pivoting it would look like

 

| **correlationId** | **data_transaction_supplementaryData_key_customerid** | **data_transaction_supplementaryData_key_paymentprofile** | **data_transaction_lineItems_userDefined_agreementid** | **data_transaction_lineItems_userDefined_agreementtype** |
| ----------------- | ----------------------------------------------------- | --------------------------------------------------------- | ------------------------------------------------------ | -------------------------------------------------------- |
| 62792273BC2F5B62  | eda12252-9e1c-21f4-2095-da4cf8948047                  | ASYNC                                                     | 12345                                                  | Perm                                                     |

### Step 6: Selecting subset of columns

We pick columns of interest only from these flattened and pivoted attributes. These columns are specified in the config json. This selection of columns can cause duplicates records because we might not be selecting the columns which make these records unique. For example, in the above sample, because of errors array, there could be two sets of rows for each error struct inside the array. Let us say the configuration didnot specify errors to be flattened, then when we selectively pick columns, rows corresponding to each error would be exactly same.

So, once we select the attributes of interest from flattened data, we then remove duplicates

This step also adds ingestiondate, ingestiontimestamp present in raw layer by default to above fields

Example:

**{**

  **"correlationId": "1fcc4b0b-a72e-4c9e-8ac9-5beb730b1b6d",**

  **"eventKey": "payments.transaction.create.failure.v1.event",**

  **"eventPublisher": "refund",**

  **"eventTimestamp": "2019-08-02T22:40:12+10:00",**

  **"eventName": "refund declined",**

  **"data": {**

​    **"transaction": {**

​      **"type": "refund",**

​      **"status": "declined",**

​      **"recurring": "false",**

​      **"merchantAccountId": "telstrabillpaymentsAUD",**

​      **"orderAmount": "500",**

​      **"orderId": "abc-visa",**

​      **"currencyIsoCode": "AUD",**

​      **"statusCode": "400215",**

​      **"statusMessage": "Payment Declined, suspected fraud",**

​      **"paymentProvider": {**

​        **"provider": "braintree",**

​        **"transactionId": "fraud1",**

​        **"transactionTimestamp": "2019-02-21T16:51:06+11:00",**

​        **"externalId": "epvad087711",**

​        **"paymentMethod": {**

​          **"type": "CREDIT_CARD",**

​          **"last4": "1511",**

​          **"cardType": "VISA",**

​          **"uniqueIdentifier": "1c649d71af539ccb139db14609e2bfa4"**

​        **}**

​      **},**

​      **"supplementaryData": [**

​        **{**

​          **"key": "externalRefundReference",**

​          **"value": "abc-visa"**

​        **},**

​        **{**

​          **"key": "channelCommonName",**

​          **"value": "svc-payment-refund-orders"**

​        **},**

​        **{**

​          **"key": "reasonCode",**

​          **"value": "PRODUCT_ADJUSTMENT"**

​        **},**

​        **{**

​          **"key": "paymentProfile",**

​          **"value": "SYNC"**

​        **}**

​      **],**

​      **"errors": [**

​        **{**

​          **"code": "5005",**

​          **"message": "fraud"**

​        **},**

​        **{**

​          **"code": "5005",**

​          **"message": "fraud2"**

​        **}**

​      **]**

​    **}**

  **}**

**}**

Here, correlationId, eventkey are examples of scalar or simple attribute, data, transaction and errors are examples of complex/composite attributes

All simple attributes are selected directly, all complex attributes are expanded and/or exploded recursively until we have only simple attributes

When flattening occurs it flattens all fields. So, it would generate a structure something like this

**correlationid,** 

**eventkey,** 

**eventname,** 

**eventpublisher,** 

**eventtimestamp,** 

**data_transaction_currencyisocode,** 

**data_transaction_merchantaccountid,** 

**data_transaction_orderamount,** 

**data_transaction_orderid,** 

**data_transaction_recurring,** 

**data_transaction_status,** 

**data_transaction_statuscode,** 

**data_transaction_statusmessage,** 

**data_transaction_type,** 

**data_transaction_paymentprovider_externalid,** 

**data_transaction_paymentprovider_provider,** 

**data_transaction_paymentprovider_transactionid,** 

**data_transaction_paymentprovider_transactiontimestamp,** 

**data_transaction_errors_code,** 

**data_transaction_errors_message,** 

**data_transaction_paymentprovider_paymentmethod_cardtype,** 

**data_transaction_paymentprovider_paymentmethod_last4,** 

**data_transaction_paymentprovider_paymentmethod_type,** 

**data_transaction_paymentprovider_paymentmethod_uniqueidentifier,** 

**data_transaction_supplementarydata_key,** 

**data_transaction_supplementarydata_value**

### Step 7: Standardizing Timestamp fields (optional)

If we specify any timestamp fields to be standardized in the config json, we then use that to standardize them. Each Standardization spec adds additional field.

**"Standardize": [** 

  **{**

​    **"Field": "data_paymentdate",**

​    **"SourceFormat": "yyyy-MM-dd'T'HH:mm:ssZ", // 2018-09-29T00:00:00.00+10:00**

​    **"TargetFormat": "yyyy-MM-dd HH:mm:ss" // 2018-09-29 00:00:00**

  **}**

**]**

 

In the above case, the framework transforms the data in the field data_paymentdate. Here, the developer is specifying to the frmaework that the format of date in this field is as in SourceFormat and it needs to be transformed into TargetFormat. We account for Timezone offsets as well.

In case, due to developers fault, if the SourceFormat doesn't match with data in that field, the framework will resort to match the data in the field with predefined formats below. If any of it matches we generate the new field with name same as source but with a suffix added - _std. Ex: for the above config, it would generate "data_paymentdate_std" as new field name

Predefined date formats the framework is capable of parsing -

**yyyy-MM-dd'T'HH:mm:ssZ**

**yyyy-MM-dd'T'HH:mm:ss.SSSzzzz**

**yyyy-MM-dd'T'HH:mm:sszzzz**

**yyyy-MM-dd'T'HH:mm:ss z**

**yyyy-MM-dd'T'HH:mm:ssz**

**yyyy-MM-dd'T'HH:mm:ss**

**yyyy-MM-dd'T'HHmmss.SSSz**

**yyyy-MM-dd'T'HH:mm:ss.SSSZ** 

**yyyy-MM-dd'T'HH:mm:ss.SSSXXX**

**yyyy-MM-dd'T'HH:mm:ssXXX**

### Step 6: Renaming ColumnNames (Optional):

the framework allows to specify any columns that need to be renamed. If any specified in the config, we would rename those columns. This is helpful if the attribute names in event are reserved/keywords in sql. Ex: timestamp attribute in receipt events.

### Step 7: Triplet Generation/External Table Creation

In the config json, we can specify, if we want Triplet or External Table. 

For receipts tactical solution, we introduced triplet generation capability. So, once triplet is generated on to HDFS, another process would read and ingest that file into KUDU.

But for **payments**, a unified model is created and so, the capability to just insert flattened data into a hdfs partitioned external impala table is introduced. You can specify the option as below

**"Target": {**
   **"Type": "table",**
   **"Name": "payment_transaction",**

 

For extract:

 

**"Target": {**
   **"Type": "extract",**
   **"Name": "rcpts_rcpt_gen_success_tact",**

 

### Step 8: Leveraging BIDH framework to load the triplet (Not applicable if type is table)

From this step onwards, we leverage BIDH standard framework. So, this should work same way as SFDC file ingestion.

From this step on, there are 6 steps that BIDH Framework executes before loading it to Kudu.

BIDH Step 1: Confirm Interface: For each triplet, we would have already specifed the schema and datatypes etc using BIDH Schema Generator. Using that, the framework validates the data in the triplet

BIDH Step 2: Standardization: For any field that is marked as timestamp, BIDH framework generates few MLT and UTC columns.

BIDH Step 3 & 4: These two steps are for generation of LightKeys and Integration keywords

BIDH Step 5: Change Data Capture: Framework will now read active records from history and reads incoming records and identifies any changes to rows based on Change Key columns.

It also uses business timestamp column specified in config to use as effective start datetime

BIDH Step 6: Using the changeset from step 5, insertion of new and updated records and updation of old records' effectiveenddttm happens

 

**Code Location:**

**As of today code resides in bidh repo in gitlab. under bidh → inbound → dna → src**

**https://dev.azure.com/DataCore-Telstra/DataAnalytics/_git/dna-batch-event-flattener-adls/**

 

 